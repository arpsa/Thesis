function [y, phi, g, uu, yy] = SimModel(u, y0, Modifiers, Parameters, fsolve_options, Scenario)

% 1) Compute the steady-state, i.e. where dy = 0.
y_temp2 = fsolve(@(y_temp) ModelDyn(0, y_temp, u, Parameters, Modifiers, Scenario), y0, fsolve_options);
% 2) Get the values of the plant at this steady-state
[~, y, g, phi, uu, yy] = ModelDyn(0, y_temp2, u, Parameters, Modifiers, Scenario);
end