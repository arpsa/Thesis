
clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic
%% Code architecture initialization & Output files 
addpath('Functions')
addpath('Plant')
addpath('Model')
Results_file_name = 'Results';

%% Tuning paramters
Ko      = 0.4; % Filtre optimale pour le cas contrain
NBiter  = 61;  % Simulation iterations number
Theta_P = Parameters('Plant');    % Parameters of the plant
Theta_M = Parameters('Mismatch'); % Parameters of the model
Scenario = struct();
    Scenario.Constraints = 1; % 0: unconstrained PB; 1: constrained PB 

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  0.- Initialization of the algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 0.1.- Boundaries on the inputs
    u_max  = [4.5*3600; 11*3600; 105+273.15];
    u_min  = [3*3600;   8*3600; 80+273.15];
% 0.2.- Scaling the probleme so that it works with variables in [0,1]
    inv_A_us = diag(u_max-u_min);
    A_us = inv(diag(u_max-u_min));
    b_u  = u_min;
% 0.3.- Solver's parameters
    PBstruct = ProblemStructure(); % options for solver | nb iterations
    fsolve_options  = PBstruct.fsolve_options;
    fmincon_options = PBstruct.fmincon_options;
% 0.4.- Initialisation for the simulations
    % For the plant:
    y0_p = [0.1302; 0.4188; 0.0224; 0.0800; 0.0984; 0.1302; 0.4188; 0.0224; 0.0984];
    u0_p = [ 1.3890e+004; 3.3491e+004; 364.2712]; % opt
    % For the model:
    y0  = [0.1302; 0.4188; 0.0224; 0.0800; 0.0984; 0.1302; 0.4188; 0.0984];
    u0  = [4*3600; 9.5*3600; 91+273.15];
    u0s =  A_us *(u0-b_u);
% 0.5.- Structures
    Results   = struct(); % For the exit file
    Modifiers = struct(); % To update teh model
        Modifiers.type = 'none';
% 0.6.- Parameters for the computation of derivatives:
    delta_P = [1e-7, 1e-7, 1e-6]; % For the plant.
    delta_M = [1e-7, 1e-7, 1e-6]; % For the model.

    
%% Algorithm: 
Modifiers.type = 'none'; % Don't use modifiers to find the first operating 
                         % point (you don't have data to do so)
uy0s = [u0s; y0]; 
uy_s_opt = RunOptimization(uy0s, Theta_M, inv_A_us, b_u, Modifiers, Scenario, fmincon_options);
u0_opt_s = uy_s_opt(1:3);             % scaled model optimum
uk{1} = inv_A_us*uy_s_opt(1:3) + b_u; % UNscaled model optimum
uk_s_last_faisable = u0_opt_s; 
    
for Type =  2 % 1: direct, 2: Indirect
    for Methode = 2 % 1:MFCA; 2:KMFCA;  3:KMA
        for k = 1:NBiter
            if k <= 30 
                Scenario.Constraints = 1;
            else
                Scenario.Constraints = 0;
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
            % 1.0.- Current SCALED state & gradients of the plant
            uk_s{k}  = A_us *(uk{k}-b_u);
            Modifiers.type = 'none';
            Plant_derivatives = derivatives_P(uk_s{k}, uk{k}, delta_P, Theta_P,  A_us, b_u, y0_p, Modifiers, fsolve_options, Scenario);
                phipk{k} = Plant_derivatives.phik;
                gpk{k}   = Plant_derivatives.gk;
                ypk{k}   = Plant_derivatives.yk;
                if gpk{k} <= 0
                    uk_s_last_faisable = uk_s{k}; 
                end
            Model_derivatives = derivatives_M(uk_s{k}, uk{k}, delta_M, Theta_M, A_us, b_u, y0,    Modifiers, fsolve_options, Scenario);
            %     [A,B] = eig(Model_derivatives.Hu_phik)
            % 2.0.- Compute the modifiers
            if Type == 1
                Modifiers.type = 'MA'; 
                Modifiers.epsilon_phi_k = (Plant_derivatives.phik     - Model_derivatives.phik);
                Modifiers.lambda_phi_k  = (Plant_derivatives.dphik_du - Model_derivatives.dphik_du);
                Modifiers.epsilon_g_k   = (Plant_derivatives.gk       - Model_derivatives.gk);
                Modifiers.lambda_g_k    = (Plant_derivatives.dgk_du   - Model_derivatives.dgk_du); 
            else % Method == 2
                Modifiers.type = 'MAy'; 
                Modifiers.epsilon_y_k = Plant_derivatives.yk      - Model_derivatives.yk;
                Modifiers.lambda_y_k  = (Plant_derivatives.dyk_du - Model_derivatives.dyk_du);
            end 

            Modifiers.uk = uk{k};
            Model_derivatives = derivatives_M(uk_s{k}, uk{k}, delta_M, Theta_M, A_us, b_u, y0,    Modifiers, fsolve_options, Scenario);
            [A,B] = eig(Model_derivatives.Hu_phik);
            A = real(A); B = real(B);
            C = zeros(3,3);
            D = zeros(3,3);
            if min(real(eig(Model_derivatives.Hu_phik))) < 0
                disp(['Cost convexified, et min(eig(Hphi)) = ', num2str(min(eig(Model_derivatives.Hu_phik))) ])
            end
        %     delta = max(eig(Model_derivatives.Hu_phik))/10; % take the highest eigenvalue
        %     delta = max(0.1,delta);                      % to make it >0 if it is not
            for i = 1:3 % (n_u=3)
                if real(B(i,i)) <= 0
                    D(i,i) = -real(B(i,i)) + 0.0001;
                end
            end
            HPHIc = A*D*A';
            % To linearize constraintes
            Modifiers.g_k   = Plant_derivatives.gk;
            Modifiers.dg_k  = Plant_derivatives.dgk_du;
            Modifiers.uk    = uk{k};
            Modifiers.HPHIc = HPHIc;
            % 3.0.- Solve the updated model; 
            % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                if  Methode == 1       % MFCA
                    for Collapse_MFCA  = 1
                        uy0_s = [uk_s_last_faisable; y0];
                        [uy_s_opt, ~, eflag] = RunOptimization_MFCA(uy0_s, Theta_M, inv_A_us, b_u, Modifiers, Scenario, fmincon_options);
                        if eflag <= 0
                            disp(['(MFCA) Solver had difficulties at k = ', num2str(k)])
                        end
                        u_opt_s{k}  = uy_s_opt(1:3);     
                        u_opt{k} = inv_A_us*uy_s_opt(1:3) + b_u;
                        if k == 1
                            KK(k) = 0.1;
                        else
                            if (max(abs(uk_s{k}-uk_s{k-1})) < 1e-4) 
                                KK(k)= KK(k-1);
                            else
                                NablaS = (uk{k}-uk{k-1})'*(u_opt{k} - u_opt{k-1}) /(norm(uk{k}-uk{k-1})^2);
                                if NablaS < 1
                                    KK(k) = max(1/(1-NablaS), 0.1);
                                else
                                    KK(k) = 1;
                                end
                            end
                        end
                        KK(k) = round(KK(k),1);
                        disp(['Kk = ',num2str(KK(k))])
                        uk{k+1} = uk{k} + KK(k)*(u_opt{k}-uk{k});
                    end
                elseif  Methode == 2  % KMFCA
                    for Collapse_KMFCA = 1
                        if k ==1 
                            if Scenario.Constraints ==  0
            %                     uy0_s = [uk_s{k} ; y0];
                                uy0_s = [uk_s_last_faisable ; y0];


            %                     uy0_s = uk_s_last_faisable; 
                            else
            %                     uy0_s = [uk_s{k} ; y0; y0];
                                uy0_s = [uk_s_last_faisable; y0; y0];
                            end
                            Modifiers.uk        = uk{k};
                            Modifiers.ukm1      = 0;
                            Modifiers.uoptkm1   = 0;
                            Modifiers.k         = k;
                            Modifiers.uk_s      = 0;
                            Modifiers.ukm1_s    = 0;
                            Modifiers.uoptkm1_s = 0;
                            Modifiers.KK_km1    = 0;
                        else
                            if Scenario.Constraints ==  0
                                uy0_s = [uk_s{k}; y0];
            %                     uy0_s = uk_s{k};
                            else
                                uy0_s = [uk_s{k}; y0; y0];
                            end
                            Modifiers.uk        = uk{k};
                            Modifiers.ukm1      = uk{k-1};
                            Modifiers.uoptkm1   = u_opt{k-1};
                            Modifiers.k         = k;
                            Modifiers.uk_s      = uk_s{k};
                            Modifiers.ukm1_s    = uk_s{k-1};
                            Modifiers.uoptkm1_s = u_opt_s{k-1};
                            Modifiers.KK_km1    = KK(k-1);
                        end

                        [uy_s_opt,~,eflag,~,~,KKK] = RunOptimization_KMFCA(uy0_s, Theta_M, inv_A_us, b_u, Modifiers, Scenario, fmincon_options);
            %             [uy_s_opt,~,eflag,~,~,KKK] = RunOptimization_KMFCA_bis(uy0_s, Theta_M, inv_A_us, b_u, Modifiers, Scenario, fmincon_options, y0,fsolve_options);
                         if eflag < 0
                            disp(['(KMFCA) Solver had difficulties at k = ', num2str(k)])
                         end
                        KK(k) = round(KKK,2);
                        u_opt_s{k} = uy_s_opt(1:3);     
                        u_opt{k} = inv_A_us*u_opt_s{k} + b_u;
            %             if k == 1
            %                 KK(k) = 0.1;
            %             else
            %                 if (max(abs(uk_s{k}-uk_s{k-1})) < 1e-4) 
            %                     KK(k)= KK(k-1);
            %                 else
            %                     NablaS = (uk{k}-uk{k-1})'*(u_opt{k} - u_opt{k-1}) /(norm(uk{k}-uk{k-1})^2);
            %                     if NablaS < 1
            %                         KK(k) = 1/(1-NablaS);
            %                     else
            %                         KK(k) = 1;
            %                     end
            %                 end
            %             end
                        disp(['Kk = ',num2str(KK(k))])
                        uk{k+1} = uk{k} + KK(k)*(u_opt{k}-uk{k});    
                    end
                end
            % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            % 4.0.-  Compute the optimum of the plant (just to compare them with the iterations)  
            uy0_s = [A_us*(uk{k+1}*0-b_u); y0_p];
            Modifiers.type = 'none';
            uyp_s_opt = RunOptimization_P(uy0_s, Theta_P, inv_A_us, b_u, Modifiers, Scenario, fmincon_options);

            u_s_opt = uyp_s_opt(1:3);
            up_opt{k} = inv_A_us*u_s_opt+b_u;
            yyp_opt = fsolve(@(y_temp) PlantDyn(0, y_temp, up_opt{k}, Theta_P, Modifiers, Scenario), y0_p, fsolve_options);
            [~, yp_opt{k}, gp_opt{k}, phip_opt{k}, ~, ~] = PlantDyn(0, yyp_opt, up_opt{k}, Theta_P, Modifiers, Scenario);
            yyp_opt_save{k} = yp_opt{k};
            
            
            Scenario_temp(k) = Scenario.Constraints;
        end
%% Save Results
    for i = 1:k
        
        Scenario_save.Constraints = 1;
        
        % Define what to save !!
        Results.uk1{Type,Methode}(i)  = uk{i}(1);
        Results.uk2{Type,Methode}(i)  = uk{i}(2);
        Results.uk3{Type,Methode}(i)  = uk{i}(3);
        Results.uk1_s{Type,Methode}(i)  = uk_s{i}(1);
        Results.uk2_s{Type,Methode}(i)  = uk_s{i}(2);
        Results.uk3_s{Type,Methode}(i)  = uk_s{i}(3);

        Results.KK{Type,Methode}(i)    = KK(i);
        Results.phipk{Type,Methode}(i) = phipk{i};
        [~,gtemp] = uy2phig(uk{i},ypk{i},1,1, Scenario_save);
        Results.gpk{Type,Methode}(i)   = gtemp;

        % Opt Point
        Results.u1_opt(i) = up_opt{i}(1);
        Results.u2_opt(i) = up_opt{i}(2);
        Results.u3_opt(i) = up_opt{i}(3);
        

        Results.phi_opt(i) = phip_opt{i};
        [~,gtemp] = uy2phig(up_opt{i},yyp_opt_save{i},1,1, Scenario_save);
        Results.g_opt(i)   = gtemp;

    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%         end
    end
end


%%
save(Results_file_name, 'Results')


%%
figure
hold on
% plot(0:NBiter-1,  Results.phipk{Type,1,scenario}/3600, 'k')
% plot(0:NBiter-1,  Results.phipk{Type,2,scenario}/3600, 'm')


% plot(0:NBiter-1,  Results.phipk{1,Methode}/3600, 'b')
plot(0:NBiter-1,  Results.phipk{2,Methode}/3600, 'k')
plot(0:NBiter-1,  Results.phi_opt/3600, 'r')
title('cost')
%%
figure
hold on
% plot(0:NBiter-1,  Results.gpk{Type,1,scenario}, 'k')
% plot(0:NBiter-1,  Results.gpk{Type,2,scenario}, 'm')

% plot(0:NBiter-1,  Results.gpk{1,Methode}, 'b')
plot(0:NBiter-1,  Results.gpk{2,Methode}, 'k')
plot(0:NBiter-1,  Results.g_opt, 'r')
title('Contrainte')
%%
figure
hold on
% plot(0:NBiter-1,  log(abs((Results.uk1{Type,1,scenario}-Results.u1_opt)/3600))/log(10), 'k')
% plot(0:NBiter-1,  log(abs((Results.uk2{Type,1,scenario}-Results.u2_opt)/3600))/log(10), 'k')
% plot(0:NBiter-1,  log(abs((Results.uk3{Type,1,scenario}-Results.u3_opt)))/log(10), 'k')
% 
% plot(0:NBiter-1,  log(abs((Results.uk1{Type,2,scenario}-Results.u1_opt)/3600))/log(10), 'm')
% plot(0:NBiter-1,  log(abs((Results.uk2{Type,2,scenario}-Results.u2_opt)/3600))/log(10), 'm')
% plot(0:NBiter-1,  log(abs((Results.uk3{Type,2,scenario}-Results.u3_opt)))/log(10), 'm')

plot(0:NBiter-1,  log(abs((Results.uk1{Type,Methode}-Results.u1_opt)/3600)+1e-4)/log(10), 'm')
% plot(0:NBiter-1,  log(abs((Results.uk1{1,2}-Results.u1_opt)/3600)+1e-4)/log(10), 'k')
plot(0:NBiter-1,  log(abs((Results.uk2{Type,Methode}-Results.u2_opt)/3600))/log(10), 'm')
% plot(0:NBiter-1,  log(abs((Results.uk2{1,Methode}-Results.u2_opt)/3600))/log(10), 'k')
plot(0:NBiter-1,  log(abs((Results.uk3{Type,Methode}-Results.u3_opt)))/log(10), 'm')
% plot(0:NBiter-1,  log(abs((Results.uk3{1,Methode}-Results.u3_opt)))/log(10), 'k')
title('Distance a l''optimum')
%% 
figure
hold on
% plot(0:NBiter-1,  Results.KK{Type,1,scenario}, 'k')
% plot(0:NBiter-1,  Results.KK{Type,2,scenario}, 'm')


plot(0:NBiter-1,  Results.KK{Type,Methode}, 'b')
title('K')
%%
figure
hold on
% plot(0:NBiter-1,  Results.uk1{Type,1,scenario}/3600, 'k')
% plot(0:NBiter-1,  Results.uk1{Type,2,scenario}/3600, 'm')

plot(0:NBiter-1,  Results.uk1{Type,Methode}/3600, 'b')
plot(0:NBiter-1,  Results.u1_opt/3600, 'r') 
title('u1')
%%
figure
hold on
% plot(0:NBiter-1,  Results.uk2{Type,1,scenario}/3600, 'k')
% plot(0:NBiter-1,  Results.uk2{Type,2,scenario}/3600, 'm')

plot(0:NBiter-1,  Results.uk2{Type,Methode}/3600, 'b')
plot(0:NBiter-1,  Results.u2_opt/3600, 'r')
title('u2')
%%
figure
hold on
% plot(0:NBiter-1,  Results.uk3{Type,1,scenario}-273.15, 'k')
% plot(0:NBiter-1,  Results.uk3{Type,2,scenario}-273.15, 'm')

plot(0:NBiter-1,  Results.uk3{Type,Methode}-273.15, 'b')
plot(0:NBiter-1,  Results.u3_opt-273.15, 'r')
title('u3')

%%
figure
hold on 
grid on

plot3(Results.uk1_s{Type,Methode},  Results.uk2_s{Type,Methode}, Results.uk3_s{Type,Methode} , 'k'  )
% plot3(Results.uk1_s{1,Methode},  Results.uk2_s{Type,Methode}, Results.uk3_s{Type,Methode} , 'b'  )
plot3(Results.uk1_s{Type,Methode}(1),  Results.uk2_s{Type,Methode}(1), Results.uk3_s{Type,Methode}(1) ,'sk'  )



%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')
