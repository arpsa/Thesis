function [dy, y_simple, g, phi, uu, yy] = PlantDyn(t, y, u, Parameters, Modifiers, Scenario)

% It is clearly not the most simple way of coding the plant's dynamics. In
% fact, I used this code to test "internal modifier adaptation (IMA)"
% and I tried to correct each reactions individualy. That's why the plant
% and the model dynamics are coded in a "subsystems way". 

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   I.- Sub-systems
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Notations
F_A = u(1);  F_B = u(2); T_R = u(3);

A_R  = y(1); B_R  = y(2); C_R  = y(3); G_R  = y(4);  P_R  = y(5);
yyA = y(6); yyB = y(7); yyC = y(8); yyP = y(9); 

%% Dynamic of A
u_A  = [F_A; F_B; T_R; yyB];
y_A  = A_R;
dy_A = reaction_Ap(t, y_A, u_A, Parameters);
if strcmp(Modifiers.type,'iMAy1')
    epsilon_iMAy1_yA = Modifiers.epsilon_iMAy1_yA;
    lambda_iMAy1_yA  = Modifiers.lambda_iMAy1_yA;
    uk               = Modifiers.uk;
    y_A = y_A + (epsilon_iMAy1_yA + lambda_iMAy1_yA*(u-uk));
elseif strcmp(Modifiers.type,'iMAy2')
    epsilon_iMAy2_yA = Modifiers.epsilon_iMAy2_yA;
    lambda_iMAy2_yA  = Modifiers.lambda_iMAy2_yA;
    uAk              = Modifiers.uAk;
    y_A = y_A + epsilon_iMAy2_yA + lambda_iMAy2_yA*(u_A-uAk);
end


%% Dynamic of B
u_B  = [F_A; F_B; T_R; yyA; yyC];
y_B  = B_R;
dy_B = reaction_Bp(t, y_B, u_B, Parameters);
if strcmp(Modifiers.type,'iMAy1')
    epsilon_iMAy1_yB = Modifiers.epsilon_iMAy1_yB;
    lambda_iMAy1_yB  = Modifiers.lambda_iMAy1_yB;
    uk               = Modifiers.uk;
    y_B = y_B + (epsilon_iMAy1_yB + lambda_iMAy1_yB*(u-uk));
elseif strcmp(Modifiers.type,'iMAy2')
    epsilon_iMAy2_yB = Modifiers.epsilon_iMAy2_yB;
    lambda_iMAy2_yB  = Modifiers.lambda_iMAy2_yB;
    uBk              = Modifiers.uBk;
    y_B = y_B + epsilon_iMAy2_yB + lambda_iMAy2_yB*(u_B-uBk);
end 


%% Dynamic of C
u_C  = [F_A; F_B; T_R; yyA; yyB; yyP];
y_C  = C_R;
dy_C = reaction_Cp(t, y_C, u_C, Parameters);
if strcmp(Modifiers.type,'iMAy1')
    epsilon_iMAy1_yC = Modifiers.epsilon_iMAy1_yC;
    lambda_iMAy1_yC  = Modifiers.lambda_iMAy1_yC;
    uk               = Modifiers.uk;
    y_C = y_C + (epsilon_iMAy1_yC + lambda_iMAy1_yC*(u-uk));
elseif strcmp(Modifiers.type,'iMAy2')
    epsilon_iMAy2_yC = Modifiers.epsilon_iMAy2_yC;
    lambda_iMAy2_yC  = Modifiers.lambda_iMAy2_yC;
    uCk              = Modifiers.uCk;
    y_C = y_C + epsilon_iMAy2_yC + lambda_iMAy2_yC*(u_C-uCk);
end


%% Dynamic of G
u_G  = [F_A; F_B; T_R; yyC; yyP];
y_G  = G_R;
dy_G = reaction_Gp(t, y_G, u_G, Parameters);
if strcmp(Modifiers.type,'iMAy1')
    epsilon_iMAy1_yG = Modifiers.epsilon_iMAy1_yG;
    lambda_iMAy1_yG  = Modifiers.lambda_iMAy1_yG;
    uk               = Modifiers.uk;
    y_G = y_G + (epsilon_iMAy1_yG + lambda_iMAy1_yG*(u-uk));
elseif strcmp(Modifiers.type,'iMAy2')
    epsilon_iMAy2_yG = Modifiers.epsilon_iMAy2_yG;
    lambda_iMAy2_yG  = Modifiers.lambda_iMAy2_yG;
    uGk              = Modifiers.uGk;
    y_G = y_G + epsilon_iMAy2_yG + lambda_iMAy2_yG*(u_G-uGk);
end


%% Dynamic of P
u_P  = [F_A; F_B; T_R; yyB; yyC];
y_P  = P_R;
dy_P = reaction_Pp(t, y_P, u_P, Parameters);
if strcmp(Modifiers.type,'iMAy1')
    epsilon_iMAy1_yP = Modifiers.epsilon_iMAy1_yP;
    lambda_iMAy1_yP  = Modifiers.lambda_iMAy1_yP;
    uk               = Modifiers.uk;
    y_P = y_P + (epsilon_iMAy1_yP + lambda_iMAy1_yP*(u-uk));
elseif strcmp(Modifiers.type,'iMAy2')
    epsilon_iMAy2_yP = Modifiers.epsilon_iMAy2_yP;
    lambda_iMAy2_yP  = Modifiers.lambda_iMAy2_yP;
    uPk              = Modifiers.uPk;
    y_P = y_P + epsilon_iMAy2_yP + lambda_iMAy2_yP*(u_P-uPk);
end


%% Dynamic of E
u_E  = [F_A; F_B; T_R; yyB; yyC];
% ME = 200;
% MP = 100;
% MG = 300;
% y_E  = ME/MP*y_P + ME/MG*y_G;            % equivalent formula
y_E  = 1 - (y_A + y_B + y_C + y_G + y_P);  % 
% dy_E = 0;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   II.- System
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dy  = [dy_A; dy_B; dy_C; dy_G; dy_P; yyA-y_A; yyB-y_B; yyC-y_C; yyP-y_P];
y_simple = [y_A; y_B; y_C; y_E; y_G; y_P];

[phi, g] = uy2phig(u, y_simple,Parameters, Modifiers, Scenario);

if strcmp(Modifiers.type,'MA')
    phi = phi + Modifiers.epsilon_phi_k + Modifiers.lambda_phi_k'*(u-Modifiers.uk);
    g   = g   + Modifiers.epsilon_g_k   + Modifiers.lambda_g_k  *(u-Modifiers.uk);
elseif strcmp(Modifiers.type,'MAy')
    y_simple = y_simple + Modifiers.epsilon_y_k + Modifiers.lambda_y_k*(u-Modifiers.uk);
    [phi, g] = uy2phig(u, y_simple,Parameters, Modifiers, Scenario);
end  
   
uu{1} = u_A; uu{2} = u_B; uu{3} = u_C; uu{4} = u_E; uu{5} = u_G;  uu{6} = u_P; 
yy{1} = y_A; yy{2} = y_B; yy{3} = y_C; yy{4} = y_E; yy{5} = y_G;  yy{6} = y_P; 


end