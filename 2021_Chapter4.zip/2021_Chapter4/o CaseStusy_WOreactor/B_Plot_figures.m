load('Results.mat')
NBiter = 61;

D = 1; I = 2;  KMFCA = 2;

%%
figure(1)
hold on
stairs(0:NBiter-1,  Results.phi_opt/3600, 'g')
plot(0:NBiter-1,  Results.phipk{I,KMFCA}/3600, 'k')
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$\phi_p [\$/h]$');
xticks([0 30 60])
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.32, 0.3, 0.62, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','WO_reactor_phi')

        
%%
figure(2)
hold on
X=[[0 30],fliplr([0 30])];                
Y=[0*[1 1],fliplr(0.07*[1 1])];           
fill(X,Y,[1,0.7,0.7],'edgecolor','none');  
plot(0:NBiter-1,  Results.gpk{I,KMFCA}, 'k')
ylim([-0.04 0.07])
xticks([0 30 60])

    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$g_p$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.32, 0.3, 0.62, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','WO_reactor_g')
        
%%
figure(3)
hold on
plot(0:NBiter-1,  Results.KK{I,KMFCA}, 'k')
xticks([0 30 60])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$K_k$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.32, 0.3, 0.62, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','WO_reactor_K')



%%
figure(4)
hold on       
stairs(0:NBiter-1,  Results.u1_opt/3600, 'g') 
plot(0:NBiter-1,  Results.uk1{I,KMFCA}/3600, 'k')
xticks([0 30 60])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u_{(1)} := F_A$ [kg/s]');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.32, 0.3, 0.62, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','WO_reactor_u1')

%%
figure(5)
hold on       
stairs(0:NBiter-1,  Results.u2_opt/3600, 'g') 
plot(0:NBiter-1,  Results.uk2{I,KMFCA}/3600, 'k')
xticks([0 30 60])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u_{(2)} := F_B$ [kg/s]');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.32, 0.3, 0.62, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','WO_reactor_u2')

%%
figure(6)
hold on       
stairs(0:NBiter-1,  Results.u3_opt-273.15, 'g') 
plot(0:NBiter-1,  Results.uk3{I,KMFCA}-273.15, 'k')
xticks([0 30 60])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u_{(3)} := T_R$ [${}^oC$]');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.32, 0.3, 0.62, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','WO_reactor_u3')

