function derivatives = derivatives_P(uk_s, uk, delta_P, Parameters, A_us, b_u, y0_p, Modifiers, fsolve_options, Scenario)

%% At the point
[yk, phik, gk] = SimPlant(uk, y0_p, Modifiers, Parameters, fsolve_options, Scenario);
nu = length(uk);

derivatives.phik = phik;
derivatives.gk   = gk;
derivatives.yk   = yk;

for i = 1:nu
    uk_perturbed_p = A_us\(uk_s+[zeros(i-1,1); delta_P(i) ; zeros(nu-i,1)]) + b_u;
        [yk_p(:,i), phik_p(i), gk_p(:,i)] = SimPlant(uk_perturbed_p, y0_p, Modifiers, Parameters, fsolve_options, Scenario);
       
    % Forward finit difference
    derivatives.dyk_du(:,i)   = (yk_p(:,i)-yk)/(norm(uk_perturbed_p-uk));
    derivatives.dphik_du(i,1) = (phik_p(i)-phik)/(norm(uk_perturbed_p-uk));
    derivatives.dgk_du(:,i)   = (gk_p(:,i)-gk)/(norm(uk_perturbed_p-uk));
    
%     % Centered finit difference
%     uk_perturbed_m = A_us\(uk_s+[zeros(i-1,1); -delta_P(i) ; zeros(nu-i,1)]) + b_u;
%         [yk_m(:,i), phik_m(i), gk_m(:,i)] = SimPlant(uk_perturbed_m, y0_p, Modifiers, Parameters, fsolve_options, Scenario);
%     derivatives.dyk_du(:,i)   = (yk_p(:,i)-yk_m(:,i))/(norm(uk_perturbed_p-uk_perturbed_m));
%     derivatives.dphik_du(i,1) = (phik_p(i)-phik_m(i))/(norm(uk_perturbed_p-uk_perturbed_m));
%     derivatives.dgk_du(:,i)   = (gk_p(:,i)-gk_m(:,i))/(norm(uk_perturbed_p-uk_perturbed_m));
end















end
