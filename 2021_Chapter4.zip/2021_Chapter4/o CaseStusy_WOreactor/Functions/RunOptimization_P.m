function [uy, f, eflag, outpt] = RunOptimization_P(uy_0_s,  Parameters, inv_A_us, b_u, Modifiers, Scenario, opts)

Last_uy  = [];
Last_f   = [];
Last_c   = [];
Last_ceq = [];

%%%%%%%%%%%%%%% 
ub = [1; 1; 1; ones(9,1)];
lb = [0; 0; 0; zeros(9,1)];
  
A = [];
b = [];

Aeq = [];  
beq = [];


%%%%%%%%%%%%%%%  

[uy, f, eflag, outpt] = fmincon(@(uy)objfun(uy),...
                                  uy_0_s, A, b, Aeq, beq, lb, ub, ...
                                @(uy)constr(uy),opts);

    function obj = objfun(uy)
        ToDo(uy)
        % Now compute objective function
        obj = Last_f;
    end

    function [c,ceq] = constr(uy)
        ToDo(uy)
        % Now compute constraint functions
        c   = Last_c;
        ceq = Last_ceq;
    end


    function [] = ToDo(uy)
        if ~isequal(uy,Last_uy) % Check if computation is necessary
            u_s = uy(1:3);
            u = inv_A_us*u_s+b_u;
            yy = uy(4:end);
            [dy, ~, g, phi] = PlantDyn(0, yy, u, Parameters, Modifiers, Scenario);
            
            Last_ceq = dy;
            Last_c   = g; 
            Last_uy  = uy;
            Last_f   = phi;
        end
    end

end