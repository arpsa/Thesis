function [uy_opt, f, eflag, outpt,lambda] = RunOptimization(uy0s,  Parameters, inv_A_us, b_u, Modifiers, Scenario, opts)


%% 

ub = [1; 1; 1; ones(8,1)];
lb = [0; 0; 0; zeros(8,1)];

A = [];
b = [];

Aeq = [];  
beq = [];

Last_uy  = [];
Last_f   = [];
Last_c   = []; 
Last_ceq = [];

%%%%%%%%%%%%%%%  

[uy_opt, f, eflag, outpt, lambda] = fmincon(@(uy)objfun(uy),...
                                uy0s, A, b, Aeq, beq, lb, ub, ...
                                @(uy)constr(uy),opts);

    function obj = objfun(uy)
        ToDo(uy);
        obj = Last_f;
    end

    function [c,ceq] = constr(uy)
        ToDo(uy);
        c   = Last_c;
        ceq = Last_ceq;
    end

    function [] = ToDo(uy)
        if ~isequal(uy,Last_uy) % Check if computation is necessary
            u_s = uy(1:3);
            u   = inv_A_us*u_s+b_u;
            yy  = uy(4:4+8-1);
            [dy, ~, g, phi] = ModelDyn(0, yy, u, Parameters, Modifiers, Scenario);
            Last_ceq = dy;
            Last_c   = g;
            Last_uy  = uy;
            Last_f   = phi;
        end
            
    end

end
