function ThetaUncertain = Parameters(test)
% test == 1 => good parameters
%      ~= 1 =>  mismatch

ThetaUncertain = struct();

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% WO reactor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 5 reactions
%
% A +  B -> C      (1)
% C +  B -> P + E  (2)
% P +  C -> G      (3)
%
if strcmp(test,'Plant') == 1
    
ThetaUncertain.A1 = 5.97*1e9;  % [1/h]
ThetaUncertain.B1 = 6666.67;   % [�K]
ThetaUncertain.A2 = 2.59*1e12; % [1/h]
ThetaUncertain.B2 = 8333.33;   % [�K]
ThetaUncertain.A3 = 9.63*1e15; % [1/h]
ThetaUncertain.B3 = 11111.11;  % [�K]

ThetaUncertain.A4 = 0; % [1/h]
ThetaUncertain.B4 = 1; % [�K]
ThetaUncertain.A5 = 0; % [1/h]                                                                 
ThetaUncertain.B5 = 1; % [�K]

else % Model
        

% ThetaUncertain.A1 = 5.97*1e9;  % [1/h]
% ThetaUncertain.B1 = 6666.67;   % [�K]
% ThetaUncertain.A2 = 2.59*1e12; % [1/h]
% ThetaUncertain.B2 = 8333.33;   % [�K]
% ThetaUncertain.A3 = 9.63*1e15; % [1/h]
% ThetaUncertain.B3 = 11111.11;  % [�K]
% 
% ThetaUncertain.A4 = 0; % [1/h]
% ThetaUncertain.B4 = 1; % [�K]
% ThetaUncertain.A5 = 0; % [1/h]                                                                 
% ThetaUncertain.B5 = 1; % [�K]
%     
ThetaUncertain.A1 = 0; % [1/h]
ThetaUncertain.B1 = 0; % [�K]
ThetaUncertain.A2 = 0; % [1/h]
ThetaUncertain.B2 = 0; % [�K]
ThetaUncertain.A3 = 0; % [1/h]
ThetaUncertain.B3 = 0; % [�K]

ThetaUncertain.A4 = 2.189e+008*3600;  % [1/h] 231810604804
ThetaUncertain.B4 = 8077.6;           % [�K]
ThetaUncertain.A5 = 4.309e+013*3600;  % [1/h] 773370943014                                                                
ThetaUncertain.B5 = 12438.5;          % [�K]  


end
% 
% ThetaUncertain.FA = 6579; % [kg/h]

end