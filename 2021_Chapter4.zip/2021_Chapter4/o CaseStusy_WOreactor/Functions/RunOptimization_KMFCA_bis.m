function [uy_opt, f, eflag, outpt, lambda, KK] = RunOptimization_KMFCA_bis(uy0_s,  Parameters, inv_A_us, b_u, Modifiers, Scenario, opts,y0,fsolve_options)


%% 
ub = ones(length(uy0_s),1);  % [1; 1; 1; ones(8*2,1)];
lb = zeros(length(uy0_s),1); % [0; 0; 0; zeros(8*2,1)];

A = [];
b = [];

Aeq = [];  
beq = [];

Last_uy  = [];
Last_f   = [];
Last_c   = []; 
Last_ceq = [];

%%%%%%%%%%%%%%%  

[uy_opt, f, eflag, outpt, lambda] = fmincon(@(uy)objfun(uy),...
                                uy0_s, A, b, Aeq, beq, lb, ub, ...
                                @(uy)constr(uy),opts);

    function obj = objfun(uy)
        Update(uy);
        obj = Last_f;
    end

    function [c,ceq] = constr(uy)
        Update(uy);
        c   = Last_c;
        ceq = Last_ceq;
    end

    function [] = Update(uy)
        if ~isequal(uy,Last_uy) % Check if computation is necessary
            
            uk         = Modifiers.uk;
            ukm1       = Modifiers.ukm1;
            uopt_km1   = Modifiers.uoptkm1;
            k          = Modifiers.k;
            uk_s       = Modifiers.uk_s;
            uk_s_m1    = Modifiers.ukm1_s;
            uopt_km1_s = Modifiers.uoptkm1_s;
            KK_km1     = Modifiers.KK_km1;
            
            % At the model-based optimum
            u_s = uy(1:3);
            u   = inv_A_us*u_s+b_u;
            
            [~, phi, g] = SimModel(u, y0, Modifiers, Parameters, fsolve_options, Scenario);

            g = Modifiers.g_k + Modifiers.dg_k * (u - Modifiers.uk); % linearized constraintes
            HPHIc = Modifiers.HPHIc;
            uk    = Modifiers.uk;
            phi   = phi + (u-uk)'*HPHIc*(u-uk)/2; % Convexified cost 
                        
            if k == 1
                KK = 0.1;
            else
                if (max(abs(uk_s-uk_s_m1)) < 1e-4) 
                    KK = KK_km1;
                else
                    NablaS = (uk-ukm1)'*(u - uopt_km1) /(norm(uk-ukm1)^2);
                    if NablaS < 1
                        KK = max(1/(1-NablaS), 0.1);
                    else
                        KK = 1;
                    end
                 end
            end
            
%             if k > 1
%                 KK = KK_km1 + 0.5*(KK - KK_km1);
%             end
            % This "if ... else ... end" should be requiered if the solver
            % were "ideal". However, we observed that when there is no
            % constraints, e.g. g(u)=-1, the solver gives different
            % responses. (probably because of the fact that dy is 2X larger
            % than before which makes the problem harder to solve).
            if Scenario.Constraints ==  0
                Last_ceq = [];
                Last_c   = g; 
            else
                u2   = uk + KK*(u-uk);
                [~, ~, g2] = SimModel(u2, y0, Modifiers, Parameters, fsolve_options, Scenario);

                
%                 yy2  = uy(4+8:end);
%                 [dy2, ~, g2] = ModelDyn(0, yy2, u2, Parameters, Modifiers, Scenario);
                Last_ceq = [ ];
                Last_c   = [g;g2;KK-3]; 
            end
            
            Last_uy  = uy;
            Last_f   = phi;
        end
    end

end
