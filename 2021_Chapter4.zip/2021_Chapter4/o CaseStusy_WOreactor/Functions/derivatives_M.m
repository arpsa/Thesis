function derivatives = derivatives_M(uk_s, uk, delta_M, Parameters, A_us, b_u, y0, Modifiers, fsolve_options, Scenario)

%% At the point
[yk, phik, gk] = SimModel(uk, y0, Modifiers, Parameters, fsolve_options, Scenario);

derivatives.yk   = yk;
derivatives.phik = phik;
derivatives.gk   = gk;

%%
nu = length(uk);
for i = 1:nu
    uk_perturbed_p = A_us\(uk_s+[zeros(i-1,1); delta_M(i) ; zeros(nu-i,1)]) + b_u;
        [yk_p(:,i), phik_p(i), gk_p(:,i)] = SimModel(uk_perturbed_p, y0, Modifiers, Parameters, fsolve_options, Scenario);
    % centered finit difference
    uk_perturbed_m = A_us\(uk_s+[zeros(i-1,1); -delta_M(i) ; zeros(nu-i,1)]) + b_u;
        [yk_m(:,i), phik_m(i), gk_m(:,i)] = SimModel(uk_perturbed_m, y0, Modifiers, Parameters, fsolve_options, Scenario);
    
    derivatives.dyk_du(:,i)   = (yk_p(:,i)-yk_m(:,i))/(norm(uk_perturbed_p-uk_perturbed_m));
    derivatives.dphik_du(i,1) = (phik_p(i)-phik_m(i))/norm(uk_perturbed_p-uk_perturbed_m);
    derivatives.dgk_du(:,i)   = (gk_p(:,i)-gk_m(:,i))/norm(uk_perturbed_p-uk_perturbed_m);
    
    derivatives.Hu_phik(i,i) = ((phik_p(i) - phik)/(norm(uk_perturbed_p-uk)) - (phik-phik_m(i))/(norm(uk_perturbed_p-uk))) /(norm(uk_perturbed_p-uk));
end


%% Compute of non-diagonal elements of the Hessian of the cost
uk_100 = A_us\(uk_s+[delta_M(1);0;0]) + b_u;
[yk_100, phik_100, gk_100] = SimModel(uk_100, y0, Modifiers, Parameters, fsolve_options, Scenario);
uk_010 = A_us\(uk_s+[0;delta_M(2);0]) + b_u;
[yk_010, phik_010, gk_010] = SimModel(uk_010, y0, Modifiers, Parameters, fsolve_options, Scenario);
uk_001 = A_us\(uk_s+[0;0;delta_M(3)]) + b_u;
[yk_001, phik_001, gk_001] = SimModel(uk_001, y0, Modifiers, Parameters, fsolve_options, Scenario);
uk_110 = A_us\(uk_s+[delta_M(1);delta_M(2);0]) + b_u;
[yk_110 phik_110, gk_110] = SimModel(uk_110, y0, Modifiers, Parameters, fsolve_options, Scenario);
uk_101 = A_us\(uk_s+[delta_M(1);0;delta_M(3)]) + b_u;
[yk_101 phik_101, gk_101] = SimModel(uk_101, y0, Modifiers, Parameters, fsolve_options, Scenario);
uk_011 = A_us\(uk_s+[0;delta_M(2);delta_M(3)]) + b_u;
[yk_011 phik_011, gk_011] = SimModel(uk_011, y0, Modifiers, Parameters, fsolve_options, Scenario);
uk_m100 = A_us\(uk_s+[-delta_M(1);0;0]) + b_u;
[yk_m100 phik_m100, gk_m100] = SimModel(uk_m100, y0, Modifiers, Parameters, fsolve_options, Scenario);
uk_0m10 = A_us\(uk_s+[0;-delta_M(2);0]) + b_u;
[yk_0m10 phik_0m10, gk_0m10] = SimModel(uk_0m10, y0, Modifiers, Parameters, fsolve_options, Scenario);
uk_00m1 = A_us\(uk_s+[0;0;-delta_M(3)]) + b_u;
[yk_00m1 phik_00m1, gk_00m1] = SimModel(uk_00m1, y0, Modifiers, Parameters, fsolve_options, Scenario);
uk_m1m10 = A_us\(uk_s+[-delta_M(1);-delta_M(2);0]) + b_u;
[yk_m1m10 phik_m1m10, gk_m1m10] = SimModel(uk_m1m10, y0, Modifiers, Parameters, fsolve_options, Scenario);
uk_m10m1 = A_us\(uk_s+[-delta_M(1);0;-delta_M(3)]) + b_u;
[yk_m10m1 phik_m10m1, gk_m10m1] = SimModel(uk_m10m1, y0, Modifiers, Parameters, fsolve_options, Scenario);
uk_0m1m1 = A_us\(uk_s+[0;-delta_M(2);-delta_M(3)]) + b_u;
[yk_0m1m1 phik_0m1m1, gk_0m1m1] = SimModel(uk_0m1m1, y0, Modifiers, Parameters, fsolve_options, Scenario);


derivatives.Hu_phik(1,2) = ((phik_110 - 2*phik + phik_m1m10) - (phik_100 - 2*phik + phik_m100)- (phik_010 - 2*phik + phik_0m10)) / (2* norm(uk_100-uk) *  norm(uk_010-uk));
derivatives.Hu_phik(2,1) = derivatives.Hu_phik(1,2);
derivatives.Hu_phik(1,3) = ((phik_101 - 2*phik + phik_m10m1) - (phik_100 - 2*phik + phik_m100)- (phik_001 - 2*phik + phik_00m1)) / (2* norm(uk_100-uk) *  norm(uk_001-uk));
derivatives.Hu_phik(3,1) = derivatives.Hu_phik(3,1);
derivatives.Hu_phik(2,3) = ((phik_011 - 2*phik + phik_0m1m1) - (phik_010 - 2*phik + phik_0m10)- (phik_001 - 2*phik + phik_00m1)) / (2* norm(uk_010-uk) *  norm(uk_001-uk));
derivatives.Hu_phik(3,2) = derivatives.Hu_phik(2,3);



% test = (yk_100 - yk_m100)/(2*norm(uk_100-uk));
% 
% test- derivatives.dyk_du(:,1) 

%%





end