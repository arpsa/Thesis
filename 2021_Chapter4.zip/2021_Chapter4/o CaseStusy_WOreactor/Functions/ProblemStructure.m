function PBstruct = ProblemStructure()

PBstruct = struct();

%% Simulation 
PBstruct.x0 = [ 0.2; 1; 0.05; 0.05; 0.05; 0.05]; 

%% Options solver/optimizer

% Interior point is a better choice than SQP in this case because SQP is
% more "aggressive" in the iterates it generates and may converge to
% model's optima that are far from the current iterate. With interior point
% we are more likely to make more reasonnable moves (at least that's what)
% I have observed. Also, the problem we are solving is not globally
% convexe (because of the feasibility constraint on the filtered point that
% is not linearised). So, doing sequential *quadratic* approchimation
% doesn't sound to be the best option. 
PBstruct.fmincon_options = optimoptions(@fmincon,'Algorithm','sqp' , ...'interior-point'   'sqp' 'active-set'
                                        'MaxIter',100000,... 
                                        'Display', 'off', ...''final',...  off   iter
                                        'MaxFunEvals',100000,...
                                        'TolFun',1e-8,...
                                        'TolCon',1e-8,...
                                        'TolX',1e-8,...
                                        'FinDiffType','central' ,... % ,...%'forward' (default), or 'central' 
                                        'ScaleProblem','obj-and-constr');

PBstruct.fsolve_options = optimset('Algorithm','trust-region-reflective',...levenberg-marquardt     trust-region-reflective
                          'LargeScale','on',...
                          'Diagnostics','off',...
                          'Display','off' ,...  final off  on 
                          'FunValCheck','on',...
                          'MaxFunEvals',100000,...
                          'MaxIter',100000,...
                          'TolFun',1e-10, ...
                          'TolX',1e-10, ...
                          'TolCon',1e-10);

%% 


end