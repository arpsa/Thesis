function [uy_opt, f, eflag, outpt,lambda] = RunOptimization_KMA_bis(uy0_s,  Parameters, inv_A_us, b_u, Modifiers, Scenario, opts, KK,fsolve_options,y0)


%% 
ub = ones(length(uy0_s),1);  % [1; 1; 1; ones(8*2,1)];
lb = zeros(length(uy0_s),1); % [0; 0; 0; zeros(8*2,1)];

A = [];
b = [];

Aeq = [];  
beq = [];

Last_uy  = [];
Last_f   = [];
Last_c   = []; 
Last_ceq = [];

%%%%%%%%%%%%%%%  

[uy_opt, f, eflag, outpt, lambda] = fmincon(@(uy)objfun(uy),...
                                uy0_s, A, b, Aeq, beq, lb, ub, ...
                                @(uy)constr(uy),opts);

    function obj = objfun(uy)
        Update(uy);
        obj = Last_f;
    end

    function [c,ceq] = constr(uy)
        Update(uy);
        c   = Last_c;
        ceq = Last_ceq;
    end

    function [] = Update(uy)
        if ~isequal(uy,Last_uy) % Check if computation is necessary
            u_s = uy(1:3);
            u   = inv_A_us*u_s+b_u;
            [~, phi, g] = SimModel(u, y0, Modifiers, Parameters, fsolve_options, Scenario);

            
%             yy  = uy(4:4+8-1);
%             [dy, ~, g, phi] = ModelDyn(0, yy, u, Parameters, Modifiers, Scenario);
            g = Modifiers.g_k + Modifiers.dg_k * (u - Modifiers.uk); % linearized constraintes
            HPHIc = Modifiers.HPHIc;
            uk   = Modifiers.uk;
            phi = phi + (u-uk)'*HPHIc*(u-uk)/2; % Convexified cost 
            
            if Scenario.Constraints == 1
                u2  = uk + KK*(u-uk);
                [~, ~, g2] = SimModel(u2, y0, Modifiers, Parameters, fsolve_options, Scenario);
                Last_ceq = [];
                Last_c   = [g;g2]; 
            else
                Last_ceq = [];
                Last_c   = g;
            end
            Last_uy  = uy;
            Last_f   = phi;
        end
    end

end
