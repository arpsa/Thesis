    clc 
clear 

x=[rand(1,10) rand(1,10) rand(1,10) rand(1,10) rand(1,10) rand(1,10)]; 
n=10 ; xx=([1:6])'; % example 
r=repmat(xx,1,n)'; 
g=r(:)'; 


positions = [1 2 3 4 5 6 ]; 
h=boxplot(x,g, 'positions', positions); 
set(h,'linewidth',2) 

set(gca,'xtick',[mean(positions(1:2)) mean(positions(3:4)) mean(positions(5:6)) ]) 
set(gca,'xticklabel',{'exp1','exp2','exp3'},'Fontsize',28) 

color = ['c', 'y', 'c', 'y','c', 'y']; 
h = findobj(gca,'Tag','Box'); 
for j=1:length(h) 
patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5); 
end 