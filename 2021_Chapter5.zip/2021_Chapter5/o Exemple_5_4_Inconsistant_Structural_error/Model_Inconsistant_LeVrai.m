clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

%% Code architecture initialization & Output files 
Results_file_name = 'Results';
Scenario = 1; 

global a1 b1 c1 a2 b2 c2         ...
       a1p b1p c1p a2p b2p c2p   ...
       ap1 bp1 cp1 dp1 ep1       ...
       ap2 bp2 cp2 dp2 ep2       ...
       ap3 bp3 cp3 dp3 ep3       ...
       ap4 bp4 cp4 dp4 ep4       ...
       epsilon_1AB   epsilon_2AB ...
       lambda_1A  lambda_2A      ...
       lambda_1B  lambda_2B H fsolve_options
H=1e-4;

a1p= 1;   b1p=-1;          c1p= 0.01;     a2p= 2;   b2p= -2;  c2p= 2;
a1 = 1.5; b1 =-1.5 ;        c1 =  0.01;                         a2 = 1;  b2 = -1 ;  c2 = 1.5; 


delta1 = 0.25;
delta2 = 0.25;
a1min= a1p-delta1;     a1max= a1p+delta1;     n_a1 = 2;    A1 = a1min:(a1max-a1min)/(n_a1-1):a1max;
b1min= b1p(1)-delta1;  b1max= b1p(1)+delta1;  n_b1 = 2;    B1 = b1min:(b1max-b1min)/(n_b1-1):b1max;
c1min= c1p(1,1)-0.01;  c1max= c1p(1,1)+0.01;  n_c1 = 2;    C1 = c1min:(c1max-c1min)/(n_c1-1):c1max;
a2min= a2p-delta2;     a2max= a2p+delta2;     n_a2 = 2;    A2 = a2min:(a2max-a2min)/(n_a2-1):a2max;
b2min= b2p-delta2;     b2max= b2p+delta2;     n_b2 = 2;    B2 = b2min:(b2max-b2min)/(n_b2-1):b2max;
c2min= c2p-0.2;        c2max= c2p+0.2;        n_c2 = 2;    C2 = c2min:(c2max-c2min)/(n_c2-1):c2max;

% Parameters of the four cost functions
ap1= 0 ; bp1= 1; cp1= 0;   dp1= 0 ;    ep1= 0;
ap2= 0 ; bp2= 0; cp2= 0;   dp2= 1 ;    ep2= 0;
ap3= 0 ; bp3= 0; cp3= 0;   dp3= 0 ;    ep3= 1;
ap4= 0 ; bp4= 1; cp4= 1;   dp4= 0.5 ;  ep4= 0.05;


%%
fsolve_options = optimset('Algorithm','levenberg-marquardt',...levenberg-marquardt     trust-region-reflective
                          'LargeScale','on',...
                          'Diagnostics','off',...
                          'Display','off' ,...  final off  on 
                          'FunValCheck','on',...
                          'MaxFunEvals',100000,...
                          'MaxIter',100000,...
                          'TolFun',1e-15, ...
                          'TolX',1e-15, ...
                          'TolCon',1e-15);

%% Plot plant functions:
UUU222 = 0;

for hide_plot_pant = []     
     xmin = -1; xmax = 1;
    nx = 10;
    dx = (xmax-xmin)/(nx-1);
    x1 = xmin:dx:xmax;
    x2 = xmin:dx:xmax;
    phi_1 = 1; phi_2 = 2; phi_3 = 3; phi_4 = 4;
    Sys12 = 5; Sys1 = 6;  Sys2 = 7; Sys22 = 8;
    figure(phi_1); grid on; view([134,21]); 
    figure(phi_2); grid on; view([-120,9]);
    figure(phi_3); grid on; view([75,14]);
    figure(phi_4); grid on; view([122,16]);
    figure(Sys12); grid on; view([58,38]);
    figure(Sys1);  grid on; view([125,23]);
    figure(Sys2);  grid on; view([-21,62]);
    figure(Sys22);  grid on; view([-21,62]);
     iter = 0;
    NBiter = length(A1)*length(B1)*length(C1)*length(A2)*length(B2)*length(C2)*nx^2;
    
    
                                for  ii = 1:length(A1)
                            for      jj = 1:length(B1)
                        for          kk = 1:length(C1)
                    for             iii = 1:length(A2)
                for                 jjj = 1:length(B2)
            for                     kkk = 1:length(C2)  
                a1 = A1(ii); a2 = A2(iii);
                b1 = B1(jj); b2 = B2(jjj);
                c1 = C1(kk); c2 = C2(kkk);  
    for i=1:length(x1)
        for j=1:length(x2)
                    UU = [x1(i);x2(j)];
                    y_12(i,j) = systeme_12(UU);
                    y_1(i,j)  = systeme_1(UU(2));
                    [PHI1(i,j),~,~] = uy2phi1(UU,y_12(i,j),0,0);
                    [PHI2(i,j),~,~] = uy2phi2(UU,y_12(i,j),0,0);
                    [PHI3(i,j),~,~] = uy2phi3(UU,y_12(i,j),0,0);
                    [PHI4(i,j),~,~] = uy2phi4(UU,y_12(i,j),0,0);
                    U1(i,j)= UU(1);   U2(i,j)= UU(2); 
                    iter = iter +1;
        end
    end
                figure(phi_1)
                hold on
                h = surf(U1,U2,PHI1,'FaceColor','red','FaceAlpha',0,'edgecolor','r','EdgeAlpha',0.2);
%                 h.Color(4) = 0.1;
                    figure(phi_2)
                    hold on
                    h = surf(U1,U2,PHI2,'FaceColor','red','FaceAlpha',0,'edgecolor','r','EdgeAlpha',0.2);
%                     h.Color(4) = 0.1;
                        figure(phi_3)
                        hold on
                        h = surf(U1,U2,PHI3,'FaceColor','red','FaceAlpha',0,'edgecolor','r','EdgeAlpha',0.2);
%                         h.Color(4) = 0.1;
                            figure(phi_4)
                            hold on
                            h = surf(U1,U2,PHI4,'FaceColor','red','FaceAlpha',0,'edgecolor','r','EdgeAlpha',0.2);
%                             h.Color(4) = 0.1;
                                figure(Sys12)
                                hold on
                                h = surf(U1,U2,y_12,'FaceColor','red','FaceAlpha',0,'edgecolor','r','EdgeAlpha',0.2);
%                                 h.Color(4) = 0.1;
                                    figure(Sys1)
                                    hold on
                                    h = surf(U1,U2,y_1,'FaceColor','red','FaceAlpha',0,'edgecolor','r','EdgeAlpha',0.2);
%                                     h.Color(4) = 0.1;
                                        figure(Sys2)
                                        hold on
                                        h = surf(y_1,U2,y_12,'FaceColor','red','FaceAlpha',0,'edgecolor','r','EdgeAlpha',0.2);
%                                         h.Color(4) = 0.1;
                                            figure(Sys22)
                                            hold on
                                            h = surf(y_1,U1,y_12,'FaceColor','red','FaceAlpha',0,'edgecolor','r','EdgeAlpha',0.2);
    %                                         h.Color(4) = 0.1;
            end
                end
                    end
                    disp(num2str(iter/NBiter))
                        end
                            end
                                end  
    for i=1:length(x1)
        for j=1:length(x2)
                UU = [x1(i);x2(j)];
                y_12p(i,j) = systeme_12p(UU);
                y_1p(i,j)  = systeme_1p(UU(1));
                [PHI1p(i,j),~,~] = uy2phi1(UU,y_12p(i,j),0,0);
                [PHI2p(i,j),~,~] = uy2phi2(UU,y_12p(i,j),0,0);
                [PHI3p(i,j),~,~] = uy2phi3(UU,y_12p(i,j),0,0);
                [PHI4p(i,j),~,~] = uy2phi4(UU,y_12p(i,j),0,0);
                 U1(i,j)= UU(1);   U2(i,j)= UU(2); 
        end    
    end
    %%
            figure(phi_1)
        hold on
        h = surf(U1,U2,PHI1p,'FaceColor','k','FaceAlpha',0.5);
%         ylim([1,7])
            hXLabel = xlabel('$u_{(1)}$');
            hYLabel = ylabel('$u_{(2)}$');
            hZLabel = zlabel('$\phi_1$');
            set([hXLabel, hYLabel,hZLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.5; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_phi1_Ex4_Sc',num2str(Scenario)])
%%
        figure(phi_2)
        hold on
        h = surf(U1,U2,PHI2p,'FaceColor','k','FaceAlpha',0.5);
%         ylim([-4,4])
            hXLabel = xlabel('$u_{(1)}$');
            hYLabel = ylabel('$u_{(2)}$');
            hZLabel = zlabel('$\phi_2$');
            set([hXLabel, hYLabel,hZLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.5; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_phi2_Ex4_Sc',num2str(Scenario)])
%%
        figure(phi_3)
        hold on
        h = surf(U1,U2,PHI3p,'FaceColor','black','FaceAlpha',0.5);
%         ylim([0,15])
            hXLabel = xlabel('$u_{(1)}$');
            hYLabel = ylabel('$u_{(2)}$');
            hZLabel = zlabel('$\phi_3$');
            set([hXLabel, hYLabel,hZLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.5; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_phi3_Ex4_Sc',num2str(Scenario)])
%%
        figure(phi_4)
        hold on
        h = surf(U1,U2,PHI4p,'FaceColor','black','FaceAlpha',0.5);
%         ylim([1,5])
            hXLabel = xlabel('$u_{(1)}$');
            hYLabel = ylabel('$u_{(2)}$');
            hZLabel = zlabel('$\phi_4$');
            set([hXLabel, hYLabel,hZLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.5; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_phi4_Ex4_Sc',num2str(Scenario)])
%%
        figure(Sys12)
        hold on
        h = surf(U1,U2,y_12p,'FaceColor','black','FaceAlpha',0.5);
%         ylim([1,5])
            hXLabel = xlabel('$u_{(1)}$');
            hYLabel = ylabel('$u_{(2)}$');
            hZLabel = zlabel('$y^{(2)}$');
            set([hXLabel, hYLabel,hZLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=6; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_Sys12_Ex4_Sc',num2str(Scenario)])
%%
        figure(Sys1)
        hold on
        h = surf(U1,U2,y_1p,'FaceColor','black','FaceAlpha',0.5);
        grid on
            hXLabel = xlabel('$u_{(1)}$');
            hYLabel = ylabel('$u_{(2)}$');
            hZLabel = zlabel('$y^{(1)}$');
            set([hXLabel, hYLabel, hZLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',0.5);
            set(gca,'Layer','Top');
%             set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=6; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_Sys1_Ex4_Sc',num2str(Scenario),'_Bis'])
        
%         figure(Sys1)
%         hold on
%         h = plot3(x,y_12p,y_1p,'k', 'LineWidth', 2);
%         grid on
% %         view([70 10]);
% %         view([56 28]);
% %         view([76 15]);
% ylim([1 5])
% %         view([46 20]);
%         view([68 34]);
%             yticks([1:2:38])
%             hXLabel = xlabel('$u$');
%             hYLabel = ylabel('$y^{(2)}$');
%             hZLabel = zlabel('$y^{(1)}$');
%             set([hXLabel, hYLabel,hZLabel],'FontSize', 10 ,'Interpreter','LaTex');
%             set(gca,'FontSize',10);
%             set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',0.5);
%             set(gca,'Layer','Top');
% %             set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
%             set(gcf, 'PaperUnits', 'centimeters');
%             x_width=6; y_width=4;  
%             set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%             print('-painters','-dpdf',['Exemple_Sys1_Ex4_Sc',num2str(Scenario)])
%%
        figure(Sys2)
        hold on
        h = surf(y_1p,U2,y_12p,'FaceColor','black','FaceAlpha',0.5);
            hXLabel = xlabel('$y^{(1)}$');
            hYLabel = ylabel('$u_{(2)}$');
            hZLabel = zlabel('$y^{(2)}$');
            set([hXLabel, hYLabel, hZLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=6; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_Sys2_Ex4_Sc',num2str(Scenario)])    
%%
        figure(Sys22)
        hold on
        h = surf(y_1p,U1,y_12p,'FaceColor','black','FaceAlpha',0.5);
            hXLabel = xlabel('$y^{(1)}$');
            hYLabel = ylabel('$u_{(1)}$');
            hZLabel = zlabel('$y^{(2)}$');
            set([hXLabel, hYLabel, hZLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=6; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_Sys22_Ex4_Sc',num2str(Scenario)])    
end
%% Analyse statistique:
for hide_Analysis = 1     
    delta1 = 0.25;
    delta2 = 0.25;
    a1min= a1p-delta1;     a1max= a1p+delta1;     n_a1 = 6;    A1 = a1min:(a1max-a1min)/(n_a1-1):a1max;
    b1min= b1p(1)-delta1;  b1max= b1p(1)+delta1;  n_b1 = 6;    B1 = b1min:(b1max-b1min)/(n_b1-1):b1max;
    c1min= c1p(1,1)-0.01;  c1max= c1p(1,1)+0.01;  n_c1 = 6;    C1 = c1min:(c1max-c1min)/(n_c1-1):c1max;
    a2min= a2p-delta2;     a2max= a2p+delta2;     n_a2 = 6;    A2 = a2min:(a2max-a2min)/(n_a2-1):a2max;
    b2min= b2p-delta2;     b2max= b2p+delta2;     n_b2 = 6;    B2 = b2min:(b2max-b2min)/(n_b2-1):b2max;
    c2min= c2p-0.2;        c2max= c2p+0.2;        n_c2 = 6;    C2 = c2min:(c2max-c2min)/(n_c2-1):c2max;


    VED1=[];VED2=[];VED3=[];VED4=[];
    SED1=[];SED2=[];SED3=[];SED4=[];
    CED1=[];CED2=[];CED3=[];CED4=[];
    
    VEI1=[];VEI2=[];VEI3=[];VEI4=[];
    SEI1=[];SEI2=[];SEI3=[];SEI4=[];
    CEI1=[];CEI2=[];CEI3=[];CEI4=[];
    
    VEA1=[];VEA2=[];VEA3=[];VEA4=[];
    SEA1=[];SEA2=[];SEA3=[];SEA4=[];
    CEA1=[];CEA2=[];CEA3=[];CEA4=[];
    
    VEB1=[];VEB2=[];VEB3=[];VEB4=[];
    SEB1=[];SEB2=[];SEB3=[];SEB4=[];
    CEB1=[];CEB2=[];CEB3=[];CEB4=[];



    x_min = -1; x_max = 1; dx = (x_max-x_min)/9; % 9 <<<<<<<<<<<<<
    x1=x_min:dx:x_max;
    x2=x_min:dx:x_max;
    iter   = 0;
    NBiter = length(A1)*length(B1)*length(C1)*length(A2)*length(B2)*length(C2)*length(x1)*length(x2);
                            for  ii = 1:length(A1)
                        for      jj = 1:length(B1)
                    for          kk = 1:length(C1)
                for             iii = 1:length(A2)
            for                 jjj = 1:length(B2)
        for                     kkk = 1:length(C2)
                a1 = A1(ii); a2 = A2(iii);
                b1 = B1(jj); b2 = B2(jjj);
                c1 = C1(kk); c2 = C2(kkk);  
        for i=1:length(x1)
            for j=1:length(x2)
            % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            % 1) Evaluate plant & model values and gradients:
            UU = [x1(i);x2(j)];
            [yp,dyp_dx,ddyp_dx,dy1p_dx] = systeme_12p(UU);  [y,dy_dx,ddy_dx,dy1_dx] = systeme_12(UU);
            U1p = UU(1);                                      U1 = UU(2); 
            [y1p]    = systeme_1p(U1p);                      [y1] = systeme_1(U1);
            U2p = [UU(2);y1p];                                U2 = [UU(1);y1p];
            [y2p,dy2p_du2]    = systeme_2p(U2p);             [y2,dy2_du2] = systeme_2(U2);
                
            [phip1,dphip1,ddphip1] = uy2phi1(UU,yp,dyp_dx,ddyp_dx); 
            [phi1,dphi1,ddphi1]    = uy2phi1(UU,y,dy_dx,ddy_dx);   
                [phip2,dphip2,ddphip2] = uy2phi2(UU,yp,dyp_dx,ddyp_dx); 
                [phi2,dphi2,ddphi2]    = uy2phi2(UU,y,dy_dx,ddy_dx);  
                    [phip3,dphip3,ddphip3] = uy2phi3(UU,yp,dyp_dx,ddyp_dx); 
                    [phi3,dphi3,ddphi3]    = uy2phi3(UU,y,dy_dx,ddy_dx); 
                        [phip4,dphip4,ddphip4] = uy2phi4(UU,yp,dyp_dx,ddyp_dx); 
                        [phi4,dphi4,ddphi4]    = uy2phi4(UU,y,dy_dx,ddy_dx);   
            % 2) Construct correction structures
            % 2.1) Direct approach:
            epsilon_d1 = phip1  - phi1;   %ok
            lambda_d1  = dphip1 - dphi1;  %ok
                epsilon_d2 = phip2  - phi2;   %ok
                lambda_d2  = dphip2 - dphi2;  %ok
                    epsilon_d3 = phip3  - phi3;   %ok
                    lambda_d3  = dphip3 - dphi3;  %ok
                        epsilon_d4 = phip4  - phi4;   %ok
                        lambda_d4  = dphip4 - dphi4;  %ok
            % 2.2) Indirect approach:
            epsilon_i = yp     - y;       %ok
            lambda_i  = dyp_dx - dy_dx;      %ok
            % 2.3) Deep A and B approaches:
            epsilon_1AB = y1p - y1;           epsilon_2AB = y2p - y2;        
            lambda_1A   = dy1p_dx - dy1_dx;   lambda_2A   = dyp_dx - [1,dy1p_dx(1);0,dy1p_dx(2)]*dy2_du2;  
            lambda_1B   = 0 - dy1_dx(2);      lambda_2B   = [dy1p_dx(1)*dy2p_du2(2);dy2p_du2(2)] - dy2_du2;      %ok

            % 3) correct models and evaluate Hessian errors
            % 3.1) Direct approach:
            offset_error_d1(i)    = (phi1 +epsilon_d1 - phip1);
            a = dphi1+lambda_d1 - dphip1;
            slope_error_d1_A(i)     = a(1);
            slope_error_d1_B(i)     = a(2);
            A = eig(ddphi1 - ddphip1);
            curvature_error_d1_A(i) = A(1);
            curvature_error_d1_B(i) = A(2);
                offset_error_d2(i)    = (phi2 +epsilon_d2 - phip2);
                a = dphi2+lambda_d2 - dphip2;
                slope_error_d2_A(i)     = a(1);
                slope_error_d2_B(i)     = a(2);
                 A = eig(ddphi2 - ddphip2);
                curvature_error_d2_A(i) = A(1);
                curvature_error_d2_B(i) = A(2);
                    offset_error_d3(i)    = (phi3 +epsilon_d3 - phip3);
                    a = dphi3+lambda_d3 - dphip3;
                    slope_error_d3_A(i)     = a(1);
                    slope_error_d3_B(i)     = a(2);
                    A = eig(ddphi3 - ddphip3);
                    curvature_error_d3_A(i) = A(1);
                    curvature_error_d3_B(i) = A(2);
                        offset_error_d4(i)    = (phi4 +epsilon_d4 - phip4);
                        a = dphi4+lambda_d4 - dphip4;
                        slope_error_d4_A(i)     = a(1);
                        slope_error_d4_B(i)     = a(2);
                        A = eig(ddphi4 - ddphip4);
                        curvature_error_d4_A(i) = A(1);
                        curvature_error_d4_B(i) = A(2);
            % 3.2) Indirect approach:
            ym  = y  + epsilon_i;      
            dym = dy_dx + lambda_i;
            [phim1,dphim1,ddphim1] = uy2phi1(UU,ym,dym,ddy_dx);
                [phim2,dphim2,ddphim2] = uy2phi2(UU,ym,dym,ddy_dx);
                    [phim3,dphim3,ddphim3] = uy2phi3(UU,ym,dym,ddy_dx);
                        [phim4,dphim4,ddphim4] = uy2phi4(UU,ym,dym,ddy_dx); 
            offset_error_i1(i)    = (phim1   - phip1);
            a = dphim1  - dphip1;
            slope_error_i1_A(i)     = a(1);
            slope_error_i1_B(i)     = a(2);
            A = eig(ddphim1 - ddphip1);
            curvature_error_i1_A(i) = A(1);
            curvature_error_i1_B(i) = A(2);
                offset_error_i2(i)    = (phim2   - phip2);
                a = dphim2  - dphip2;
                slope_error_i2_A(i)     = a(1);
                slope_error_i2_B(i)     = a(2);
                 A = eig(ddphim2 - ddphip2);
                curvature_error_i2_A(i) = A(1);
                curvature_error_i2_B(i) = A(2);
                    offset_error_i3(i)    = (phim3   - phip3);
                    a = dphim3  - dphip3;
                    slope_error_i3_A(i)     = a(1);
                    slope_error_i3_B(i)     = a(2);
                    A = eig(ddphim3 - ddphip3);
                    curvature_error_i3_A(i) = A(1);
                    curvature_error_i3_B(i) = A(2);
                        offset_error_i4(i)    = (phim4   - phip4);
                        a = dphim4  - dphip4;
                        slope_error_i4_A(i)     = a(1);
                        slope_error_i4_B(i)     = a(2);
                        slope_error_i4(i)     = max(abs(dphim4  - dphip4));
                        A = eig(ddphim4 - ddphip4);
                        curvature_error_i4_A(i) = A(1);
                        curvature_error_i4_B(i) = A(2);
            % 3.3) Deep A approach:
            
            [~,~,~, dy1p_test]      = systeme_12p(UU);
            [ym,dym,ddym,dy1_test]  = systeme_12A(UU,UU);
            [phim1,dphim1,ddphim1] = uy2phi1(UU,ym,dym,ddym); 
                [phim2,dphim2,ddphim2] = uy2phi2(UU,ym,dym,ddym); 
                    [phim3,dphim3,ddphim3] = uy2phi3(UU,ym,dym,ddym); 
                        [phim4,dphim4,ddphim4] = uy2phi4(UU,ym,dym,ddym); 
            offset_error_A1(i)    = (phim1   - phip1);
            a = dphim1  - dphip1;
            slope_error_A1_A(i)     = a(1);
            slope_error_A1_B(i)     = a(2);
            A = eig(ddphim1 - ddphip1);
            curvature_error_A1_A(i) = A(1);
            curvature_error_A1_B(i) = A(2);
                offset_error_A2(i)    = (phim2   - phip2);
                a = dphim2  - dphip2;
                slope_error_A2_A(i)     = a(1);
                slope_error_A2_B(i)     = a(2);
                A = eig(ddphim2 - ddphip2);
                curvature_error_A2_A(i) = A(1);
                curvature_error_A2_B(i) = A(2);
                    offset_error_A3(i)    = (phim3   - phip3);
                    a = dphim3  - dphip3;
                    slope_error_A3_A(i)     = a(1);
                    slope_error_A3_B(i)     = a(2);
                    A = eig(ddphim3 - ddphip3);
                    curvature_error_A3_A(i) = A(1);
                    curvature_error_A3_B(i) = A(2);
                        offset_error_A4(i)    = (phim4   - phip4);
                        a = dphim4  - dphip4;
                        slope_error_A4_A(i)     = a(1);
                        slope_error_A4_B(i)     = a(2);
                        A = eig(ddphim4 - ddphip4);
                        curvature_error_A4_A(i) = A(1);
                        curvature_error_A4_B(i) = A(2);
            % 3.3) Deep B approach:   (x,u1k,u2k
            u1k = UU(2);    u2k = [UU(1);y1p];
            [ym,dym,ddym] = systeme_12B(UU,u1k,u2k);
            [phim1,dphim1,ddphim1] = uy2phi1(UU,ym,dym,ddym); 
                [phim2,dphim2,ddphim2] = uy2phi2(UU,ym,dym,ddym); 
                    [phim3,dphim3,ddphim3] = uy2phi3(UU,ym,dym,ddym); 
                        [phim4,dphim4,ddphim4] = uy2phi4(UU,ym,dym,ddym); 
            offset_error_B1(i)    = (phim1   - phip1);
            a = dphim1 - dphip1;
            slope_error_B1_A(i)     = a(1);
            slope_error_B1_B(i)     = a(2);
            A = eig(ddphim1 - ddphip1);
            curvature_error_B1_A(i) = A(1);
            curvature_error_B1_B(i) = A(2);
                offset_error_B2(i)    = (phim2   - phip2);
                a = dphim2 - dphip2;
                slope_error_B2_A(i)     = a(1);
                slope_error_B2_B(i)     = a(2);
                A = eig(ddphim2 - ddphip2);
                curvature_error_B2_A(i) = A(1);
                curvature_error_B2_B(i) = A(2);
                        offset_error_B3(i)    = (phim3   - phip3);
                        a = dphim3 - dphip3;
                        slope_error_B3_A(i)     = a(1);
                        slope_error_B3_B(i)     = a(2);
                        A = eig(ddphim3 - ddphip3);
                        curvature_error_B3_A(i) = A(1);
                        curvature_error_B3_B(i) = A(2);
                            offset_error_B4(i)    = (phim4   - phip4);
                            a = dphim4 - dphip4;
                            slope_error_B4_A(i)     = a(1);
                            slope_error_B4_B(i)     = a(2);
                            A = eig(ddphim4 - ddphip4);
                            curvature_error_B4_A(i) = A(1);
                            curvature_error_B4_B(i) = A(2);
            % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            iter = iter +1;
            end
        end
        VED1 = [VED1,offset_error_d1];
        SED1 = [SED1,slope_error_d1_A];   
        SED1 = [SED1,slope_error_d1_B];    
        CED1 = [CED1,curvature_error_d1_A];
        CED1 = [CED1,curvature_error_d1_B];
            VED2 = [VED2,offset_error_d2];
            SED2 = [SED2,slope_error_d2_A];    
            SED2 = [SED2,slope_error_d2_B];    
            CED2 = [CED2,curvature_error_d2_A];
            CED2 = [CED2,curvature_error_d2_B];
                VED3 = [VED3,offset_error_d3];
                SED3 = [SED3,slope_error_d3_A];   
                SED3 = [SED3,slope_error_d3_B];    
                CED3 = [CED3,curvature_error_d3_A];
                CED3 = [CED3,curvature_error_d3_B];
                    VED4 = [VED4,offset_error_d4];
                    SED4 = [SED4,slope_error_d4_A];    
                    SED4 = [SED4,slope_error_d4_B];    
                    CED4 = [CED4,curvature_error_d4_A];
                    CED4 = [CED4,curvature_error_d4_B];
        VEI1 = [VEI1,offset_error_i1];
        SEI1 = [SEI1,slope_error_i1_A];    
        SEI1 = [SEI1,slope_error_i1_B];    
        CEI1 = [CEI1,curvature_error_i1_A];
        CEI1 = [CEI1,curvature_error_i1_B];
            VEI2 = [VEI2,offset_error_i2];
            SEI2 = [SEI2,slope_error_i2_A];    
            SEI2 = [SEI2,slope_error_i2_B];    
            CEI2 = [CEI2,curvature_error_i2_A];
            CEI2 = [CEI2,curvature_error_i2_B];
                VEI3 = [VEI3,offset_error_i3];
                SEI3 = [SEI3,slope_error_i3_A];  
                SEI3 = [SEI3,slope_error_i3_B];    
                CEI3 = [CEI3,curvature_error_i3_A]; 
                CEI3 = [CEI3,curvature_error_i3_B];
                    VEI4 = [VEI4,offset_error_i4];
                    SEI4 = [SEI4,slope_error_i4_A]; 
                    SEI4 = [SEI4,slope_error_i4_B];    
                    CEI4 = [CEI4,curvature_error_i4_A]; 
                    CEI4 = [CEI4,curvature_error_i4_B];                
        VEA1 = [VEA1,offset_error_A1];
        SEA1 = [SEA1,slope_error_A1_A];    
        SEA1 = [SEA1,slope_error_A1_B];    
        CEA1 = [CEA1,curvature_error_A1_A];
        CEA1 = [CEA1,curvature_error_A1_B];   
            VEA2 = [VEA2,offset_error_A2];
            SEA2 = [SEA2,slope_error_A2_A];    
            SEA2 = [SEA2,slope_error_A2_B];    
            CEA2 = [CEA2,curvature_error_A2_A];
            CEA2 = [CEA2,curvature_error_A2_B];
                VEA3 = [VEA3,offset_error_A3];
                SEA3 = [SEA3,slope_error_A3_A];   
                SEA3 = [SEA3,slope_error_A3_B];    
                CEA3 = [CEA3,curvature_error_A3_A];
                CEA3 = [CEA3,curvature_error_A3_B];
                    VEA4 = [VEA4,offset_error_A4];
                    SEA4 = [SEA4,slope_error_A4_A];   
                    SEA4 = [SEA4,slope_error_A4_B];    
                    CEA4 = [CEA4,curvature_error_A4_A];  
                    CEA4 = [CEA4,curvature_error_A4_B];           
        VEB1 = [VEB1,offset_error_B1];
        SEB1 = [SEB1,slope_error_B1_A];    
        SEB1 = [SEB1,slope_error_B1_B];    
        CEB1 = [CEB1,curvature_error_B1_A];   
        CEB1 = [CEB1,curvature_error_B1_B];   
            VEB2 = [VEB2,offset_error_B2];
            SEB2 = [SEB2,slope_error_B2_A];   
            SEB2 = [SEB2,slope_error_B2_B];    
            CEB2 = [CEB2,curvature_error_B2_A];
            CEB2 = [CEB2,curvature_error_B2_B];
                VEB3 = [VEB3,offset_error_B3];
                SEB3 = [SEB3,slope_error_B3_A];  
                SEB3 = [SEB3,slope_error_B3_B];    
                CEB3 = [CEB3,curvature_error_B3_A];
                CEB3 = [CEB3,curvature_error_B3_B];
                    VEB4 = [VEB4,offset_error_B4];
                    SEB4 = [SEB4,slope_error_B4_A];   
                    SEB4 = [SEB4,slope_error_B4_B];    
                    CEB4 = [CEB4,curvature_error_B4_A];  
                    CEB4 = [CEB4,curvature_error_B4_B];  
        end
            end
            disp(num2str(iter/NBiter))
                end
                    end
                        end
                            end
end   
for hide_plot_figures = 1 
    figure 
   plot([0,0],[0.5,4.5],'g-','Linewidth',2)
    hold on
    n=length(CEB4) ; xx=(1:4)'; % example 
    r=repmat(xx,1,n)'; 
    g=r(:)';
    positions = [1 2 3 4]; 
    h=boxplot([CEB4',CEA4',CEI4',CED4']./10,g,'positions',positions,'Jitter',1,'Symbol','', 'Orientation','horizontal'); 
    set(h,'linewidth',2) 
    set(gca,'ytick',[1 2 3 4])
    set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex') 
    color = [ 'k' ,'b', 'y','m']; 
    
    h = findobj(gca,'Tag','Box'); 
    for j=1:length(h) 
        if j ==3 
            patch(get(h(j),'XData'),get(h(j),'YData'),[0.749, 0.5647, 0],'FaceAlpha',.5,'EdgeAlpha',0); 
        else
            patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5,'EdgeAlpha',0); 
        end
        set(h(j), 'Color', color(j), 'linewidth',1);
        h(j).Color(4) = 0;
    end 
    set(findobj(gcf,'tag','Median'), 'Color','k');
    xlim([-1.5,2])
    hXLabel = xlabel('$\frac{\nabla_u^2\phi_4 - \nabla_u^2\phi_{p,4}}{10}$');
            set([ hXLabel],'FontSize', 10 *3,'Interpreter','LaTex');
                set(gca,'FontSize',10*3);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*3; y_width=4*3;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['Exemple_Err_phi4_Ex4_Sc',num2str(Scenario)])
    %%
    figure 
    plot([0,0],[0.5,4.5],'g-','Linewidth',2)
    hold on
    n=length(CEB4) ; xx=(1:4)'; % example 
    r=repmat(xx,1,n)'; 
    g=r(:)';
    positions = [1 2 3 4]; 
    h=boxplot([CEB3',CEA3',CEI3',CED3']./100,g,'positions',positions,'Jitter',1,'Symbol','', 'Orientation','horizontal'); 
    set(h,'linewidth',2) 
    set(gca,'ytick',[1 2 3 4])
    set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex') 
    color = [ 'k' ,'b', 'y','m']; 
    h = findobj(gca,'Tag','Box'); 
    for j=1:length(h) 
        if j ==3 
            patch(get(h(j),'XData'),get(h(j),'YData'),[0.749, 0.5647, 0],'FaceAlpha',.5,'EdgeAlpha',0); 
        else
            patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5,'EdgeAlpha',0); 
        end
        set(h(j), 'Color', color(j), 'linewidth',1);
        h(j).Color(4) = 0;
    end 
    set(findobj(gcf,'tag','Median'), 'Color','k');
    xlim([-1.5,1])
    hXLabel = xlabel('$\frac{\nabla_u^2\phi_3 - \nabla_u^2\phi_{p,3}}{100}$');
            set([ hXLabel],'FontSize', 10 *3,'Interpreter','LaTex');
                set(gca,'FontSize',10*3);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*3; y_width=4*3;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['Exemple_Err_phi3_Ex4_Sc',num2str(Scenario)])
    %%
    figure 
    plot([0,0],[0.5,4.5],'g-','Linewidth',2)
    hold on
    n=length(CEB4) ; xx=(1:4)'; % example 
    r=repmat(xx,1,n)'; 
    g=r(:)';
    positions = [1 2 3 4]; 
    h=boxplot([CEB2',CEA2',CEI2',CED2']./10,g,'positions',positions,'Jitter',1,'Symbol','', 'Orientation','horizontal'); 
    set(h,'linewidth',2) 
    set(gca,'ytick',[1 2 3 4])
    set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex') 
    color = [ 'k' ,'b', 'y','m']; 
    h = findobj(gca,'Tag','Box'); 
    for j=1:length(h) 
        if j ==3 
            patch(get(h(j),'XData'),get(h(j),'YData'),[0.749, 0.5647, 0],'FaceAlpha',.5,'EdgeAlpha',0); 
        else
            patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5,'EdgeAlpha',0); 
        end
        set(h(j), 'Color', color(j), 'linewidth',1);
        h(j).Color(4) = 0;
    end 
    set(findobj(gcf,'tag','Median'), 'Color','k');
    xlim([-2,2.5])
%     hXLabel = xlabel('erreur $\phi_2/100$');
    hXLabel = xlabel('$\frac{\nabla_u^2\phi_2 - \nabla_u^2\phi_{p,2}}{10}$');
            set([ hXLabel],'FontSize', 10 *3,'Interpreter','LaTex');
                set(gca,'FontSize',10*3);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*3; y_width=4*3;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['Exemple_Err_phi2_Ex4_Sc',num2str(Scenario)])
     %%
    figure 
    plot([0,0],[0.5,4.5],'g-','Linewidth',2)
    hold on
    n=length(CEB4) ; xx=(1:4)'; % example 
    r=repmat(xx,1,n)'; 
    g=r(:)';
    positions = [1 2 3 4]; 
    h=boxplot([CEB1',CEA1',CEI1',CED1']./10,g,'positions',positions,'Jitter',1,'Symbol','', 'Orientation','horizontal'); 
    set(h,'linewidth',2) 
    set(gca,'ytick',[1 2 3 4])
    set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex') 
    color = [ 'k' ,'b', 'y','m']; 
    h = findobj(gca,'Tag','Box'); 
    for j=1:length(h) 
        if j ==3 
            patch(get(h(j),'XData'),get(h(j),'YData'),[0.749, 0.5647, 0],'FaceAlpha',.5,'EdgeAlpha',0); 
        else
            patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5,'EdgeAlpha',0); 
        end
        set(h(j), 'Color', color(j), 'linewidth',1);
        h(j).Color(4) = 0;
    end 
    set(findobj(gcf,'tag','Median'), 'Color','k');
    xlim([-0.5,1])
    hXLabel = xlabel('$\frac{\nabla_u^2\phi_1 - \nabla_u^2\phi_{p,1}}{10}$');
            set([ hXLabel],'FontSize', 25,'Interpreter','LaTex');
                set(gca,'FontSize',10*3);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*3; y_width=4*3;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['Exemple_Err_phi1_Ex4_Sc',num2str(Scenario)])
%%
%%
%%
%%
    figure 
   plot([0,0],[0.5,4.5],'g-','Linewidth',2)
    hold on
    n=length(SEB4) ; xx=(1:4)'; % example 
    r=repmat(xx,1,n)'; 
    g=r(:)';
    positions = [1 2 3 4]; 
    h=boxplot([SEB4',SEA4',SEI4',SED4']./10,g,'positions',positions,'Jitter',1,'Symbol','', 'Orientation','horizontal'); 
    set(h,'linewidth',2) 
    set(gca,'ytick',[1 2 3 4])
    set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex') 
    color = [ 'k' ,'b', 'y','m']; 
    
    h = findobj(gca,'Tag','Box'); 
    for j=1:length(h) 
        if j ==3 
            patch(get(h(j),'XData'),get(h(j),'YData'),[0.749, 0.5647, 0],'FaceAlpha',.5,'EdgeAlpha',0); 
        else
            patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5,'EdgeAlpha',0); 
        end
        set(h(j), 'Color', color(j), 'linewidth',1);
        h(j).Color(4) = 0;
    end 
    set(findobj(gcf,'tag','Median'), 'Color','k');
    xlim([-1,2.5])
    hXLabel = xlabel('$\frac{\nabla_u\phi_4 - \nabla_u\phi_{p,4}}{10}$');
            set([ hXLabel],'FontSize', 10 *3,'Interpreter','LaTex');
                set(gca,'FontSize',10*3);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*3; y_width=4*3;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['Exemple_Err_phi4_Slop_Ex4_Sc',num2str(Scenario)])
    %%
    figure 
    plot([0,0],[0.5,4.5],'g-','Linewidth',2)
    hold on
    n=length(SEB4) ; xx=(1:4)'; % example 
    r=repmat(xx,1,n)'; 
    g=r(:)';
    positions = [1 2 3 4]; 
    h=boxplot([SEB3',SEA3',SEI3',SED3']./100,g,'positions',positions,'Jitter',1,'Symbol','', 'Orientation','horizontal'); 
    set(h,'linewidth',2) 
    set(gca,'ytick',[1 2 3 4])
    set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex') 
    color = [ 'k' ,'b', 'y','m']; 
    h = findobj(gca,'Tag','Box'); 
    for j=1:length(h) 
        if j ==3 
            patch(get(h(j),'XData'),get(h(j),'YData'),[0.749, 0.5647, 0],'FaceAlpha',.5,'EdgeAlpha',0); 
        else
            patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5,'EdgeAlpha',0); 
        end
        set(h(j), 'Color', color(j), 'linewidth',1);
        h(j).Color(4) = 0;
    end 
    set(findobj(gcf,'tag','Median'), 'Color','k');
    xlim([-0.5,1.25])
    hXLabel = xlabel('$\frac{\nabla_u\phi_3 - \nabla_u\phi_{p,3}}{100}$');
            set([ hXLabel],'FontSize', 10 *3,'Interpreter','LaTex');
                set(gca,'FontSize',10*3);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*3; y_width=4*3;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['Exemple_Err_phi3_Slop_Ex4_Sc',num2str(Scenario)])
    %%
    figure 
    plot([0,0],[0.5,4.5],'g-','Linewidth',2)
    hold on
    n=length(CEB4) ; xx=(1:4)'; % example 
    r=repmat(xx,1,n)'; 
    g=r(:)';
    positions = [1 2 3 4]; 
    h=boxplot([SEB2',SEA2',SEI2',SED2']./1,g,'positions',positions,'Jitter',1,'Symbol','', 'Orientation','horizontal'); 
    set(h,'linewidth',2) 
    set(gca,'ytick',[1 2 3 4])
    set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex') 
    color = [ 'k' ,'b', 'y','m']; 
    h = findobj(gca,'Tag','Box'); 
    for j=1:length(h) 
        if j ==3 
            patch(get(h(j),'XData'),get(h(j),'YData'),[0.749, 0.5647, 0],'FaceAlpha',.5,'EdgeAlpha',0); 
        else
            patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5,'EdgeAlpha',0); 
        end
        set(h(j), 'Color', color(j), 'linewidth',1);
        h(j).Color(4) = 0;
    end 
    set(findobj(gcf,'tag','Median'), 'Color','k');
    xlim([-5,5.5])
%     hXLabel = xlabel('erreur $\phi_2/100$');
    hXLabel = xlabel('$\nabla_u\phi_2 - \nabla_u\phi_{p,2}$');
            set([ hXLabel],'FontSize', 10 *3,'Interpreter','LaTex');
                set(gca,'FontSize',10*3);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*3; y_width=4*3;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['Exemple_Err_phi2_Slop_Ex4_Sc',num2str(Scenario)])
     %%
    figure 
    plot([0,0],[0.5,4.5],'g-','Linewidth',2)
    hold on
    n=length(CEB4) ; xx=(1:4)'; % example 
    r=repmat(xx,1,n)'; 
    g=r(:)';
    positions = [1 2 3 4]; 
    h=boxplot([SEB1',SEA1',SEI1',SED1']./10,g,'positions',positions,'Jitter',1,'Symbol','', 'Orientation','horizontal'); 
    set(h,'linewidth',2) 
    set(gca,'ytick',[1 2 3 4])
    set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex') 
    color = [ 'k' ,'b', 'y','m']; 
    h = findobj(gca,'Tag','Box'); 
    for j=1:length(h) 
        if j ==3 
            patch(get(h(j),'XData'),get(h(j),'YData'),[0.749, 0.5647, 0],'FaceAlpha',.5,'EdgeAlpha',0); 
        else
            patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5,'EdgeAlpha',0); 
        end
        set(h(j), 'Color', color(j), 'linewidth',1);
        h(j).Color(4) = 0;
    end 
    set(findobj(gcf,'tag','Median'), 'Color','k');
    xlim([-0.5,1.5])
    hXLabel = xlabel('$\frac{\nabla_u\phi_1 - \nabla_u\phi_{p,1}}{10}$');
            set([ hXLabel],'FontSize', 25,'Interpreter','LaTex');
                set(gca,'FontSize',10*3);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*3; y_width=4*3;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['Exemple_Err_phi1_Slop_Ex3_Sc',num2str(Scenario)])

end    
   
  
%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')




%% Functions
function [y1,dy1_du1,ddy1_du1] = systeme_1p(u1)   
    global a1p b1p c1p
    y1       = a1p + b1p*u1 + c1p*u1^2 ;
    dy1_du1  =       b1p    + c1p*u1*2;
    ddy1_du1 =                c1p*2;
end
function [y2,dy2_du2,ddy2_du2] = systeme_2p(u2)   
    global a2p b2p c2p
    y2       = a2p + b2p*u2(1) + c2p*u2(1)^2 + c2p*u2(2)^2;
    dy2_du2  = [b2p+2*c2p*u2(1); 2*c2p*u2(2)];
    ddy2_du2 = [2*c2p,0; 0,  2*c2p];          
end
function [y,dy_dx,ddy_dx, dy1] = systeme_12p(x)   
    global a1p b1p c1p a2p b2p c2p
    
    y1   = a1p+b1p*x(1)+c1p*x(1)^2;
    dy1  = [b1p+c1p*x(1)*2;0];
    ddy1 = [c1p*2,0;0,0];
    
    y2   = a2p + b2p*x(2) + c2p*x(2)^2 + c2p*y1^2;
    dy2  = [c2p*dy1(1)*y1*2;  b2p+c2p*x(2)*2];
    ddy2 = [c2p*ddy1(1,1)*y1*2+c2p*dy1(1)^2*2,0; 0,c2p*2];
    
    y   = y2;
    dy_dx  = dy2;
    ddy_dx = ddy2;
end

function [y1,dy1_du1,ddy1_du1] = systeme_1(u1)     
    global a1 b1 c1; 
    y1       = a1 + b1*u1 + c1*u1^2;
    dy1_du1  =              c1*u1*2;
    ddy1_du1 =              c1*2;
end
function [y2,dy2_du2,ddy2_du2] = systeme_2(u2)     
    global a2 b2 c2
    y2   = a2 + b2*u2(1) +c2*u2(1)^2 + c2*u2(2)^2;
    dy2_du2  = [b2+2*c2*u2(1); 2*c2*u2(2)];
    ddy2_du2 = [2*c2,0; 0,  2*c2];   
end
function [y,dy_dx,ddy_dx,dy1]  = systeme_12(x)     
    global a1 b1 c1 a2 b2 c2;
    
    y1   = a1+b1*x(2)+c1*x(2)^2;
    dy1  = [0; b1+c1*x(2)*2];
    ddy1 = [0,0;0,c1*2];
        y2   = a2 + b2*x(1) + c2*x(1)^2 + c2*y1^2;
        dy2  = [b2+c2*x(1)*2;  c2*dy1(2)*y1*2];
        ddy2 = [c2*2,0; 0,c2*ddy1(2,2)*y1*2+c2*dy1(2)^2*2];
            y      = y2;
            dy_dx  = dy2;
            ddy_dx = ddy2;
end
function [y,dy,ddy,dy1]        = systeme_12A(x,xk) 

    global a1 b1 c1 a2 b2 c2 epsilon_1AB   epsilon_2AB  lambda_1A  lambda_2A  
    
     y1   = a1+b1*x(2)+c1*x(2)^2 + epsilon_1AB+lambda_1A'*(x-xk); 
    dy1  = [0; b1+c1*x(2)*2]     + lambda_1A;
    ddy1 = [0,0;0,c1*2];
        y2   = a2 + b2*x(1) + c2*x(1)^2 + c2*y1^2                   + epsilon_2AB+lambda_2A'*(x-xk);
        dy2  = [b2+c2*x(1)*2 + c2*dy1(1)*y1*2;  c2*dy1(2)*y1*2]     + lambda_2A;
        ddy2 = [c2*2 + c2*dy1(1)*dy1(1)*2  , c2*dy1(1)*dy1(2)*2; ...
                c2*dy1(1)*dy1(2)*2         , c2*ddy1(2,2)*y1*2+c2*dy1(2)^2*2];
            y   = y2;
            dy  = dy2;
            ddy = ddy2;

end
function [y,dy,ddy]            = systeme_12B(x,u1k,u2k)  

    global a1 b1 c1 a2 b2 c2  epsilon_1AB   epsilon_2AB  lambda_1B  lambda_2B
    
    y1   = a1+b1*x(2)+c1*x(2)^2 + epsilon_1AB+ lambda_1B'*(x(2)-u1k); 
    dy1  = [0; b1+c1*x(2)*2]    + lambda_1B;
    ddy1 = [0,0;0,c1*2];
    
        u2 = [x(1);y1];
        y2   = a2 + b2*x(1) + c2*x(1)^2 + c2*y1^2                   + epsilon_2AB+lambda_2B'*(u2-u2k);
        dy2  = [b2+c2*x(1)*2 + c2*dy1(1)*y1*2;  c2*dy1(2)*y1*2]     + [lambda_2B(1)+lambda_2B(2)*dy1(1);lambda_2B(2)*dy1(2)];
        ddy2 = [c2*2 + c2*dy1(1)*dy1(1)*2  , c2*dy1(1)*dy1(2)*2; ...
                c2*dy1(1)*dy1(2)*2         , c2*ddy1(2,2)*y1*2+c2*dy1(2)^2*2] + ...
               [0,0;0,lambda_2B(2)*ddy1(2,2)];
            y   = y2;
            dy  = dy2;
            ddy = ddy2;
end


function [phi,dphi,ddphi] = uy2phi1(u,y,dy,ddy)
    global ap1 bp1 cp1 dp1 ep1 
    uu = u(1) + u(2);
    phi   = ap1*uu + bp1*y + cp1*uu^2 + dp1*uu*y + ep1*y^2;
    dphi  = [ap1 + 2*cp1*uu + dp1*y;  ...
             ap1 + 2*cp1*uu + dp1*y]+ ...
             dy*(bp1+dp1*uu(1)+2*ep1*y);
    ddphi = 2*cp1*[1,1;1,1] + dp1*[dy';dy'] +  ddy*(bp1+dp1*uu(1)+2*ep1*y) + dy*(dp1*[1,1]+2*ep1*dy');
end
function [phi,dphi,ddphi] = uy2phi2(u,y,dy,ddy)
    global ap2 bp2 cp2 dp2 ep2 
    uu = u(1) + u(2);
    phi   = ap2*uu + bp2*y + cp2*uu^2 + dp2*uu*y + ep2*y^2;
    dphi  = [ap2 + 2*cp2*uu + dp2*y;  ...
             ap2 + 2*cp2*uu + dp2*y]+ ...
             dy*(bp2+dp2*uu(1)+2*ep2*y);
    ddphi = 2*cp2*[1,1;1,1] + dp2*[dy';dy'] +  ddy*(bp2+dp2*uu(1)+2*ep2*y) + dy*(dp2*[1,1]+2*ep2*dy');
end
function [phi,dphi,ddphi] = uy2phi3(u,y,dy,ddy)
    global ap3 bp3 cp3 dp3 ep3 
    uu = u(1) + u(2);
    phi   = ap3*uu + bp3*y + cp3*uu^2 + dp3*uu*y + ep3*y^2;
    dphi  = [ap3 + 2*cp3*uu + dp3*y;  ...
             ap3 + 2*cp3*uu + dp3*y]+ ...
             dy*(bp3+dp3*uu(1)+2*ep3*y);
    ddphi = 2*cp3*[1,1;1,1] + dp3*[dy';dy'] +  ddy*(bp3+dp3*uu(1)+2*ep3*y) + dy*(dp3*[1,1]+2*ep3*dy');
end
function [phi,dphi,ddphi] = uy2phi4(u,y,dy,ddy)
    global ap4 bp4 cp4 dp4 ep4
    uu = u(1) + u(2);
    phi   = ap4*uu + bp4*y + cp4*uu^2 + dp4*uu*y + ep4*y^2;
    dphi  = [ap4 + 2*cp4*uu + dp4*y;  ...
             ap4 + 2*cp4*uu + dp4*y]+ ...
             dy*(bp4+dp4*uu(1)+2*ep4*y);
    ddphi = 2*cp4*[1,1;1,1] + dp4*[dy';dy'] +  ddy*(bp4+dp4*uu(1)+2*ep4*y) + dy*(dp4*[1,1]+2*ep4*dy');
end
