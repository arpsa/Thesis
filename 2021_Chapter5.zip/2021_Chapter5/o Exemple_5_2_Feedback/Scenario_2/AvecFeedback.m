clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic
%% Code architecture initialization & Output files 
Results_file_name = 'Results';

Scenario = 2; 

global a1 b1 c1 a2 b2 c2         ...
       a1p b1p c1p a2p b2p c2p   ...
       ap1 bp1 cp1 dp1 ep1       ...
       ap2 bp2 cp2 dp2 ep2       ...
       ap3 bp3 cp3 dp3 ep3       ...
       ap4 bp4 cp4 dp4 ep4       ...
       epsilon_1AB   epsilon_2AB ...
       lambda_1A  lambda_2A      ...
       lambda_1B  lambda_2B H fsolve_options
H=1e-4;

% a1p= 2;   b1p=[-2;0.01];     c1p = [0.01 0.08;0.08 0.0020];         a2p= 2;  b2p= -2;   c2p= 2;
% a1 = 1.5; b1 =[-1.5;0.01] ; c1  = [0.008 0.08; 0.0800  0.0016];  a2 = 1;  b2 = -1 ;  c2 = 1.5; 
a1p= 1;   b1p=[-1;0.01];     c1p = [0.01 0.08;0.08 0.0020];         a2p = 2;  b2p= -2;   c2p = 2*0;
a1 = 1.5; b1 =[-1.5;0.01] ;  c1  = [0.008 0.08; 0.0800  0.0016];     a2  = 1;  b2 = -1 ;     c2  = 1.5*0; 
%                            ^
%                            0.0080    0.0800
%                            0.0800    0.0016
  
% Autres scenario:
% a1p= 2;   b1p=[-2;0.01];    c1p= [0.01 0.1;0.1 0]*0;    a2p= 2;   b2p= -2;       c2p= 2;
% a1 = 1.5; b1 =[-1.5;-0.01] ; c1 = c1p*0.9;   a2 = 1;  b2 = -1 ;  c2 = 1.5; 
% a1 = 1.5; b1 =[-1.5;-0.01] ; c1  = [0.008 0.08; 0.0800  0.0016];  a2 = 1;  b2 = -1 ;  c2 = 1.5; 

delta1 = 0.25;
delta2 = 0.25;
a1min= a1p-delta1;  a1max= a1p+delta1;     n_a1 = 3;    A1 = a1min:(a1max-a1min)/(n_a1-1):a1max;
b1min= b1p-delta1;  b1max= b1p+delta1;     n_b1 = 3;    B1 = b1min:(b1max-b1min)/(n_b1-1):b1max;
c1min= 0.07;        c1max= 0.09;           n_c1 = 3;    C1 = c1min:(c1max-c1min)/(n_c1-1):c1max;
a2min= a2p-delta2;  a2max= a2p+delta2;     n_a2 = 3;    A2 = a2min:(a2max-a2min)/(n_a2-1):a2max;
b2min= b2p-delta2;  b2max= b2p+delta2;     n_b2 = 3;    B2 = b2min:(b2max-b2min)/(n_b2-1):b2max;
C2 = 0; % c2min= c2p-0.2;     c2max= c2p+0.2;        n_c2 = 3;    C2 = c2min:(c2max-c2min)/(n_c2-1):c2max;

% Parameters of the four cost functions
ap1= 0 ; bp1= 1; cp1= 0;   dp1= 0 ;    ep1= 0;
ap2= 0 ; bp2= 0; cp2= 0;   dp2= 1 ;    ep2= 0;
ap3= 0 ; bp3= 0; cp3= 0;   dp3= 0 ;    ep3= 1;
ap4= 0 ; bp4= 1; cp4= 1;   dp4= 0.5 ;  ep4= 0.05;
%%
fsolve_options = optimset('Algorithm','levenberg-marquardt',...levenberg-marquardt     trust-region-reflective
                          'LargeScale','on',...
                          'Diagnostics','off',...
                          'Display','off' ,...  final off  on 
                          'FunValCheck','on',...
                          'MaxFunEvals',100000,...
                          'MaxIter',100000,...
                          'TolFun',1e-15, ...
                          'TolX',1e-15, ...
                          'TolCon',1e-15);
%% Plot plant functions:
for hide_plot_pant = [] 
    xmin = -1; xmax = 1;
    nx = 100;
    dx = (xmax-xmin)/(nx-1);
    x = xmin:dx:xmax;
    phi_1 = 1; phi_2 = 2; phi_3 = 3; phi_4 = 4;
    Sys12 = 5; Sys1 = 6;  Sys2 = 7;
        figure(phi_1); figure(phi_2); figure(phi_3); figure(phi_4);
        figure(Sys12); figure(Sys2);
        figure(Sys1); 
            grid on
            view([49 11]); 
        iter = 0;
        
        NBiter = length(A1)*length(B1)*length(C1)*length(A2)*length(B2)*length(C2)*nx;
                                for  ii = 1:length(A1)
                            for      jj = 1:length(B1)
                        for          kk = 1:length(C1)
                    for             iii = 1:length(A2)
                for                 jjj = 1:length(B2)
            for                     kkk = 1:length(C2)
                a1 = A1(ii);         a2 = A2(iii);
                b1 = [B1(jj);0.01]; b2 = B2(jjj);
                c1 = [0.01 C1(kk); C1(kk)  0.002]; c2 = C2(kkk);  
                for i=1:length(x)
                    y_12(i) = systeme_12(x(i));
                    u1      = [x(i);y_12(i)];
                    y_1(i)   = systeme_1(u1);
                    [PHI1(i),~,~] = uy2phi1(x(i),y_12(i),0,0);
                    [PHI2(i),~,~] = uy2phi2(x(i),y_12(i),0,0);
                    [PHI3(i),~,~] = uy2phi3(x(i),y_12(i),0,0);
                    [PHI4(i),~,~] = uy2phi4(x(i),y_12(i),0,0);
                    iter = iter +1;
                end
                figure(phi_1)
                hold on
                h = plot(x,PHI1,'-','Color','r', 'LineWidth', 0.2);
                h.Color(4) = 0.1;
                    figure(phi_2)
                    hold on
                    h = plot(x,PHI2,'-','Color','r', 'LineWidth', 0.2);
                    h.Color(4) = 0.1;
                        figure(phi_3)
                        hold on
                        h = plot(x,PHI3,'-','Color','r', 'LineWidth', 0.2);
                        h.Color(4) = 0.1;
                            figure(phi_4)
                            hold on
                            h = plot(x,PHI4,'-','Color','r', 'LineWidth', 0.2);
                            h.Color(4) = 0.1;
                                figure(Sys12)
                                hold on
                                h = plot(x,y_12,'-','Color','r', 'LineWidth', 0.2);
                                h.Color(4) = 0.1;
                                    figure(Sys1)
                                    hold on
                                    h = plot3(x,y_12,y_1,'-','Color','r', 'LineWidth', 0.2);
                                    h.Color(4) = 0.1;
                                        figure(Sys2)
                                        hold on
                                        h = plot(y_1,y_12,'-','Color','r', 'LineWidth', 0.2);
                                        h.Color(4) = 0.1;
            end
                end
                    end
                    disp(num2str(iter/NBiter))
                        end
                            end
                                end
            
        for i=1:length(x)
            y_12p(i) = systeme_12p(x(i));
            u1p      = [x(i);y_12p(i)];
            y_1p(i)   = systeme_1p(u1p);
            [PHI1p(i),~,~] = uy2phi1(x(i),y_12p(i),0,0);
            [PHI2p(i),~,~] = uy2phi2(x(i),y_12p(i),0,0);
            [PHI3p(i),~,~] = uy2phi3(x(i),y_12p(i),0,0);
            [PHI4p(i),~,~] = uy2phi4(x(i),y_12p(i),0,0);
        end
        figure(phi_1)
        hold on
        h = plot(x,PHI1p,'k', 'LineWidth', 2);
        ylim([-1,2.5])
            hXLabel = xlabel('$u$');
            hYLabel = ylabel('$\phi_1$');
            set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_phi1_Ex2_Sc',num2str(Scenario)])

        figure(phi_2)
        hold on
        h = plot(x,PHI2p,'k', 'LineWidth', 2);
        ylim([-0.5,3])
             hXLabel = xlabel('$u$');
            hYLabel = ylabel('$\phi_2$');
            set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_phi2_Ex2_Sc',num2str(Scenario)])

        figure(phi_3)
        ylim([0,10])
        hold on
        h = plot(x,PHI3p,'k', 'LineWidth', 2);
            hXLabel = xlabel('$u$');
            hYLabel = ylabel('$\phi_3$');
            set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_phi3_Ex2_Sc',num2str(Scenario)])

        figure(phi_4)
        hold on
        h = plot(x,PHI4p,'k', 'LineWidth', 2);
            hXLabel = xlabel('$u$');
            hYLabel = ylabel('$\phi_4$');
            set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_phi4_Ex2_Sc',num2str(Scenario)])

        figure(Sys12)
        hold on
        h = plot(x,y_12p,'k', 'LineWidth', 2);
            hXLabel = xlabel('$u$');
            hYLabel = ylabel('$y^{(2)}$');
            set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_Sys12_Ex2_Sc',num2str(Scenario)])
%%
        figure(Sys1)
        hold on
        h = plot3(x,y_12p,y_1p,'k', 'LineWidth', 2);
        grid on
%         view([70 10]);
        view([105 38]);
            yticks([-14:2:14])
            hXLabel = xlabel('$u$');
            hYLabel = ylabel('$y^{(2)}$');
            hZLabel = zlabel('$y^{(1)}$');
            set([hXLabel, hYLabel,hZLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',0.5);
            set(gca,'Layer','Top');
%             set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=6; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_Sys1_Ex2_Sc',num2str(Scenario)])
%%
        figure(Sys2)
        hold on
        h = plot(y_1p,y_12p,'k', 'LineWidth', 2);
            hXLabel = xlabel('$y^{(1)}$');
            hYLabel = ylabel('$y^{(2)}$');
            set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-r620','-djpeg',['Exemple_Sys2_Ex2_Sc',num2str(Scenario)])
end
%% Analyse statistique:
for hide_Analysis = 1  
    delta1 = 0.25;
    delta2 = 0.25;
    a1min= a1p-delta1;  a1max= a1p+delta1;     n_a1 = 6;    A1 = a1min:(a1max-a1min)/(n_a1-1):a1max; % <<<<<<<<<<<<<<
    b1min= b1p-delta1;  b1max= b1p+delta1;     n_b1 = 6;    B1 = b1min:(b1max-b1min)/(n_b1-1):b1max; % <<<<<<<<<<<<<<
    c1min= 0.07;        c1max= 0.09;           n_c1 = 6;    C1 = c1min:(c1max-c1min)/(n_c1-1):c1max; % <<<<<<<<<<<<<<
    a2min= a2p-delta2;  a2max= a2p+delta2;     n_a2 = 6;    A2 = a2min:(a2max-a2min)/(n_a2-1):a2max; % <<<<<<<<<<<<<<
    b2min= b2p-delta2;  b2max= b2p+delta2;     n_b2 = 6;    B2 = b2min:(b2max-b2min)/(n_b2-1):b2max; % <<<<<<<<<<<<<<
    C2 = 0; % c2min= c2p-0.2;     c2max= c2p+0.2;        n_c2 =6;    C2 = c2min:(c2max-c2min)/(n_c2-1):c2max; % <<<<<<<<<<<<<<

    
    VED1=[];VED2=[];VED3=[];VED4=[];
    SED1=[];SED2=[];SED3=[];SED4=[];
    CED1=[];CED2=[];CED3=[];CED4=[];
    
    VEI1=[];VEI2=[];VEI3=[];VEI4=[];
    SEI1=[];SEI2=[];SEI3=[];SEI4=[];
    CEI1=[];CEI2=[];CEI3=[];CEI4=[];
    
    VEA1=[];VEA2=[];VEA3=[];VEA4=[];
    SEA1=[];SEA2=[];SEA3=[];SEA4=[];
    CEA1=[];CEA2=[];CEA3=[];CEA4=[];
    
    VEB1=[];VEB2=[];VEB3=[];VEB4=[];
    SEB1=[];SEB2=[];SEB3=[];SEB4=[];
    CEB1=[];CEB2=[];CEB3=[];CEB4=[];
    
    x_min=-1;   x_max=1;   dx=(x_max-x_min)/2; % <<<<<<<<<<<<<<
    x=x_min:dx:x_max;
    iter   = 0;
    NBiter = length(A1)*length(B1)*length(C1)*length(A2)*length(B2)*length(C2)*length(x);
                            for  ii = 1:length(A1)
                        for      jj = 1:length(B1)
                    for          kk = 1:length(C1)
                for             iii = 1:length(A2)
            for                 jjj = 1:length(B2)
        for                     kkk = 1:length(C2)
        a1 = A1(ii);                       a2 = A2(iii);
        b1 = [B1(jj);0.01];                b2 = B2(jjj);
        c1 = [0.01 C1(kk); C1(kk)  0.002]; c2 = C2(kkk);  
    for i=1:length(x)
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % 1) Evaluate plant & model values and gradients:
        [yp,dyp,ddyp] = systeme_12p(x(i));     [y,dy,ddy] = systeme_12(x(i));
        u1 = [x(i);yp];
        [y1p,dy1p]    = systeme_1p(u1);   [y1,dy1]   = systeme_1(u1);
        [y2p,dy2p]    = systeme_2p(y1p);  [y2,dy2]   = systeme_2(y1p); % Notice that we use "y1p", not "y1"
        [phip1,dphip1,ddphip1] = uy2phi1(x(i),yp,dyp,ddyp); 
        [phi1,dphi1,ddphi1]    = uy2phi1(x(i),y,dy,ddy);   
            [phip2,dphip2,ddphip2] = uy2phi2(x(i),yp,dyp,ddyp); 
            [phi2,dphi2,ddphi2]    = uy2phi2(x(i),y,dy,ddy);  
                [phip3,dphip3,ddphip3] = uy2phi3(x(i),yp,dyp,ddyp); 
                [phi3,dphi3,ddphi3]    = uy2phi3(x(i),y,dy,ddy); 
                    [phip4,dphip4,ddphip4] = uy2phi4(x(i),yp,dyp,ddyp); 
                    [phi4,dphi4,ddphi4]    = uy2phi4(x(i),y,dy,ddy);   
        % 2) Construct correction structures
        % 2.1) Direct approach:
        epsilon_d1 = phip1  - phi1;   %ok
        lambda_d1  = dphip1 - dphi1;  %ok
            epsilon_d2 = phip2  - phi2;   %ok
            lambda_d2  = dphip2 - dphi2;  %ok
                epsilon_d3 = phip3  - phi3;   %ok
                lambda_d3  = dphip3 - dphi3;  %ok
                    epsilon_d4 = phip4  - phi4;   %ok
                    lambda_d4  = dphip4 - dphi4;  %ok
        % 2.2) Indirect approach:
        epsilon_i = yp  - y;       %ok
        lambda_i  = dyp - dy;      %ok
        % 2.3) Deep A and B approaches:
        epsilon_1AB = y1p - y1;                            epsilon_2AB  = y2p - y2;        %ok
        lambda_1A   = [1;dyp]'*dy1p - [1;dyp]'*dy1;  lambda_2A    = dyp - [1;dyp]'*dy1p*dy2;  %ok
        lambda_1B   = dy1p - dy1;                            lambda_2B    = dy2p - dy2;      %ok
        
%         offset_error_A1
        
        % 3) correct models and evaluate Hessian errors
        % 3.1) Direct approach:
        offset_error_d1(i)    = (phi1 +epsilon_d1 - phip1);
        slope_error_d1(i)     = (dphi1+lambda_d1 - dphip1);
        curvature_error_d1(i) = (ddphi1 - ddphip1);
            offset_error_d2(i)    = (phi2 +epsilon_d2 - phip2);
            slope_error_d2(i)     = (dphi2+lambda_d2 - dphip2);
            curvature_error_d2(i) = (ddphi2 - ddphip2);
                offset_error_d3(i)    = (phi3 +epsilon_d3 - phip3);
                slope_error_d3(i)     = (dphi3+lambda_d3 - dphip3);
                curvature_error_d3(i) = (ddphi3 - ddphip3);
                    offset_error_d4(i)    = (phi4 +epsilon_d4 - phip4);
                    slope_error_d4(i)     = (dphi4+lambda_d4 - dphip4);
                    curvature_error_d4(i) = (ddphi4 - ddphip4);
        % 3.2) Indirect approach:
        ym  = y  + epsilon_i;      
        dym = dy + lambda_i;
        [phim1,dphim1,ddphim1] = uy2phi1(x(i),ym,dym,ddy);
            [phim2,dphim2,ddphim2] = uy2phi2(x(i),ym,dym,ddy);
                [phim3,dphim3,ddphim3] = uy2phi3(x(i),ym,dym,ddy);
                	[phim4,dphim4,ddphim4] = uy2phi4(x(i),ym,dym,ddy); 
        offset_error_i1(i)    = (phim1   - phip1);
        slope_error_i1(i)     = (dphim1  - dphip1);
        curvature_error_i1(i) = (ddphim1 - ddphip1);
            offset_error_i2(i)    = (phim2   - phip2);
            slope_error_i2(i)     = (dphim2  - dphip2);
            curvature_error_i2(i) = (ddphim2 - ddphip2);
                offset_error_i3(i)    = (phim3   - phip3);
                slope_error_i3(i)     = (dphim3  - dphip3);
                curvature_error_i3(i) = (ddphim3 - ddphip3);
                    offset_error_i4(i)    = (phim4   - phip4);
                    slope_error_i4(i)     = (dphim4  - dphip4);
                    curvature_error_i4(i) = (ddphim4 - ddphip4);
        % 3.3) Deep A approach:
        [ym,dym,ddym]       = systeme_12A(x(i));
        [phim1,dphim1,ddphim1] = uy2phi1(x(i),ym,dym,ddym); 
            [phim2,dphim2,ddphim2] = uy2phi2(x(i),ym,dym,ddym); 
                [phim3,dphim3,ddphim3] = uy2phi3(x(i),ym,dym,ddym); 
                    [phim4,dphim4,ddphim4] = uy2phi4(x(i),ym,dym,ddym); 
        offset_error_A1(i)    = (phim1   - phip1);
        slope_error_A1(i)     = (dphim1  - dphip1);
        curvature_error_A1(i) = (ddphim1 - ddphip1);
            offset_error_A2(i)    = (phim2   - phip2);
            slope_error_A2(i)     = (dphim2  - dphip2);
            curvature_error_A2(i) = (ddphim2 - ddphip2);
                offset_error_A3(i)    = (phim3   - phip3);
                slope_error_A3(i)     = (dphim3  - dphip3);
                curvature_error_A3(i) = (ddphim3 - ddphip3);
                    offset_error_A4(i)    = (phim4   - phip4);
                    slope_error_A4(i)     = (dphim4  - dphip4);
                    curvature_error_A4(i) = (ddphim4 - ddphip4);
        % 3.3) Deep B approach:   (x,u1k,u2k
        u1k = [x(i);y2p];   u2k = y1p;
        [ym,dym,ddym] = systeme_12B(x(i),u1k,u2k);
        [phim1,dphim1,ddphim1] = uy2phi1(x(i),ym,dym,ddym); 
            [phim2,dphim2,ddphim2] = uy2phi2(x(i),ym,dym,ddym); 
                [phim3,dphim3,ddphim3] = uy2phi3(x(i),ym,dym,ddym); 
                    [phim4,dphim4,ddphim4] = uy2phi4(x(i),ym,dym,ddym); 
        offset_error_B1(i)    = (phim1   - phip1);
        slope_error_B1(i)     = (dphim1  - dphip1);
        curvature_error_B1(i) = (ddphim1 - ddphip1);
            offset_error_B2(i)    = (phim2   - phip2);
            slope_error_B2(i)     = (dphim2  - dphip2);
            curvature_error_B2(i) = (ddphim2 - ddphip2);
                    offset_error_B3(i)    = (phim3   - phip3);
                    slope_error_B3(i)     = (dphim3  - dphip3);
                    curvature_error_B3(i) = (ddphim3 - ddphip3);
                        offset_error_B4(i)    = (phim4   - phip4);
                        slope_error_B4(i)     = (dphim4  - dphip4);
                        curvature_error_B4(i) = (ddphim4 - ddphip4);
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        iter = iter +1;
    end
    VED1 = [VED1,offset_error_d1];
    SED1 = [SED1,slope_error_d1];    
    CED1 = [CED1,curvature_error_d1];
        VED2 = [VED2,offset_error_d2];
        SED2 = [SED2,slope_error_d2];    
        CED2 = [CED2,curvature_error_d2];
            VED3 = [VED3,offset_error_d3];
            SED3 = [SED3,slope_error_d3];    
            CED3 = [CED3,curvature_error_d3];
                VED4 = [VED4,offset_error_d4];
                SED4 = [SED4,slope_error_d4];    
                CED4 = [CED4,curvature_error_d4];
    VEI1 = [VEI1,offset_error_i1];
    SEI1 = [SEI1,slope_error_i1];    
    CEI1 = [CEI1,curvature_error_i1];
        VEI2 = [VEI2,offset_error_i2];
        SEI2 = [SEI2,slope_error_i2];    
        CEI2 = [CEI2,curvature_error_i2];
            VEI3 = [VEI3,offset_error_i3];
            SEI3 = [SEI3,slope_error_i3];    
            CEI3 = [CEI3,curvature_error_i3];
                VEI4 = [VEI4,offset_error_i4];
                SEI4 = [SEI4,slope_error_i4];    
                CEI4 = [CEI4,curvature_error_i4];                
    VEA1 = [VEA1,offset_error_A1];
    SEA1 = [SEA1,slope_error_A1];    
    CEA1 = [CEA1,curvature_error_A1];   
        VEA2 = [VEA2,offset_error_A2];
        SEA2 = [SEA2,slope_error_A2];    
        CEA2 = [CEA2,curvature_error_A2];
            VEA3 = [VEA3,offset_error_A3];
            SEA3 = [SEA3,slope_error_A3];    
            CEA3 = [CEA3,curvature_error_A3];
                VEA4 = [VEA4,offset_error_A4];
                SEA4 = [SEA4,slope_error_A4];    
                CEA4 = [CEA4,curvature_error_A4];           
    VEB1 = [VEB1,offset_error_B1];
    SEB1 = [SEB1,slope_error_B1];    
    CEB1 = [CEB1,curvature_error_B1];   
        VEB2 = [VEB2,offset_error_B2];
        SEB2 = [SEB2,slope_error_B2];    
        CEB2 = [CEB2,curvature_error_B2];
            VEB3 = [VEB3,offset_error_B3];
            SEB3 = [SEB3,slope_error_B3];    
            CEB3 = [CEB3,curvature_error_B3];
                VEB4 = [VEB4,offset_error_B4];
                SEB4 = [SEB4,slope_error_B4];    
                CEB4 = [CEB4,curvature_error_B4];                      
                       

        end
            end
            disp(num2str(iter/NBiter))
                end
                    end
                        end
                            end
                                
    
%     x_min = -1; x_max = 1; dx = (x_max-x_min)/9;
%     x_test = x_min:dx:x_max;
%     for i =1:length(x_test)
%         x = x_test(i);
%         % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%         % 1) Evaluate plant & model values and gradients:
%         [yp,dyp_du,ddyp_du,du1p_du,du2p_du,dy1_du, ddy1_du] = systeme_12p(x);   [y,dy_du,ddy_du] = systeme_12(x);
%         u1p = [x;yp];
%         [y1p,dy1p]    = systeme_1p(u1p); [y1,dy1]   = systeme_1(u1p); 
%         u2p = y1p;
%         [y2p,dy2p]    = systeme_2p(u2p);  [y2,dy2]   = systeme_2(u2p); % Notice that we use "y1p", not "y1"
%         
%         [phip,dphip,ddphip] = uy2phi(x,yp,dyp_du,ddyp_du); 
%         [phi,dphi,ddphi]    = uy2phi(x,y,dy_du,ddy_du); 
%         % 2) Construct correction structures
%         % 2.1) Direct approach:
%         epsilon_d = phip  - phi;   %ok
%         lambda_d  = dphip - dphi;  %ok
%         % 2.2) Indirect approach:
%         epsilon_i = yp  - y;       %ok
%         lambda_i  = dyp_du - dy_du;      %ok
%         % 2.3) Deep A and B approaches:
%         epsilon_1AB = y1p - y1;               epsilon_2AB  = y2p - y2;              %ok
%         lambda_1A   = dy1_du - dy1'*du1p_du;  lambda_2A    = dyp_du - dy2*du2p_du;  %ok
%         lambda_1B   = dy1p - dy1;             lambda_2B    = dy2p - dy2;            %ok
%         % 3) correct models and evaluate Hessian errors
%         % 3.1) Direct approach:
%         offset_error_d(i)    = abs(phi +epsilon_d - phip);
%         slope_error_d(i)     = abs(dphi+lambda_d - dphip);
%         curvature_error_d(i) = abs(ddphi - ddphip);
%         % 3.2) Indirect approach:
%         ym  = y  + epsilon_i;      
%         dym = dy_du + lambda_i;
%         [phim,dphim,ddphim] = uy2phi(x,ym,dym,ddy_du); 
%         offset_error_i(i)    = abs(phim   - phip);
%         slope_error_i(i)     = abs(dphim  - dphip);
%         curvature_error_i(i) = abs(ddphim - ddphip);
%         % 3.3) Deep A approach:
%         [ym,dym,ddym]       = systeme_12A(x);
%         [phim,dphim,ddphim] = uy2phi(x,ym,dym,ddym); 
%         offset_error_A(i)    = abs(phim   - phip);
%         slope_error_A(i)     = abs(dphim  - dphip);
%         curvature_error_A(i) = abs(ddphim - ddphip);
%         % 3.3) Deep B approach:
% %         u1k = [x;yp]; u2k = y1p; 
%         [ym,dym,ddym]       = systeme_12B(x,u1p,u2p);
%         [phim,dphim,ddphim] = uy2phi(x,ym,dym,ddym); 
%         offset_error_B(i)    = abs(phim   - phip);
%         slope_error_B(i)     = abs(dphim  - dphip);
%         curvature_error_B(i) = abs(ddphim - ddphip);
%         % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%     end
end   
% Figures stat
for hide_plot_figures = 1
    figure 
   plot([0,0],[0.5,4.5],'g-','Linewidth',2)
    hold on
    n=length(CEB4) ; xx=(1:4)'; % example 
    r=repmat(xx,1,n)'; 
    g=r(:)';
    positions = [1 2 3 4]; 
    h=boxplot([CEB4',CEA4',CEI4',CED4'],g,'positions',positions,'Jitter',1,'Symbol','', 'Orientation','horizontal'); 
    set(h,'linewidth',2) 
    set(gca,'ytick',[1 2 3 4])
    set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex') 
    color = [ 'k' ,'b', 'y','m']; 
    
%     hh = findobj(gcf,'tag','Outliers');
%     for iH = 1:length(h)
%         h(iH).Alpha =.2;
%     end
    
    h = findobj(gca,'Tag','Box'); 
    for j=1:length(h) 
        if j ==3 
            patch(get(h(j),'XData'),get(h(j),'YData'),[0.749, 0.5647, 0],'FaceAlpha',.5,'EdgeAlpha',0); 
        else
            patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5,'EdgeAlpha',0); 
        end
        set(h(j), 'Color', color(j), 'linewidth',1);
        h(j).Color(4) = 0;
    end 
    set(findobj(gcf,'tag','Median'), 'Color','k');
    xlim([-3,3])
    hXLabel = xlabel('$\nabla_u^2\phi_4 - \nabla_u^2\phi_{p,4}$');
            set([ hXLabel],'FontSize', 10 *3,'Interpreter','LaTex');
                set(gca,'FontSize',10*3);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*3; y_width=4*3;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['Exemple_Err_phi4_Ex2_Sc',num2str(Scenario)])
    %%
    figure 
    plot([0,0],[0.5,4.5],'g-','Linewidth',2)
    hold on
    n=length(CEB4) ; xx=(1:4)'; % example 
    r=repmat(xx,1,n)'; 
    g=r(:)';
    positions = [1 2 3 4]; 
    h=boxplot([CEB3',CEA3',CEI3',CED3'],g,'positions',positions,'Jitter',1,'Symbol','', 'Orientation','horizontal'); 
    set(h,'linewidth',2) 
    set(gca,'ytick',[1 2 3 4])
    set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex') 
    color = [ 'k' ,'b', 'y','m']; 
    h = findobj(gca,'Tag','Box'); 
    for j=1:length(h) 
        if j ==3 
            patch(get(h(j),'XData'),get(h(j),'YData'),[0.749, 0.5647, 0],'FaceAlpha',.5,'EdgeAlpha',0); 
        else
            patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5,'EdgeAlpha',0); 
        end
        set(h(j), 'Color', color(j), 'linewidth',1);
        h(j).Color(4) = 0;
    end 
    set(findobj(gcf,'tag','Median'), 'Color','k');
    xlim([-10,10])
    hXLabel = xlabel('$\nabla_u^2\phi_3 - \nabla_u^2\phi_{p,3}$');
            set([ hXLabel],'FontSize', 10 *3,'Interpreter','LaTex');
                set(gca,'FontSize',10*3);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*3; y_width=4*3;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['Exemple_Err_phi3_Ex2_Sc',num2str(Scenario)])
    %%
    figure 
    plot([0,0],[0.5,4.5],'g-','Linewidth',2)
    hold on
    n=length(CEB4) ; xx=(1:4)'; % example 
    r=repmat(xx,1,n)'; 
    g=r(:)';
    positions = [1 2 3 4]; 
    h=boxplot([CEB2',CEA2',CEI2',CED2'],g,'positions',positions,'Jitter',1,'Symbol','', 'Orientation','horizontal'); 
    set(h,'linewidth',2) 
    set(gca,'ytick',[1 2 3 4])
    set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex') 
    color = [ 'k' ,'b', 'y','m']; 
    h = findobj(gca,'Tag','Box'); 
    for j=1:length(h) 
        if j ==3 
            patch(get(h(j),'XData'),get(h(j),'YData'),[0.749, 0.5647, 0],'FaceAlpha',.5,'EdgeAlpha',0); 
        else
            patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5,'EdgeAlpha',0); 
        end
        set(h(j), 'Color', color(j), 'linewidth',1);
        h(j).Color(4) = 0;
    end 
    set(findobj(gcf,'tag','Median'), 'Color','k');
    xlim([-3,3])
%     hXLabel = xlabel('erreur $\phi_2/100$');
    hXLabel = xlabel('$\nabla_u^2\phi_2 - \nabla_u^2\phi_{p,2}$');
            set([ hXLabel],'FontSize', 10 *3,'Interpreter','LaTex');
                set(gca,'FontSize',10*3);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*3; y_width=4*3;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['Exemple_Err_phi2_Ex2_Sc',num2str(Scenario)])
     %%
    figure 
    plot([0,0],[0.5,4.5],'g-','Linewidth',2)
    hold on
    n=length(CEB4) ; xx=(1:4)'; % example 
    r=repmat(xx,1,n)'; 
    g=r(:)';
    positions = [1 2 3 4]; 
    h=boxplot([CEB1',CEA1',CEI1',CED1'],g,'positions',positions,'Jitter',1,'Symbol','', 'Orientation','horizontal'); 
    set(h,'linewidth',2) 
    set(gca,'ytick',[1 2 3 4])
    set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex') 
    color = [ 'k' ,'b', 'y','m']; 
    h = findobj(gca,'Tag','Box'); 
    for j=1:length(h) 
        if j ==3 
            patch(get(h(j),'XData'),get(h(j),'YData'),[0.749, 0.5647, 0],'FaceAlpha',.5,'EdgeAlpha',0); 
        else
            patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5,'EdgeAlpha',0); 
        end
        set(h(j), 'Color', color(j), 'linewidth',1);
        h(j).Color(4) = 0;
    end 
    set(findobj(gcf,'tag','Median'), 'Color','k');
    xlim([-1.5,1.5])
    hXLabel = xlabel('$\nabla_u^2\phi_1 - \nabla_u^2\phi_{p,1}$');
            set([ hXLabel],'FontSize', 25,'Interpreter','LaTex');
                set(gca,'FontSize',10*3);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*3; y_width=4*3;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['Exemple_Err_phi1_Ex2_Sc',num2str(Scenario)])
            
end    
%% Pourcentage de modeles
for hide_stats = 1
Counter_I1 = 0;
    Counter_I2 = 0;
        Counter_I3 = 0;
            Counter_I4 = 0;
Counter_D1 = 0;
    Counter_D2 = 0;
        Counter_D3 = 0;
            Counter_D4 = 0;
Counter_A1 = 0;
    Counter_A2 = 0;
        Counter_A3 = 0;
            Counter_A4 = 0;
Counter_B1 = 0;
    Counter_B2 = 0;
        Counter_B3 = 0;
            Counter_B4 = 0;
Counter_tot = length(CEA1);
for i = 1:length(CEA1)
    MinObs1 = min(abs([CED1(i),CEI1(i),CEA1(i),CEB1(i)]));
        MinObs2 = min(abs([CED2(i),CEI2(i),CEA2(i),CEB2(i)]));
            MinObs3 = min(abs([CED3(i),CEI3(i),CEA3(i),CEB3(i)]));
                MinObs4 = min(abs([CED4(i),CEI4(i),CEA4(i),CEB4(i)]));
Test = 7;
    if round(abs(CED1(i)),Test) ==  round(MinObs1,Test) 
        Counter_D1 = Counter_D1+1;
    end
        if round(abs(CED2(i)),Test) ==  round(MinObs2,Test) 
            Counter_D2 = Counter_D2+1;
        end
            if round(abs(CED3(i)),Test) ==  round(MinObs3,Test) 
                Counter_D3 = Counter_D3+1;
            end
                if round(abs(CED4(i)),Test) ==  round(MinObs4,Test) 
                    Counter_D4 = Counter_D4+1;
                end
    if round(abs(CEI1(i)),Test) ==  round(MinObs1,Test) 
        Counter_I1 = Counter_I1+1;
    end
        if round(abs(CEI2(i)),Test) ==  round(MinObs2,Test) 
            Counter_I2 = Counter_I2+1;
        end
            if round(abs(CEI3(i)),Test) ==  round(MinObs3,Test) 
                Counter_I3 = Counter_I3+1;
            end
                if round(abs(CEI4(i)),Test) ==  round(MinObs4,Test) 
                    Counter_I4 = Counter_I4+1;
                end
    if round(abs(CEA1(i)),Test) ==  round(MinObs1,Test) 
        Counter_A1 = Counter_A1+1;
    end
        if round(abs(CEA2(i)),Test) ==  round(MinObs2,Test) 
            Counter_A2 = Counter_A2+1;
        end
            if round(abs(CEA3(i)),Test) ==  round(MinObs3,Test) 
                Counter_A3 = Counter_A3+1;
            end
                if round(abs(CEA4(i)),Test) ==  round(MinObs4,Test) 
                    Counter_A4 = Counter_A4+1;
                end
    if round(abs(CEB1(i)),Test) ==  round(MinObs1,Test) 
        Counter_B1 = Counter_B1+1;
    end
        if round(abs(CEB2(i)),Test) ==  round(MinObs2,Test) 
            Counter_B2 = Counter_B2+1;
        end
            if round(abs(CEB3(i)),Test) ==  round(MinObs3,Test) 
                Counter_B3 = Counter_B3+1;
            end
                if round(abs(CEB4(i)),Test) ==  round(MinObs4,Test) 
                    Counter_B4 = Counter_B4+1;
                end
end
%%

figure
YY = [Counter_D1, Counter_I1, Counter_A1, Counter_B1]./Counter_tot;
h1 = barh(4,YY(1)*100);
set(h1,'FaceColor', [0.5 0.5 0.5]);
hold on
h2 = barh(3,YY(2)*100);
set(h2,'FaceColor', [0   0   1]);
h3 = barh(2,YY(3)*100);
set(h3,'FaceColor', [0.749, 0.5647, 0]);
h4 = barh(1,YY(4)*100);
set(h4,'FaceColor', [1 0 1]);
xlim([0,100])
ylim([0,5])
yticks([1 2 3 4])
set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex')

hXLabel = xlabel([sprintf('\\%%'),' ($\phi_1$)']);
    set([hXLabel],'FontSize', 10,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.25, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf',['Exemple_PerC_phi1_Ex2_Sc',num2str(Scenario)])
%%
figure
YY = [Counter_D2, Counter_I2, Counter_A2, Counter_B2]./Counter_tot;
h1 = barh(4,YY(1)*100);
set(h1,'FaceColor', [0.5 0.5 0.5]);
hold on
h2 = barh(3,YY(2)*100);
set(h2,'FaceColor', [0   0   1]);
h3 = barh(2,YY(3)*100);
set(h3,'FaceColor', [0.749, 0.5647, 0]);
h4 = barh(1,YY(4)*100);
set(h4,'FaceColor', [1 0 1]);
xlim([0,100])
ylim([0,5])
yticks([1 2 3 4])
set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex')

hXLabel = xlabel([sprintf('\\%%'),' ($\phi_2$)']);
    set([hXLabel],'FontSize', 10,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.25, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf',['Exemple_PerC_phi2_Ex2_Sc',num2str(Scenario)])

%%
figure
YY = [Counter_D3, Counter_I3, Counter_A3, Counter_B3]./Counter_tot;
h1 = barh(4,YY(1)*100);
set(h1,'FaceColor', [0.5 0.5 0.5]);
hold on
h2 = barh(3,YY(2)*100);
set(h2,'FaceColor', [0   0   1]);
h3 = barh(2,YY(3)*100);
set(h3,'FaceColor', [0.749, 0.5647, 0]);
h4 = barh(1,YY(4)*100);
set(h4,'FaceColor', [1 0 1]);
xlim([0,1]*100)
ylim([0,5])
yticks([1 2 3 4])
set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex')

hXLabel = xlabel([sprintf('\\%%'),' ($\phi_3$)']);
    set([hXLabel],'FontSize', 10,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.25, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf',['Exemple_PerC_phi3_Ex2_Sc',num2str(Scenario)])

%%
figure
YY = [Counter_D4, Counter_I4, Counter_A4, Counter_B4]./Counter_tot;
h1 = barh(4,YY(1)*100);
set(h1,'FaceColor', [0.5 0.5 0.5]);
hold on
h2 = barh(3,YY(2)*100);
set(h2,'FaceColor', [0   0   1]);
h3 = barh(2,YY(3)*100);
set(h3,'FaceColor', [0.749, 0.5647, 0]);
h4 = barh(1,YY(4)*100);
set(h4,'FaceColor', [1 0 1]);
xlim([0,1]*100)
ylim([0,5])
yticks([1 2 3 4])
set(gca,'yticklabel',{'B','A','I','D'},'Fontsize',12, 'TickLabelInterpreter', 'latex')

hXLabel = xlabel([sprintf('\\%%'),' ($\phi_4$)']);
    set([hXLabel],'FontSize', 10,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
%         set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gca, 'Position', [0.25, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf',['Exemple_PerC_phi4_Ex2_Sc',num2str(Scenario)])

end        
%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')




%% Functions
function [y1,dy1,ddy1] = systeme_1p(u1)   
    global a1p b1p c1p
    y1   = a1p + b1p'*u1 + u1'*c1p*u1;
    dy1  = b1p + 2*c1p*u1;
    ddy1 = 2*c1p;
end
function [y2,dy2,ddy2] = systeme_2p(u2)   
    global a2p b2p c2p
    y2   = a2p + b2p*u2 + c2p*u2^2;
    dy2  = b2p + 2*c2p*u2;
    ddy2 = 2*c2p  ;
end
function [y2,dy2_du,ddy2_du,du1_du,du2_du,dy1_du, ddy1_du] = systeme_12p(x)   
    global fsolve_options H
    y0 = 0; 
    
%     [y2,~,exitflag]        = fsolve(@(y)DynSys12(y,x),y0,fsolve_options);
%     if exitflag <0
%         disp('PB')
%     end
    
    [y2,~,exitflag]        = fsolve(@(y)DynSys12p(y,x),y0,fsolve_options);
    if exitflag <0
        disp('PB')
    end
    [y_MinusH,~,exitflag]  = fsolve(@(y)DynSys12p(y,x-H),y0,fsolve_options);
    if exitflag <0
        disp('PB')
    end
    [y_PlusH,~,exitflag]   = fsolve(@(y)DynSys12p(y,x+H),y0,fsolve_options);
    if exitflag <0
        disp('PB')
    end
    dy2_du    = (y_PlusH - y_MinusH)/(2*H);
    ddy2_du   = ((y2 - y_MinusH)/H  - (y_PlusH - y2)/H) /H;
    
    u1_PlusH  = [x+H;y_PlusH];
    u1_MinusH = [x-H;y_MinusH];
    
    u1        = [x;y2];
    y1        = systeme_1p(u1);
    y1_PlusH  = systeme_1p(u1_PlusH);
    y1_MinusH = systeme_1p(u1_MinusH);
    dy1_du    = (y1_PlusH - y1_MinusH)/(2*H);
    ddy1_du   = ((y1 - y1_MinusH)/H  - (y1_PlusH - y1)/H) /H;
    du1_du = [1;dy2_du];
    du2_du = dy1_du;
end
function dy = DynSys12p(y2_bis,x)         
    global a1p b1p c1p a2p b2p c2p
    u1 = [x;y2_bis];
    y1 = a1p + b1p'*u1 + u1'*c1p*u1;
    u2 = y1;
    y2 = a2p + b2p*u2 + u2'*c2p*u2;
    dy = y2_bis-y2;
end



function [y1,dy1,ddy1] = systeme_1(u1)  
    global a1 b1 c1
    y1   = a1 + b1'*u1 + u1'*c1*u1;
    dy1  = b1 + 2*c1*u1;
    ddy1 = 2*c1;
end
function [y2,dy2,ddy2] = systeme_2(u2)  
    global a2 b2 c2
    y2   = a2 + b2*u2 + c2*u2^2;
    dy2  = b2 + 2*c2*u2;
    ddy2 = 2*c2  ;
end
function [y2,dy2,ddy2] = systeme_12(x)  
    global fsolve_options H
    y0 = 0; 
    [y2,~,exitflag]        = fsolve(@(y)DynSys12(y,x),y0,fsolve_options);
    if exitflag <0
        disp('PB')
    end
    [y_MinusH,~,exitflag]  = fsolve(@(y)DynSys12(y,x-H),y0,fsolve_options);
    if exitflag <0
        disp('PB')
    end
    [y_PlusH,~,exitflag]   = fsolve(@(y)DynSys12(y,x+H),y0,fsolve_options);
    if exitflag <0
        disp('PB')
    end
    dy2       = (y_PlusH - y_MinusH)/(2*H);
    ddy2      = ((y2 - y_MinusH)/H  - (y_PlusH - y2)/H) /H;
end
function dy = DynSys12(y2_bis,x)        
    global a1 b1 c1 a2 b2 c2
    u1 = [x;y2_bis];
    y1 = a1 + b1'*u1 + u1'*c1*u1;
    u2 = y1;
    y2 = a2 + b2*u2 + u2'*c2*u2;
    dy = (y2_bis-y2)^2;
end


function [y1,dy1,ddy1] = systeme_12A(x)  
    global fsolve_options H
    y0 = 0;  
    [y1,~,exitflag]        = fsolve(@(y)DynSys12A(y,x,x),y0,fsolve_options);
    if exitflag <0
        disp('PB')
    end
    [y_MinusH,~,exitflag]  = fsolve(@(y)DynSys12A(y,x-H,x),y0,fsolve_options);
    if exitflag <0
        disp('PB')
    end
    [y_PlusH,~,exitflag]   = fsolve(@(y)DynSys12A(y,x+H,x),y0,fsolve_options);
    if exitflag <0
        disp('PB')
    end
    dy1       = (y_PlusH - y_MinusH)/(2*H);
    ddy1      = ((y1 - y_MinusH)/H  - (y_PlusH - y1)/H) /H;
end
function dy = DynSys12A(y2_bis,x,xk)     
    global a1 b1 c1 a2 b2 c2
    global epsilon_1AB   epsilon_2AB  lambda_1A  lambda_2A
    
    u1 = [x;y2_bis];
    y1 = a1 + b1'*u1 + u1'*c1*u1 + epsilon_1AB + lambda_1A*(x-xk);
    u2 = y1;
    y2 = a2 + b2*u2 + u2'*c2*u2  + epsilon_2AB + lambda_2A*(x-xk);
    dy = y2_bis-y2;
end


function [y2,dy2,ddy2] = systeme_12B(x,u1k,u2k)  
    global fsolve_options H
    y0 = -0.4;  
    [y2,~,exitflag]        = fsolve(@(y)DynSys12B(y,x,u1k,u2k),y0,fsolve_options);
    if exitflag <0
        disp('PB')
    end
    [y_MinusH,~,exitflag]  = fsolve(@(y)DynSys12B(y,x-H,u1k,u2k),y0,fsolve_options);
    if exitflag <0
        disp('PB')
    end
    [y_PlusH,~,exitflag]   = fsolve(@(y)DynSys12B(y,x+H,u1k,u2k),y0,fsolve_options);
    if exitflag <0
        disp('PB')
    end
    dy2       = (y_PlusH - y_MinusH)/(2*H);
    ddy2      = ((y2 - y_MinusH)/H  - (y_PlusH - y2)/H) /H;
end
function dy = DynSys12B(y2_bis,x,u1k,u2k)        
    global a1 b1 c1 a2 b2 c2
    global epsilon_1AB   epsilon_2AB  lambda_1B  lambda_2B
    
    u1 = [x;y2_bis];
    y1 = a1 + b1'*u1 + u1'*c1*u1 + epsilon_1AB + lambda_1B'*(u1-u1k);
    u2 = y1;
    y2 = a2 + b2*u2 + u2'*c2*u2  + epsilon_2AB + lambda_2B*(u2-u2k);
    dy = y2_bis-y2;
end



% function [y,dy,ddy]    = systeme_12B(x,epsilon_1B,lambda_1B,epsilon_2B,lambda_2B,x1k,x2k)   
%     global a1 b1 c1 a2 b2 c2;
%     
%     y1   = a1+b1*x+c1*x^2 + epsilon_1B + lambda_1B*(x-x1k);
%     dy1  =    b1  +c1*x*2 + lambda_1B;
%     ddy1 =         c1*2;
%     
%     y2   = a2 + b2*y1   + c2*y1^2                  + epsilon_2B + lambda_2B*(y1-x2k);
%     dy2  =      b2*dy1  + c2*2*y1*dy1              + lambda_2B*dy1;
%     ddy2 =      b2*ddy1 + c2*2*(dy1*dy1 + y1*ddy1) + lambda_2B*ddy1;
%     
%     y   = y2;
%     dy  = dy2;
%     ddy = ddy2;
% end



function [phi,dphi,ddphi] = uy2phi1(u,y,dy,ddy)
    global ap1 bp1 cp1 dp1 ep1 
    phi   = ap1*u + bp1*y + cp1*u^2 + dp1*u*y + ep1*y^2;
    dphi  = ap1 + 2*cp1*u + dp1*y + dy*(bp1+dp1*u+2*ep1*y);
    ddphi = 2*cp1 + dp1*dy + ddy*(bp1+dp1*u+2*ep1*y) + dy*(dp1+2*ep1*dy);
end
function [phi,dphi,ddphi] = uy2phi2(u,y,dy,ddy)
    global ap2 bp2 cp2 dp2 ep2 
    phi   = ap2*u + bp2*y + cp2*u^2 + dp2*u*y + ep2*y^2;
    dphi  = ap2 + 2*cp2*u + dp2*y + dy*(bp2+dp2*u+2*ep2*y);
    ddphi = 2*cp2 + dp2*dy + ddy*(bp2+dp2*u+2*ep2*y) + dy*(dp2+2*ep2*dy);
end
function [phi,dphi,ddphi] = uy2phi3(u,y,dy,ddy)
    global ap3 bp3 cp3 dp3 ep3 
    phi   = ap3*u + bp3*y + cp3*u^2 + dp3*u*y + ep3*y^2;
    dphi  = ap3 + 2*cp3*u + dp3*y + dy*(bp3+dp3*u+2*ep3*y);
    ddphi = 2*cp3 + dp3*dy + ddy*(bp3+dp3*u+2*ep3*y) + dy*(dp3+2*ep3*dy);
end
function [phi,dphi,ddphi] = uy2phi4(u,y,dy,ddy)
    global ap4 bp4 cp4 dp4 ep4
    phi   = ap4*u + bp4*y + cp4*u^2 + dp4*u*y + ep4*y^2;
    dphi  = ap4 + 2*cp4*u + dp4*y + dy*(bp4+dp4*u+2*ep4*y);
    ddphi = 2*cp4 + dp4*dy + ddy*(bp4+dp4*u+2*ep4*y) + dy*(dp4+2*ep4*dy);
end