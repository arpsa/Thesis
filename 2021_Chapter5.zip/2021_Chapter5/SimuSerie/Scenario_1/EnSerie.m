clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

%% Code architecture initialization & Output files 
Results_file_name = 'Results';

Scenario = 1;

    global a1 b1 c1 a2 b2 c2       ...
       a1p b1p c1p a2p b2p c2p ...
       ap1 bp1 cp1 dp1 ep1     ...
       ap2 bp2 cp2 dp2 ep2     ...
       ap3 bp3 cp3 dp3 ep3     ...
       ap4 bp4 cp4 dp4 ep4     ...
       lambda_D uk_D     k     ...
       epsilon_I lambda_I uk_I ...
       epsilon_1A lambda_1A epsilon_2A lambda_2A uk_A ...
       epsilon_1B lambda_1B epsilon_2B lambda_2B uk_B ...
       k uk_D ukm1_D uoptk_D K_km1_D ...
       uk_I ukm1_I uoptk_I K_km1_I   ... 
       ukm1_B uoptk_B K_km1_B  u1k_B  u2k_B ...
       ukm1_A uoptk_A K_km1_A   
  
a1 = 1.5; b1 =-1.5 ; c1 = 0;  a2 = 1;  b2 = -3 ;  c2 = 4; 
a1p= 2;   b1p=-2;    c1p= 0;  a2p= 2;  b2p= -2;   c2p= 2 ;
% Other Scenario:
% a1 = 1;   b1 =-3 ; c1 = 1;  a2 = 1;  b2 = -1 ;  c2 = 0; 
% a1p= 2;   b1p=-2; c1p= 2;  a2p= 2;  b2p= 2;  c2p =0 ;
% a1 = 1;   b1 =-1 ; c1 = 1;  a2 = 1;  b2 = -1 ;  c2 = 1; 
% a1p= 2;   b1p=-2; c1p= 2;  a2p= 2;  b2p= -2;  c2p =2 ;

a1min= 1; a1max= 3; n_a1 = 3;    A1 = a1min:(a1max-a1min)/(n_a1-1):a1max;
b1min=-3; b1max=-1; n_b1 = 3;    B1 = b1min:(b1max-b1min)/(n_b1-1):b1max;
C1 = 0;  % c1min= 1; c1max= 3; n_c1 = 3;    C1 = c1min:(c1max-c1min)/(n_c1-1):c1max;
a2min= 1; a2max= 3; n_a2 = 3;    A2 = a2min:(a2max-a2min)/(n_a2-1):a2max;
b2min=-3; b2max=-1; n_b2 = 3;    B2 = b2min:(b2max-b2min)/(n_b2-1):b2max;
c2min= 1; c2max= 3; n_c2 = 3;    C2 = c2min:(c2max-c2min)/(n_c2-1):c2max;

ap1= 0 ; bp1= 1; cp1= 0;   dp1= 0 ;    ep1= 0;
ap2= 0 ; bp2= 0; cp2= 0;   dp2= 1 ;    ep2= 0;
ap3= 0 ; bp3= 0; cp3= 0;   dp3= 0 ;    ep3= 1;
ap4= 3 ; bp4= -0.1; cp4= 0; dp4= -0.3 ; ep4= 0.1;
%% Simulation RTO iterations
for hide_RTO_iter = 1
    
    
    fmincon_options = optimoptions(@fmincon,'Algorithm','sqp' , ...
                                'MaxIter',100000,... 
                                'Display', 'off', ...'
                                'MaxFunEvals',100000,...
                                'TolFun',1e-9,...
                                'TolCon',1e-9,...
                                'TolX',1e-9,...
                                'FinDiffType','central' ,... 
                                'ScaleProblem','obj-and-constr');
    
    Modifiers = struct();
    Results   = struct();

    Last_u = [];  Last_c   = [];
    Last_f = [];  Last_ceq = [];
    ub = 1;  Aeq = [];  A = [];
    lb = -1;  beq = [];  b = [];

    a1min= 1; a1max= 3; n_a1 = 4;    A1 = a1min:(a1max-a1min)/(n_a1-1):a1max;
    b1min=-3; b1max=-1; n_b1 = 4;    B1 = b1min:(b1max-b1min)/(n_b1-1):b1max;
    C1 = 0; % c1min= 1; c1max= 2; n_c1 = 3;    C1 = c1min:(c1max-c1min)/(n_c1-1):c1max;
    a2min= 1; a2max= 3; n_a2 = 4;    A2 = a2min:(a2max-a2min)/(n_a2-1):a2max;
    b2min=-3; b2max=-1; n_b2 = 4;    B2 = b2min:(b2max-b2min)/(n_b2-1):b2max;
    c2min= 1; c2max= 3; n_c2 = 4;    C2 = c2min:(c2max-c2min)/(n_c2-1):c2max;
    
    xmin = -1; xmax = 1;
    dx = (xmax-xmin)/9;
    x = xmin:dx:xmax;
    
    NBiter = 15;
    u_max  =  1;
    u_min  = -1;
    
    
    KMFCA_D = 1; KMFCA_I = 2; KMFCA_A = 3; KMFCA_B = 4;
    % .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.
    UK_D = 1; UK_I=2; UK_A=3; UK_B=4;
    figure(UK_D); % hold on
%     figure(UK_I); %  hold on
%     figure(UK_A); % hold on
%     figure(UK_B); % hold on
    counter    = 0;
    nb_counter = length(A1)*length(B1)*length(C1)*length(A2)*length(B2)*length(C2)*length(x)*NBiter;
    
    PlotXD=  [];
    PlotXI=  [];
    PlotXA=  [];
    PlotXB=  [];
    
    
                                for  ii = 1:length(A1)
                            for      jj = 1:length(B1)
                        for          kk = 1:length(C1)
                    for             iii = 1:length(A2)
                for                 jjj = 1:length(B2)
            for                     kkk = 1:length(C2)
                a1 = A1(ii); a2 = A2(iii);
                b1 = B1(jj); b2 = B2(jjj);
                c1 = C1(kk); c2 = C2(kkk);  
                for i=1:length(x)
                    X_D(1,i) = x(i);
                    X_I(1,i) = x(i);
                    X_A(1,i) = x(i);
                    X_B(1,i) = x(i);
                    for k=1:NBiter
                        counter = counter+1;
                        % 1) Compute the model's and plant's values end derivatives at uk.
                        u = X_D(k,i);
                        [yp_D,dyp_D,ddyp_D,y1p_D,dy1p_D] = systeme_12p(u);
                        [y_D ,dy_D ,ddy_D,y1_D,dy1_D]    = systeme_12(u);
                        [phip_D(k,i), dphip_D] = uy2phi4(u,yp_D,dyp_D,ddyp_D);
                        [phi_D      ,  dphi_D] = uy2phi4(u,y_D,dy_D,ddy_D);
                            u = X_I(k,i);
                            [yp_I,dyp_I,ddyp_I,y1p_I,dy1p_I] = systeme_12p(u);
                            [y_I ,dy_I ,ddy_I,y1_I,dy1_I]    = systeme_12(u);
                            [phip_I(k,i), dphip_I]           = uy2phi4(u,yp_I,dyp_I,ddyp_I);
                                u = X_A(k,i);
                                [y1p_A,dy1p_A]         = systeme_1p(u);     [y1_A,dy1_A]     = systeme_1(u); 
                                [y2p_A,dy2p_A]         = systeme_2p(y1p_A); [y2_A,dy2_A]     = systeme_2(y1p_A); % Notice that we use "y1p", not "y1"
                                [yp_A,dyp_A,ddyp_A]    = systeme_12p(u);    [y_A,dy_A,ddy_A] = systeme_12(u);
                                [phip_A(k,i), dphip_A] = uy2phi4(u,yp_A,dyp_A,ddyp_A);
                                    u = X_B(k,i);
                                    [y1p_B,dy1p_B]    = systeme_1p(u);     [y1_B,dy1_B]   = systeme_1(u); 
                                    [y2p_B,dy2p_B]    = systeme_2p(y1p_B); [y2_B,dy2_B]   = systeme_2(y1p_B); % Notice that we use "y1p", not "y1"
                                    [yp_B,dyp_B,ddyp_B] = systeme_12p(u);  [y_B,dy_B,ddy_B] = systeme_12(u);
                                    [phip_B(k,i), dphip_B] = uy2phi4(u,yp_B,dyp_B,ddyp_B);
                        lambda_D  = dphip_D - dphi_D;
                        uk_D      = X_D(k,i);
                            epsilon_I = yp_I - y_I;
                            lambda_I  = dyp_I - dy_I;
                            uk_I      = X_I(k,i);
                                epsilon_1A = y1p_A - y1_A;
                                lambda_1A  = dy1p_A - dy1_A;
                                epsilon_2A = y2p_A - y2_A;
                                lambda_2A  = dyp_A - dy2_A*dy1p_A;
                                uk_A       = X_A(k,i);
                                    epsilon_1B = y1p_B - y1_B;
                                    lambda_1B   = dy1p_B - dy1_B;
                                    epsilon_2B   = y2p_B - y2_B;
                                    lambda_2B    = dy2p_B - dy2_B;
                                    uk_B       = X_B(k,i);
                                    u1k_B      = X_B(k,i);
                                    u2k_B      = y1p_B;
                                
                        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~           
                        for Hide_KMFCA_D  = 1 
                            if k > 1
                                uk_D    = X_D(k,i);
                                ukm1_D  = X_D(k-1,i);
                                uoptk_D = uopt_D(k);
                                K_km1_D = K_D(k-1);
                            end
                            uopt_D(k+1) = fmincon(@(u)objfun_KMFCA_D(u),X_D(k,i), A, b, ...
                                        Aeq, beq, lb, ub, @(u)constr_KMFCA_D(u),fmincon_options);
                            % 3) Apply filter
                            if k == 1
                                K_D(k) = 0.1;
                                else
                                if abs(X_D(k,i)-X_D(k-1,i)) > 1e-12
                                    NablaS = (X_D(k,i)-X_D(k-1,i))'*(uopt_D(k+1)-uopt_D(k))/(norm(X_D(k,i)-X_D(k-1,i))^2);
                                    if NablaS < 1
                                        K_D(k) = 1/(1-NablaS);
                                    else
                                        K_D(k) = 1;
                                    end
                                else
                                    K_D(k) = K_D(k-1);
                                end
                            end
                        X_D(k+1,i) = X_D(k,i) + K_D(k)*(uopt_D(k+1)-X_D(k,i));
                        end
                        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
                        for Hide_KMFCA_I  = 1 
                            if k > 1
                                uk_I    = X_I(k,i);
                                ukm1_I  = X_I(k-1,i);
                                uoptk_I = uopt_I(k);
                                K_km1_I = K_I(k-1);
                            end
                            uopt_I(k+1) = fmincon(@(u)objfun_KMFCA_I(u),X_I(k,i), A, b, ...
                                        Aeq, beq, lb, ub, @(u)constr_KMFCA_I(u),fmincon_options);
                            % 3) Apply filter
                            if k == 1
                                K_I(k) = 0.1;
                                else
                                if abs(X_I(k,i)-X_I(k-1,i)) > 1e-12
                                    NablaS = (X_I(k,i)-X_I(k-1,i))'*(uopt_I(k+1)-uopt_I(k))/(norm(X_I(k,i)-X_I(k-1,i))^2);
                                    if NablaS < 1
                                        K_I(k) = 1/(1-NablaS);
                                    else
                                        K_I(k) = 1;
                                    end
                                else
                                    K_I(k) = K_I(k-1);
                                end
                            end
                        X_I(k+1,i) = X_I(k,i) + K_I(k)*(uopt_I(k+1)-X_I(k,i));
                        end
                        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
                        for Hide_KMFCA_A  = 1 
                            if k > 1
                                uk_A    = X_A(k,i);
                                ukm1_A  = X_A(k-1,i);
                                uoptk_A = uopt_A(k);
                                K_km1_A = K_A(k-1);
                            end
                            uopt_A(k+1) = fmincon(@(u)objfun_KMFCA_A(u),X_A(k,i), A, b, ...
                                        Aeq, beq, lb, ub, @(u)constr_KMFCA_A(u),fmincon_options);
                            % 3) Apply filter
                            if k == 1
                                K_A(k) = 0.1;
                                else
                                if abs(X_A(k,i)-X_A(k-1,i)) > 1e-12
                                    NablaS = (X_A(k,i)-X_A(k-1,i))'*(uopt_A(k+1)-uopt_A(k))/(norm(X_A(k,i)-X_A(k-1,i))^2);
                                    if NablaS < 1
                                        K_A(k) = 1/(1-NablaS);
                                    else
                                        K_A(k) = 1;
                                    end
                                else
                                    K_A(k) = K_A(k-1);
                                end
                            end
                        X_A(k+1,i) = X_A(k,i) + K_A(k)*(uopt_A(k+1)-X_A(k,i));
                        end
                        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
                        for Hide_KMFCA_B  = 1 
                            if k > 1
                                uk_B    = X_B(k,i);
                                ukm1_B  = X_B(k-1,i);
                                uoptk_B = uopt_B(k);
                                K_km1_B = K_B(k-1);
                            end
                            uopt_B(k+1) = fmincon(@(u)objfun_KMFCA_B(u),X_B(k,i), A, b, ...
                                        Aeq, beq, lb, ub, @(u)constr_KMFCA_B(u),fmincon_options);
                            % 3) Apply filter
                            if k == 1
                                K_B(k) = 0.1;
                                else
                                if abs(X_B(k,i)-X_B(k-1,i)) > 1e-12
                                    NablaS = (X_B(k,i)-X_B(k-1,i))'*(uopt_B(k+1)-uopt_B(k))/(norm(X_B(k,i)-X_B(k-1,i))^2);
                                    if NablaS < 1
                                        K_B(k) = 1/(1-NablaS);
                                    else
                                        K_B(k) = 1;
                                    end
                                else
                                    K_B(k) = K_B(k-1);
                                end
                            end
                        X_B(k+1,i) = X_B(k,i) + K_B(k)*(uopt_B(k+1)-X_B(k,i));
                        end
                        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
                                    
                    end
                    PlotXD = [PlotXD;X_D(:,i)'];
                    PlotXI = [PlotXI;X_I(:,i)'];
                    PlotXA = [PlotXA;X_A(:,i)'];
                    PlotXB = [PlotXB;X_B(:,i)'];
                end
            end
            disp(num2str(counter/nb_counter))
                end
                    end
                        end
                            end
                                end

 %% 
close all
%% D
figure
hold on
for iiiii = 1:size(PlotXD,1)
    h = plot(0:k,PlotXD(iiiii,:),'Color',[0.3,0.3,0.3],'Linewidth',0.5);
    h.Color(4) = 0.01; 
end
plot(0:k,mean(PlotXD),'k-','Linewidth',1.5)
plot(0:k,median(PlotXD),'k-','Linewidth',0.5)
plot(0:k,PlotXB(end,end)*ones(1,k+1),'g-');
    ylim([-1,1])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u$');
        set([hXLabel, hYLabel],'FontSize', 9 ,'Interpreter','LaTex');
        set(gca,'FontSize',9);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45*0.7865; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-r620','-djpeg',['Exemple_5_1_uk_D_Sc_',num2str(Scenario)])
%% D - log
figure
hold on
for iiiii = 1:size(PlotXD,1)
    h = plot(0:k,log(abs(PlotXD(iiiii,:)-PlotXB(end,end)))/log(10),'Color',[0.3,0.3,0.3],'Linewidth',0.5);
%         log(max(abs(mean(PlotXD)+2*sqrt(var(PlotXD))-PlotXB(end,end))
    h.Color(4) = 0.01; 
end
plot(0:k,log(abs(mean(PlotXD)-PlotXB(end,end)))/log(10),'k-','Linewidth',1.5)
plot(0:k,log(abs(median(PlotXD)-PlotXB(end,end)))/log(10),'k-','Linewidth',0.5)
ylim([-15,1])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$log_{10}(|u_k-u_p^{\star}|)$');
        set([hXLabel, hYLabel],'FontSize', 9 ,'Interpreter','LaTex');
        set(gca,'FontSize',9);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45*0.7865; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-r620','-djpeg',['Exemple_5_1_loguk_D_Sc_',num2str(Scenario)])%% D
%% I 
figure
hold on
for iiiii = 1:size(PlotXI,1)
    h = plot(0:k,PlotXI(iiiii,:),'Color',[0.3 0.3 0.9],'Linewidth',0.5);
    h.Color(4) = 0.01; 
end
plot(0:k,mean(PlotXI),'k-','Linewidth',1.5)
plot(0:k,median(PlotXI),'k-','Linewidth',0.5)
plot(0:k,PlotXB(end,end)*ones(1,k+1),'g-');
    ylim([-1,1])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u$');
        set([hXLabel, hYLabel],'FontSize', 9 ,'Interpreter','LaTex');
        set(gca,'FontSize',9);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45*0.7865; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-r620','-djpeg',['Exemple_5_1_uk_I_Sc_',num2str(Scenario)])
%% I - log
figure
hold on
for iiiii = 1:size(PlotXI,1)
    h = plot(0:k,log(abs(PlotXI(iiiii,:)-PlotXB(end,end)))/log(10),'Color',[0.3 0.3 0.9],'Linewidth',0.5);
    h.Color(4) = 0.01; 
end
plot(0:k,log(abs(mean(PlotXI)-PlotXB(end,end)))/log(10),'k-','Linewidth',1.5)
plot(0:k,log(abs(median(PlotXI)-PlotXB(end,end)))/log(10),'k-','Linewidth',0.5)
ylim([-15,1])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$log_{10}(|u_k-u_p^{\star}|)$');
        set([hXLabel, hYLabel],'FontSize', 9 ,'Interpreter','LaTex');
        set(gca,'FontSize',9);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45*0.7865; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-r620','-djpeg',['Exemple_5_1_loguk_I_Sc_',num2str(Scenario)])

%% A 
figure
hold on
for iiiii = 1:size(PlotXA,1)
    h = plot(0:k,PlotXA(iiiii,:),'Color',[0.749, 0.5647, 0]);
    h.Color(4) = 0.1; 
end
plot(0:k,mean(PlotXA),'k-','Linewidth',1.5)
plot(0:k,median(PlotXA),'k-','Linewidth',0.5)
plot(0:k,PlotXB(end,end)*ones(1,k+1),'g-');
    ylim([-1,1])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u$');
        set([hXLabel, hYLabel],'FontSize', 9 ,'Interpreter','LaTex');
        set(gca,'FontSize',9);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45*0.7865; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-r620','-djpeg',['Exemple_5_1_uk_A_Sc_',num2str(Scenario)])
%% A - log
figure
hold on
for iiiii = 1:size(PlotXA,1)
    h = plot(0:k,log(abs(PlotXA(iiiii,:)-PlotXB(end,end)))/log(10),'Color',[0.749, 0.5647, 0],'Linewidth',0.5);
    h.Color(4) = 0.01; 
end
plot(0:k,log(abs(mean(PlotXA)-PlotXB(end,end)))/log(10),'k-','Linewidth',1.5)
plot(0:k,log(abs(median(PlotXA)-PlotXB(end,end)))/log(10),'k-','Linewidth',0.5)
ylim([-15,1])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$log_{10}(|u_k-u_p^{\star}|)$');
        set([hXLabel, hYLabel],'FontSize', 9 ,'Interpreter','LaTex');
        set(gca,'FontSize',9);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45*0.7865; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-r620','-djpeg',['Exemple_5_1_loguk_A_Sc_',num2str(Scenario)])


%% B 
figure
hold on
for iiiii = 1:size(PlotXB,1)
    h = plot(0:k,PlotXB(iiiii,:),'Color',[0.9 0.3 0.9],'Linewidth',0.5);
    h.Color(4) = 0.01; 
end
plot(0:k,mean(PlotXB),'k-','Linewidth',1.5)
plot(0:k,median(PlotXB),'k-','Linewidth',0.5)
plot(0:k,PlotXB(end,end)*ones(1,k+1),'g-');
    ylim([-1,1])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u$');
        set([hXLabel, hYLabel],'FontSize', 9 ,'Interpreter','LaTex');
        set(gca,'FontSize',9);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45*0.7865; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-r620','-djpeg',['Exemple_5_1_uk_B_Sc_',num2str(Scenario)])
%% B - log
figure
hold on
for iiiii = 1:size(PlotXB,1)
    h = plot(0:k,log(abs(PlotXB(iiiii,:)-PlotXB(end,end)+1e-25))/log(10),'Color',[0.9 0.3 0.9],'Linewidth',0.5);
    h.Color(4) = 0.01; 
end
plot(0:k,log(abs(mean(PlotXB)-PlotXB(end,end)))/log(10),'k-','Linewidth',1.5)
plot(0:k,log(abs(median(PlotXB)-PlotXB(end,end)))/log(10),'k-','Linewidth',0.5)
ylim([-15,1])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$log_{10}(|u_k-u_p^{\star}|)$');
        set([hXLabel, hYLabel],'FontSize', 9 ,'Interpreter','LaTex');
        set(gca,'FontSize',9);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45*0.7865; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-r620','-djpeg',['Exemple_5_1_loguk_B_Sc_',num2str(Scenario)])

         
end
%%
close all
clear all
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')




%% Functions
function [y1,dy1,ddy1]     = systeme_1p(x)   
    global a1p b1p c1p
    y1   = a1p + b1p*x + c1p*x^2 ;
    dy1  =       b1p   + 2*c1p*x ;
    ddy1 =               2*c1p   ;
end
function [y2,dy2,ddy2]     = systeme_2p(x)   
    global a2p b2p c2p
    y2   = a2p + b2p*x + c2p*x^2;
    dy2  =       b2p   + 2*c2p*x;
    ddy2 =               2*c2p  ;
end
function [y,dy,ddy,y1,dy1] = systeme_12p(x)  
    global a1p b1p c1p a2p b2p c2p
    
    y1   = a1p+b1p*x+c1p*x^2;
    dy1  =    b1p  +c1p*x*2;
    ddy1 =         c1p*2;
    
    y2   = a2p + b2p*y1   + c2p*y1^2;
    dy2  =       b2p*dy1  + c2p*2*y1*dy1;
    ddy2 =       b2p*ddy1 + c2p*2*(dy1*dy1 + y1*ddy1);
    
    y   = y2;
    dy  = dy2;
    ddy = ddy2;
end

function [y1,dy1,ddy1]     = systeme_1(x)    
    global a1 b1 c1; 
    y1   = a1 + b1*x + x'*c1*x;
    dy1  =       b1 +  2*c1*x;
    ddy1 =             2*c1  ;
end
function [y2,dy2,ddy2]     = systeme_2(x)    
    global a2 b2 c2
    y2   = a2 + b2*x + x'*c2*x;
    dy2  =      b2   + 2*c2*x;
    ddy2 =             2*c2  ;
end
function [y,dy,ddy,y1,dy1] = systeme_12(x)   
    global a1 b1 c1 a2 b2 c2;
    
    y1   = a1+b1*x+c1*x^2;
    dy1  =    b1  +c1*x*2;
    ddy1 =         c1*2;
    
    y2   = a2 + b2*y1   + c2*y1^2;
    dy2  =      b2*dy1  + c2*2*y1*dy1;
    ddy2 =      b2*ddy1 + c2*2*(dy1*dy1 + y1*ddy1);
    
    y   = y2;
    dy  = dy2;
    ddy = ddy2;
end
function [y,dy,ddy]    = systeme_12A(x,xk)        
    global a1 b1 c1 a2 b2 c2 epsilon_1A lambda_1A epsilon_2A lambda_2A;
    
    y1   = a1+b1*x+c1*x^2 + epsilon_1A + lambda_1A*(x-xk);
    dy1  =    b1  +c1*x*2 + lambda_1A;
    ddy1 =         c1*2;
    
    y2   = a2 + b2*y1   + c2*y1^2                  + epsilon_2A + lambda_2A*(x-xk);
    dy2  =      b2*dy1  + c2*2*y1*dy1              + lambda_2A;
    ddy2 =      b2*ddy1 + c2*2*(dy1*dy1 + y1*ddy1);
    
    y   = y2;
    dy  = dy2;
    ddy = ddy2;
end
function [y,dy,ddy]    = systeme_12B(x,x1k,x2k)   
    global a1 b1 c1 a2 b2 c2 epsilon_1B lambda_1B epsilon_2B lambda_2B;
    
    y1   = a1+b1*x+c1*x^2 + epsilon_1B + lambda_1B*(x-x1k);
    dy1  =    b1  +c1*x*2 + lambda_1B;
    ddy1 =         c1*2;
    
    y2   = a2 + b2*y1   + c2*y1^2                  + epsilon_2B + lambda_2B*(y1-x2k);
    dy2  =      b2*dy1  + c2*2*y1*dy1              + lambda_2B*dy1;
    ddy2 =      b2*ddy1 + c2*2*(dy1*dy1 + y1*ddy1) + lambda_2B*ddy1;
    
    y   = y2;
    dy  = dy2;
    ddy = ddy2;
end

function [phi,dphi,ddphi] = uy2phi1(u,y,dy,ddy)
    global ap1 bp1 cp1 dp1 ep1 
    phi   = ap1*u + bp1*y + cp1*u^2 + dp1*u*y + ep1*y^2;
    dphi  = ap1 + 2*cp1*u + dp1*y + dy*(bp1+dp1*u+2*ep1*y);
    ddphi = 2*cp1 + dp1*dy + ddy*(bp1+dp1*u+2*ep1*y) + dy*(dp1+2*ep1*dy);
end
function [phi,dphi,ddphi] = uy2phi2(u,y,dy,ddy)
    global ap2 bp2 cp2 dp2 ep2 
    phi   = ap2*u + bp2*y + cp2*u^2 + dp2*u*y + ep2*y^2;
    dphi  = ap2 + 2*cp2*u + dp2*y + dy*(bp2+dp2*u+2*ep2*y);
    ddphi = 2*cp2 + dp2*dy + ddy*(bp2+dp2*u+2*ep2*y) + dy*(dp2+2*ep2*dy);
end
function [phi,dphi,ddphi] = uy2phi3(u,y,dy,ddy)
    global ap3 bp3 cp3 dp3 ep3 
    phi   = ap3*u + bp3*y + cp3*u^2 + dp3*u*y + ep3*y^2;
    dphi  = ap3 + 2*cp3*u + dp3*y + dy*(bp3+dp3*u+2*ep3*y);
    ddphi = 2*cp3 + dp3*dy + ddy*(bp3+dp3*u+2*ep3*y) + dy*(dp3+2*ep3*dy);
end
function [phi,dphi,ddphi] = uy2phi4(u,y,dy,ddy)
    global ap4 bp4 cp4 dp4 ep4
    phi   = ap4*u + bp4*y + cp4*u^2 + dp4*u*y + ep4*y^2;
    dphi  = ap4 + 2*cp4*u + dp4*y + dy*(bp4+dp4*u+2*ep4*y);
    ddphi = 2*cp4 + dp4*dy + ddy*(bp4+dp4*u+2*ep4*y) + dy*(dp4+2*ep4*dy);
end


%% KMFCA_D ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_KMFCA_D(u)
    global Last_f
    ToDo_KMFCA_D(u)
    y = Last_f;
end
function [c,ceq] = constr_KMFCA_D(u)
    global  Last_c Last_ceq 
    ToDo_KMFCA_D(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_KMFCA_D(u)  
    global Last_u Last_c Last_f Last_ceq  k ...
        uk_D ukm1_D uoptk_D K_km1_D lambda_D
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        y = systeme_12(u);
        phi = uy2phi4(u,y,0,0);
        % Compute  filter
        if k == 1
            K = 0.1;
        else
            if abs(uk_D-ukm1_D) > 1e-8
                NablaS = (uk_D-ukm1_D)'*(u-uoptk_D)/(norm(uk_D-ukm1_D)^2);
                if NablaS < 1
                    K = 1/(1-NablaS);
                else
                    K = 1;
                end
            else
                K = K_km1_D;
            end
        end
        u2 = uk_D + K*(u-uk_D);
        % Apply an afine correction          
        phi = phi + lambda_D'* (u - uk_D);
        Last_u   = u;
        Last_f   = phi;
        Last_c   = [u2-1;-u2-1];
        Last_ceq = [];
    end
end

%% KMFCA_I ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_KMFCA_I(u)
    global Last_f
    ToDo_KMFCA_I(u)
    y = Last_f;
end
function [c,ceq] = constr_KMFCA_I(u)
    global  Last_c Last_ceq 
    ToDo_KMFCA_I(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_KMFCA_I(u)  
    global Last_u Last_c Last_f Last_ceq  k ...
        uk_I ukm1_I uoptk_I K_km1_I epsilon_I lambda_I
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Compute  filter
        if k == 1
            K = 0.1;
        else
            if abs(uk_I-ukm1_I) > 1e-8
                NablaS = (uk_I-ukm1_I)'*(u-uoptk_I)/(norm(uk_I-ukm1_I)^2);
                if NablaS < 1
                    K = 1/(1-NablaS);
                else
                    K = 1;
                end
            else
                K = K_km1_I;
            end
        end
        % Evaluate the updated model at a point u
        y = systeme_12(u) + epsilon_I + lambda_I*(u-uk_I);
        phi = uy2phi4(u,y,0,0);
%         Next point
        u2 = uk_I + K*(u-uk_I);
        Last_u   = u;
        Last_f   = phi;
        Last_c   = [u2-1;-u2-1];
        Last_ceq = [];
    end
end

%% KMFCA_A ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_KMFCA_A(u)
    global Last_f
    ToDo_KMFCA_A(u)
    y = Last_f;
end
function [c,ceq] = constr_KMFCA_A(u)
    global  Last_c Last_ceq 
    ToDo_KMFCA_A(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_KMFCA_A(u)  
    global Last_u Last_c Last_f Last_ceq  k ...
        uk_A ukm1_A uoptk_A K_km1_A  ...
    
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Compute  filter
        if k == 1
            K = 0.1;
        else
            if abs(uk_A-ukm1_A) > 1e-8
                NablaS = (uk_A-ukm1_A)'*(u-uoptk_A)/(norm(uk_A-ukm1_A)^2);
                if NablaS < 1
                    K = 1/(1-NablaS);
                else
                    K = 1;
                end
            else
                K = K_km1_A;
            end
        end
        % Evaluate the updated model at a point u
        y = systeme_12A(u,uk_A);
        phi = uy2phi4(u,y,0,0);
%         Next point
        u2 = uk_A + K*(u-uk_A);
        Last_u   = u;
        Last_f   = phi;
        Last_c   = [u2-1;-u2-1];
        Last_ceq = [];
    end
end

%% KMFCA_B ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_KMFCA_B(u)
    global Last_f
    ToDo_KMFCA_B(u)
    y = Last_f;
end
function [c,ceq] = constr_KMFCA_B(u)
    global  Last_c Last_ceq 
    ToDo_KMFCA_B(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_KMFCA_B(u)  
    global Last_u Last_c Last_f Last_ceq  k ...
        uk_B ukm1_B uoptk_B K_km1_B  u1k_B  u2k_B 
    
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Compute  filter
        if k == 1
            K = 0.1;
        else
            if abs(uk_B-ukm1_B) > 1e-8
                NablaS = (uk_B-ukm1_B)'*(u-uoptk_B)/(norm(uk_B-ukm1_B)^2);
                if NablaS < 1
                    K = 1/(1-NablaS);
                else
                    K = 1;
                end
            else
                K = K_km1_B;
            end
        end
        % Evaluate the updated model at a point u
        y = systeme_12B(u,u1k_B,u2k_B);
        phi = uy2phi4(u,y,0,0);
%         Next point
        u2 = uk_B + K*(u-uk_B);
        Last_u   = u;
        Last_f   = phi;
        Last_c   = [u2-1;-u2-1];
        Last_ceq = [];
    end
end

