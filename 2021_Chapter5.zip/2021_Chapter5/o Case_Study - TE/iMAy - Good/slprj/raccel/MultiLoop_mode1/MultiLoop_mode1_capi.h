#include "__cf_MultiLoop_mode1.h"
#ifndef RTW_HEADER_MultiLoop_mode1_capi_h
#define RTW_HEADER_MultiLoop_mode1_capi_h
#include "MultiLoop_mode1.h"
extern void MultiLoop_mode1_InitializeDataMapInfo ( void ) ;
#endif
