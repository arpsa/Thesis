#include "__cf_MultiLoop_mode1.h"
#include "rt_logging_mmi.h"
#include "MultiLoop_mode1_capi.h"
#include <math.h>
#include "MultiLoop_mode1.h"
#include "MultiLoop_mode1_private.h"
#include "MultiLoop_mode1_dt.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; extern boolean_T
gblExtModeStartPktReceived ; void raccelForceExtModeShutdown ( ) { if ( !
gblExtModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 4 , & stopRequested ) ; }
rtExtModeShutdown ( 4 ) ; }
#include "slsv_diagnostic_codegen_c_api.h"
const int_T gblNumToFiles = 0 ; const int_T gblNumFrFiles = 0 ; const int_T
gblNumFrWksBlocks = 3 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 1 ; int_T gbl_raccel_NumST = 5 ; const char_T
* gbl_raccel_Version = "8.13 (R2017b) 24-Jul-2017" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const char * gblSlvrJacPatternFileName =
"slprj\\raccel\\MultiLoop_mode1\\MultiLoop_mode1_Jpattern.mat" ; const int_T
gblNumRootInportBlks = 0 ; const int_T gblNumModelInputs = 0 ; extern
rtInportTUtable * gblInportTUtables ; extern const char * gblInportFileName ;
const int_T gblInportDataTypeIdx [ ] = { - 1 } ; const int_T gblInportDims [
] = { - 1 } ; const int_T gblInportComplex [ ] = { - 1 } ; const int_T
gblInportInterpoFlag [ ] = { - 1 } ; const int_T gblInportContinuous [ ] = {
- 1 } ;
#include "simstruc.h"
#include "fixedpoint.h"
B rtB ; X rtX ; DW rtDW ; static SimStruct model_S ; SimStruct * const rtS =
& model_S ; void MdlInitialize ( void ) { rtDW . b15chhqxbl = rtP . xmv1_0 ;
rtDW . gi2i3ynyug = rtP . xmv2_0 ; rtDW . i0wtqgyaoh = rtP . xmv3_0 ; rtDW .
b0yeel01dg = rtP . xmv4_0 ; rtDW . ekfb3mlxia = ( rtInf ) ; rtDW . kreyu5dtil
= rtP . xmv6_0 ; rtDW . a43kgavcjl = rtP . xmv7_0 ; rtDW . lck0yfjpoc = rtP .
xmv8_0 ; rtDW . b30wxoefe1 = ( rtInf ) ; rtDW . imzpv25nrh = rtP . xmv10_0 ;
rtDW . fdvolofpz2 = rtP . xmv11_0 ; rtDW . fmlqmojal0 = ( rtInf ) ; {
SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnInitializeConditions ( rts
) ; if ( ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } rtDW . bu34crt1v1
= ( rtInf ) ; rtDW . bngn1tntsv = rtP . Productionrate_x0 ; rtDW . o3jy54xzl4
= rtP . r1_0 ; rtDW . o51mmpjmne = ( rtInf ) ; rtDW . ofaprpi3ub = rtP .
UnitDelay_InitialCondition ; rtDW . bgawoufyg5 = ( rtInf ) ; rtDW .
gyhogfj3mi = rtP . Eadj_0 ; rtDW . iajewt1drp = ( rtInf ) ; rtDW . kf0tcjs1us
= rtP . UnitDelay_InitialCondition_irra24gzxq ; rtDW . lttqcvvdla = rtP .
r4_0 ; rtDW . klfqvxjavt = rtP . r5_0 ; rtDW . dtc5w4dyjs = rtP . r6_0 ; rtDW
. h3ggkxop2c = rtP . r7_0 ; rtDW . nkzljw5ytc = rtP . SP17_0 ; rtDW .
ie2lmlkvwc = rtP . UnitDelay_InitialCondition_eax13q1gy5 ; rtDW . mntgwrqzc0
= rtP . UnitDelay_InitialCondition_dnaty0hwiv ; rtDW . na2aurdisb = rtP .
UnitDelay_InitialCondition_i4ssjdv1x0 ; rtDW . bpyfsnmjtj = rtP .
UnitDelay_InitialCondition_l1wkjfueiw ; rtDW . dctqktm2mj = rtP .
UnitDelay_InitialCondition_nant221b3n ; rtDW . pezj2tsriy = rtP .
UnitDelay_InitialCondition_jds2mdg4dh ; rtDW . bncnd3iagx = rtP .
UnitDelay_InitialCondition_hup2ah5pmm ; rtDW . pn42trpqan = ( rtInf ) ; rtDW
. e0jcmikseh = ( rtInf ) ; rtDW . b5iesyj5df = ( rtInf ) ; rtDW . axrr55q2tu
= ( rtInf ) ; rtDW . hegs43c0e0 = ( rtInf ) ; rtDW . hwd0jegvir = rtP .
UnitDelay_InitialCondition_atyxdvbsf2 ; rtDW . fw4qwmmztz = rtP .
UnitDelay_InitialCondition_do4nccx1tx ; rtDW . pfo30wpbs5 = rtP .
UnitDelay_InitialCondition_kwbvpaeu2p ; rtDW . gdes5aukxs = rtP .
UnitDelay_InitialCondition_hrzr4dbmzu ; rtDW . niz4kap4en = rtP .
UnitDelay_InitialCondition_ht5jlrjgzg ; rtDW . ezrisir0qm = rtP .
UnitDelay_InitialCondition_aqdsuyvwgd ; rtDW . j1eqfx30ih = rtP .
UnitDelay_InitialCondition_frnu4gucc1 ; rtDW . oswghqu4mb = rtP .
UnitDelay_InitialCondition_jxvafx45id ; } void MdlStart ( void ) { { void * *
slioCatalogueAddr = rt_slioCatalogueAddr ( ) ; void * r2 = ( NULL ) ; void *
* pOSigstreamManagerAddr = ( NULL ) ; const char *
errorCreatingOSigstreamManager = ( NULL ) ; const char *
errorAddingR2SharedResource = ( NULL ) ; * slioCatalogueAddr =
rtwGetNewSlioCatalogue ( rt_GetMatSigLogSelectorFileName ( ) ) ;
errorAddingR2SharedResource = rtwAddR2SharedResource (
rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) , 1 ) ; if (
errorAddingR2SharedResource != ( NULL ) ) { rtwTerminateSlioCatalogue (
slioCatalogueAddr ) ; * slioCatalogueAddr = ( NULL ) ; ssSetErrorStatus ( rtS
, errorAddingR2SharedResource ) ; return ; } r2 = rtwGetR2SharedResource (
rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) ) ;
pOSigstreamManagerAddr = rt_GetOSigstreamManagerAddr ( ) ;
errorCreatingOSigstreamManager = rtwOSigstreamManagerCreateInstance (
rt_GetMatSigLogSelectorFileName ( ) , r2 , pOSigstreamManagerAddr ) ; if (
errorCreatingOSigstreamManager != ( NULL ) ) { * pOSigstreamManagerAddr = (
NULL ) ; ssSetErrorStatus ( rtS , errorCreatingOSigstreamManager ) ; return ;
} } { FWksInfo * fromwksInfo ; if ( ( fromwksInfo = ( FWksInfo * ) calloc ( 1
, sizeof ( FWksInfo ) ) ) == ( NULL ) ) { ssSetErrorStatus ( rtS ,
"from workspace STRING(Name) memory allocation error" ) ; } else {
fromwksInfo -> origWorkspaceVarName = "prev_setpoints" ; fromwksInfo ->
origDataTypeId = 0 ; fromwksInfo -> origIsComplex = 0 ; fromwksInfo ->
origWidth = 12 ; fromwksInfo -> origElSize = sizeof ( real_T ) ; fromwksInfo
-> data = ( void * ) rtP . FromWorkspace2_Data0 ; fromwksInfo -> nDataPoints
= 1 ; fromwksInfo -> time = ( double * ) & rtP . FromWorkspace2_Time0 ; rtDW
. oaotpdsye1 . TimePtr = fromwksInfo -> time ; rtDW . oaotpdsye1 . DataPtr =
fromwksInfo -> data ; rtDW . oaotpdsye1 . RSimInfoPtr = fromwksInfo ; } rtDW
. dga4g4wh0i . PrevIndex = 0 ; } { FWksInfo * fromwksInfo ; if ( (
fromwksInfo = ( FWksInfo * ) calloc ( 1 , sizeof ( FWksInfo ) ) ) == ( NULL )
) { ssSetErrorStatus ( rtS ,
"from workspace STRING(Name) memory allocation error" ) ; } else {
fromwksInfo -> origWorkspaceVarName = "setpoints" ; fromwksInfo ->
origDataTypeId = 0 ; fromwksInfo -> origIsComplex = 0 ; fromwksInfo ->
origWidth = 12 ; fromwksInfo -> origElSize = sizeof ( real_T ) ; fromwksInfo
-> data = ( void * ) rtP . FromWorkspace_Data0 ; fromwksInfo -> nDataPoints =
1 ; fromwksInfo -> time = ( double * ) & rtP . FromWorkspace_Time0 ; rtDW .
kzrko0fdik . TimePtr = fromwksInfo -> time ; rtDW . kzrko0fdik . DataPtr =
fromwksInfo -> data ; rtDW . kzrko0fdik . RSimInfoPtr = fromwksInfo ; } rtDW
. mszkyy54ed . PrevIndex = 0 ; } { FWksInfo * fromwksInfo ; if ( (
fromwksInfo = ( FWksInfo * ) calloc ( 1 , sizeof ( FWksInfo ) ) ) == ( NULL )
) { ssSetErrorStatus ( rtS ,
"from workspace STRING(Name) memory allocation error" ) ; } else {
fromwksInfo -> origWorkspaceVarName = "MNoise" ; fromwksInfo ->
origDataTypeId = 0 ; fromwksInfo -> origIsComplex = 0 ; fromwksInfo ->
origWidth = 1 ; fromwksInfo -> origElSize = sizeof ( real_T ) ; fromwksInfo
-> data = ( void * ) & rtP . FromWorkspace1_Data0 ; fromwksInfo ->
nDataPoints = 1 ; fromwksInfo -> time = ( double * ) & rtP .
FromWorkspace1_Time0 ; rtDW . n1d1uedpum . TimePtr = fromwksInfo -> time ;
rtDW . n1d1uedpum . DataPtr = fromwksInfo -> data ; rtDW . n1d1uedpum .
RSimInfoPtr = fromwksInfo ; } rtDW . bha2seug1p . PrevIndex = 0 ; } {
SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; sfcnStart ( rts ) ; if (
ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } { int_T dimensions [ 1 ] =
{ 41 } ; rtDW . hamffxefoc . LoggedData = rt_CreateLogVar ( ssGetRTWLogInfo (
rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , ( &
ssGetErrorStatus ( rtS ) ) , "XMEAS" , SS_DOUBLE , 0 , 0 , 0 , 41 , 1 ,
dimensions , NO_LOGVALDIMS , ( NULL ) , ( NULL ) , 0 , 1 , 0.01 , 1 ) ; if (
rtDW . hamffxefoc . LoggedData == ( NULL ) ) return ; } { int_T dimensions [
1 ] = { 12 } ; rtDW . lcfh0ubvex . LoggedData = rt_CreateLogVar (
ssGetRTWLogInfo ( rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , (
& ssGetErrorStatus ( rtS ) ) , "XMV" , SS_DOUBLE , 0 , 0 , 0 , 12 , 1 ,
dimensions , NO_LOGVALDIMS , ( NULL ) , ( NULL ) , 0 , 1 , 0.01 , 1 ) ; if (
rtDW . lcfh0ubvex . LoggedData == ( NULL ) ) return ; } { int_T dimensions [
1 ] = { 28 } ; rtDW . jjazz2siws . LoggedData = rt_CreateLogVar (
ssGetRTWLogInfo ( rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , (
& ssGetErrorStatus ( rtS ) ) , "IDV" , SS_DOUBLE , 0 , 0 , 0 , 28 , 1 ,
dimensions , NO_LOGVALDIMS , ( NULL ) , ( NULL ) , 0 , 1 , 0.01 , 1 ) ; if (
rtDW . jjazz2siws . LoggedData == ( NULL ) ) return ; } { int_T dimensions [
1 ] = { 1 } ; rtDW . aumzl4rw1t . LoggedData = rt_CreateLogVar (
ssGetRTWLogInfo ( rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , (
& ssGetErrorStatus ( rtS ) ) , "OpCost" , SS_DOUBLE , 0 , 0 , 0 , 1 , 1 ,
dimensions , NO_LOGVALDIMS , ( NULL ) , ( NULL ) , 0 , 1 , 0.01 , 1 ) ; if (
rtDW . aumzl4rw1t . LoggedData == ( NULL ) ) return ; } { int_T dimensions [
1 ] = { 10 } ; rtDW . dxxbfpxsda . LoggedData = rt_CreateLogVar (
ssGetRTWLogInfo ( rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , (
& ssGetErrorStatus ( rtS ) ) , "r" , SS_DOUBLE , 0 , 0 , 0 , 10 , 1 ,
dimensions , NO_LOGVALDIMS , ( NULL ) , ( NULL ) , 0 , 1 , 0.01 , 1 ) ; if (
rtDW . dxxbfpxsda . LoggedData == ( NULL ) ) return ; } { int_T dimensions [
1 ] = { 96 } ; rtDW . o1go0jwcko . LoggedData = rt_CreateLogVar (
ssGetRTWLogInfo ( rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , (
& ssGetErrorStatus ( rtS ) ) , "XMEASCOMP" , SS_DOUBLE , 0 , 0 , 0 , 96 , 1 ,
dimensions , NO_LOGVALDIMS , ( NULL ) , ( NULL ) , 0 , 1 , 0.01 , 1 ) ; if (
rtDW . o1go0jwcko . LoggedData == ( NULL ) ) return ; } { int_T dimensions [
1 ] = { 50 } ; rtDW . i4gnbypwkl . LoggedData = rt_CreateLogVar (
ssGetRTWLogInfo ( rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , (
& ssGetErrorStatus ( rtS ) ) , "x" , SS_DOUBLE , 0 , 0 , 0 , 50 , 1 ,
dimensions , NO_LOGVALDIMS , ( NULL ) , ( NULL ) , 0 , 1 , 0.01 , 1 ) ; if (
rtDW . i4gnbypwkl . LoggedData == ( NULL ) ) return ; } { int_T dimensions [
1 ] = { 11 } ; rtDW . gm0yt5d4nb . LoggedData = rt_CreateLogVar (
ssGetRTWLogInfo ( rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , (
& ssGetErrorStatus ( rtS ) ) , "XMEASSTREAM" , SS_DOUBLE , 0 , 0 , 0 , 11 , 1
, dimensions , NO_LOGVALDIMS , ( NULL ) , ( NULL ) , 0 , 1 , 0.01 , 1 ) ; if
( rtDW . gm0yt5d4nb . LoggedData == ( NULL ) ) return ; } { int_T dimensions
[ 1 ] = { 2 } ; rtDW . lwpcmu122x . LoggedData = rt_CreateLogVar (
ssGetRTWLogInfo ( rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , (
& ssGetErrorStatus ( rtS ) ) , "XMEASRHO" , SS_DOUBLE , 0 , 0 , 0 , 2 , 1 ,
dimensions , NO_LOGVALDIMS , ( NULL ) , ( NULL ) , 0 , 1 , 0.01 , 1 ) ; if (
rtDW . lwpcmu122x . LoggedData == ( NULL ) ) return ; } { int_T dimensions [
1 ] = { 1 } ; rtDW . af044523tm . LoggedData = rt_CreateLogVar (
ssGetRTWLogInfo ( rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , (
& ssGetErrorStatus ( rtS ) ) , "tout" , SS_DOUBLE , 0 , 0 , 0 , 1 , 1 ,
dimensions , NO_LOGVALDIMS , ( NULL ) , ( NULL ) , 0 , 1 , 0.01 , 1 ) ; if (
rtDW . af044523tm . LoggedData == ( NULL ) ) return ; } { RTWLogSignalInfo
rt_ScopeSignalInfo ; static int_T rt_ScopeSignalWidths [ ] = { 2 } ; static
int_T rt_ScopeSignalNumDimensions [ ] = { 1 } ; static int_T
rt_ScopeSignalDimensions [ ] = { 2 } ; static void * rt_ScopeCurrSigDims [ ]
= { ( NULL ) } ; static int_T rt_ScopeCurrSigDimsSize [ ] = { 4 } ; static
const char_T * rt_ScopeSignalLabels [ ] = { "" } ; static char_T
rt_ScopeSignalTitles [ ] = "" ; static int_T rt_ScopeSignalTitleLengths [ ] =
{ 0 } ; static boolean_T rt_ScopeSignalIsVarDims [ ] = { 0 } ; static int_T
rt_ScopeSignalPlotStyles [ ] = { 0 , 0 } ; BuiltInDTypeId dTypes [ 1 ] = {
SS_DOUBLE } ; static char_T rt_ScopeBlockName [ ] =
"MultiLoop_mode1/Production Loop Monitor/Production" ; static int_T
rt_ScopeFrameData [ ] = { 0 } ; static RTWPreprocessingFcnPtr
rt_ScopeSignalLoggingPreprocessingFcnPtrs [ ] = { ( NULL ) } ;
rt_ScopeSignalInfo . numSignals = 1 ; rt_ScopeSignalInfo . numCols =
rt_ScopeSignalWidths ; rt_ScopeSignalInfo . numDims =
rt_ScopeSignalNumDimensions ; rt_ScopeSignalInfo . dims =
rt_ScopeSignalDimensions ; rt_ScopeSignalInfo . isVarDims =
rt_ScopeSignalIsVarDims ; rt_ScopeSignalInfo . currSigDims =
rt_ScopeCurrSigDims ; rt_ScopeSignalInfo . currSigDimsSize =
rt_ScopeCurrSigDimsSize ; rt_ScopeSignalInfo . dataTypes = dTypes ;
rt_ScopeSignalInfo . complexSignals = ( NULL ) ; rt_ScopeSignalInfo .
frameData = rt_ScopeFrameData ; rt_ScopeSignalInfo . preprocessingPtrs =
rt_ScopeSignalLoggingPreprocessingFcnPtrs ; rt_ScopeSignalInfo . labels .
cptr = rt_ScopeSignalLabels ; rt_ScopeSignalInfo . titles =
rt_ScopeSignalTitles ; rt_ScopeSignalInfo . titleLengths =
rt_ScopeSignalTitleLengths ; rt_ScopeSignalInfo . plotStyles =
rt_ScopeSignalPlotStyles ; rt_ScopeSignalInfo . blockNames . cptr = ( NULL )
; rt_ScopeSignalInfo . stateNames . cptr = ( NULL ) ; rt_ScopeSignalInfo .
crossMdlRef = ( NULL ) ; rt_ScopeSignalInfo . dataTypeConvert = ( NULL ) ;
rtDW . kzls2lxgyw . LoggedData = rt_CreateStructLogVar ( ssGetRTWLogInfo (
rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , ( &
ssGetErrorStatus ( rtS ) ) , "Production" , 1 , 0 , 1 , 0.01 , &
rt_ScopeSignalInfo , rt_ScopeBlockName ) ; if ( rtDW . kzls2lxgyw .
LoggedData == ( NULL ) ) return ; } { RTWLogSignalInfo rt_ScopeSignalInfo ;
static int_T rt_ScopeSignalWidths [ ] = { 2 } ; static int_T
rt_ScopeSignalNumDimensions [ ] = { 1 } ; static int_T
rt_ScopeSignalDimensions [ ] = { 2 } ; static void * rt_ScopeCurrSigDims [ ]
= { ( NULL ) } ; static int_T rt_ScopeCurrSigDimsSize [ ] = { 4 } ; static
const char_T * rt_ScopeSignalLabels [ ] = { "" } ; static char_T
rt_ScopeSignalTitles [ ] = "" ; static int_T rt_ScopeSignalTitleLengths [ ] =
{ 0 } ; static boolean_T rt_ScopeSignalIsVarDims [ ] = { 0 } ; static int_T
rt_ScopeSignalPlotStyles [ ] = { 0 , 0 } ; BuiltInDTypeId dTypes [ 1 ] = {
SS_DOUBLE } ; static char_T rt_ScopeBlockName [ ] =
"MultiLoop_mode1/Quality Loop Monitor/Quality" ; static int_T
rt_ScopeFrameData [ ] = { 0 } ; static RTWPreprocessingFcnPtr
rt_ScopeSignalLoggingPreprocessingFcnPtrs [ ] = { ( NULL ) } ;
rt_ScopeSignalInfo . numSignals = 1 ; rt_ScopeSignalInfo . numCols =
rt_ScopeSignalWidths ; rt_ScopeSignalInfo . numDims =
rt_ScopeSignalNumDimensions ; rt_ScopeSignalInfo . dims =
rt_ScopeSignalDimensions ; rt_ScopeSignalInfo . isVarDims =
rt_ScopeSignalIsVarDims ; rt_ScopeSignalInfo . currSigDims =
rt_ScopeCurrSigDims ; rt_ScopeSignalInfo . currSigDimsSize =
rt_ScopeCurrSigDimsSize ; rt_ScopeSignalInfo . dataTypes = dTypes ;
rt_ScopeSignalInfo . complexSignals = ( NULL ) ; rt_ScopeSignalInfo .
frameData = rt_ScopeFrameData ; rt_ScopeSignalInfo . preprocessingPtrs =
rt_ScopeSignalLoggingPreprocessingFcnPtrs ; rt_ScopeSignalInfo . labels .
cptr = rt_ScopeSignalLabels ; rt_ScopeSignalInfo . titles =
rt_ScopeSignalTitles ; rt_ScopeSignalInfo . titleLengths =
rt_ScopeSignalTitleLengths ; rt_ScopeSignalInfo . plotStyles =
rt_ScopeSignalPlotStyles ; rt_ScopeSignalInfo . blockNames . cptr = ( NULL )
; rt_ScopeSignalInfo . stateNames . cptr = ( NULL ) ; rt_ScopeSignalInfo .
crossMdlRef = ( NULL ) ; rt_ScopeSignalInfo . dataTypeConvert = ( NULL ) ;
rtDW . jwlo4oww5f . LoggedData = rt_CreateStructLogVar ( ssGetRTWLogInfo (
rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , ( &
ssGetErrorStatus ( rtS ) ) , "Quality" , 1 , 0 , 1 , 0.01 , &
rt_ScopeSignalInfo , rt_ScopeBlockName ) ; if ( rtDW . jwlo4oww5f .
LoggedData == ( NULL ) ) return ; } MdlInitialize ( ) ; { static const real_T
rtcs0_dzj03d1j4v [ 50 ] = { 11.952176106184915 , 7.950300220587021 ,
4.8684537248819986 , 0.27297286851217462 , 18.170957937566698 ,
6.0756857605350705 , 138.77247446239622 , 136.12805974424231 ,
2.5240502421064033 , 62.627138395126366 , 41.656312838317461 ,
25.522301888401437 , 0.15168510251838813 , 10.746156544195594 ,
3.5933712166350196 , 52.279082275951872 , 41.117503515415947 ,
0.6488228317916539 , 0.42478972487351035 , 0.0078827063665042191 ,
0.89337220488861935 , 0.0096027938562258663 , 0.51506858356948537 ,
0.16681715341625392 , 48.183122896125951 , 39.420524571989105 ,
0.380153203870486 , 113.68415846339275 , 52.611730377082857 ,
66.661346315892743 , 21.212165336364368 , 58.941968290602773 ,
14.336659127811398 , 17.649098880625942 , 8.5121732654982658 ,
1.1379896577954212 , 102.4800282325948 , 92.262530705397239 ,
62.806559460324159 , 53.286026966911585 , 26.661254009105338 ,
60.484801083141221 , 4.44659081257122E-323 , 24.234688815797391 ,
37.209102766947353 , 46.430892344071623 , 8.20148972096469E-322 ,
35.944588369409736 , 12.209547880014606 , 99.999999999999915 } ; ( void )
memcpy ( rtX . dzj03d1j4v , rtcs0_dzj03d1j4v , 50 * sizeof ( real_T ) ) ; }
rtDW . b15chhqxbl = 62.806983901159221 ; rtDW . gi2i3ynyug =
53.286708861352047 ; rtDW . i0wtqgyaoh = 26.662172563362368 ; rtDW .
b0yeel01dg = 60.482853992876215 ; rtDW . kreyu5dtil = 24.229300906565072 ;
rtDW . a43kgavcjl = 37.208198128091411 ; rtDW . lck0yfjpoc =
46.430526395103641 ; rtDW . imzpv25nrh = 35.86532151232776 ; rtDW .
fdvolofpz2 = 12.930642047543767 ; rtDW . bngn1tntsv = - 0.44888336148273855 ;
rtDW . o3jy54xzl4 = 0.0027228362442928825 ; rtDW . ofaprpi3ub =
0.15679989365145985 ; rtDW . gyhogfj3mi = 0.63225024450851919 ; rtDW .
kf0tcjs1us = - 0.19359235829376331 ; rtDW . lttqcvvdla = 0.0922366099003225 ;
rtDW . klfqvxjavt = 0.0019155098024649312 ; rtDW . dtc5w4dyjs =
0.25370500558318143 ; rtDW . h3ggkxop2c = 0.2287117711745113 ; rtDW .
nkzljw5ytc = 92.020048977831067 ; rtDW . ie2lmlkvwc = - 0.50665674770999658 ;
rtDW . mntgwrqzc0 = 0.0026940509994885509 ; rtDW . na2aurdisb =
0.083514558990948728 ; rtDW . bpyfsnmjtj = 62.429570964992763 ; rtDW .
dctqktm2mj = 9.7233862746652449 ; rtDW . pezj2tsriy = - 0.140664345075038 ;
rtDW . bncnd3iagx = - 0.0063601433077061786 ; rtDW . hwd0jegvir =
0.0407516156845702 ; rtDW . fw4qwmmztz = 1.0408538619039973 ; rtDW .
pfo30wpbs5 = 0.0079613898323600552 ; rtDW . gdes5aukxs = 0.048094569533532194
; rtDW . niz4kap4en = - 1.0417700470544915 ; rtDW . ezrisir0qm = -
0.14156661603362863 ; rtDW . j1eqfx30ih = 0.077381965807635567 ; rtDW .
oswghqu4mb = 0.94917471361589634 ; { bool externalInputIsInDatasetFormat =
false ; void * pISigstreamManager = rt_GetISigstreamManager ( ) ;
rtwISigstreamManagerGetInputIsInDatasetFormat ( pISigstreamManager , &
externalInputIsInDatasetFormat ) ; if ( externalInputIsInDatasetFormat ) { }
} } void MdlOutputs ( int_T tid ) { real_T deltaT ; real_T riseValLimit ;
real_T rateLimiterRate ; boolean_T cnd1lynbtc ; real_T e23lo4llas ; real_T
nvbt4nphgs ; real_T fnsk42iewn ; int32_T i ; real_T tmp [ 7 ] ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . iolwllfzji = rtDW . b15chhqxbl ; rtB
. ljqiskk5u3 = rtDW . gi2i3ynyug ; rtB . gwhpssih4t = rtDW . i0wtqgyaoh ; rtB
. fpgen5oqtn = rtDW . b0yeel01dg ; { real_T t = ssGetTaskTime ( rtS , 1 ) ;
real_T * pTimeValues = ( real_T * ) rtDW . oaotpdsye1 . TimePtr ; real_T *
pDataValues = ( real_T * ) rtDW . oaotpdsye1 . DataPtr ; int numPoints ,
lastPoint ; FWksInfo * fromwksInfo = ( FWksInfo * ) rtDW . oaotpdsye1 .
RSimInfoPtr ; numPoints = fromwksInfo -> nDataPoints ; lastPoint = numPoints
- 1 ; if ( t < pTimeValues [ 0 ] ) { { int_T elIdx ; for ( elIdx = 0 ; elIdx
< 12 ; ++ elIdx ) { ( & rtB . bccrbyw3op [ 0 ] ) [ elIdx ] = 0.0 ; } } } else
if ( t >= pTimeValues [ lastPoint ] ) { { int_T elIdx ; for ( elIdx = 0 ;
elIdx < 12 ; ++ elIdx ) { ( & rtB . bccrbyw3op [ 0 ] ) [ elIdx ] =
pDataValues [ lastPoint ] ; pDataValues += numPoints ; } } } else { int_T
currTimeIndex = rtDW . dga4g4wh0i . PrevIndex ; if ( t < pTimeValues [
currTimeIndex ] ) { while ( t < pTimeValues [ currTimeIndex ] ) {
currTimeIndex -- ; } } else { while ( t >= pTimeValues [ currTimeIndex + 1 ]
) { currTimeIndex ++ ; } } { int_T elIdx ; for ( elIdx = 0 ; elIdx < 12 ; ++
elIdx ) { ( & rtB . bccrbyw3op [ 0 ] ) [ elIdx ] = pDataValues [
currTimeIndex ] ; pDataValues += numPoints ; } } rtDW . dga4g4wh0i .
PrevIndex = currTimeIndex ; } } } cnd1lynbtc = ( ssGetT ( rtS ) <= rtP .
CompareToConstant1_const ) ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { { real_T
t = ssGetTaskTime ( rtS , 1 ) ; real_T * pTimeValues = ( real_T * ) rtDW .
kzrko0fdik . TimePtr ; real_T * pDataValues = ( real_T * ) rtDW . kzrko0fdik
. DataPtr ; int numPoints , lastPoint ; FWksInfo * fromwksInfo = ( FWksInfo *
) rtDW . kzrko0fdik . RSimInfoPtr ; numPoints = fromwksInfo -> nDataPoints ;
lastPoint = numPoints - 1 ; if ( t < pTimeValues [ 0 ] ) { { int_T elIdx ;
for ( elIdx = 0 ; elIdx < 12 ; ++ elIdx ) { ( & rtB . cs2ztziz0k [ 0 ] ) [
elIdx ] = 0.0 ; } } } else if ( t >= pTimeValues [ lastPoint ] ) { { int_T
elIdx ; for ( elIdx = 0 ; elIdx < 12 ; ++ elIdx ) { ( & rtB . cs2ztziz0k [ 0
] ) [ elIdx ] = pDataValues [ lastPoint ] ; pDataValues += numPoints ; } } }
else { int_T currTimeIndex = rtDW . mszkyy54ed . PrevIndex ; if ( t <
pTimeValues [ currTimeIndex ] ) { while ( t < pTimeValues [ currTimeIndex ] )
{ currTimeIndex -- ; } } else { while ( t >= pTimeValues [ currTimeIndex + 1
] ) { currTimeIndex ++ ; } } { int_T elIdx ; for ( elIdx = 0 ; elIdx < 12 ;
++ elIdx ) { ( & rtB . cs2ztziz0k [ 0 ] ) [ elIdx ] = pDataValues [
currTimeIndex ] ; pDataValues += numPoints ; } } rtDW . mszkyy54ed .
PrevIndex = currTimeIndex ; } } } for ( i = 0 ; i < 12 ; i ++ ) { if (
cnd1lynbtc ) { rtB . m5xbxvfteh [ i ] = rtB . bccrbyw3op [ i ] ; } else { rtB
. m5xbxvfteh [ i ] = rtB . cs2ztziz0k [ i ] ; } } if ( rtDW . ekfb3mlxia == (
rtInf ) ) { rtB . gyprops4hy = rtB . m5xbxvfteh [ 9 ] ; } else { deltaT =
ssGetTaskTime ( rtS , 0 ) - rtDW . ekfb3mlxia ; riseValLimit = deltaT * rtP .
RateLimiter11_RisingLim ; rateLimiterRate = rtB . m5xbxvfteh [ 9 ] - rtDW .
mlmenq1uvm ; if ( rateLimiterRate > riseValLimit ) { rtB . gyprops4hy = rtDW
. mlmenq1uvm + riseValLimit ; } else { deltaT *= rtP .
RateLimiter11_FallingLim ; if ( rateLimiterRate < deltaT ) { rtB . gyprops4hy
= rtDW . mlmenq1uvm + deltaT ; } else { rtB . gyprops4hy = rtB . m5xbxvfteh [
9 ] ; } } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . hxgdkcqc2i = rtDW .
kreyu5dtil ; rtB . mcfswk5n2o = rtDW . a43kgavcjl ; rtB . gtctzgqgd2 = rtDW .
lck0yfjpoc ; rtB . j0cur13put = rtDW . imzpv25nrh ; rtB . mangrqenh4 = rtDW .
fdvolofpz2 ; } if ( rtDW . b30wxoefe1 == ( rtInf ) ) { rtB . fzdqkoyver = rtB
. m5xbxvfteh [ 10 ] ; } else { deltaT = ssGetTaskTime ( rtS , 0 ) - rtDW .
b30wxoefe1 ; riseValLimit = deltaT * rtP . RateLimiter9_RisingLim ;
rateLimiterRate = rtB . m5xbxvfteh [ 10 ] - rtDW . g2qwfqxtqm ; if (
rateLimiterRate > riseValLimit ) { rtB . fzdqkoyver = rtDW . g2qwfqxtqm +
riseValLimit ; } else { deltaT *= rtP . RateLimiter9_FallingLim ; if (
rateLimiterRate < deltaT ) { rtB . fzdqkoyver = rtDW . g2qwfqxtqm + deltaT ;
} else { rtB . fzdqkoyver = rtB . m5xbxvfteh [ 10 ] ; } } } if ( rtDW .
fmlqmojal0 == ( rtInf ) ) { rtB . j24sggezs0 = rtB . m5xbxvfteh [ 11 ] ; }
else { deltaT = ssGetTaskTime ( rtS , 0 ) - rtDW . fmlqmojal0 ; riseValLimit
= deltaT * rtP . RateLimiter10_RisingLim ; rateLimiterRate = rtB . m5xbxvfteh
[ 11 ] - rtDW . gcno0q5mlf ; if ( rateLimiterRate > riseValLimit ) { rtB .
j24sggezs0 = rtDW . gcno0q5mlf + riseValLimit ; } else { deltaT *= rtP .
RateLimiter10_FallingLim ; if ( rateLimiterRate < deltaT ) { rtB . j24sggezs0
= rtDW . gcno0q5mlf + deltaT ; } else { rtB . j24sggezs0 = rtB . m5xbxvfteh [
11 ] ; } } } if ( ssGetTaskTime ( rtS , 0 ) < rtP . Step_Time ) { e23lo4llas
= rtP . Step_Y0 ; } else { e23lo4llas = rtP . Step_YFinal ; } for ( i = 0 ; i
< 28 ; i ++ ) { rtB . df14e2fwpd [ i ] = rtP . Disturbances1_Value [ i ] *
e23lo4llas ; rtB . g0ajxjwpf3 [ i ] = rtP . Disturbances_Value [ i ] + rtB .
df14e2fwpd [ i ] ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { { real_T t =
ssGetTaskTime ( rtS , 1 ) ; real_T * pTimeValues = ( real_T * ) rtDW .
n1d1uedpum . TimePtr ; real_T * pDataValues = ( real_T * ) rtDW . n1d1uedpum
. DataPtr ; int numPoints , lastPoint ; FWksInfo * fromwksInfo = ( FWksInfo *
) rtDW . n1d1uedpum . RSimInfoPtr ; numPoints = fromwksInfo -> nDataPoints ;
lastPoint = numPoints - 1 ; if ( t < pTimeValues [ 0 ] ) { rtB . i5fngjpd5u =
0.0 ; } else if ( t >= pTimeValues [ lastPoint ] ) { rtB . i5fngjpd5u =
pDataValues [ lastPoint ] ; } else { int_T currTimeIndex = rtDW . bha2seug1p
. PrevIndex ; if ( t < pTimeValues [ currTimeIndex ] ) { while ( t <
pTimeValues [ currTimeIndex ] ) { currTimeIndex -- ; } } else { while ( t >=
pTimeValues [ currTimeIndex + 1 ] ) { currTimeIndex ++ ; } } rtB . i5fngjpd5u
= pDataValues [ currTimeIndex ] ; rtDW . bha2seug1p . PrevIndex =
currTimeIndex ; } } } { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ;
sfcnOutputs ( rts , 0 ) ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB .
kku5xrtb04 = rtP . Gain4_Gain * rtB . gtctzgqgd2 ; } tmp [ 0 ] = rtB .
omprcv5sy2 [ 28 ] ; for ( i = 0 ; i < 6 ; i ++ ) { tmp [ i + 1 ] = rtB .
omprcv5sy2 [ 30 + i ] ; } deltaT = 0.0 ; for ( i = 0 ; i < 7 ; i ++ ) {
deltaT += rtP . Gain2_Gain [ i ] * tmp [ i ] ; } rtB . omriyhtfeo = ( ( rtP .
Gain3_Gain [ 0 ] * rtB . omprcv5sy2 [ 36 ] + rtP . Gain3_Gain [ 1 ] * rtB .
omprcv5sy2 [ 37 ] ) + rtP . Gain3_Gain [ 2 ] * rtB . omprcv5sy2 [ 38 ] ) *
rtB . kku5xrtb04 + ( ( rtP . Gain_Gain [ 0 ] * rtB . omprcv5sy2 [ 18 ] + rtP
. Gain_Gain [ 1 ] * rtB . omprcv5sy2 [ 19 ] ) + rtP . Gain1_Gain * rtB .
omprcv5sy2 [ 9 ] * deltaT ) ; if ( ssIsSampleHit ( rtS , 2 , 0 ) ) { if (
ssGetLogOutput ( rtS ) ) { { double locTime = ssGetTaskTime ( rtS , 2 ) ; ;
if ( rtwTimeInLoggingInterval ( rtliGetLoggingInterval ( ssGetRootSS ( rtS )
-> mdlInfo -> rtwLogInfo ) , locTime ) ) { rt_UpdateLogVar ( ( LogVar * ) (
LogVar * ) ( rtDW . hamffxefoc . LoggedData ) , & rtB . omprcv5sy2 [ 0 ] , 0
) ; } } } rtB . avhxbjy5jl [ 0 ] = rtB . iolwllfzji ; rtB . avhxbjy5jl [ 1 ]
= rtB . ljqiskk5u3 ; rtB . avhxbjy5jl [ 2 ] = rtB . gwhpssih4t ; rtB .
avhxbjy5jl [ 3 ] = rtB . fpgen5oqtn ; rtB . avhxbjy5jl [ 4 ] = rtB .
gyprops4hy ; rtB . avhxbjy5jl [ 5 ] = rtB . hxgdkcqc2i ; rtB . avhxbjy5jl [ 6
] = rtB . mcfswk5n2o ; rtB . avhxbjy5jl [ 7 ] = rtB . gtctzgqgd2 ; rtB .
avhxbjy5jl [ 8 ] = rtB . fzdqkoyver ; rtB . avhxbjy5jl [ 9 ] = rtB .
j0cur13put ; rtB . avhxbjy5jl [ 10 ] = rtB . mangrqenh4 ; rtB . avhxbjy5jl [
11 ] = rtB . j24sggezs0 ; if ( ssGetLogOutput ( rtS ) ) { { double locTime =
ssGetTaskTime ( rtS , 2 ) ; ; if ( rtwTimeInLoggingInterval (
rtliGetLoggingInterval ( ssGetRootSS ( rtS ) -> mdlInfo -> rtwLogInfo ) ,
locTime ) ) { rt_UpdateLogVar ( ( LogVar * ) ( LogVar * ) ( rtDW . lcfh0ubvex
. LoggedData ) , & rtB . avhxbjy5jl [ 0 ] , 0 ) ; } } } if ( ssGetLogOutput (
rtS ) ) { { double locTime = ssGetTaskTime ( rtS , 2 ) ; ; if (
rtwTimeInLoggingInterval ( rtliGetLoggingInterval ( ssGetRootSS ( rtS ) ->
mdlInfo -> rtwLogInfo ) , locTime ) ) { rt_UpdateLogVar ( ( LogVar * ) (
LogVar * ) ( rtDW . jjazz2siws . LoggedData ) , & rtB . g0ajxjwpf3 [ 0 ] , 0
) ; } } } if ( ssGetLogOutput ( rtS ) ) { { double locTime = ssGetTaskTime (
rtS , 2 ) ; ; if ( rtwTimeInLoggingInterval ( rtliGetLoggingInterval (
ssGetRootSS ( rtS ) -> mdlInfo -> rtwLogInfo ) , locTime ) ) {
rt_UpdateLogVar ( ( LogVar * ) ( LogVar * ) ( rtDW . aumzl4rw1t . LoggedData
) , & rtB . omprcv5sy2 [ 201 ] , 0 ) ; } } } } if ( rtDW . bu34crt1v1 == (
rtInf ) ) { rtB . l5enleslqf = rtB . m5xbxvfteh [ 0 ] ; } else { deltaT =
ssGetTaskTime ( rtS , 0 ) - rtDW . bu34crt1v1 ; riseValLimit = deltaT * rtP .
RateLimiter_RisingLim ; rateLimiterRate = rtB . m5xbxvfteh [ 0 ] - rtDW .
jbapjrt3qt ; if ( rateLimiterRate > riseValLimit ) { rtB . l5enleslqf = rtDW
. jbapjrt3qt + riseValLimit ; } else { deltaT *= rtP . RateLimiter_FallingLim
; if ( rateLimiterRate < deltaT ) { rtB . l5enleslqf = rtDW . jbapjrt3qt +
deltaT ; } else { rtB . l5enleslqf = rtB . m5xbxvfteh [ 0 ] ; } } } if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . ikqwcxe241 = rtDW . bngn1tntsv ; }
rtB . ozcp3eaat4 = rtP . Gain_Gain_pdu3ue3qpg * rtB . l5enleslqf + rtB .
ikqwcxe241 ; if ( ssIsSampleHit ( rtS , 3 , 0 ) ) { fnsk42iewn = rtDW .
o3jy54xzl4 ; } if ( rtDW . o51mmpjmne == ( rtInf ) ) { rtB . iygofvadrj = rtB
. m5xbxvfteh [ 6 ] ; } else { deltaT = ssGetTaskTime ( rtS , 0 ) - rtDW .
o51mmpjmne ; riseValLimit = deltaT * rtP . RateLimiter6_RisingLim ;
rateLimiterRate = rtB . m5xbxvfteh [ 6 ] - rtDW . e42tdvzthc ; if (
rateLimiterRate > riseValLimit ) { rtB . iygofvadrj = rtDW . e42tdvzthc +
riseValLimit ; } else { deltaT *= rtP . RateLimiter6_FallingLim ; if (
rateLimiterRate < deltaT ) { rtB . iygofvadrj = rtDW . e42tdvzthc + deltaT ;
} else { rtB . iygofvadrj = rtB . m5xbxvfteh [ 6 ] ; } } } e23lo4llas = rtB .
omprcv5sy2 [ 22 ] + rtB . omprcv5sy2 [ 24 ] ; rtB . dxh4onrpf2 = rtB .
iygofvadrj - rtP . Gain1_Gain_a1wggbqhys * rtB . omprcv5sy2 [ 22 ] /
e23lo4llas ; if ( ssIsSampleHit ( rtS , 3 , 0 ) ) { rtB . dfqakv4d54 = rtB .
dxh4onrpf2 ; nvbt4nphgs = ( ( rtP . yAcontrol_Ts / rtP . yAcontrol_Ti * rtB .
dfqakv4d54 + rtB . dfqakv4d54 ) - rtDW . ofaprpi3ub ) * rtP . yAcontrol_Kc ;
rtB . kjns5co5t5 = fnsk42iewn + nvbt4nphgs ; } if ( rtDW . bgawoufyg5 == (
rtInf ) ) { rtB . j0cvegqaqh = rtB . m5xbxvfteh [ 5 ] ; } else { deltaT =
ssGetTaskTime ( rtS , 0 ) - rtDW . bgawoufyg5 ; riseValLimit = deltaT * rtP .
RateLimiter1_RisingLim ; rateLimiterRate = rtB . m5xbxvfteh [ 5 ] - rtDW .
n1cxse1jno ; if ( rateLimiterRate > riseValLimit ) { rtB . j0cvegqaqh = rtDW
. n1cxse1jno + riseValLimit ; } else { deltaT *= rtP .
RateLimiter1_FallingLim ; if ( rateLimiterRate < deltaT ) { rtB . j0cvegqaqh
= rtDW . n1cxse1jno + deltaT ; } else { rtB . j0cvegqaqh = rtB . m5xbxvfteh [
5 ] ; } } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . f4zvypfoze = rtDW .
gyhogfj3mi ; rtB . agz0woju0p = rtP . Gain1_Gain_et34qjmame * rtB .
f4zvypfoze ; rtB . hrzv1fvxzj = rtP . Gain_Gain_au5n3t3t54 * rtB . f4zvypfoze
; } rtB . k2wkz11jl0 = ( ( rtP . P2_Coefs [ 0 ] * rtB . j0cvegqaqh + rtP .
P2_Coefs [ 1 ] ) * rtB . j0cvegqaqh + rtP . P2_Coefs [ 2 ] ) - rtB .
agz0woju0p / rtB . ozcp3eaat4 ; rtB . ndg0mjtwv5 = ( ( rtP . P3_Coefs [ 0 ] *
rtB . j0cvegqaqh + rtP . P3_Coefs [ 1 ] ) * rtB . j0cvegqaqh + rtP . P3_Coefs
[ 2 ] ) + rtB . hrzv1fvxzj / rtB . ozcp3eaat4 ; if ( rtDW . iajewt1drp == (
rtInf ) ) { rtB . fmtr4xt2pw = rtB . m5xbxvfteh [ 7 ] ; } else { deltaT =
ssGetTaskTime ( rtS , 0 ) - rtDW . iajewt1drp ; riseValLimit = deltaT * rtP .
RateLimiter7_RisingLim ; rateLimiterRate = rtB . m5xbxvfteh [ 7 ] - rtDW .
a3igfd1reu ; if ( rateLimiterRate > riseValLimit ) { rtB . fmtr4xt2pw = rtDW
. a3igfd1reu + riseValLimit ; } else { deltaT *= rtP .
RateLimiter7_FallingLim ; if ( rateLimiterRate < deltaT ) { rtB . fmtr4xt2pw
= rtDW . a3igfd1reu + deltaT ; } else { rtB . fmtr4xt2pw = rtB . m5xbxvfteh [
7 ] ; } } } rtB . jodh2mlmue = rtB . fmtr4xt2pw - e23lo4llas ; if (
ssIsSampleHit ( rtS , 3 , 0 ) ) { rtB . o32oplehzw = rtB . jodh2mlmue ; rtB .
jyyd5wflg2 = ( ( ( rtP . yACcontrol_Ts / rtP . yACcontrol_Ti * rtB .
o32oplehzw + rtB . o32oplehzw ) - rtDW . kf0tcjs1us ) * rtP . yACcontrol_Kc -
nvbt4nphgs ) + rtDW . lttqcvvdla ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtB . aj5vhl240h = rtDW . klfqvxjavt ; rtB . jjnncqp5so = rtDW . dtc5w4dyjs ;
rtB . ba4zpaneod = rtDW . h3ggkxop2c ; rtB . majq1kos5f = rtDW . nkzljw5ytc ;
} if ( ssIsSampleHit ( rtS , 2 , 0 ) ) { rtB . jffesjegzu [ 0 ] = rtB .
ozcp3eaat4 ; rtB . jffesjegzu [ 1 ] = rtB . kjns5co5t5 ; rtB . jffesjegzu [ 2
] = rtB . k2wkz11jl0 ; rtB . jffesjegzu [ 3 ] = rtB . ndg0mjtwv5 ; rtB .
jffesjegzu [ 4 ] = rtB . jyyd5wflg2 ; rtB . jffesjegzu [ 5 ] = rtB .
aj5vhl240h ; rtB . jffesjegzu [ 6 ] = rtB . jjnncqp5so ; rtB . jffesjegzu [ 7
] = rtB . ba4zpaneod ; rtB . jffesjegzu [ 8 ] = rtB . f4zvypfoze ; rtB .
jffesjegzu [ 9 ] = rtB . majq1kos5f ; if ( ssGetLogOutput ( rtS ) ) { {
double locTime = ssGetTaskTime ( rtS , 2 ) ; ; if ( rtwTimeInLoggingInterval
( rtliGetLoggingInterval ( ssGetRootSS ( rtS ) -> mdlInfo -> rtwLogInfo ) ,
locTime ) ) { rt_UpdateLogVar ( ( LogVar * ) ( LogVar * ) ( rtDW . dxxbfpxsda
. LoggedData ) , & rtB . jffesjegzu [ 0 ] , 0 ) ; } } } if ( ssGetLogOutput (
rtS ) ) { { double locTime = ssGetTaskTime ( rtS , 2 ) ; ; if (
rtwTimeInLoggingInterval ( rtliGetLoggingInterval ( ssGetRootSS ( rtS ) ->
mdlInfo -> rtwLogInfo ) , locTime ) ) { rt_UpdateLogVar ( ( LogVar * ) (
LogVar * ) ( rtDW . o1go0jwcko . LoggedData ) , & rtB . omprcv5sy2 [ 41 ] , 0
) ; } } } if ( ssGetLogOutput ( rtS ) ) { { double locTime = ssGetTaskTime (
rtS , 2 ) ; ; if ( rtwTimeInLoggingInterval ( rtliGetLoggingInterval (
ssGetRootSS ( rtS ) -> mdlInfo -> rtwLogInfo ) , locTime ) ) {
rt_UpdateLogVar ( ( LogVar * ) ( LogVar * ) ( rtDW . i4gnbypwkl . LoggedData
) , & rtB . omprcv5sy2 [ 137 ] , 0 ) ; } } } if ( ssGetLogOutput ( rtS ) ) {
{ double locTime = ssGetTaskTime ( rtS , 2 ) ; ; if (
rtwTimeInLoggingInterval ( rtliGetLoggingInterval ( ssGetRootSS ( rtS ) ->
mdlInfo -> rtwLogInfo ) , locTime ) ) { rt_UpdateLogVar ( ( LogVar * ) (
LogVar * ) ( rtDW . gm0yt5d4nb . LoggedData ) , & rtB . omprcv5sy2 [ 188 ] ,
0 ) ; } } } if ( ssGetLogOutput ( rtS ) ) { { double locTime = ssGetTaskTime
( rtS , 2 ) ; ; if ( rtwTimeInLoggingInterval ( rtliGetLoggingInterval (
ssGetRootSS ( rtS ) -> mdlInfo -> rtwLogInfo ) , locTime ) ) {
rt_UpdateLogVar ( ( LogVar * ) ( LogVar * ) ( rtDW . lwpcmu122x . LoggedData
) , & rtB . omprcv5sy2 [ 199 ] , 0 ) ; } } } } rtB . ljjc0rufmn = ( ( rtB .
omprcv5sy2 [ 187 ] <= rtP . CompareToConstant_const ) && ( ssGetT ( rtS ) >=
rtP . CompareToConstant1_const_eicxgrgmw1 ) ) ; if ( ssIsSampleHit ( rtS , 1
, 0 ) && rtB . ljjc0rufmn ) { ssSetStopRequested ( rtS , 1 ) ; } if (
ssIsSampleHit ( rtS , 2 , 0 ) ) { } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtB . e2o4pc31nk = rtP . Constant_Value * rtB . aj5vhl240h ; } if (
ssIsSampleHit ( rtS , 2 , 0 ) ) { } rtB . e2s03baw04 = rtB . j0cvegqaqh - rtB
. omprcv5sy2 [ 39 ] ; rtB . hfeigvk5ij = rtB . kjns5co5t5 * rtB . ozcp3eaat4
- rtB . omprcv5sy2 [ 0 ] ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB .
izpriwjdfu = rtB . e2s03baw04 ; fnsk42iewn = ( ( rtP . Ts_base / rtP .
Ginproduct_Ti * rtB . izpriwjdfu + rtB . izpriwjdfu ) - rtDW . ie2lmlkvwc ) *
rtP . Ginproduct_Kc + rtB . f4zvypfoze ; if ( fnsk42iewn > rtP .
Ginproduct_Hi ) { rtB . pgxmijpjc3 = rtP . Ginproduct_Hi ; } else if (
fnsk42iewn < rtP . Ginproduct_Lo ) { rtB . pgxmijpjc3 = rtP . Ginproduct_Lo ;
} else { rtB . pgxmijpjc3 = fnsk42iewn ; } } rtB . hbcctdqirx = rtB .
jyyd5wflg2 * rtB . ozcp3eaat4 - rtB . omprcv5sy2 [ 3 ] ; if ( ssIsSampleHit (
rtS , 1 , 0 ) ) { rtB . cljhe41yhf = rtB . hfeigvk5ij ; fnsk42iewn = ( ( rtP
. Ts_base / rtP . DiscretePI_Ti * rtB . cljhe41yhf + rtB . cljhe41yhf ) -
rtDW . mntgwrqzc0 ) * rtP . DiscretePI_Kc + rtB . gwhpssih4t ; if (
fnsk42iewn > rtP . DiscretePI_Hi ) { rtB . is1c2rdpo5 = rtP . DiscretePI_Hi ;
} else if ( fnsk42iewn < rtP . DiscretePI_Lo ) { rtB . is1c2rdpo5 = rtP .
DiscretePI_Lo ; } else { rtB . is1c2rdpo5 = fnsk42iewn ; } } rtB . jicbvnq24s
= rtB . k2wkz11jl0 * rtB . ozcp3eaat4 - rtB . omprcv5sy2 [ 1 ] ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . ni4spndrc5 = rtB . hbcctdqirx ;
fnsk42iewn = ( ( rtP . Ts_base / rtP . DiscretePI_Ti_c3baatq2tq * rtB .
ni4spndrc5 + rtB . ni4spndrc5 ) - rtDW . na2aurdisb ) * rtP .
DiscretePI_Kc_p5gypvfx1j + rtB . fpgen5oqtn ; if ( fnsk42iewn > rtP .
DiscretePI_Hi_clrmb2kvpv ) { rtB . llartmgedu = rtP .
DiscretePI_Hi_clrmb2kvpv ; } else if ( fnsk42iewn < rtP .
DiscretePI_Lo_f4v111b4tf ) { rtB . llartmgedu = rtP .
DiscretePI_Lo_f4v111b4tf ; } else { rtB . llartmgedu = fnsk42iewn ; } } rtB .
ao0f0spd50 = rtB . ndg0mjtwv5 * rtB . ozcp3eaat4 - rtB . omprcv5sy2 [ 2 ] ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . ndvlbxwnml = rtB . jicbvnq24s ;
fnsk42iewn = ( ( rtP . Ts_base / rtP . DiscretePI_Ti_md5jahyv1n * rtB .
ndvlbxwnml + rtB . ndvlbxwnml ) - rtDW . bpyfsnmjtj ) * rtP .
DiscretePI_Kc_djwdb4m1wy + rtB . iolwllfzji ; if ( fnsk42iewn > rtP .
DiscretePI_Hi_mmkevxvu4q ) { rtB . d1ok4vw0uh = rtP .
DiscretePI_Hi_mmkevxvu4q ; } else if ( fnsk42iewn < rtP .
DiscretePI_Lo_pmxz0leexm ) { rtB . d1ok4vw0uh = rtP .
DiscretePI_Lo_pmxz0leexm ; } else { rtB . d1ok4vw0uh = fnsk42iewn ; } } rtB .
fozxexl310 = rtB . l5enleslqf - rtB . omprcv5sy2 [ 16 ] ; if ( ssIsSampleHit
( rtS , 1 , 0 ) ) { rtB . deusv2ebrk = rtB . ao0f0spd50 ; fnsk42iewn = ( (
rtP . Ts_base / rtP . DiscretePI_Ti_fzhzo2ofo5 * rtB . deusv2ebrk + rtB .
deusv2ebrk ) - rtDW . dctqktm2mj ) * rtP . DiscretePI_Kc_geg1c1fr31 + rtB .
ljqiskk5u3 ; if ( fnsk42iewn > rtP . DiscretePI_Hi_hd32nb3dx4 ) { rtB .
l0su2jqw10 = rtP . DiscretePI_Hi_hd32nb3dx4 ; } else if ( fnsk42iewn < rtP .
DiscretePI_Lo_e5ennd4tjd ) { rtB . l0su2jqw10 = rtP .
DiscretePI_Lo_e5ennd4tjd ; } else { rtB . l0su2jqw10 = fnsk42iewn ; } } rtB .
mcoyogtvix = rtB . aj5vhl240h * rtB . ozcp3eaat4 - rtB . omprcv5sy2 [ 9 ] ;
if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . b30c2nbh3s = rtB . fozxexl310 ;
fnsk42iewn = ( ( rtP . Ts_base / rtP . Productionrate_Ti * rtB . b30c2nbh3s +
rtB . b30c2nbh3s ) - rtDW . pezj2tsriy ) * rtP . Productionrate_Kc + rtB .
ikqwcxe241 ; if ( fnsk42iewn > rtP . Productionrate_Hi ) { rtB . b4jatpuzm5 =
rtP . Productionrate_Hi ; } else if ( fnsk42iewn < rtP . Productionrate_Lo )
{ rtB . b4jatpuzm5 = rtP . Productionrate_Lo ; } else { rtB . b4jatpuzm5 =
fnsk42iewn ; } rtB . muy0uepi0b = rtB . mcoyogtvix ; fnsk42iewn = ( ( rtP .
Ts_base / rtP . DiscretePI_Ti_p2j0zc1phi * rtB . muy0uepi0b + rtB .
muy0uepi0b ) - rtDW . bncnd3iagx ) * rtP . DiscretePI_Kc_a4m4uoefrs + rtB .
hxgdkcqc2i ; if ( fnsk42iewn > rtP . DiscretePI_Hi_lniehyd5nc ) { rtB .
gpbb1gvvcj = rtP . DiscretePI_Hi_lniehyd5nc ; } else if ( fnsk42iewn < rtP .
DiscretePI_Lo_kbw43or5wm ) { rtB . gpbb1gvvcj = rtP .
DiscretePI_Lo_kbw43or5wm ; } else { rtB . gpbb1gvvcj = fnsk42iewn ; } } if (
rtDW . pn42trpqan == ( rtInf ) ) { rtB . oi1a2acgvm = rtB . m5xbxvfteh [ 2 ]
; } else { deltaT = ssGetTaskTime ( rtS , 0 ) - rtDW . pn42trpqan ;
riseValLimit = deltaT * rtP . RateLimiter2_RisingLim ; rateLimiterRate = rtB
. m5xbxvfteh [ 2 ] - rtDW . lim0zq1t1u ; if ( rateLimiterRate > riseValLimit
) { rtB . oi1a2acgvm = rtDW . lim0zq1t1u + riseValLimit ; } else { deltaT *=
rtP . RateLimiter2_FallingLim ; if ( rateLimiterRate < deltaT ) { rtB .
oi1a2acgvm = rtDW . lim0zq1t1u + deltaT ; } else { rtB . oi1a2acgvm = rtB .
m5xbxvfteh [ 2 ] ; } } } if ( rtDW . e0jcmikseh == ( rtInf ) ) { rtB .
g2q3ntw1j1 = rtB . m5xbxvfteh [ 3 ] ; } else { deltaT = ssGetTaskTime ( rtS ,
0 ) - rtDW . e0jcmikseh ; riseValLimit = deltaT * rtP .
RateLimiter3_RisingLim ; rateLimiterRate = rtB . m5xbxvfteh [ 3 ] - rtDW .
ky0xqcu33m ; if ( rateLimiterRate > riseValLimit ) { rtB . g2q3ntw1j1 = rtDW
. ky0xqcu33m + riseValLimit ; } else { deltaT *= rtP .
RateLimiter3_FallingLim ; if ( rateLimiterRate < deltaT ) { rtB . g2q3ntw1j1
= rtDW . ky0xqcu33m + deltaT ; } else { rtB . g2q3ntw1j1 = rtB . m5xbxvfteh [
3 ] ; } } } if ( rtDW . b5iesyj5df == ( rtInf ) ) { rtB . cxmfrfyaum = rtB .
m5xbxvfteh [ 1 ] ; } else { deltaT = ssGetTaskTime ( rtS , 0 ) - rtDW .
b5iesyj5df ; riseValLimit = deltaT * rtP . RateLimiter4_RisingLim ;
rateLimiterRate = rtB . m5xbxvfteh [ 1 ] - rtDW . la2eksughs ; if (
rateLimiterRate > riseValLimit ) { rtB . cxmfrfyaum = rtDW . la2eksughs +
riseValLimit ; } else { deltaT *= rtP . RateLimiter4_FallingLim ; if (
rateLimiterRate < deltaT ) { rtB . cxmfrfyaum = rtDW . la2eksughs + deltaT ;
} else { rtB . cxmfrfyaum = rtB . m5xbxvfteh [ 1 ] ; } } } if ( rtDW .
axrr55q2tu == ( rtInf ) ) { rtB . dznrfiazyw = rtB . m5xbxvfteh [ 4 ] ; }
else { deltaT = ssGetTaskTime ( rtS , 0 ) - rtDW . axrr55q2tu ; riseValLimit
= deltaT * rtP . RateLimiter5_RisingLim ; rateLimiterRate = rtB . m5xbxvfteh
[ 4 ] - rtDW . pgdmfzfof1 ; if ( rateLimiterRate > riseValLimit ) { rtB .
dznrfiazyw = rtDW . pgdmfzfof1 + riseValLimit ; } else { deltaT *= rtP .
RateLimiter5_FallingLim ; if ( rateLimiterRate < deltaT ) { rtB . dznrfiazyw
= rtDW . pgdmfzfof1 + deltaT ; } else { rtB . dznrfiazyw = rtB . m5xbxvfteh [
4 ] ; } } } if ( rtDW . hegs43c0e0 == ( rtInf ) ) { rtB . hmc2jf4w3i = rtB .
m5xbxvfteh [ 8 ] ; } else { deltaT = ssGetTaskTime ( rtS , 0 ) - rtDW .
hegs43c0e0 ; riseValLimit = deltaT * rtP . RateLimiter8_RisingLim ;
rateLimiterRate = rtB . m5xbxvfteh [ 8 ] - rtDW . nnzuvh3h1i ; if (
rateLimiterRate > riseValLimit ) { rtB . hmc2jf4w3i = rtDW . nnzuvh3h1i +
riseValLimit ; } else { deltaT *= rtP . RateLimiter8_FallingLim ; if (
rateLimiterRate < deltaT ) { rtB . hmc2jf4w3i = rtDW . nnzuvh3h1i + deltaT ;
} else { rtB . hmc2jf4w3i = rtB . m5xbxvfteh [ 8 ] ; } } } rtB . ofpl4daui3 =
rtB . g2q3ntw1j1 - rtB . omprcv5sy2 [ 7 ] ; rtB . pl1bbzopud = rtB .
dznrfiazyw - rtB . omprcv5sy2 [ 6 ] ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtB . cj5hl50xku = rtB . ofpl4daui3 ; fnsk42iewn = ( ( rtP . Ts_base / rtP .
Reactorlevel_Ti * rtB . cj5hl50xku + rtB . cj5hl50xku ) - rtDW . hwd0jegvir )
* rtP . Reactorlevel_Kc + rtB . majq1kos5f ; if ( fnsk42iewn > rtP .
Reactorlevel_Hi ) { rtB . j425ztqp2s = rtP . Reactorlevel_Hi ; } else if (
fnsk42iewn < rtP . Reactorlevel_Lo ) { rtB . j425ztqp2s = rtP .
Reactorlevel_Lo ; } else { rtB . j425ztqp2s = fnsk42iewn ; } } rtB .
ipwewafmjl = rtB . hmc2jf4w3i - rtB . omprcv5sy2 [ 8 ] ; if ( ssIsSampleHit (
rtS , 1 , 0 ) ) { rtB . gnyqyrbwif = rtB . pl1bbzopud ; fnsk42iewn = ( ( rtP
. Ts_base / rtP . Reactorpressure_Ti * rtB . gnyqyrbwif + rtB . gnyqyrbwif )
- rtDW . fw4qwmmztz ) * rtP . Reactorpressure_Kc + rtB . aj5vhl240h ; if (
fnsk42iewn > rtP . Reactorpressure_Hi ) { rtB . hq5s01lzzb = rtP .
Reactorpressure_Hi ; } else if ( fnsk42iewn < rtP . Reactorpressure_Lo ) {
rtB . hq5s01lzzb = rtP . Reactorpressure_Lo ; } else { rtB . hq5s01lzzb =
fnsk42iewn ; } } rtB . eup0jwsamj = rtB . jjnncqp5so * rtB . ozcp3eaat4 - rtB
. omprcv5sy2 [ 13 ] ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . founh1g0rd
= rtB . ipwewafmjl ; fnsk42iewn = ( ( rtP . Ts_base / rtP .
Reactortemperature_Ti * rtB . founh1g0rd + rtB . founh1g0rd ) - rtDW .
pfo30wpbs5 ) * rtP . Reactortemperature_Kc + rtB . j0cur13put ; if (
fnsk42iewn > rtP . Reactortemperature_Hi ) { rtB . ouskwvaeim = rtP .
Reactortemperature_Hi ; } else if ( fnsk42iewn < rtP . Reactortemperature_Lo
) { rtB . ouskwvaeim = rtP . Reactortemperature_Lo ; } else { rtB .
ouskwvaeim = fnsk42iewn ; } } rtB . e10mphjtjt = rtB . oi1a2acgvm - rtB .
omprcv5sy2 [ 11 ] ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . npqfy50alm =
rtB . eup0jwsamj ; fnsk42iewn = ( ( rtP . Ts_base / rtP .
DiscretePI_Ti_mjqeflcq5c * rtB . npqfy50alm + rtB . npqfy50alm ) - rtDW .
gdes5aukxs ) * rtP . DiscretePI_Kc_cya5ip4lvt + rtB . mcfswk5n2o ; if (
fnsk42iewn > rtP . DiscretePI_Hi_ovtb5jvins ) { rtB . iafivlbguu = rtP .
DiscretePI_Hi_ovtb5jvins ; } else if ( fnsk42iewn < rtP .
DiscretePI_Lo_oiqe5mpnn5 ) { rtB . iafivlbguu = rtP .
DiscretePI_Lo_oiqe5mpnn5 ; } else { rtB . iafivlbguu = fnsk42iewn ; } } rtB .
ofdezn5rxo = rtB . majq1kos5f - rtB . omprcv5sy2 [ 10 ] ; if ( ssIsSampleHit
( rtS , 1 , 0 ) ) { rtB . jaor2xt4n1 = rtB . e10mphjtjt ; fnsk42iewn = ( (
rtP . Ts_base / rtP . Separatorlevel_Ti * rtB . jaor2xt4n1 + rtB . jaor2xt4n1
) - rtDW . niz4kap4en ) * rtP . Separatorlevel_Kc + rtB . jjnncqp5so ; if (
fnsk42iewn > rtP . Separatorlevel_Hi ) { rtB . ff3ioxcqht = rtP .
Separatorlevel_Hi ; } else if ( fnsk42iewn < rtP . Separatorlevel_Lo ) { rtB
. ff3ioxcqht = rtP . Separatorlevel_Lo ; } else { rtB . ff3ioxcqht =
fnsk42iewn ; } } rtB . ciejj5ghav = rtB . ba4zpaneod * rtB . ozcp3eaat4 - rtB
. omprcv5sy2 [ 16 ] ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . oahdemerjr
= rtB . ofdezn5rxo ; fnsk42iewn = ( ( rtP . Ts_base / rtP .
Separatortemperature_Ti * rtB . oahdemerjr + rtB . oahdemerjr ) - rtDW .
ezrisir0qm ) * rtP . Separatortemperature_Kc + rtB . mangrqenh4 ; if (
fnsk42iewn > rtP . Separatortemperature_Hi ) { rtB . a0bsusal0x = rtP .
Separatortemperature_Hi ; } else if ( fnsk42iewn < rtP .
Separatortemperature_Lo ) { rtB . a0bsusal0x = rtP . Separatortemperature_Lo
; } else { rtB . a0bsusal0x = fnsk42iewn ; } } rtB . kkq4v1qduu = rtB .
cxmfrfyaum - rtB . omprcv5sy2 [ 14 ] ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
rtB . osvbstbttp = rtB . ciejj5ghav ; fnsk42iewn = ( ( rtP . Ts_base / rtP .
DiscretePI_Ti_fdbl1x51xg * rtB . osvbstbttp + rtB . osvbstbttp ) - rtDW .
j1eqfx30ih ) * rtP . DiscretePI_Kc_acyt0oa3ay + rtB . gtctzgqgd2 ; if (
fnsk42iewn > rtP . DiscretePI_Hi_eagnldn5ck ) { rtB . ojy3rf0rid = rtP .
DiscretePI_Hi_eagnldn5ck ; } else if ( fnsk42iewn < rtP .
DiscretePI_Lo_jjfywxfpq4 ) { rtB . ojy3rf0rid = rtP .
DiscretePI_Lo_jjfywxfpq4 ; } else { rtB . ojy3rf0rid = fnsk42iewn ; } rtB .
fukcmanscn = rtB . kkq4v1qduu ; fnsk42iewn = ( ( rtP . Ts_base / rtP .
Stripperlevel_Ti * rtB . fukcmanscn + rtB . fukcmanscn ) - rtDW . oswghqu4mb
) * rtP . Stripperlevel_Kc + rtB . ba4zpaneod ; if ( fnsk42iewn > rtP .
Stripperlevel_Hi ) { rtB . ebu4kln0gn = rtP . Stripperlevel_Hi ; } else if (
fnsk42iewn < rtP . Stripperlevel_Lo ) { rtB . ebu4kln0gn = rtP .
Stripperlevel_Lo ; } else { rtB . ebu4kln0gn = fnsk42iewn ; } } rtB .
hkk5zkpnn1 = ssGetT ( rtS ) ; if ( ssIsSampleHit ( rtS , 2 , 0 ) ) { if (
ssGetLogOutput ( rtS ) ) { { double locTime = ssGetTaskTime ( rtS , 2 ) ; ;
if ( rtwTimeInLoggingInterval ( rtliGetLoggingInterval ( ssGetRootSS ( rtS )
-> mdlInfo -> rtwLogInfo ) , locTime ) ) { rt_UpdateLogVar ( ( LogVar * ) (
LogVar * ) ( rtDW . af044523tm . LoggedData ) , & rtB . hkk5zkpnn1 , 0 ) ; }
} } if ( ssGetLogOutput ( rtS ) ) { StructLogVar * svar = ( StructLogVar * )
rtDW . kzls2lxgyw . LoggedData ; LogVar * var = svar -> signals . values ; {
double locTime = ssGetTaskTime ( rtS , 2 ) ; ; rt_UpdateLogVar ( ( LogVar * )
svar -> time , & locTime , 0 ) ; } { real_T up0 [ 2 ] ; up0 [ 0 ] = rtB .
l5enleslqf ; up0 [ 1 ] = rtB . omprcv5sy2 [ 16 ] ; rt_UpdateLogVar ( ( LogVar
* ) var , up0 , 0 ) ; } } if ( ssGetLogOutput ( rtS ) ) { StructLogVar * svar
= ( StructLogVar * ) rtDW . jwlo4oww5f . LoggedData ; LogVar * var = svar ->
signals . values ; { double locTime = ssGetTaskTime ( rtS , 2 ) ; ;
rt_UpdateLogVar ( ( LogVar * ) svar -> time , & locTime , 0 ) ; } { real_T
up0 [ 2 ] ; up0 [ 0 ] = rtB . j0cvegqaqh ; up0 [ 1 ] = rtB . omprcv5sy2 [ 39
] ; rt_UpdateLogVar ( ( LogVar * ) var , up0 , 0 ) ; } } } UNUSED_PARAMETER (
tid ) ; } void MdlUpdate ( int_T tid ) { if ( ssIsSampleHit ( rtS , 1 , 0 ) )
{ rtDW . b15chhqxbl = rtB . d1ok4vw0uh ; rtDW . gi2i3ynyug = rtB . l0su2jqw10
; rtDW . i0wtqgyaoh = rtB . is1c2rdpo5 ; rtDW . b0yeel01dg = rtB . llartmgedu
; rtDW . kreyu5dtil = rtB . gpbb1gvvcj ; rtDW . a43kgavcjl = rtB . iafivlbguu
; rtDW . lck0yfjpoc = rtB . ojy3rf0rid ; } rtDW . mlmenq1uvm = rtB .
gyprops4hy ; rtDW . ekfb3mlxia = ssGetTaskTime ( rtS , 0 ) ; rtDW .
g2qwfqxtqm = rtB . fzdqkoyver ; rtDW . b30wxoefe1 = ssGetTaskTime ( rtS , 0 )
; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . imzpv25nrh = rtB . ouskwvaeim
; rtDW . fdvolofpz2 = rtB . a0bsusal0x ; rtDW . bngn1tntsv = rtB . b4jatpuzm5
; } rtDW . gcno0q5mlf = rtB . j24sggezs0 ; rtDW . fmlqmojal0 = ssGetTaskTime
( rtS , 0 ) ; rtDW . jbapjrt3qt = rtB . l5enleslqf ; rtDW . bu34crt1v1 =
ssGetTaskTime ( rtS , 0 ) ; if ( ssIsSampleHit ( rtS , 3 , 0 ) ) { rtDW .
o3jy54xzl4 = rtB . kjns5co5t5 ; rtDW . ofaprpi3ub = rtB . dfqakv4d54 ; } rtDW
. e42tdvzthc = rtB . iygofvadrj ; rtDW . o51mmpjmne = ssGetTaskTime ( rtS , 0
) ; rtDW . n1cxse1jno = rtB . j0cvegqaqh ; rtDW . bgawoufyg5 = ssGetTaskTime
( rtS , 0 ) ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . gyhogfj3mi = rtB
. pgxmijpjc3 ; } rtDW . a3igfd1reu = rtB . fmtr4xt2pw ; rtDW . iajewt1drp =
ssGetTaskTime ( rtS , 0 ) ; if ( ssIsSampleHit ( rtS , 3 , 0 ) ) { rtDW .
kf0tcjs1us = rtB . o32oplehzw ; rtDW . lttqcvvdla = rtB . jyyd5wflg2 ; } if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . klfqvxjavt = rtB . hq5s01lzzb ; rtDW
. dtc5w4dyjs = rtB . ff3ioxcqht ; rtDW . h3ggkxop2c = rtB . ebu4kln0gn ; rtDW
. nkzljw5ytc = rtB . j425ztqp2s ; rtDW . ie2lmlkvwc = rtB . izpriwjdfu ; rtDW
. mntgwrqzc0 = rtB . cljhe41yhf ; rtDW . na2aurdisb = rtB . ni4spndrc5 ; rtDW
. bpyfsnmjtj = rtB . ndvlbxwnml ; rtDW . dctqktm2mj = rtB . deusv2ebrk ; rtDW
. pezj2tsriy = rtB . b30c2nbh3s ; rtDW . bncnd3iagx = rtB . muy0uepi0b ; rtDW
. hwd0jegvir = rtB . cj5hl50xku ; rtDW . fw4qwmmztz = rtB . gnyqyrbwif ; rtDW
. pfo30wpbs5 = rtB . founh1g0rd ; rtDW . gdes5aukxs = rtB . npqfy50alm ; rtDW
. niz4kap4en = rtB . jaor2xt4n1 ; rtDW . ezrisir0qm = rtB . oahdemerjr ; rtDW
. j1eqfx30ih = rtB . osvbstbttp ; rtDW . oswghqu4mb = rtB . fukcmanscn ; }
rtDW . lim0zq1t1u = rtB . oi1a2acgvm ; rtDW . pn42trpqan = ssGetTaskTime (
rtS , 0 ) ; rtDW . ky0xqcu33m = rtB . g2q3ntw1j1 ; rtDW . e0jcmikseh =
ssGetTaskTime ( rtS , 0 ) ; rtDW . la2eksughs = rtB . cxmfrfyaum ; rtDW .
b5iesyj5df = ssGetTaskTime ( rtS , 0 ) ; rtDW . pgdmfzfof1 = rtB . dznrfiazyw
; rtDW . axrr55q2tu = ssGetTaskTime ( rtS , 0 ) ; rtDW . nnzuvh3h1i = rtB .
hmc2jf4w3i ; rtDW . hegs43c0e0 = ssGetTaskTime ( rtS , 0 ) ; UNUSED_PARAMETER
( tid ) ; } void MdlUpdateTID4 ( int_T tid ) { UNUSED_PARAMETER ( tid ) ; }
void MdlDerivatives ( void ) { { SimStruct * rts = ssGetSFunction ( rtS , 0 )
; real_T * sfcndX_fx = ( real_T * ) & ( ( XDot * ) ssGetdX ( rtS ) ) ->
dzj03d1j4v [ 0 ] ; ssSetdX ( rts , sfcndX_fx ) ; sfcnDerivatives ( rts ) ; if
( ssGetErrorStatus ( rts ) != ( NULL ) ) return ; } } void MdlProjection (
void ) { } void MdlTerminate ( void ) { rt_FREE ( rtDW . oaotpdsye1 .
RSimInfoPtr ) ; rt_FREE ( rtDW . kzrko0fdik . RSimInfoPtr ) ; rt_FREE ( rtDW
. n1d1uedpum . RSimInfoPtr ) ; { SimStruct * rts = ssGetSFunction ( rtS , 0 )
; sfcnTerminate ( rts ) ; } if ( rt_slioCatalogue ( ) != ( NULL ) ) { void *
* slioCatalogueAddr = rt_slioCatalogueAddr ( ) ; rtwSaveDatasetsToMatFile (
rtwGetPointerFromUniquePtr ( rt_slioCatalogue ( ) ) ,
rt_GetMatSigstreamLoggingFileName ( ) ) ; rtwTerminateSlioCatalogue (
slioCatalogueAddr ) ; * slioCatalogueAddr = NULL ; } } void
MdlInitializeSizes ( void ) { ssSetNumContStates ( rtS , 50 ) ;
ssSetNumPeriodicContStates ( rtS , 0 ) ; ssSetNumY ( rtS , 0 ) ; ssSetNumU (
rtS , 0 ) ; ssSetDirectFeedThrough ( rtS , 0 ) ; ssSetNumSampleTimes ( rtS ,
4 ) ; ssSetNumBlocks ( rtS , 239 ) ; ssSetNumBlockIO ( rtS , 97 ) ;
ssSetNumBlockParams ( rtS , 240 ) ; } void MdlInitializeSampleTimes ( void )
{ ssSetSampleTime ( rtS , 0 , 0.0 ) ; ssSetSampleTime ( rtS , 1 , 0.0005 ) ;
ssSetSampleTime ( rtS , 2 , 0.01 ) ; ssSetSampleTime ( rtS , 3 , 0.1 ) ;
ssSetOffsetTime ( rtS , 0 , 0.0 ) ; ssSetOffsetTime ( rtS , 1 , 0.0 ) ;
ssSetOffsetTime ( rtS , 2 , 0.0 ) ; ssSetOffsetTime ( rtS , 3 , 0.0 ) ; }
void raccel_set_checksum ( ) { ssSetChecksumVal ( rtS , 0 , 3926258508U ) ;
ssSetChecksumVal ( rtS , 1 , 3215925013U ) ; ssSetChecksumVal ( rtS , 2 ,
3711287366U ) ; ssSetChecksumVal ( rtS , 3 , 182737605U ) ; }
#if defined(_MSC_VER)
#pragma optimize( "", off )
#endif
SimStruct * raccel_register_model ( void ) { static struct _ssMdlInfo mdlInfo
; ( void ) memset ( ( char * ) rtS , 0 , sizeof ( SimStruct ) ) ; ( void )
memset ( ( char * ) & mdlInfo , 0 , sizeof ( struct _ssMdlInfo ) ) ;
ssSetMdlInfoPtr ( rtS , & mdlInfo ) ; { static time_T mdlPeriod [
NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ; static time_T
mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [ NSAMPLE_TIMES ] ;
static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static boolean_T
mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T mdlPerTaskSampleHits
[ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T mdlTimeOfNextSampleHit [
NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i < NSAMPLE_TIMES ; i ++ ) {
mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ; mdlTaskTimes [ i ] = 0.0 ;
mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } } ssSetSampleTimePtr ( rtS ,
& mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , & mdlOffset [ 0 ] ) ;
ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ; ssSetTPtr ( rtS , &
mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , & mdlSampleHits [ 0 ] ) ;
ssSetTNextWasAdjustedPtr ( rtS , & mdlTNextWasAdjustedPtr [ 0 ] ) ;
ssSetPerTaskSampleHitsPtr ( rtS , & mdlPerTaskSampleHits [ 0 ] ) ;
ssSetTimeOfNextSampleHitPtr ( rtS , & mdlTimeOfNextSampleHit [ 0 ] ) ; }
ssSetSolverMode ( rtS , SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS ,
( ( void * ) & rtB ) ) ; ( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof
( B ) ) ; { int32_T i ; for ( i = 0 ; i < 12 ; i ++ ) { rtB . bccrbyw3op [ i
] = 0.0 ; } for ( i = 0 ; i < 12 ; i ++ ) { rtB . cs2ztziz0k [ i ] = 0.0 ; }
for ( i = 0 ; i < 12 ; i ++ ) { rtB . m5xbxvfteh [ i ] = 0.0 ; } for ( i = 0
; i < 28 ; i ++ ) { rtB . df14e2fwpd [ i ] = 0.0 ; } for ( i = 0 ; i < 28 ; i
++ ) { rtB . g0ajxjwpf3 [ i ] = 0.0 ; } for ( i = 0 ; i < 202 ; i ++ ) { rtB
. omprcv5sy2 [ i ] = 0.0 ; } for ( i = 0 ; i < 12 ; i ++ ) { rtB . avhxbjy5jl
[ i ] = 0.0 ; } for ( i = 0 ; i < 10 ; i ++ ) { rtB . jffesjegzu [ i ] = 0.0
; } rtB . iolwllfzji = 0.0 ; rtB . ljqiskk5u3 = 0.0 ; rtB . gwhpssih4t = 0.0
; rtB . fpgen5oqtn = 0.0 ; rtB . gyprops4hy = 0.0 ; rtB . hxgdkcqc2i = 0.0 ;
rtB . mcfswk5n2o = 0.0 ; rtB . gtctzgqgd2 = 0.0 ; rtB . fzdqkoyver = 0.0 ;
rtB . j0cur13put = 0.0 ; rtB . mangrqenh4 = 0.0 ; rtB . j24sggezs0 = 0.0 ;
rtB . i5fngjpd5u = 0.0 ; rtB . kku5xrtb04 = 0.0 ; rtB . omriyhtfeo = 0.0 ;
rtB . l5enleslqf = 0.0 ; rtB . ikqwcxe241 = 0.0 ; rtB . ozcp3eaat4 = 0.0 ;
rtB . iygofvadrj = 0.0 ; rtB . dxh4onrpf2 = 0.0 ; rtB . dfqakv4d54 = 0.0 ;
rtB . kjns5co5t5 = 0.0 ; rtB . j0cvegqaqh = 0.0 ; rtB . f4zvypfoze = 0.0 ;
rtB . agz0woju0p = 0.0 ; rtB . k2wkz11jl0 = 0.0 ; rtB . hrzv1fvxzj = 0.0 ;
rtB . ndg0mjtwv5 = 0.0 ; rtB . fmtr4xt2pw = 0.0 ; rtB . jodh2mlmue = 0.0 ;
rtB . o32oplehzw = 0.0 ; rtB . jyyd5wflg2 = 0.0 ; rtB . aj5vhl240h = 0.0 ;
rtB . jjnncqp5so = 0.0 ; rtB . ba4zpaneod = 0.0 ; rtB . majq1kos5f = 0.0 ;
rtB . e2o4pc31nk = 0.0 ; rtB . e2s03baw04 = 0.0 ; rtB . izpriwjdfu = 0.0 ;
rtB . pgxmijpjc3 = 0.0 ; rtB . hfeigvk5ij = 0.0 ; rtB . cljhe41yhf = 0.0 ;
rtB . is1c2rdpo5 = 0.0 ; rtB . hbcctdqirx = 0.0 ; rtB . ni4spndrc5 = 0.0 ;
rtB . llartmgedu = 0.0 ; rtB . jicbvnq24s = 0.0 ; rtB . ndvlbxwnml = 0.0 ;
rtB . d1ok4vw0uh = 0.0 ; rtB . ao0f0spd50 = 0.0 ; rtB . deusv2ebrk = 0.0 ;
rtB . l0su2jqw10 = 0.0 ; rtB . fozxexl310 = 0.0 ; rtB . b30c2nbh3s = 0.0 ;
rtB . b4jatpuzm5 = 0.0 ; rtB . mcoyogtvix = 0.0 ; rtB . muy0uepi0b = 0.0 ;
rtB . gpbb1gvvcj = 0.0 ; rtB . oi1a2acgvm = 0.0 ; rtB . g2q3ntw1j1 = 0.0 ;
rtB . cxmfrfyaum = 0.0 ; rtB . dznrfiazyw = 0.0 ; rtB . hmc2jf4w3i = 0.0 ;
rtB . ofpl4daui3 = 0.0 ; rtB . cj5hl50xku = 0.0 ; rtB . j425ztqp2s = 0.0 ;
rtB . pl1bbzopud = 0.0 ; rtB . gnyqyrbwif = 0.0 ; rtB . hq5s01lzzb = 0.0 ;
rtB . ipwewafmjl = 0.0 ; rtB . founh1g0rd = 0.0 ; rtB . ouskwvaeim = 0.0 ;
rtB . eup0jwsamj = 0.0 ; rtB . npqfy50alm = 0.0 ; rtB . iafivlbguu = 0.0 ;
rtB . e10mphjtjt = 0.0 ; rtB . jaor2xt4n1 = 0.0 ; rtB . ff3ioxcqht = 0.0 ;
rtB . ofdezn5rxo = 0.0 ; rtB . oahdemerjr = 0.0 ; rtB . a0bsusal0x = 0.0 ;
rtB . ciejj5ghav = 0.0 ; rtB . osvbstbttp = 0.0 ; rtB . ojy3rf0rid = 0.0 ;
rtB . kkq4v1qduu = 0.0 ; rtB . fukcmanscn = 0.0 ; rtB . ebu4kln0gn = 0.0 ;
rtB . hkk5zkpnn1 = 0.0 ; } } ssSetDefaultParam ( rtS , ( real_T * ) & rtP ) ;
{ real_T * x = ( real_T * ) & rtX ; ssSetContStates ( rtS , x ) ; ( void )
memset ( ( void * ) x , 0 , sizeof ( X ) ) ; } { void * dwork = ( void * ) &
rtDW ; ssSetRootDWork ( rtS , dwork ) ; ( void ) memset ( dwork , 0 , sizeof
( DW ) ) ; rtDW . b15chhqxbl = 0.0 ; rtDW . gi2i3ynyug = 0.0 ; rtDW .
i0wtqgyaoh = 0.0 ; rtDW . b0yeel01dg = 0.0 ; rtDW . kreyu5dtil = 0.0 ; rtDW .
a43kgavcjl = 0.0 ; rtDW . lck0yfjpoc = 0.0 ; rtDW . imzpv25nrh = 0.0 ; rtDW .
fdvolofpz2 = 0.0 ; rtDW . bngn1tntsv = 0.0 ; rtDW . o3jy54xzl4 = 0.0 ; rtDW .
ofaprpi3ub = 0.0 ; rtDW . gyhogfj3mi = 0.0 ; rtDW . kf0tcjs1us = 0.0 ; rtDW .
lttqcvvdla = 0.0 ; rtDW . klfqvxjavt = 0.0 ; rtDW . dtc5w4dyjs = 0.0 ; rtDW .
h3ggkxop2c = 0.0 ; rtDW . nkzljw5ytc = 0.0 ; rtDW . ie2lmlkvwc = 0.0 ; rtDW .
mntgwrqzc0 = 0.0 ; rtDW . na2aurdisb = 0.0 ; rtDW . bpyfsnmjtj = 0.0 ; rtDW .
dctqktm2mj = 0.0 ; rtDW . pezj2tsriy = 0.0 ; rtDW . bncnd3iagx = 0.0 ; rtDW .
hwd0jegvir = 0.0 ; rtDW . fw4qwmmztz = 0.0 ; rtDW . pfo30wpbs5 = 0.0 ; rtDW .
gdes5aukxs = 0.0 ; rtDW . niz4kap4en = 0.0 ; rtDW . ezrisir0qm = 0.0 ; rtDW .
j1eqfx30ih = 0.0 ; rtDW . oswghqu4mb = 0.0 ; rtDW . mlmenq1uvm = 0.0 ; rtDW .
ekfb3mlxia = 0.0 ; rtDW . g2qwfqxtqm = 0.0 ; rtDW . b30wxoefe1 = 0.0 ; rtDW .
gcno0q5mlf = 0.0 ; rtDW . fmlqmojal0 = 0.0 ; rtDW . jbapjrt3qt = 0.0 ; rtDW .
bu34crt1v1 = 0.0 ; rtDW . e42tdvzthc = 0.0 ; rtDW . o51mmpjmne = 0.0 ; rtDW .
n1cxse1jno = 0.0 ; rtDW . bgawoufyg5 = 0.0 ; rtDW . a3igfd1reu = 0.0 ; rtDW .
iajewt1drp = 0.0 ; rtDW . lim0zq1t1u = 0.0 ; rtDW . pn42trpqan = 0.0 ; rtDW .
ky0xqcu33m = 0.0 ; rtDW . e0jcmikseh = 0.0 ; rtDW . la2eksughs = 0.0 ; rtDW .
b5iesyj5df = 0.0 ; rtDW . pgdmfzfof1 = 0.0 ; rtDW . axrr55q2tu = 0.0 ; rtDW .
nnzuvh3h1i = 0.0 ; rtDW . hegs43c0e0 = 0.0 ; } { static DataTypeTransInfo
dtInfo ; ( void ) memset ( ( char_T * ) & dtInfo , 0 , sizeof ( dtInfo ) ) ;
ssSetModelMappingInfo ( rtS , & dtInfo ) ; dtInfo . numDataTypes = 18 ;
dtInfo . dataTypeSizes = & rtDataTypeSizes [ 0 ] ; dtInfo . dataTypeNames = &
rtDataTypeNames [ 0 ] ; dtInfo . BTransTable = & rtBTransTable ; dtInfo .
PTransTable = & rtPTransTable ; } MultiLoop_mode1_InitializeDataMapInfo ( ) ;
ssSetIsRapidAcceleratorActive ( rtS , true ) ; ssSetRootSS ( rtS , rtS ) ;
ssSetVersion ( rtS , SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS ,
"MultiLoop_mode1" ) ; ssSetPath ( rtS , "MultiLoop_mode1" ) ; ssSetTStart (
rtS , 0.0 ) ; ssSetTFinal ( rtS , 1000.0 ) ; ssSetStepSize ( rtS , 0.0005 ) ;
ssSetFixedStepSize ( rtS , 0.0005 ) ; { static RTWLogInfo rt_DataLoggingInfo
; rt_DataLoggingInfo . loggingInterval = NULL ; ssSetRTWLogInfo ( rtS , &
rt_DataLoggingInfo ) ; } { { static int_T rt_LoggedStateWidths [ ] = { 50 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; static int_T
rt_LoggedStateNumDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 , 1 , 1 } ; static int_T rt_LoggedStateDimensions [ ] = { 50 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; static boolean_T
rt_LoggedStateIsVarDims [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 } ; static BuiltInDTypeId rt_LoggedStateDataTypeIds [ ] = {
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE } ; static int_T
rt_LoggedStateComplexSignals [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 } ; static const char_T * rt_LoggedStateLabels [ ] = {
"CSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" ,
"DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" ,
"DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" ,
"DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" ,
"DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" }
; static const char_T * rt_LoggedStateBlockNames [ ] = {
"MultiLoop_mode1/TE Plant/TE Code" ,
"MultiLoop_mode1/TE Plant/D feed rate/Discrete PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/E feed rate/Discrete PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/A feed rate/Discrete PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/C feed rate/Discrete PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Purge rate/Discrete PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Separator flow rate/Discrete PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Stripper flow rate/Discrete PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Reactor temperature/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Separator temperature/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Production rate/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Ratio trimming/Unit Delay" ,
"MultiLoop_mode1/TE Plant/yA control/Unit Delay" ,
"MultiLoop_mode1/TE Plant/%G in product/Unit Delay" ,
"MultiLoop_mode1/TE Plant/yAC control/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Ratio trimming/Unit Delay1" ,
"MultiLoop_mode1/TE Plant/Reactor pressure/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Separator level/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Stripper level/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Reactor level/Unit Delay" ,
"MultiLoop_mode1/TE Plant/%G in product/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/A feed rate/Discrete PI/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/C feed rate/Discrete PI/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/D feed rate/Discrete PI/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/E feed rate/Discrete PI/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Production rate/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Purge rate/Discrete PI/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Reactor level/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Reactor pressure/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Reactor temperature/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Separator flow rate/Discrete PI/Vel PI/Unit Delay"
, "MultiLoop_mode1/TE Plant/Separator level/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Separator temperature/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Stripper flow rate/Discrete PI/Vel PI/Unit Delay" ,
"MultiLoop_mode1/TE Plant/Stripper level/Vel PI/Unit Delay" } ; static const
char_T * rt_LoggedStateNames [ ] = { "" , "" , "" , "" , "" , "" , "" , "" ,
"" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , ""
, "" , "" , "" , "" , "" , "" , "" , "" , "" , "" , "" } ; static boolean_T
rt_LoggedStateCrossMdlRef [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 } ; static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert [ ]
= { { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } } ; static RTWLogSignalInfo rt_LoggedStateSignalInfo = { 35 ,
rt_LoggedStateWidths , rt_LoggedStateNumDimensions , rt_LoggedStateDimensions
, rt_LoggedStateIsVarDims , ( NULL ) , ( NULL ) , rt_LoggedStateDataTypeIds ,
rt_LoggedStateComplexSignals , ( NULL ) , ( NULL ) , { rt_LoggedStateLabels }
, ( NULL ) , ( NULL ) , ( NULL ) , { rt_LoggedStateBlockNames } , {
rt_LoggedStateNames } , rt_LoggedStateCrossMdlRef , rt_RTWLogDataTypeConvert
} ; static void * rt_LoggedStateSignalPtrs [ 35 ] ; rtliSetLogXSignalPtrs (
ssGetRTWLogInfo ( rtS ) , ( LogSignalPtrsType ) rt_LoggedStateSignalPtrs ) ;
rtliSetLogXSignalInfo ( ssGetRTWLogInfo ( rtS ) , & rt_LoggedStateSignalInfo
) ; rt_LoggedStateSignalPtrs [ 0 ] = ( void * ) & rtX . dzj03d1j4v [ 0 ] ;
rt_LoggedStateSignalPtrs [ 1 ] = ( void * ) & rtDW . b15chhqxbl ;
rt_LoggedStateSignalPtrs [ 2 ] = ( void * ) & rtDW . gi2i3ynyug ;
rt_LoggedStateSignalPtrs [ 3 ] = ( void * ) & rtDW . i0wtqgyaoh ;
rt_LoggedStateSignalPtrs [ 4 ] = ( void * ) & rtDW . b0yeel01dg ;
rt_LoggedStateSignalPtrs [ 5 ] = ( void * ) & rtDW . kreyu5dtil ;
rt_LoggedStateSignalPtrs [ 6 ] = ( void * ) & rtDW . a43kgavcjl ;
rt_LoggedStateSignalPtrs [ 7 ] = ( void * ) & rtDW . lck0yfjpoc ;
rt_LoggedStateSignalPtrs [ 8 ] = ( void * ) & rtDW . imzpv25nrh ;
rt_LoggedStateSignalPtrs [ 9 ] = ( void * ) & rtDW . fdvolofpz2 ;
rt_LoggedStateSignalPtrs [ 10 ] = ( void * ) & rtDW . bngn1tntsv ;
rt_LoggedStateSignalPtrs [ 11 ] = ( void * ) & rtDW . o3jy54xzl4 ;
rt_LoggedStateSignalPtrs [ 12 ] = ( void * ) & rtDW . ofaprpi3ub ;
rt_LoggedStateSignalPtrs [ 13 ] = ( void * ) & rtDW . gyhogfj3mi ;
rt_LoggedStateSignalPtrs [ 14 ] = ( void * ) & rtDW . kf0tcjs1us ;
rt_LoggedStateSignalPtrs [ 15 ] = ( void * ) & rtDW . lttqcvvdla ;
rt_LoggedStateSignalPtrs [ 16 ] = ( void * ) & rtDW . klfqvxjavt ;
rt_LoggedStateSignalPtrs [ 17 ] = ( void * ) & rtDW . dtc5w4dyjs ;
rt_LoggedStateSignalPtrs [ 18 ] = ( void * ) & rtDW . h3ggkxop2c ;
rt_LoggedStateSignalPtrs [ 19 ] = ( void * ) & rtDW . nkzljw5ytc ;
rt_LoggedStateSignalPtrs [ 20 ] = ( void * ) & rtDW . ie2lmlkvwc ;
rt_LoggedStateSignalPtrs [ 21 ] = ( void * ) & rtDW . mntgwrqzc0 ;
rt_LoggedStateSignalPtrs [ 22 ] = ( void * ) & rtDW . na2aurdisb ;
rt_LoggedStateSignalPtrs [ 23 ] = ( void * ) & rtDW . bpyfsnmjtj ;
rt_LoggedStateSignalPtrs [ 24 ] = ( void * ) & rtDW . dctqktm2mj ;
rt_LoggedStateSignalPtrs [ 25 ] = ( void * ) & rtDW . pezj2tsriy ;
rt_LoggedStateSignalPtrs [ 26 ] = ( void * ) & rtDW . bncnd3iagx ;
rt_LoggedStateSignalPtrs [ 27 ] = ( void * ) & rtDW . hwd0jegvir ;
rt_LoggedStateSignalPtrs [ 28 ] = ( void * ) & rtDW . fw4qwmmztz ;
rt_LoggedStateSignalPtrs [ 29 ] = ( void * ) & rtDW . pfo30wpbs5 ;
rt_LoggedStateSignalPtrs [ 30 ] = ( void * ) & rtDW . gdes5aukxs ;
rt_LoggedStateSignalPtrs [ 31 ] = ( void * ) & rtDW . niz4kap4en ;
rt_LoggedStateSignalPtrs [ 32 ] = ( void * ) & rtDW . ezrisir0qm ;
rt_LoggedStateSignalPtrs [ 33 ] = ( void * ) & rtDW . j1eqfx30ih ;
rt_LoggedStateSignalPtrs [ 34 ] = ( void * ) & rtDW . oswghqu4mb ; }
rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout" ) ; rtliSetLogX (
ssGetRTWLogInfo ( rtS ) , "tmp_raccel_xout" ) ; rtliSetLogXFinal (
ssGetRTWLogInfo ( rtS ) , "xFinal" ) ; rtliSetLogVarNameModifier (
ssGetRTWLogInfo ( rtS ) , "none" ) ; rtliSetLogFormat ( ssGetRTWLogInfo ( rtS
) , 2 ) ; rtliSetLogMaxRows ( ssGetRTWLogInfo ( rtS ) , 0 ) ;
rtliSetLogDecimation ( ssGetRTWLogInfo ( rtS ) , 1 ) ; rtliSetLogY (
ssGetRTWLogInfo ( rtS ) , "" ) ; rtliSetLogYSignalInfo ( ssGetRTWLogInfo (
rtS ) , ( NULL ) ) ; rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL
) ) ; } { static struct _ssStatesInfo2 statesInfo2 ; ssSetStatesInfo2 ( rtS ,
& statesInfo2 ) ; } { static ssPeriodicStatesInfo periodicStatesInfo ;
ssSetPeriodicStatesInfo ( rtS , & periodicStatesInfo ) ; } { static
ssSolverInfo slvrInfo ; static boolean_T contStatesDisabled [ 50 ] ;
ssSetSolverInfo ( rtS , & slvrInfo ) ; ssSetSolverName ( rtS , "ode1" ) ;
ssSetVariableStepSolver ( rtS , 0 ) ; ssSetSolverConsistencyChecking ( rtS ,
0 ) ; ssSetSolverAdaptiveZcDetection ( rtS , 0 ) ;
ssSetSolverRobustResetMethod ( rtS , 0 ) ; ssSetSolverStateProjection ( rtS ,
0 ) ; ssSetSolverMassMatrixType ( rtS , ( ssMatrixType ) 0 ) ;
ssSetSolverMassMatrixNzMax ( rtS , 0 ) ; ssSetModelOutputs ( rtS , MdlOutputs
) ; ssSetModelLogData ( rtS , rt_UpdateTXYLogVars ) ;
ssSetModelLogDataIfInInterval ( rtS , rt_UpdateTXXFYLogVars ) ;
ssSetModelUpdate ( rtS , MdlUpdate ) ; ssSetModelDerivatives ( rtS ,
MdlDerivatives ) ; ssSetTNextTid ( rtS , INT_MIN ) ; ssSetTNext ( rtS ,
rtMinusInf ) ; ssSetSolverNeedsReset ( rtS ) ; ssSetNumNonsampledZCs ( rtS ,
0 ) ; ssSetContStateDisabled ( rtS , contStatesDisabled ) ; }
ssSetChecksumVal ( rtS , 0 , 3926258508U ) ; ssSetChecksumVal ( rtS , 1 ,
3215925013U ) ; ssSetChecksumVal ( rtS , 2 , 3711287366U ) ; ssSetChecksumVal
( rtS , 3 , 182737605U ) ; { static const sysRanDType rtAlwaysEnabled =
SUBSYS_RAN_BC_ENABLE ; static RTWExtModeInfo rt_ExtModeInfo ; static const
sysRanDType * systemRan [ 1 ] ; gblRTWExtModeInfo = & rt_ExtModeInfo ;
ssSetRTWExtModeInfo ( rtS , & rt_ExtModeInfo ) ;
rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo , systemRan ) ;
systemRan [ 0 ] = & rtAlwaysEnabled ; rteiSetModelMappingInfoPtr (
ssGetRTWExtModeInfo ( rtS ) , & ssGetModelMappingInfo ( rtS ) ) ;
rteiSetChecksumsPtr ( ssGetRTWExtModeInfo ( rtS ) , ssGetChecksums ( rtS ) )
; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS ) , ssGetTPtr ( rtS ) ) ; } rtP .
Ginproduct_Hi = rtInf ; rtP . Ginproduct_Lo = rtMinusInf ; ssSetNumSFunctions
( rtS , 1 ) ; { static SimStruct childSFunctions [ 1 ] ; static SimStruct *
childSFunctionPtrs [ 1 ] ; ( void ) memset ( ( void * ) & childSFunctions [ 0
] , 0 , sizeof ( childSFunctions ) ) ; ssSetSFunctions ( rtS , &
childSFunctionPtrs [ 0 ] ) ; ssSetSFunction ( rtS , 0 , & childSFunctions [ 0
] ) ; { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; static time_T
sfcnPeriod [ 1 ] ; static time_T sfcnOffset [ 1 ] ; static int_T sfcnTsMap [
1 ] ; ( void ) memset ( ( void * ) sfcnPeriod , 0 , sizeof ( time_T ) * 1 ) ;
( void ) memset ( ( void * ) sfcnOffset , 0 , sizeof ( time_T ) * 1 ) ;
ssSetSampleTimePtr ( rts , & sfcnPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rts ,
& sfcnOffset [ 0 ] ) ; ssSetSampleTimeTaskIDPtr ( rts , sfcnTsMap ) ; {
static struct _ssBlkInfo2 _blkInfo2 ; struct _ssBlkInfo2 * blkInfo2 = &
_blkInfo2 ; ssSetBlkInfo2Ptr ( rts , blkInfo2 ) ; } { static struct
_ssPortInfo2 _portInfo2 ; struct _ssPortInfo2 * portInfo2 = & _portInfo2 ;
_ssSetBlkInfo2PortInfo2Ptr ( rts , portInfo2 ) ; } ssSetMdlInfoPtr ( rts ,
ssGetMdlInfoPtr ( rtS ) ) ; { static struct _ssSFcnModelMethods2 methods2 ;
ssSetModelMethods2 ( rts , & methods2 ) ; } { static struct
_ssSFcnModelMethods3 methods3 ; ssSetModelMethods3 ( rts , & methods3 ) ; } {
static struct _ssSFcnModelMethods4 methods4 ; ssSetModelMethods4 ( rts , &
methods4 ) ; } { static struct _ssStatesInfo2 statesInfo2 ; static
ssPeriodicStatesInfo periodicStatesInfo ; ssSetStatesInfo2 ( rts , &
statesInfo2 ) ; ssSetPeriodicStatesInfo ( rts , & periodicStatesInfo ) ; } {
static struct _ssPortInputs inputPortInfo [ 1 ] ; _ssSetNumInputPorts ( rts ,
1 ) ; ssSetPortInfoForInputs ( rts , & inputPortInfo [ 0 ] ) ; { static
struct _ssInPortUnit inputPortUnits [ 1 ] ; _ssSetPortInfo2ForInputUnits (
rts , & inputPortUnits [ 0 ] ) ; } ssSetInputPortUnit ( rts , 0 , 0 ) ; {
static real_T const * sfcnUPtrs [ 41 ] ; sfcnUPtrs [ 0 ] = & rtB . iolwllfzji
; sfcnUPtrs [ 1 ] = & rtB . ljqiskk5u3 ; sfcnUPtrs [ 2 ] = & rtB . gwhpssih4t
; sfcnUPtrs [ 3 ] = & rtB . fpgen5oqtn ; sfcnUPtrs [ 4 ] = & rtB . gyprops4hy
; sfcnUPtrs [ 5 ] = & rtB . hxgdkcqc2i ; sfcnUPtrs [ 6 ] = & rtB . mcfswk5n2o
; sfcnUPtrs [ 7 ] = & rtB . gtctzgqgd2 ; sfcnUPtrs [ 8 ] = & rtB . fzdqkoyver
; sfcnUPtrs [ 9 ] = & rtB . j0cur13put ; sfcnUPtrs [ 10 ] = & rtB .
mangrqenh4 ; sfcnUPtrs [ 11 ] = & rtB . j24sggezs0 ; { int_T i1 ; const
real_T * u0 = & rtB . g0ajxjwpf3 [ 0 ] ; for ( i1 = 0 ; i1 < 28 ; i1 ++ ) {
sfcnUPtrs [ i1 + 12 ] = & u0 [ i1 ] ; } sfcnUPtrs [ 40 ] = & rtB . i5fngjpd5u
; } ssSetInputPortSignalPtrs ( rts , 0 , ( InputPtrsType ) & sfcnUPtrs [ 0 ]
) ; _ssSetInputPortNumDimensions ( rts , 0 , 1 ) ; ssSetInputPortWidth ( rts
, 0 , 41 ) ; } } { static struct _ssPortOutputs outputPortInfo [ 1 ] ;
ssSetPortInfoForOutputs ( rts , & outputPortInfo [ 0 ] ) ;
_ssSetNumOutputPorts ( rts , 1 ) ; { static struct _ssOutPortUnit
outputPortUnits [ 1 ] ; _ssSetPortInfo2ForOutputUnits ( rts , &
outputPortUnits [ 0 ] ) ; } ssSetOutputPortUnit ( rts , 0 , 0 ) ; {
_ssSetOutputPortNumDimensions ( rts , 0 , 1 ) ; ssSetOutputPortWidth ( rts ,
0 , 202 ) ; ssSetOutputPortSignal ( rts , 0 , ( ( real_T * ) rtB . omprcv5sy2
) ) ; } } ssSetContStates ( rts , & rtX . dzj03d1j4v [ 0 ] ) ; ssSetModelName
( rts , "TE Code" ) ; ssSetPath ( rts , "MultiLoop_mode1/TE Plant/TE Code" )
; if ( ssGetRTModel ( rtS ) == ( NULL ) ) { ssSetParentSS ( rts , rtS ) ;
ssSetRootSS ( rts , ssGetRootSS ( rtS ) ) ; } else { ssSetRTModel ( rts ,
ssGetRTModel ( rtS ) ) ; ssSetParentSS ( rts , ( NULL ) ) ; ssSetRootSS ( rts
, rts ) ; } ssSetVersion ( rts , SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetPWork (
rts , ( void * * ) & rtDW . cyxk4nbtee ) ; { static struct _ssDWorkRecord
dWorkRecord [ 1 ] ; static struct _ssDWorkAuxRecord dWorkAuxRecord [ 1 ] ;
ssSetSFcnDWork ( rts , dWorkRecord ) ; ssSetSFcnDWorkAux ( rts ,
dWorkAuxRecord ) ; _ssSetNumDWork ( rts , 1 ) ; ssSetDWorkWidth ( rts , 0 , 1
) ; ssSetDWorkDataType ( rts , 0 , SS_POINTER ) ; ssSetDWorkComplexSignal (
rts , 0 , 0 ) ; ssSetDWork ( rts , 0 , & rtDW . cyxk4nbtee ) ; } temexd_mod (
rts ) ; sfcnInitializeSizes ( rts ) ; sfcnInitializeSampleTimes ( rts ) ;
ssSetSampleTime ( rts , 0 , 0.0 ) ; ssSetOffsetTime ( rts , 0 , 0.0 ) ;
sfcnTsMap [ 0 ] = 0 ; ssSetNumNonsampledZCs ( rts , 0 ) ;
_ssSetInputPortConnected ( rts , 0 , 1 ) ; _ssSetOutputPortConnected ( rts ,
0 , 1 ) ; _ssSetOutputPortBeingMerged ( rts , 0 , 0 ) ;
ssSetInputPortBufferDstPort ( rts , 0 , - 1 ) ; } } return rtS ; }
#if defined(_MSC_VER)
#pragma optimize( "", on )
#endif
const int_T gblParameterTuningTid = 4 ; void MdlOutputsParameterSampleTime (
int_T tid ) { UNUSED_PARAMETER ( tid ) ; }
