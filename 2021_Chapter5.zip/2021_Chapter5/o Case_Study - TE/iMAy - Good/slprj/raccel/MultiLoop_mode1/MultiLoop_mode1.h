#include "__cf_MultiLoop_mode1.h"
#ifndef RTW_HEADER_MultiLoop_mode1_h_
#define RTW_HEADER_MultiLoop_mode1_h_
#include <stddef.h>
#include <string.h>
#include "rtw_modelmap.h"
#ifndef MultiLoop_mode1_COMMON_INCLUDES_
#define MultiLoop_mode1_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "sigstream_rtw.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging.h"
#include "dt_info.h"
#include "ext_work.h"
#endif
#include "MultiLoop_mode1_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "rt_defines.h"
#define MODEL_NAME MultiLoop_mode1
#define NSAMPLE_TIMES (5) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (97) 
#define NUM_ZC_EVENTS (0) 
#ifndef NCSTATES
#define NCSTATES (50)   
#elif NCSTATES != 50
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T iolwllfzji ; real_T ljqiskk5u3 ; real_T gwhpssih4t ;
real_T fpgen5oqtn ; real_T bccrbyw3op [ 12 ] ; real_T cs2ztziz0k [ 12 ] ;
real_T m5xbxvfteh [ 12 ] ; real_T gyprops4hy ; real_T hxgdkcqc2i ; real_T
mcfswk5n2o ; real_T gtctzgqgd2 ; real_T fzdqkoyver ; real_T j0cur13put ;
real_T mangrqenh4 ; real_T j24sggezs0 ; real_T df14e2fwpd [ 28 ] ; real_T
g0ajxjwpf3 [ 28 ] ; real_T i5fngjpd5u ; real_T omprcv5sy2 [ 202 ] ; real_T
kku5xrtb04 ; real_T omriyhtfeo ; real_T avhxbjy5jl [ 12 ] ; real_T l5enleslqf
; real_T ikqwcxe241 ; real_T ozcp3eaat4 ; real_T iygofvadrj ; real_T
dxh4onrpf2 ; real_T dfqakv4d54 ; real_T kjns5co5t5 ; real_T j0cvegqaqh ;
real_T f4zvypfoze ; real_T agz0woju0p ; real_T k2wkz11jl0 ; real_T hrzv1fvxzj
; real_T ndg0mjtwv5 ; real_T fmtr4xt2pw ; real_T jodh2mlmue ; real_T
o32oplehzw ; real_T jyyd5wflg2 ; real_T aj5vhl240h ; real_T jjnncqp5so ;
real_T ba4zpaneod ; real_T majq1kos5f ; real_T jffesjegzu [ 10 ] ; real_T
e2o4pc31nk ; real_T e2s03baw04 ; real_T izpriwjdfu ; real_T pgxmijpjc3 ;
real_T hfeigvk5ij ; real_T cljhe41yhf ; real_T is1c2rdpo5 ; real_T hbcctdqirx
; real_T ni4spndrc5 ; real_T llartmgedu ; real_T jicbvnq24s ; real_T
ndvlbxwnml ; real_T d1ok4vw0uh ; real_T ao0f0spd50 ; real_T deusv2ebrk ;
real_T l0su2jqw10 ; real_T fozxexl310 ; real_T b30c2nbh3s ; real_T b4jatpuzm5
; real_T mcoyogtvix ; real_T muy0uepi0b ; real_T gpbb1gvvcj ; real_T
oi1a2acgvm ; real_T g2q3ntw1j1 ; real_T cxmfrfyaum ; real_T dznrfiazyw ;
real_T hmc2jf4w3i ; real_T ofpl4daui3 ; real_T cj5hl50xku ; real_T j425ztqp2s
; real_T pl1bbzopud ; real_T gnyqyrbwif ; real_T hq5s01lzzb ; real_T
ipwewafmjl ; real_T founh1g0rd ; real_T ouskwvaeim ; real_T eup0jwsamj ;
real_T npqfy50alm ; real_T iafivlbguu ; real_T e10mphjtjt ; real_T jaor2xt4n1
; real_T ff3ioxcqht ; real_T ofdezn5rxo ; real_T oahdemerjr ; real_T
a0bsusal0x ; real_T ciejj5ghav ; real_T osvbstbttp ; real_T ojy3rf0rid ;
real_T kkq4v1qduu ; real_T fukcmanscn ; real_T ebu4kln0gn ; real_T hkk5zkpnn1
; boolean_T ljjc0rufmn ; } B ; typedef struct { real_T b15chhqxbl ; real_T
gi2i3ynyug ; real_T i0wtqgyaoh ; real_T b0yeel01dg ; real_T kreyu5dtil ;
real_T a43kgavcjl ; real_T lck0yfjpoc ; real_T imzpv25nrh ; real_T fdvolofpz2
; real_T bngn1tntsv ; real_T o3jy54xzl4 ; real_T ofaprpi3ub ; real_T
gyhogfj3mi ; real_T kf0tcjs1us ; real_T lttqcvvdla ; real_T klfqvxjavt ;
real_T dtc5w4dyjs ; real_T h3ggkxop2c ; real_T nkzljw5ytc ; real_T ie2lmlkvwc
; real_T mntgwrqzc0 ; real_T na2aurdisb ; real_T bpyfsnmjtj ; real_T
dctqktm2mj ; real_T pezj2tsriy ; real_T bncnd3iagx ; real_T hwd0jegvir ;
real_T fw4qwmmztz ; real_T pfo30wpbs5 ; real_T gdes5aukxs ; real_T niz4kap4en
; real_T ezrisir0qm ; real_T j1eqfx30ih ; real_T oswghqu4mb ; real_T
mlmenq1uvm ; real_T ekfb3mlxia ; real_T g2qwfqxtqm ; real_T b30wxoefe1 ;
real_T gcno0q5mlf ; real_T fmlqmojal0 ; real_T jbapjrt3qt ; real_T bu34crt1v1
; real_T e42tdvzthc ; real_T o51mmpjmne ; real_T n1cxse1jno ; real_T
bgawoufyg5 ; real_T a3igfd1reu ; real_T iajewt1drp ; real_T lim0zq1t1u ;
real_T pn42trpqan ; real_T ky0xqcu33m ; real_T e0jcmikseh ; real_T la2eksughs
; real_T b5iesyj5df ; real_T pgdmfzfof1 ; real_T axrr55q2tu ; real_T
nnzuvh3h1i ; real_T hegs43c0e0 ; struct { void * TimePtr ; void * DataPtr ;
void * RSimInfoPtr ; } oaotpdsye1 ; struct { void * TimePtr ; void * DataPtr
; void * RSimInfoPtr ; } kzrko0fdik ; struct { void * TimePtr ; void *
DataPtr ; void * RSimInfoPtr ; } n1d1uedpum ; void * cyxk4nbtee ; struct {
void * LoggedData ; } ajwi2z0nrm ; struct { void * LoggedData ; } lunmhu10cc
; struct { void * LoggedData ; } hamffxefoc ; struct { void * LoggedData ; }
lcfh0ubvex ; struct { void * LoggedData ; } jjazz2siws ; struct { void *
LoggedData ; } aumzl4rw1t ; struct { void * LoggedData ; } dxxbfpxsda ;
struct { void * LoggedData ; } o1go0jwcko ; struct { void * LoggedData ; }
i4gnbypwkl ; struct { void * LoggedData ; } gm0yt5d4nb ; struct { void *
LoggedData ; } lwpcmu122x ; struct { void * LoggedData ; } ggwhxshmyz ;
struct { void * LoggedData ; } f5sa3s55ij ; struct { void * LoggedData ; }
g3kwbdgvbf ; struct { void * LoggedData ; } pfrei5pknw ; struct { void *
LoggedData ; } k00ulh2fqg ; struct { void * LoggedData ; } a4fv5sect4 ;
struct { void * LoggedData ; } arkehrpdxa ; struct { void * LoggedData [ 2 ]
; } kaxtvjsz1c ; struct { void * LoggedData ; } af044523tm ; struct { void *
LoggedData ; } kzls2lxgyw ; struct { void * LoggedData ; } jwlo4oww5f ;
struct { int_T PrevIndex ; } dga4g4wh0i ; struct { int_T PrevIndex ; }
mszkyy54ed ; struct { int_T PrevIndex ; } bha2seug1p ; } DW ; typedef struct
{ real_T dzj03d1j4v [ 50 ] ; } X ; typedef struct { real_T dzj03d1j4v [ 50 ]
; } XDot ; typedef struct { boolean_T dzj03d1j4v [ 50 ] ; } XDis ; typedef
struct { rtwCAPI_ModelMappingInfo mmi ; } DataMapInfo ; struct P_ { real_T
Eadj_0 ; real_T SP17_0 ; real_T Ts_base ; real_T r1_0 ; real_T r4_0 ; real_T
r5_0 ; real_T r6_0 ; real_T r7_0 ; real_T xmv10_0 ; real_T xmv11_0 ; real_T
xmv1_0 ; real_T xmv2_0 ; real_T xmv3_0 ; real_T xmv4_0 ; real_T xmv6_0 ;
real_T xmv7_0 ; real_T xmv8_0 ; real_T Ginproduct_Hi ; real_T DiscretePI_Hi ;
real_T DiscretePI_Hi_clrmb2kvpv ; real_T DiscretePI_Hi_mmkevxvu4q ; real_T
DiscretePI_Hi_hd32nb3dx4 ; real_T Productionrate_Hi ; real_T
DiscretePI_Hi_lniehyd5nc ; real_T Reactorlevel_Hi ; real_T Reactorpressure_Hi
; real_T Reactortemperature_Hi ; real_T DiscretePI_Hi_ovtb5jvins ; real_T
Separatorlevel_Hi ; real_T Separatortemperature_Hi ; real_T
DiscretePI_Hi_eagnldn5ck ; real_T Stripperlevel_Hi ; real_T yAcontrol_Kc ;
real_T yACcontrol_Kc ; real_T Ginproduct_Kc ; real_T DiscretePI_Kc ; real_T
DiscretePI_Kc_p5gypvfx1j ; real_T DiscretePI_Kc_djwdb4m1wy ; real_T
DiscretePI_Kc_geg1c1fr31 ; real_T Productionrate_Kc ; real_T
DiscretePI_Kc_a4m4uoefrs ; real_T Reactorlevel_Kc ; real_T Reactorpressure_Kc
; real_T Reactortemperature_Kc ; real_T DiscretePI_Kc_cya5ip4lvt ; real_T
Separatorlevel_Kc ; real_T Separatortemperature_Kc ; real_T
DiscretePI_Kc_acyt0oa3ay ; real_T Stripperlevel_Kc ; real_T Ginproduct_Lo ;
real_T DiscretePI_Lo ; real_T DiscretePI_Lo_f4v111b4tf ; real_T
DiscretePI_Lo_pmxz0leexm ; real_T DiscretePI_Lo_e5ennd4tjd ; real_T
Productionrate_Lo ; real_T DiscretePI_Lo_kbw43or5wm ; real_T Reactorlevel_Lo
; real_T Reactorpressure_Lo ; real_T Reactortemperature_Lo ; real_T
DiscretePI_Lo_oiqe5mpnn5 ; real_T Separatorlevel_Lo ; real_T
Separatortemperature_Lo ; real_T DiscretePI_Lo_jjfywxfpq4 ; real_T
Stripperlevel_Lo ; real_T yAcontrol_Ti ; real_T yACcontrol_Ti ; real_T
Ginproduct_Ti ; real_T DiscretePI_Ti ; real_T DiscretePI_Ti_c3baatq2tq ;
real_T DiscretePI_Ti_md5jahyv1n ; real_T DiscretePI_Ti_fzhzo2ofo5 ; real_T
Productionrate_Ti ; real_T DiscretePI_Ti_p2j0zc1phi ; real_T Reactorlevel_Ti
; real_T Reactorpressure_Ti ; real_T Reactortemperature_Ti ; real_T
DiscretePI_Ti_mjqeflcq5c ; real_T Separatorlevel_Ti ; real_T
Separatortemperature_Ti ; real_T DiscretePI_Ti_fdbl1x51xg ; real_T
Stripperlevel_Ti ; real_T yAcontrol_Ts ; real_T yACcontrol_Ts ; real_T
CompareToConstant1_const ; real_T CompareToConstant_const ; real_T
CompareToConstant1_const_eicxgrgmw1 ; real_T Productionrate_x0 ; real_T
FromWorkspace2_Time0 ; real_T FromWorkspace2_Data0 [ 12 ] ; real_T
FromWorkspace_Time0 ; real_T FromWorkspace_Data0 [ 12 ] ; real_T
RateLimiter11_RisingLim ; real_T RateLimiter11_FallingLim ; real_T
RateLimiter9_RisingLim ; real_T RateLimiter9_FallingLim ; real_T
RateLimiter10_RisingLim ; real_T RateLimiter10_FallingLim ; real_T
Disturbances_Value [ 28 ] ; real_T Disturbances1_Value [ 28 ] ; real_T
Step_Time ; real_T Step_Y0 ; real_T Step_YFinal ; real_T FromWorkspace1_Time0
; real_T FromWorkspace1_Data0 ; real_T Gain_Gain [ 2 ] ; real_T Gain1_Gain ;
real_T Gain2_Gain [ 7 ] ; real_T Gain3_Gain [ 3 ] ; real_T Gain4_Gain ;
real_T RateLimiter_RisingLim ; real_T RateLimiter_FallingLim ; real_T
Gain_Gain_pdu3ue3qpg ; real_T RateLimiter6_RisingLim ; real_T
RateLimiter6_FallingLim ; real_T Gain1_Gain_a1wggbqhys ; real_T
UnitDelay_InitialCondition ; real_T RateLimiter1_RisingLim ; real_T
RateLimiter1_FallingLim ; real_T P2_Coefs [ 3 ] ; real_T
Gain1_Gain_et34qjmame ; real_T Gain_Gain_au5n3t3t54 ; real_T P3_Coefs [ 3 ] ;
real_T RateLimiter7_RisingLim ; real_T RateLimiter7_FallingLim ; real_T
UnitDelay_InitialCondition_irra24gzxq ; real_T Constant_Value ; real_T
UnitDelay_InitialCondition_eax13q1gy5 ; real_T
UnitDelay_InitialCondition_dnaty0hwiv ; real_T
UnitDelay_InitialCondition_i4ssjdv1x0 ; real_T
UnitDelay_InitialCondition_l1wkjfueiw ; real_T
UnitDelay_InitialCondition_nant221b3n ; real_T
UnitDelay_InitialCondition_jds2mdg4dh ; real_T
UnitDelay_InitialCondition_hup2ah5pmm ; real_T RateLimiter2_RisingLim ;
real_T RateLimiter2_FallingLim ; real_T RateLimiter3_RisingLim ; real_T
RateLimiter3_FallingLim ; real_T RateLimiter4_RisingLim ; real_T
RateLimiter4_FallingLim ; real_T RateLimiter5_RisingLim ; real_T
RateLimiter5_FallingLim ; real_T RateLimiter8_RisingLim ; real_T
RateLimiter8_FallingLim ; real_T UnitDelay_InitialCondition_atyxdvbsf2 ;
real_T UnitDelay_InitialCondition_do4nccx1tx ; real_T
UnitDelay_InitialCondition_kwbvpaeu2p ; real_T
UnitDelay_InitialCondition_hrzr4dbmzu ; real_T
UnitDelay_InitialCondition_ht5jlrjgzg ; real_T
UnitDelay_InitialCondition_aqdsuyvwgd ; real_T
UnitDelay_InitialCondition_frnu4gucc1 ; real_T
UnitDelay_InitialCondition_jxvafx45id ; } ; extern const char *
RT_MEMORY_ALLOCATION_ERROR ; extern B rtB ; extern X rtX ; extern DW rtDW ;
extern P rtP ; extern const rtwCAPI_ModelMappingStaticInfo *
MultiLoop_mode1_GetCAPIStaticMap ( void ) ; extern SimStruct * const rtS ;
extern const int_T gblNumToFiles ; extern const int_T gblNumFrFiles ; extern
const int_T gblNumFrWksBlocks ; extern rtInportTUtable * gblInportTUtables ;
extern const char * gblInportFileName ; extern const int_T
gblNumRootInportBlks ; extern const int_T gblNumModelInputs ; extern const
int_T gblInportDataTypeIdx [ ] ; extern const int_T gblInportDims [ ] ;
extern const int_T gblInportComplex [ ] ; extern const int_T
gblInportInterpoFlag [ ] ; extern const int_T gblInportContinuous [ ] ;
extern const int_T gblParameterTuningTid ; extern size_t gblCurrentSFcnIdx ;
extern DataMapInfo * rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo *
rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid ) ; void
MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T tid ) ;
void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model ( void
) ;
#endif
