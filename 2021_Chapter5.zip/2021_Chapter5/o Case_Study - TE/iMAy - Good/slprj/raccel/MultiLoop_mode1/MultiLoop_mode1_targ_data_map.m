  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtP)
    ;%
      section.nData     = 151;
      section.data(151)  = dumData; %prealloc
      
	  ;% rtP.Eadj_0
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtP.SP17_0
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtP.Ts_base
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtP.r1_0
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtP.r4_0
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtP.r5_0
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtP.r6_0
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtP.r7_0
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtP.xmv10_0
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtP.xmv11_0
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtP.xmv1_0
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtP.xmv2_0
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtP.xmv3_0
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtP.xmv4_0
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtP.xmv6_0
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtP.xmv7_0
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtP.xmv8_0
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtP.Ginproduct_Hi
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtP.DiscretePI_Hi
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtP.DiscretePI_Hi_clrmb2kvpv
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtP.DiscretePI_Hi_mmkevxvu4q
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtP.DiscretePI_Hi_hd32nb3dx4
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtP.Productionrate_Hi
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtP.DiscretePI_Hi_lniehyd5nc
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtP.Reactorlevel_Hi
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtP.Reactorpressure_Hi
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtP.Reactortemperature_Hi
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtP.DiscretePI_Hi_ovtb5jvins
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtP.Separatorlevel_Hi
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 28;
	
	  ;% rtP.Separatortemperature_Hi
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 29;
	
	  ;% rtP.DiscretePI_Hi_eagnldn5ck
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 30;
	
	  ;% rtP.Stripperlevel_Hi
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 31;
	
	  ;% rtP.yAcontrol_Kc
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 32;
	
	  ;% rtP.yACcontrol_Kc
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 33;
	
	  ;% rtP.Ginproduct_Kc
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 34;
	
	  ;% rtP.DiscretePI_Kc
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 35;
	
	  ;% rtP.DiscretePI_Kc_p5gypvfx1j
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 36;
	
	  ;% rtP.DiscretePI_Kc_djwdb4m1wy
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 37;
	
	  ;% rtP.DiscretePI_Kc_geg1c1fr31
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 38;
	
	  ;% rtP.Productionrate_Kc
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 39;
	
	  ;% rtP.DiscretePI_Kc_a4m4uoefrs
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 40;
	
	  ;% rtP.Reactorlevel_Kc
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 41;
	
	  ;% rtP.Reactorpressure_Kc
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 42;
	
	  ;% rtP.Reactortemperature_Kc
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 43;
	
	  ;% rtP.DiscretePI_Kc_cya5ip4lvt
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 44;
	
	  ;% rtP.Separatorlevel_Kc
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 45;
	
	  ;% rtP.Separatortemperature_Kc
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 46;
	
	  ;% rtP.DiscretePI_Kc_acyt0oa3ay
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 47;
	
	  ;% rtP.Stripperlevel_Kc
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 48;
	
	  ;% rtP.Ginproduct_Lo
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 49;
	
	  ;% rtP.DiscretePI_Lo
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 50;
	
	  ;% rtP.DiscretePI_Lo_f4v111b4tf
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 51;
	
	  ;% rtP.DiscretePI_Lo_pmxz0leexm
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 52;
	
	  ;% rtP.DiscretePI_Lo_e5ennd4tjd
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 53;
	
	  ;% rtP.Productionrate_Lo
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 54;
	
	  ;% rtP.DiscretePI_Lo_kbw43or5wm
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 55;
	
	  ;% rtP.Reactorlevel_Lo
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 56;
	
	  ;% rtP.Reactorpressure_Lo
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 57;
	
	  ;% rtP.Reactortemperature_Lo
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 58;
	
	  ;% rtP.DiscretePI_Lo_oiqe5mpnn5
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 59;
	
	  ;% rtP.Separatorlevel_Lo
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 60;
	
	  ;% rtP.Separatortemperature_Lo
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 61;
	
	  ;% rtP.DiscretePI_Lo_jjfywxfpq4
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 62;
	
	  ;% rtP.Stripperlevel_Lo
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 63;
	
	  ;% rtP.yAcontrol_Ti
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 64;
	
	  ;% rtP.yACcontrol_Ti
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 65;
	
	  ;% rtP.Ginproduct_Ti
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 66;
	
	  ;% rtP.DiscretePI_Ti
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 67;
	
	  ;% rtP.DiscretePI_Ti_c3baatq2tq
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 68;
	
	  ;% rtP.DiscretePI_Ti_md5jahyv1n
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 69;
	
	  ;% rtP.DiscretePI_Ti_fzhzo2ofo5
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 70;
	
	  ;% rtP.Productionrate_Ti
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 71;
	
	  ;% rtP.DiscretePI_Ti_p2j0zc1phi
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 72;
	
	  ;% rtP.Reactorlevel_Ti
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 73;
	
	  ;% rtP.Reactorpressure_Ti
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 74;
	
	  ;% rtP.Reactortemperature_Ti
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 75;
	
	  ;% rtP.DiscretePI_Ti_mjqeflcq5c
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 76;
	
	  ;% rtP.Separatorlevel_Ti
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 77;
	
	  ;% rtP.Separatortemperature_Ti
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 78;
	
	  ;% rtP.DiscretePI_Ti_fdbl1x51xg
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 79;
	
	  ;% rtP.Stripperlevel_Ti
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 80;
	
	  ;% rtP.yAcontrol_Ts
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 81;
	
	  ;% rtP.yACcontrol_Ts
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 82;
	
	  ;% rtP.CompareToConstant1_const
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 83;
	
	  ;% rtP.CompareToConstant_const
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 84;
	
	  ;% rtP.CompareToConstant1_const_eicxgrgmw1
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 85;
	
	  ;% rtP.Productionrate_x0
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 86;
	
	  ;% rtP.FromWorkspace2_Time0
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 87;
	
	  ;% rtP.FromWorkspace2_Data0
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 88;
	
	  ;% rtP.FromWorkspace_Time0
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 100;
	
	  ;% rtP.FromWorkspace_Data0
	  section.data(91).logicalSrcIdx = 90;
	  section.data(91).dtTransOffset = 101;
	
	  ;% rtP.RateLimiter11_RisingLim
	  section.data(92).logicalSrcIdx = 91;
	  section.data(92).dtTransOffset = 113;
	
	  ;% rtP.RateLimiter11_FallingLim
	  section.data(93).logicalSrcIdx = 92;
	  section.data(93).dtTransOffset = 114;
	
	  ;% rtP.RateLimiter9_RisingLim
	  section.data(94).logicalSrcIdx = 93;
	  section.data(94).dtTransOffset = 115;
	
	  ;% rtP.RateLimiter9_FallingLim
	  section.data(95).logicalSrcIdx = 94;
	  section.data(95).dtTransOffset = 116;
	
	  ;% rtP.RateLimiter10_RisingLim
	  section.data(96).logicalSrcIdx = 95;
	  section.data(96).dtTransOffset = 117;
	
	  ;% rtP.RateLimiter10_FallingLim
	  section.data(97).logicalSrcIdx = 96;
	  section.data(97).dtTransOffset = 118;
	
	  ;% rtP.Disturbances_Value
	  section.data(98).logicalSrcIdx = 97;
	  section.data(98).dtTransOffset = 119;
	
	  ;% rtP.Disturbances1_Value
	  section.data(99).logicalSrcIdx = 98;
	  section.data(99).dtTransOffset = 147;
	
	  ;% rtP.Step_Time
	  section.data(100).logicalSrcIdx = 99;
	  section.data(100).dtTransOffset = 175;
	
	  ;% rtP.Step_Y0
	  section.data(101).logicalSrcIdx = 100;
	  section.data(101).dtTransOffset = 176;
	
	  ;% rtP.Step_YFinal
	  section.data(102).logicalSrcIdx = 101;
	  section.data(102).dtTransOffset = 177;
	
	  ;% rtP.FromWorkspace1_Time0
	  section.data(103).logicalSrcIdx = 102;
	  section.data(103).dtTransOffset = 178;
	
	  ;% rtP.FromWorkspace1_Data0
	  section.data(104).logicalSrcIdx = 103;
	  section.data(104).dtTransOffset = 179;
	
	  ;% rtP.Gain_Gain
	  section.data(105).logicalSrcIdx = 104;
	  section.data(105).dtTransOffset = 180;
	
	  ;% rtP.Gain1_Gain
	  section.data(106).logicalSrcIdx = 105;
	  section.data(106).dtTransOffset = 182;
	
	  ;% rtP.Gain2_Gain
	  section.data(107).logicalSrcIdx = 106;
	  section.data(107).dtTransOffset = 183;
	
	  ;% rtP.Gain3_Gain
	  section.data(108).logicalSrcIdx = 107;
	  section.data(108).dtTransOffset = 190;
	
	  ;% rtP.Gain4_Gain
	  section.data(109).logicalSrcIdx = 108;
	  section.data(109).dtTransOffset = 193;
	
	  ;% rtP.RateLimiter_RisingLim
	  section.data(110).logicalSrcIdx = 109;
	  section.data(110).dtTransOffset = 194;
	
	  ;% rtP.RateLimiter_FallingLim
	  section.data(111).logicalSrcIdx = 110;
	  section.data(111).dtTransOffset = 195;
	
	  ;% rtP.Gain_Gain_pdu3ue3qpg
	  section.data(112).logicalSrcIdx = 111;
	  section.data(112).dtTransOffset = 196;
	
	  ;% rtP.RateLimiter6_RisingLim
	  section.data(113).logicalSrcIdx = 112;
	  section.data(113).dtTransOffset = 197;
	
	  ;% rtP.RateLimiter6_FallingLim
	  section.data(114).logicalSrcIdx = 113;
	  section.data(114).dtTransOffset = 198;
	
	  ;% rtP.Gain1_Gain_a1wggbqhys
	  section.data(115).logicalSrcIdx = 114;
	  section.data(115).dtTransOffset = 199;
	
	  ;% rtP.UnitDelay_InitialCondition
	  section.data(116).logicalSrcIdx = 115;
	  section.data(116).dtTransOffset = 200;
	
	  ;% rtP.RateLimiter1_RisingLim
	  section.data(117).logicalSrcIdx = 116;
	  section.data(117).dtTransOffset = 201;
	
	  ;% rtP.RateLimiter1_FallingLim
	  section.data(118).logicalSrcIdx = 117;
	  section.data(118).dtTransOffset = 202;
	
	  ;% rtP.P2_Coefs
	  section.data(119).logicalSrcIdx = 118;
	  section.data(119).dtTransOffset = 203;
	
	  ;% rtP.Gain1_Gain_et34qjmame
	  section.data(120).logicalSrcIdx = 119;
	  section.data(120).dtTransOffset = 206;
	
	  ;% rtP.Gain_Gain_au5n3t3t54
	  section.data(121).logicalSrcIdx = 120;
	  section.data(121).dtTransOffset = 207;
	
	  ;% rtP.P3_Coefs
	  section.data(122).logicalSrcIdx = 121;
	  section.data(122).dtTransOffset = 208;
	
	  ;% rtP.RateLimiter7_RisingLim
	  section.data(123).logicalSrcIdx = 122;
	  section.data(123).dtTransOffset = 211;
	
	  ;% rtP.RateLimiter7_FallingLim
	  section.data(124).logicalSrcIdx = 123;
	  section.data(124).dtTransOffset = 212;
	
	  ;% rtP.UnitDelay_InitialCondition_irra24gzxq
	  section.data(125).logicalSrcIdx = 124;
	  section.data(125).dtTransOffset = 213;
	
	  ;% rtP.Constant_Value
	  section.data(126).logicalSrcIdx = 125;
	  section.data(126).dtTransOffset = 214;
	
	  ;% rtP.UnitDelay_InitialCondition_eax13q1gy5
	  section.data(127).logicalSrcIdx = 126;
	  section.data(127).dtTransOffset = 215;
	
	  ;% rtP.UnitDelay_InitialCondition_dnaty0hwiv
	  section.data(128).logicalSrcIdx = 127;
	  section.data(128).dtTransOffset = 216;
	
	  ;% rtP.UnitDelay_InitialCondition_i4ssjdv1x0
	  section.data(129).logicalSrcIdx = 128;
	  section.data(129).dtTransOffset = 217;
	
	  ;% rtP.UnitDelay_InitialCondition_l1wkjfueiw
	  section.data(130).logicalSrcIdx = 129;
	  section.data(130).dtTransOffset = 218;
	
	  ;% rtP.UnitDelay_InitialCondition_nant221b3n
	  section.data(131).logicalSrcIdx = 130;
	  section.data(131).dtTransOffset = 219;
	
	  ;% rtP.UnitDelay_InitialCondition_jds2mdg4dh
	  section.data(132).logicalSrcIdx = 131;
	  section.data(132).dtTransOffset = 220;
	
	  ;% rtP.UnitDelay_InitialCondition_hup2ah5pmm
	  section.data(133).logicalSrcIdx = 132;
	  section.data(133).dtTransOffset = 221;
	
	  ;% rtP.RateLimiter2_RisingLim
	  section.data(134).logicalSrcIdx = 133;
	  section.data(134).dtTransOffset = 222;
	
	  ;% rtP.RateLimiter2_FallingLim
	  section.data(135).logicalSrcIdx = 134;
	  section.data(135).dtTransOffset = 223;
	
	  ;% rtP.RateLimiter3_RisingLim
	  section.data(136).logicalSrcIdx = 135;
	  section.data(136).dtTransOffset = 224;
	
	  ;% rtP.RateLimiter3_FallingLim
	  section.data(137).logicalSrcIdx = 136;
	  section.data(137).dtTransOffset = 225;
	
	  ;% rtP.RateLimiter4_RisingLim
	  section.data(138).logicalSrcIdx = 137;
	  section.data(138).dtTransOffset = 226;
	
	  ;% rtP.RateLimiter4_FallingLim
	  section.data(139).logicalSrcIdx = 138;
	  section.data(139).dtTransOffset = 227;
	
	  ;% rtP.RateLimiter5_RisingLim
	  section.data(140).logicalSrcIdx = 139;
	  section.data(140).dtTransOffset = 228;
	
	  ;% rtP.RateLimiter5_FallingLim
	  section.data(141).logicalSrcIdx = 140;
	  section.data(141).dtTransOffset = 229;
	
	  ;% rtP.RateLimiter8_RisingLim
	  section.data(142).logicalSrcIdx = 141;
	  section.data(142).dtTransOffset = 230;
	
	  ;% rtP.RateLimiter8_FallingLim
	  section.data(143).logicalSrcIdx = 142;
	  section.data(143).dtTransOffset = 231;
	
	  ;% rtP.UnitDelay_InitialCondition_atyxdvbsf2
	  section.data(144).logicalSrcIdx = 143;
	  section.data(144).dtTransOffset = 232;
	
	  ;% rtP.UnitDelay_InitialCondition_do4nccx1tx
	  section.data(145).logicalSrcIdx = 144;
	  section.data(145).dtTransOffset = 233;
	
	  ;% rtP.UnitDelay_InitialCondition_kwbvpaeu2p
	  section.data(146).logicalSrcIdx = 145;
	  section.data(146).dtTransOffset = 234;
	
	  ;% rtP.UnitDelay_InitialCondition_hrzr4dbmzu
	  section.data(147).logicalSrcIdx = 146;
	  section.data(147).dtTransOffset = 235;
	
	  ;% rtP.UnitDelay_InitialCondition_ht5jlrjgzg
	  section.data(148).logicalSrcIdx = 147;
	  section.data(148).dtTransOffset = 236;
	
	  ;% rtP.UnitDelay_InitialCondition_aqdsuyvwgd
	  section.data(149).logicalSrcIdx = 148;
	  section.data(149).dtTransOffset = 237;
	
	  ;% rtP.UnitDelay_InitialCondition_frnu4gucc1
	  section.data(150).logicalSrcIdx = 149;
	  section.data(150).dtTransOffset = 238;
	
	  ;% rtP.UnitDelay_InitialCondition_jxvafx45id
	  section.data(151).logicalSrcIdx = 150;
	  section.data(151).dtTransOffset = 239;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 2;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtB)
    ;%
      section.nData     = 96;
      section.data(96)  = dumData; %prealloc
      
	  ;% rtB.iolwllfzji
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.ljqiskk5u3
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtB.gwhpssih4t
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtB.fpgen5oqtn
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtB.bccrbyw3op
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtB.cs2ztziz0k
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 16;
	
	  ;% rtB.m5xbxvfteh
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 28;
	
	  ;% rtB.gyprops4hy
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 40;
	
	  ;% rtB.hxgdkcqc2i
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 41;
	
	  ;% rtB.mcfswk5n2o
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 42;
	
	  ;% rtB.gtctzgqgd2
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 43;
	
	  ;% rtB.fzdqkoyver
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 44;
	
	  ;% rtB.j0cur13put
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 45;
	
	  ;% rtB.mangrqenh4
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 46;
	
	  ;% rtB.j24sggezs0
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 47;
	
	  ;% rtB.df14e2fwpd
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 48;
	
	  ;% rtB.g0ajxjwpf3
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 76;
	
	  ;% rtB.i5fngjpd5u
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 104;
	
	  ;% rtB.omprcv5sy2
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 105;
	
	  ;% rtB.kku5xrtb04
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 307;
	
	  ;% rtB.omriyhtfeo
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 308;
	
	  ;% rtB.avhxbjy5jl
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 309;
	
	  ;% rtB.l5enleslqf
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 321;
	
	  ;% rtB.ikqwcxe241
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 322;
	
	  ;% rtB.ozcp3eaat4
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 323;
	
	  ;% rtB.iygofvadrj
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 324;
	
	  ;% rtB.dxh4onrpf2
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 325;
	
	  ;% rtB.dfqakv4d54
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 326;
	
	  ;% rtB.kjns5co5t5
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 327;
	
	  ;% rtB.j0cvegqaqh
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 328;
	
	  ;% rtB.f4zvypfoze
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 329;
	
	  ;% rtB.agz0woju0p
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 330;
	
	  ;% rtB.k2wkz11jl0
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 331;
	
	  ;% rtB.hrzv1fvxzj
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 332;
	
	  ;% rtB.ndg0mjtwv5
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 333;
	
	  ;% rtB.fmtr4xt2pw
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 334;
	
	  ;% rtB.jodh2mlmue
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 335;
	
	  ;% rtB.o32oplehzw
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 336;
	
	  ;% rtB.jyyd5wflg2
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 337;
	
	  ;% rtB.aj5vhl240h
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 338;
	
	  ;% rtB.jjnncqp5so
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 339;
	
	  ;% rtB.ba4zpaneod
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 340;
	
	  ;% rtB.majq1kos5f
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 341;
	
	  ;% rtB.jffesjegzu
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 342;
	
	  ;% rtB.e2o4pc31nk
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 352;
	
	  ;% rtB.e2s03baw04
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 353;
	
	  ;% rtB.izpriwjdfu
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 354;
	
	  ;% rtB.pgxmijpjc3
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 355;
	
	  ;% rtB.hfeigvk5ij
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 356;
	
	  ;% rtB.cljhe41yhf
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 357;
	
	  ;% rtB.is1c2rdpo5
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 358;
	
	  ;% rtB.hbcctdqirx
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 359;
	
	  ;% rtB.ni4spndrc5
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 360;
	
	  ;% rtB.llartmgedu
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 361;
	
	  ;% rtB.jicbvnq24s
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 362;
	
	  ;% rtB.ndvlbxwnml
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 363;
	
	  ;% rtB.d1ok4vw0uh
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 364;
	
	  ;% rtB.ao0f0spd50
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 365;
	
	  ;% rtB.deusv2ebrk
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 366;
	
	  ;% rtB.l0su2jqw10
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 367;
	
	  ;% rtB.fozxexl310
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 368;
	
	  ;% rtB.b30c2nbh3s
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 369;
	
	  ;% rtB.b4jatpuzm5
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 370;
	
	  ;% rtB.mcoyogtvix
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 371;
	
	  ;% rtB.muy0uepi0b
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 372;
	
	  ;% rtB.gpbb1gvvcj
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 373;
	
	  ;% rtB.oi1a2acgvm
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 374;
	
	  ;% rtB.g2q3ntw1j1
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 375;
	
	  ;% rtB.cxmfrfyaum
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 376;
	
	  ;% rtB.dznrfiazyw
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 377;
	
	  ;% rtB.hmc2jf4w3i
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 378;
	
	  ;% rtB.ofpl4daui3
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 379;
	
	  ;% rtB.cj5hl50xku
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 380;
	
	  ;% rtB.j425ztqp2s
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 381;
	
	  ;% rtB.pl1bbzopud
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 382;
	
	  ;% rtB.gnyqyrbwif
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 383;
	
	  ;% rtB.hq5s01lzzb
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 384;
	
	  ;% rtB.ipwewafmjl
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 385;
	
	  ;% rtB.founh1g0rd
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 386;
	
	  ;% rtB.ouskwvaeim
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 387;
	
	  ;% rtB.eup0jwsamj
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 388;
	
	  ;% rtB.npqfy50alm
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 389;
	
	  ;% rtB.iafivlbguu
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 390;
	
	  ;% rtB.e10mphjtjt
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 391;
	
	  ;% rtB.jaor2xt4n1
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 392;
	
	  ;% rtB.ff3ioxcqht
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 393;
	
	  ;% rtB.ofdezn5rxo
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 394;
	
	  ;% rtB.oahdemerjr
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 395;
	
	  ;% rtB.a0bsusal0x
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 396;
	
	  ;% rtB.ciejj5ghav
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 397;
	
	  ;% rtB.osvbstbttp
	  section.data(91).logicalSrcIdx = 90;
	  section.data(91).dtTransOffset = 398;
	
	  ;% rtB.ojy3rf0rid
	  section.data(92).logicalSrcIdx = 91;
	  section.data(92).dtTransOffset = 399;
	
	  ;% rtB.kkq4v1qduu
	  section.data(93).logicalSrcIdx = 92;
	  section.data(93).dtTransOffset = 400;
	
	  ;% rtB.fukcmanscn
	  section.data(94).logicalSrcIdx = 93;
	  section.data(94).dtTransOffset = 401;
	
	  ;% rtB.ebu4kln0gn
	  section.data(95).logicalSrcIdx = 94;
	  section.data(95).dtTransOffset = 402;
	
	  ;% rtB.hkk5zkpnn1
	  section.data(96).logicalSrcIdx = 95;
	  section.data(96).dtTransOffset = 403;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtB.ljjc0rufmn
	  section.data(1).logicalSrcIdx = 96;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 3;
    sectIdxOffset = 2;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtDW)
    ;%
      section.nData     = 58;
      section.data(58)  = dumData; %prealloc
      
	  ;% rtDW.b15chhqxbl
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.gi2i3ynyug
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.i0wtqgyaoh
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.b0yeel01dg
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.kreyu5dtil
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.a43kgavcjl
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.lck0yfjpoc
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtDW.imzpv25nrh
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtDW.fdvolofpz2
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtDW.bngn1tntsv
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtDW.o3jy54xzl4
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtDW.ofaprpi3ub
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtDW.gyhogfj3mi
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtDW.kf0tcjs1us
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtDW.lttqcvvdla
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtDW.klfqvxjavt
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtDW.dtc5w4dyjs
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtDW.h3ggkxop2c
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtDW.nkzljw5ytc
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtDW.ie2lmlkvwc
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtDW.mntgwrqzc0
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtDW.na2aurdisb
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtDW.bpyfsnmjtj
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtDW.dctqktm2mj
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 23;
	
	  ;% rtDW.pezj2tsriy
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 24;
	
	  ;% rtDW.bncnd3iagx
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 25;
	
	  ;% rtDW.hwd0jegvir
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 26;
	
	  ;% rtDW.fw4qwmmztz
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 27;
	
	  ;% rtDW.pfo30wpbs5
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 28;
	
	  ;% rtDW.gdes5aukxs
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 29;
	
	  ;% rtDW.niz4kap4en
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 30;
	
	  ;% rtDW.ezrisir0qm
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 31;
	
	  ;% rtDW.j1eqfx30ih
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 32;
	
	  ;% rtDW.oswghqu4mb
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 33;
	
	  ;% rtDW.mlmenq1uvm
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 34;
	
	  ;% rtDW.ekfb3mlxia
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 35;
	
	  ;% rtDW.g2qwfqxtqm
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 36;
	
	  ;% rtDW.b30wxoefe1
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 37;
	
	  ;% rtDW.gcno0q5mlf
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 38;
	
	  ;% rtDW.fmlqmojal0
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 39;
	
	  ;% rtDW.jbapjrt3qt
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 40;
	
	  ;% rtDW.bu34crt1v1
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 41;
	
	  ;% rtDW.e42tdvzthc
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 42;
	
	  ;% rtDW.o51mmpjmne
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 43;
	
	  ;% rtDW.n1cxse1jno
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 44;
	
	  ;% rtDW.bgawoufyg5
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 45;
	
	  ;% rtDW.a3igfd1reu
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 46;
	
	  ;% rtDW.iajewt1drp
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 47;
	
	  ;% rtDW.lim0zq1t1u
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 48;
	
	  ;% rtDW.pn42trpqan
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 49;
	
	  ;% rtDW.ky0xqcu33m
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 50;
	
	  ;% rtDW.e0jcmikseh
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 51;
	
	  ;% rtDW.la2eksughs
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 52;
	
	  ;% rtDW.b5iesyj5df
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 53;
	
	  ;% rtDW.pgdmfzfof1
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 54;
	
	  ;% rtDW.axrr55q2tu
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 55;
	
	  ;% rtDW.nnzuvh3h1i
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 56;
	
	  ;% rtDW.hegs43c0e0
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 57;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 26;
      section.data(26)  = dumData; %prealloc
      
	  ;% rtDW.oaotpdsye1.TimePtr
	  section.data(1).logicalSrcIdx = 58;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.kzrko0fdik.TimePtr
	  section.data(2).logicalSrcIdx = 59;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.n1d1uedpum.TimePtr
	  section.data(3).logicalSrcIdx = 60;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.cyxk4nbtee
	  section.data(4).logicalSrcIdx = 61;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.ajwi2z0nrm.LoggedData
	  section.data(5).logicalSrcIdx = 62;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.lunmhu10cc.LoggedData
	  section.data(6).logicalSrcIdx = 63;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.hamffxefoc.LoggedData
	  section.data(7).logicalSrcIdx = 64;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtDW.lcfh0ubvex.LoggedData
	  section.data(8).logicalSrcIdx = 65;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtDW.jjazz2siws.LoggedData
	  section.data(9).logicalSrcIdx = 66;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtDW.aumzl4rw1t.LoggedData
	  section.data(10).logicalSrcIdx = 67;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtDW.dxxbfpxsda.LoggedData
	  section.data(11).logicalSrcIdx = 68;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtDW.o1go0jwcko.LoggedData
	  section.data(12).logicalSrcIdx = 69;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtDW.i4gnbypwkl.LoggedData
	  section.data(13).logicalSrcIdx = 70;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtDW.gm0yt5d4nb.LoggedData
	  section.data(14).logicalSrcIdx = 71;
	  section.data(14).dtTransOffset = 13;
	
	  ;% rtDW.lwpcmu122x.LoggedData
	  section.data(15).logicalSrcIdx = 72;
	  section.data(15).dtTransOffset = 14;
	
	  ;% rtDW.ggwhxshmyz.LoggedData
	  section.data(16).logicalSrcIdx = 73;
	  section.data(16).dtTransOffset = 15;
	
	  ;% rtDW.f5sa3s55ij.LoggedData
	  section.data(17).logicalSrcIdx = 74;
	  section.data(17).dtTransOffset = 16;
	
	  ;% rtDW.g3kwbdgvbf.LoggedData
	  section.data(18).logicalSrcIdx = 75;
	  section.data(18).dtTransOffset = 17;
	
	  ;% rtDW.pfrei5pknw.LoggedData
	  section.data(19).logicalSrcIdx = 76;
	  section.data(19).dtTransOffset = 18;
	
	  ;% rtDW.k00ulh2fqg.LoggedData
	  section.data(20).logicalSrcIdx = 77;
	  section.data(20).dtTransOffset = 19;
	
	  ;% rtDW.a4fv5sect4.LoggedData
	  section.data(21).logicalSrcIdx = 78;
	  section.data(21).dtTransOffset = 20;
	
	  ;% rtDW.arkehrpdxa.LoggedData
	  section.data(22).logicalSrcIdx = 79;
	  section.data(22).dtTransOffset = 21;
	
	  ;% rtDW.kaxtvjsz1c.LoggedData
	  section.data(23).logicalSrcIdx = 80;
	  section.data(23).dtTransOffset = 22;
	
	  ;% rtDW.af044523tm.LoggedData
	  section.data(24).logicalSrcIdx = 81;
	  section.data(24).dtTransOffset = 24;
	
	  ;% rtDW.kzls2lxgyw.LoggedData
	  section.data(25).logicalSrcIdx = 82;
	  section.data(25).dtTransOffset = 25;
	
	  ;% rtDW.jwlo4oww5f.LoggedData
	  section.data(26).logicalSrcIdx = 83;
	  section.data(26).dtTransOffset = 26;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 3;
      section.data(3)  = dumData; %prealloc
      
	  ;% rtDW.dga4g4wh0i.PrevIndex
	  section.data(1).logicalSrcIdx = 84;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.mszkyy54ed.PrevIndex
	  section.data(2).logicalSrcIdx = 85;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.bha2seug1p.PrevIndex
	  section.data(3).logicalSrcIdx = 86;
	  section.data(3).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 3926258508;
  targMap.checksum1 = 3215925013;
  targMap.checksum2 = 3711287366;
  targMap.checksum3 = 182737605;

