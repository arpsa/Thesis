#include "__cf_MultiLoop_mode1.h"
#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "MultiLoop_mode1_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#else
#include "builtin_typeid_types.h"
#include "MultiLoop_mode1.h"
#include "MultiLoop_mode1_capi.h"
#include "MultiLoop_mode1_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , TARGET_STRING (
"MultiLoop_mode1/Clock" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 1
, 0 , TARGET_STRING ( "MultiLoop_mode1/From Workspace" ) , TARGET_STRING ( ""
) , 0 , 0 , 1 , 0 , 1 } , { 2 , 0 , TARGET_STRING (
"MultiLoop_mode1/From Workspace1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 ,
1 } , { 3 , 0 , TARGET_STRING ( "MultiLoop_mode1/From Workspace2" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 1 } , { 4 , 0 , TARGET_STRING (
"MultiLoop_mode1/Product1" ) , TARGET_STRING ( "" ) , 0 , 0 , 2 , 0 , 0 } , {
5 , 0 , TARGET_STRING ( "MultiLoop_mode1/Sum" ) , TARGET_STRING ( "" ) , 0 ,
0 , 2 , 0 , 0 } , { 6 , 0 , TARGET_STRING ( "MultiLoop_mode1/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 7 , 0 , TARGET_STRING (
"MultiLoop_mode1/HourlyCost/Gain4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 ,
1 } , { 8 , 0 , TARGET_STRING ( "MultiLoop_mode1/HourlyCost/Sum" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 9 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Logical Operator" ) , TARGET_STRING ( "" ) , 0 , 1
, 0 , 0 , 0 } , { 10 , 0 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Product"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 11 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 12 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 13 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter10" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 14 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter11" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 15 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 16 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter3" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 17 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter4" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 18 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter5" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 19 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter6" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 20 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter7" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 21 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter8" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 22 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0
, 0 , 0 } , { 23 , 0 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/TE Code" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 3 , 0 , 0 } , { 24 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Sum" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 }
, { 25 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/%G in product/Saturation" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 1 } , { 26 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/%G in product/Unit Delay" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 1 } , { 27 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Feedforward/Gain" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 28 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Feedforward/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 1 } , { 29 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Feedforward/Sum" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 30 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Feedforward/Sum1" ) , TARGET_STRING ( "" ) , 0 , 0
, 0 , 0 , 0 } , { 31 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Production rate/Saturation" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 1 } , { 32 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Production rate/Unit Delay" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 1 } , { 33 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Ratio trimming/Sum1" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 2 } , { 34 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Ratio trimming/Sum2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 2 } , { 35 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor level/Saturation" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 1 } , { 36 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor level/Unit Delay" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 1 } , { 37 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor pressure/Saturation" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 1 } , { 38 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor pressure/Unit Delay" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 1 } , { 39 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor temperature/Saturation" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 40 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor temperature/Unit Delay" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 1 } , { 41 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator level/Saturation" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 1 } , { 42 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator level/Unit Delay" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 1 } , { 43 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator temperature/Saturation" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 1 } , { 44 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator temperature/Unit Delay" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 1 } , { 45 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper level/Saturation" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 1 } , { 46 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper level/Unit Delay" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 1 } , { 47 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/yA control/Sum" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 48 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/yA control/Zero-Order Hold" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 2 } , { 49 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/yAC control/Sum" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 50 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/yAC control/Zero-Order Hold" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 2 } , { 51 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/%G in product/Vel PI/Sum" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 52 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/%G in product/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 53 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/A feed rate/Discrete PI/Saturation" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 54 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/A feed rate/Discrete PI/Unit Delay" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 55 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/C feed rate/Discrete PI/Saturation" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 56 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/C feed rate/Discrete PI/Unit Delay" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 57 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/D feed rate/Discrete PI/Saturation" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 58 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/D feed rate/Discrete PI/Unit Delay" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 59 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/E feed rate/Discrete PI/Saturation" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 60 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/E feed rate/Discrete PI/Unit Delay" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 61 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Production rate/Vel PI/Sum" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 0 } , { 62 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Production rate/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 63 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Purge rate/Discrete PI/Saturation" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 64 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Purge rate/Discrete PI/Unit Delay" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 65 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor level/Vel PI/Sum" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 66 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor level/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 67 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor pressure/Vel PI/Sum" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 0 } , { 68 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor pressure/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 69 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor temperature/Vel PI/Sum" ) , TARGET_STRING (
"" ) , 0 , 0 , 0 , 0 , 0 } , { 70 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor temperature/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 71 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator flow rate/Discrete PI/Saturation" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 72 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator flow rate/Discrete PI/Unit Delay" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 73 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator level/Vel PI/Sum" ) , TARGET_STRING ( ""
) , 0 , 0 , 0 , 0 , 0 } , { 74 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator level/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 75 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator temperature/Vel PI/Sum" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 76 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator temperature/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 77 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper flow rate/Discrete PI/Saturation" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 78 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper flow rate/Discrete PI/Unit Delay" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 79 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper level/Vel PI/Sum" ) , TARGET_STRING ( "" )
, 0 , 0 , 0 , 0 , 0 } , { 80 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper level/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 81 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/A feed rate/Discrete PI/Vel PI/Sum" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 82 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/A feed rate/Discrete PI/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 83 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/C feed rate/Discrete PI/Vel PI/Sum" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 84 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/C feed rate/Discrete PI/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 85 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/D feed rate/Discrete PI/Vel PI/Sum" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 86 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/D feed rate/Discrete PI/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 87 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/E feed rate/Discrete PI/Vel PI/Sum" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 88 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/E feed rate/Discrete PI/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 89 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Purge rate/Discrete PI/Vel PI/Sum" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 90 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Purge rate/Discrete PI/Vel PI/Zero-Order Hold" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 91 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator flow rate/Discrete PI/Vel PI/Sum" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 92 , 0 , TARGET_STRING (
 "MultiLoop_mode1/TE Plant/Separator flow rate/Discrete PI/Vel PI/Zero-Order Hold"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 93 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper flow rate/Discrete PI/Vel PI/Sum" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 94 , 0 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper flow rate/Discrete PI/Vel PI/Zero-Order Hold"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 } , { 0 , 0 , ( NULL ) , ( NULL
) , 0 , 0 , 0 , 0 , 0 } } ; static const rtwCAPI_BlockParameters
rtBlockParameters [ ] = { { 95 , TARGET_STRING (
"MultiLoop_mode1/Compare To Constant1" ) , TARGET_STRING ( "const" ) , 0 , 0
, 0 } , { 96 , TARGET_STRING ( "MultiLoop_mode1/Disturbances" ) ,
TARGET_STRING ( "Value" ) , 0 , 4 , 0 } , { 97 , TARGET_STRING (
"MultiLoop_mode1/Disturbances1" ) , TARGET_STRING ( "Value" ) , 0 , 4 , 0 } ,
{ 98 , TARGET_STRING ( "MultiLoop_mode1/From Workspace" ) , TARGET_STRING (
"Time0" ) , 0 , 0 , 0 } , { 99 , TARGET_STRING (
"MultiLoop_mode1/From Workspace" ) , TARGET_STRING ( "Data0" ) , 0 , 1 , 0 }
, { 100 , TARGET_STRING ( "MultiLoop_mode1/From Workspace1" ) , TARGET_STRING
( "Time0" ) , 0 , 0 , 0 } , { 101 , TARGET_STRING (
"MultiLoop_mode1/From Workspace1" ) , TARGET_STRING ( "Data0" ) , 0 , 0 , 0 }
, { 102 , TARGET_STRING ( "MultiLoop_mode1/From Workspace2" ) , TARGET_STRING
( "Time0" ) , 0 , 0 , 0 } , { 103 , TARGET_STRING (
"MultiLoop_mode1/From Workspace2" ) , TARGET_STRING ( "Data0" ) , 0 , 1 , 0 }
, { 104 , TARGET_STRING ( "MultiLoop_mode1/Step" ) , TARGET_STRING ( "Time" )
, 0 , 0 , 0 } , { 105 , TARGET_STRING ( "MultiLoop_mode1/Step" ) ,
TARGET_STRING ( "Before" ) , 0 , 0 , 0 } , { 106 , TARGET_STRING (
"MultiLoop_mode1/Step" ) , TARGET_STRING ( "After" ) , 0 , 0 , 0 } , { 107 ,
TARGET_STRING ( "MultiLoop_mode1/HourlyCost/Gain" ) , TARGET_STRING ( "Gain"
) , 0 , 5 , 0 } , { 108 , TARGET_STRING ( "MultiLoop_mode1/HourlyCost/Gain1"
) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , { 109 , TARGET_STRING (
"MultiLoop_mode1/HourlyCost/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 6 , 0 }
, { 110 , TARGET_STRING ( "MultiLoop_mode1/HourlyCost/Gain3" ) ,
TARGET_STRING ( "Gain" ) , 0 , 7 , 0 } , { 111 , TARGET_STRING (
"MultiLoop_mode1/HourlyCost/Gain4" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 }
, { 112 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/%G in product" ) ,
TARGET_STRING ( "Kc" ) , 0 , 0 , 0 } , { 113 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/%G in product" ) , TARGET_STRING ( "Ti" ) , 0 , 0 ,
0 } , { 114 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/%G in product" ) ,
TARGET_STRING ( "Hi" ) , 0 , 0 , 0 } , { 115 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/%G in product" ) , TARGET_STRING ( "Lo" ) , 0 , 0 ,
0 } , { 116 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Compare To Constant"
) , TARGET_STRING ( "const" ) , 0 , 0 , 0 } , { 117 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Compare To Constant1" ) , TARGET_STRING ( "const" )
, 0 , 0 , 0 } , { 118 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Production rate" ) , TARGET_STRING ( "Kc" ) , 0 , 0
, 0 } , { 119 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Production rate" )
, TARGET_STRING ( "Ti" ) , 0 , 0 , 0 } , { 120 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Production rate" ) , TARGET_STRING ( "x0" ) , 0 , 0
, 0 } , { 121 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Production rate" )
, TARGET_STRING ( "Hi" ) , 0 , 0 , 0 } , { 122 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Production rate" ) , TARGET_STRING ( "Lo" ) , 0 , 0
, 0 } , { 123 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Reactor level" ) ,
TARGET_STRING ( "Kc" ) , 0 , 0 , 0 } , { 124 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor level" ) , TARGET_STRING ( "Ti" ) , 0 , 0 ,
0 } , { 125 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Reactor level" ) ,
TARGET_STRING ( "Hi" ) , 0 , 0 , 0 } , { 126 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor level" ) , TARGET_STRING ( "Lo" ) , 0 , 0 ,
0 } , { 127 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Reactor pressure" ) ,
TARGET_STRING ( "Kc" ) , 0 , 0 , 0 } , { 128 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor pressure" ) , TARGET_STRING ( "Ti" ) , 0 ,
0 , 0 } , { 129 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Reactor pressure"
) , TARGET_STRING ( "Hi" ) , 0 , 0 , 0 } , { 130 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor pressure" ) , TARGET_STRING ( "Lo" ) , 0 ,
0 , 0 } , { 131 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor temperature" ) , TARGET_STRING ( "Kc" ) , 0
, 0 , 0 } , { 132 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor temperature" ) , TARGET_STRING ( "Ti" ) , 0
, 0 , 0 } , { 133 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor temperature" ) , TARGET_STRING ( "Hi" ) , 0
, 0 , 0 } , { 134 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor temperature" ) , TARGET_STRING ( "Lo" ) , 0
, 0 , 0 } , { 135 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator level" ) , TARGET_STRING ( "Kc" ) , 0 , 0
, 0 } , { 136 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Separator level" )
, TARGET_STRING ( "Ti" ) , 0 , 0 , 0 } , { 137 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator level" ) , TARGET_STRING ( "Hi" ) , 0 , 0
, 0 } , { 138 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Separator level" )
, TARGET_STRING ( "Lo" ) , 0 , 0 , 0 } , { 139 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator temperature" ) , TARGET_STRING ( "Kc" ) ,
0 , 0 , 0 } , { 140 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator temperature" ) , TARGET_STRING ( "Ti" ) ,
0 , 0 , 0 } , { 141 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator temperature" ) , TARGET_STRING ( "Hi" ) ,
0 , 0 , 0 } , { 142 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator temperature" ) , TARGET_STRING ( "Lo" ) ,
0 , 0 , 0 } , { 143 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper level" ) , TARGET_STRING ( "Kc" ) , 0 , 0
, 0 } , { 144 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Stripper level" ) ,
TARGET_STRING ( "Ti" ) , 0 , 0 , 0 } , { 145 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper level" ) , TARGET_STRING ( "Hi" ) , 0 , 0
, 0 } , { 146 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Stripper level" ) ,
TARGET_STRING ( "Lo" ) , 0 , 0 , 0 } , { 147 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/yA control" ) , TARGET_STRING ( "Kc" ) , 0 , 0 , 0
} , { 148 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/yA control" ) ,
TARGET_STRING ( "Ti" ) , 0 , 0 , 0 } , { 149 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/yA control" ) , TARGET_STRING ( "Ts" ) , 0 , 0 , 0
} , { 150 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/yAC control" ) ,
TARGET_STRING ( "Kc" ) , 0 , 0 , 0 } , { 151 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/yAC control" ) , TARGET_STRING ( "Ti" ) , 0 , 0 , 0
} , { 152 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/yAC control" ) ,
TARGET_STRING ( "Ts" ) , 0 , 0 , 0 } , { 153 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Constant" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0
} , { 154 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Gain" ) , TARGET_STRING
( "Gain" ) , 0 , 0 , 0 } , { 155 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter" ) , TARGET_STRING ( "RisingSlewLimit"
) , 0 , 0 , 0 } , { 156 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter" ) , TARGET_STRING (
"FallingSlewLimit" ) , 0 , 0 , 0 } , { 157 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter1" ) , TARGET_STRING (
"RisingSlewLimit" ) , 0 , 0 , 0 } , { 158 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter1" ) , TARGET_STRING (
"FallingSlewLimit" ) , 0 , 0 , 0 } , { 159 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter10" ) , TARGET_STRING (
"RisingSlewLimit" ) , 0 , 0 , 0 } , { 160 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter10" ) , TARGET_STRING (
"FallingSlewLimit" ) , 0 , 0 , 0 } , { 161 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter11" ) , TARGET_STRING (
"RisingSlewLimit" ) , 0 , 0 , 0 } , { 162 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter11" ) , TARGET_STRING (
"FallingSlewLimit" ) , 0 , 0 , 0 } , { 163 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter2" ) , TARGET_STRING (
"RisingSlewLimit" ) , 0 , 0 , 0 } , { 164 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter2" ) , TARGET_STRING (
"FallingSlewLimit" ) , 0 , 0 , 0 } , { 165 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter3" ) , TARGET_STRING (
"RisingSlewLimit" ) , 0 , 0 , 0 } , { 166 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter3" ) , TARGET_STRING (
"FallingSlewLimit" ) , 0 , 0 , 0 } , { 167 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter4" ) , TARGET_STRING (
"RisingSlewLimit" ) , 0 , 0 , 0 } , { 168 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter4" ) , TARGET_STRING (
"FallingSlewLimit" ) , 0 , 0 , 0 } , { 169 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter5" ) , TARGET_STRING (
"RisingSlewLimit" ) , 0 , 0 , 0 } , { 170 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter5" ) , TARGET_STRING (
"FallingSlewLimit" ) , 0 , 0 , 0 } , { 171 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter6" ) , TARGET_STRING (
"RisingSlewLimit" ) , 0 , 0 , 0 } , { 172 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter6" ) , TARGET_STRING (
"FallingSlewLimit" ) , 0 , 0 , 0 } , { 173 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter7" ) , TARGET_STRING (
"RisingSlewLimit" ) , 0 , 0 , 0 } , { 174 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter7" ) , TARGET_STRING (
"FallingSlewLimit" ) , 0 , 0 , 0 } , { 175 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter8" ) , TARGET_STRING (
"RisingSlewLimit" ) , 0 , 0 , 0 } , { 176 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter8" ) , TARGET_STRING (
"FallingSlewLimit" ) , 0 , 0 , 0 } , { 177 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter9" ) , TARGET_STRING (
"RisingSlewLimit" ) , 0 , 0 , 0 } , { 178 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Rate Limiter9" ) , TARGET_STRING (
"FallingSlewLimit" ) , 0 , 0 , 0 } , { 179 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/A & C measurements/Gain1" ) , TARGET_STRING (
"Gain" ) , 0 , 0 , 0 } , { 180 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/A feed rate/Discrete PI" ) , TARGET_STRING ( "Kc" )
, 0 , 0 , 0 } , { 181 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/A feed rate/Discrete PI" ) , TARGET_STRING ( "Ti" )
, 0 , 0 , 0 } , { 182 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/A feed rate/Discrete PI" ) , TARGET_STRING ( "Hi" )
, 0 , 0 , 0 } , { 183 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/A feed rate/Discrete PI" ) , TARGET_STRING ( "Lo" )
, 0 , 0 , 0 } , { 184 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/C feed rate/Discrete PI" ) , TARGET_STRING ( "Kc" )
, 0 , 0 , 0 } , { 185 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/C feed rate/Discrete PI" ) , TARGET_STRING ( "Ti" )
, 0 , 0 , 0 } , { 186 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/C feed rate/Discrete PI" ) , TARGET_STRING ( "Hi" )
, 0 , 0 , 0 } , { 187 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/C feed rate/Discrete PI" ) , TARGET_STRING ( "Lo" )
, 0 , 0 , 0 } , { 188 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/D feed rate/Discrete PI" ) , TARGET_STRING ( "Kc" )
, 0 , 0 , 0 } , { 189 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/D feed rate/Discrete PI" ) , TARGET_STRING ( "Ti" )
, 0 , 0 , 0 } , { 190 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/D feed rate/Discrete PI" ) , TARGET_STRING ( "Hi" )
, 0 , 0 , 0 } , { 191 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/D feed rate/Discrete PI" ) , TARGET_STRING ( "Lo" )
, 0 , 0 , 0 } , { 192 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/E feed rate/Discrete PI" ) , TARGET_STRING ( "Kc" )
, 0 , 0 , 0 } , { 193 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/E feed rate/Discrete PI" ) , TARGET_STRING ( "Ti" )
, 0 , 0 , 0 } , { 194 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/E feed rate/Discrete PI" ) , TARGET_STRING ( "Hi" )
, 0 , 0 , 0 } , { 195 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/E feed rate/Discrete PI" ) , TARGET_STRING ( "Lo" )
, 0 , 0 , 0 } , { 196 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Feedforward/Gain" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 197 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Feedforward/Gain1" ) , TARGET_STRING ( "Gain" ) , 0
, 0 , 0 } , { 198 , TARGET_STRING ( "MultiLoop_mode1/TE Plant/Feedforward/P2"
) , TARGET_STRING ( "Coefs" ) , 0 , 7 , 0 } , { 199 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Feedforward/P3" ) , TARGET_STRING ( "Coefs" ) , 0 ,
7 , 0 } , { 200 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Purge rate/Discrete PI" ) , TARGET_STRING ( "Kc" )
, 0 , 0 , 0 } , { 201 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Purge rate/Discrete PI" ) , TARGET_STRING ( "Ti" )
, 0 , 0 , 0 } , { 202 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Purge rate/Discrete PI" ) , TARGET_STRING ( "Hi" )
, 0 , 0 , 0 } , { 203 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Purge rate/Discrete PI" ) , TARGET_STRING ( "Lo" )
, 0 , 0 , 0 } , { 204 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator flow rate/Discrete PI" ) , TARGET_STRING
( "Kc" ) , 0 , 0 , 0 } , { 205 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator flow rate/Discrete PI" ) , TARGET_STRING
( "Ti" ) , 0 , 0 , 0 } , { 206 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator flow rate/Discrete PI" ) , TARGET_STRING
( "Hi" ) , 0 , 0 , 0 } , { 207 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator flow rate/Discrete PI" ) , TARGET_STRING
( "Lo" ) , 0 , 0 , 0 } , { 208 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper flow rate/Discrete PI" ) , TARGET_STRING (
"Kc" ) , 0 , 0 , 0 } , { 209 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper flow rate/Discrete PI" ) , TARGET_STRING (
"Ti" ) , 0 , 0 , 0 } , { 210 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper flow rate/Discrete PI" ) , TARGET_STRING (
"Hi" ) , 0 , 0 , 0 } , { 211 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper flow rate/Discrete PI" ) , TARGET_STRING (
"Lo" ) , 0 , 0 , 0 } , { 212 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/yA control/Unit Delay" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 213 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/yAC control/Unit Delay" ) , TARGET_STRING (
"InitialCondition" ) , 0 , 0 , 0 } , { 214 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/%G in product/Vel PI/Unit Delay" ) , TARGET_STRING
( "InitialCondition" ) , 0 , 0 , 0 } , { 215 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Production rate/Vel PI/Unit Delay" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 216 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor level/Vel PI/Unit Delay" ) , TARGET_STRING
( "InitialCondition" ) , 0 , 0 , 0 } , { 217 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor pressure/Vel PI/Unit Delay" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 218 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Reactor temperature/Vel PI/Unit Delay" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 219 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator level/Vel PI/Unit Delay" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 220 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator temperature/Vel PI/Unit Delay" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 221 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper level/Vel PI/Unit Delay" ) , TARGET_STRING
( "InitialCondition" ) , 0 , 0 , 0 } , { 222 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/A feed rate/Discrete PI/Vel PI/Unit Delay" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 223 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/C feed rate/Discrete PI/Vel PI/Unit Delay" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 224 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/D feed rate/Discrete PI/Vel PI/Unit Delay" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 225 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/E feed rate/Discrete PI/Vel PI/Unit Delay" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 226 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Purge rate/Discrete PI/Vel PI/Unit Delay" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 227 , TARGET_STRING (
"MultiLoop_mode1/TE Plant/Separator flow rate/Discrete PI/Vel PI/Unit Delay"
) , TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 228 ,
TARGET_STRING (
"MultiLoop_mode1/TE Plant/Stripper flow rate/Discrete PI/Vel PI/Unit Delay" )
, TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 0 , ( NULL ) , (
NULL ) , 0 , 0 , 0 } } ; static const rtwCAPI_ModelParameters
rtModelParameters [ ] = { { 229 , TARGET_STRING ( "Eadj_0" ) , 0 , 0 , 0 } ,
{ 230 , TARGET_STRING ( "SP17_0" ) , 0 , 0 , 0 } , { 231 , TARGET_STRING (
"Ts_base" ) , 0 , 0 , 0 } , { 232 , TARGET_STRING ( "r1_0" ) , 0 , 0 , 0 } ,
{ 233 , TARGET_STRING ( "r4_0" ) , 0 , 0 , 0 } , { 234 , TARGET_STRING (
"r5_0" ) , 0 , 0 , 0 } , { 235 , TARGET_STRING ( "r6_0" ) , 0 , 0 , 0 } , {
236 , TARGET_STRING ( "r7_0" ) , 0 , 0 , 0 } , { 237 , TARGET_STRING (
"xmv10_0" ) , 0 , 0 , 0 } , { 238 , TARGET_STRING ( "xmv11_0" ) , 0 , 0 , 0 }
, { 239 , TARGET_STRING ( "xmv1_0" ) , 0 , 0 , 0 } , { 240 , TARGET_STRING (
"xmv2_0" ) , 0 , 0 , 0 } , { 241 , TARGET_STRING ( "xmv3_0" ) , 0 , 0 , 0 } ,
{ 242 , TARGET_STRING ( "xmv4_0" ) , 0 , 0 , 0 } , { 243 , TARGET_STRING (
"xmv6_0" ) , 0 , 0 , 0 } , { 244 , TARGET_STRING ( "xmv7_0" ) , 0 , 0 , 0 } ,
{ 245 , TARGET_STRING ( "xmv8_0" ) , 0 , 0 , 0 } , { 0 , ( NULL ) , 0 , 0 , 0
} } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtB . hkk5zkpnn1 , & rtB . cs2ztziz0k [
0 ] , & rtB . i5fngjpd5u , & rtB . bccrbyw3op [ 0 ] , & rtB . df14e2fwpd [ 0
] , & rtB . g0ajxjwpf3 [ 0 ] , & rtB . m5xbxvfteh [ 0 ] , & rtB . kku5xrtb04
, & rtB . omriyhtfeo , & rtB . ljjc0rufmn , & rtB . e2o4pc31nk , & rtB .
l5enleslqf , & rtB . j0cvegqaqh , & rtB . j24sggezs0 , & rtB . gyprops4hy , &
rtB . oi1a2acgvm , & rtB . g2q3ntw1j1 , & rtB . cxmfrfyaum , & rtB .
dznrfiazyw , & rtB . iygofvadrj , & rtB . fmtr4xt2pw , & rtB . hmc2jf4w3i , &
rtB . fzdqkoyver , & rtB . omprcv5sy2 [ 0 ] , & rtB . ozcp3eaat4 , & rtB .
pgxmijpjc3 , & rtB . f4zvypfoze , & rtB . hrzv1fvxzj , & rtB . agz0woju0p , &
rtB . k2wkz11jl0 , & rtB . ndg0mjtwv5 , & rtB . b4jatpuzm5 , & rtB .
ikqwcxe241 , & rtB . jyyd5wflg2 , & rtB . kjns5co5t5 , & rtB . j425ztqp2s , &
rtB . majq1kos5f , & rtB . hq5s01lzzb , & rtB . aj5vhl240h , & rtB .
ouskwvaeim , & rtB . j0cur13put , & rtB . ff3ioxcqht , & rtB . jjnncqp5so , &
rtB . a0bsusal0x , & rtB . mangrqenh4 , & rtB . ebu4kln0gn , & rtB .
ba4zpaneod , & rtB . dxh4onrpf2 , & rtB . dfqakv4d54 , & rtB . jodh2mlmue , &
rtB . o32oplehzw , & rtB . e2s03baw04 , & rtB . izpriwjdfu , & rtB .
is1c2rdpo5 , & rtB . gwhpssih4t , & rtB . llartmgedu , & rtB . fpgen5oqtn , &
rtB . d1ok4vw0uh , & rtB . iolwllfzji , & rtB . l0su2jqw10 , & rtB .
ljqiskk5u3 , & rtB . fozxexl310 , & rtB . b30c2nbh3s , & rtB . gpbb1gvvcj , &
rtB . hxgdkcqc2i , & rtB . ofpl4daui3 , & rtB . cj5hl50xku , & rtB .
pl1bbzopud , & rtB . gnyqyrbwif , & rtB . ipwewafmjl , & rtB . founh1g0rd , &
rtB . iafivlbguu , & rtB . mcfswk5n2o , & rtB . e10mphjtjt , & rtB .
jaor2xt4n1 , & rtB . ofdezn5rxo , & rtB . oahdemerjr , & rtB . ojy3rf0rid , &
rtB . gtctzgqgd2 , & rtB . kkq4v1qduu , & rtB . fukcmanscn , & rtB .
hfeigvk5ij , & rtB . cljhe41yhf , & rtB . hbcctdqirx , & rtB . ni4spndrc5 , &
rtB . jicbvnq24s , & rtB . ndvlbxwnml , & rtB . ao0f0spd50 , & rtB .
deusv2ebrk , & rtB . mcoyogtvix , & rtB . muy0uepi0b , & rtB . eup0jwsamj , &
rtB . npqfy50alm , & rtB . ciejj5ghav , & rtB . osvbstbttp , & rtP .
CompareToConstant1_const , & rtP . Disturbances_Value [ 0 ] , & rtP .
Disturbances1_Value [ 0 ] , & rtP . FromWorkspace_Time0 , & rtP .
FromWorkspace_Data0 [ 0 ] , & rtP . FromWorkspace1_Time0 , & rtP .
FromWorkspace1_Data0 , & rtP . FromWorkspace2_Time0 , & rtP .
FromWorkspace2_Data0 [ 0 ] , & rtP . Step_Time , & rtP . Step_Y0 , & rtP .
Step_YFinal , & rtP . Gain_Gain [ 0 ] , & rtP . Gain1_Gain , & rtP .
Gain2_Gain [ 0 ] , & rtP . Gain3_Gain [ 0 ] , & rtP . Gain4_Gain , & rtP .
Ginproduct_Kc , & rtP . Ginproduct_Ti , & rtP . Ginproduct_Hi , & rtP .
Ginproduct_Lo , & rtP . CompareToConstant_const , & rtP .
CompareToConstant1_const_eicxgrgmw1 , & rtP . Productionrate_Kc , & rtP .
Productionrate_Ti , & rtP . Productionrate_x0 , & rtP . Productionrate_Hi , &
rtP . Productionrate_Lo , & rtP . Reactorlevel_Kc , & rtP . Reactorlevel_Ti ,
& rtP . Reactorlevel_Hi , & rtP . Reactorlevel_Lo , & rtP .
Reactorpressure_Kc , & rtP . Reactorpressure_Ti , & rtP . Reactorpressure_Hi
, & rtP . Reactorpressure_Lo , & rtP . Reactortemperature_Kc , & rtP .
Reactortemperature_Ti , & rtP . Reactortemperature_Hi , & rtP .
Reactortemperature_Lo , & rtP . Separatorlevel_Kc , & rtP . Separatorlevel_Ti
, & rtP . Separatorlevel_Hi , & rtP . Separatorlevel_Lo , & rtP .
Separatortemperature_Kc , & rtP . Separatortemperature_Ti , & rtP .
Separatortemperature_Hi , & rtP . Separatortemperature_Lo , & rtP .
Stripperlevel_Kc , & rtP . Stripperlevel_Ti , & rtP . Stripperlevel_Hi , &
rtP . Stripperlevel_Lo , & rtP . yAcontrol_Kc , & rtP . yAcontrol_Ti , & rtP
. yAcontrol_Ts , & rtP . yACcontrol_Kc , & rtP . yACcontrol_Ti , & rtP .
yACcontrol_Ts , & rtP . Constant_Value , & rtP . Gain_Gain_pdu3ue3qpg , & rtP
. RateLimiter_RisingLim , & rtP . RateLimiter_FallingLim , & rtP .
RateLimiter1_RisingLim , & rtP . RateLimiter1_FallingLim , & rtP .
RateLimiter10_RisingLim , & rtP . RateLimiter10_FallingLim , & rtP .
RateLimiter11_RisingLim , & rtP . RateLimiter11_FallingLim , & rtP .
RateLimiter2_RisingLim , & rtP . RateLimiter2_FallingLim , & rtP .
RateLimiter3_RisingLim , & rtP . RateLimiter3_FallingLim , & rtP .
RateLimiter4_RisingLim , & rtP . RateLimiter4_FallingLim , & rtP .
RateLimiter5_RisingLim , & rtP . RateLimiter5_FallingLim , & rtP .
RateLimiter6_RisingLim , & rtP . RateLimiter6_FallingLim , & rtP .
RateLimiter7_RisingLim , & rtP . RateLimiter7_FallingLim , & rtP .
RateLimiter8_RisingLim , & rtP . RateLimiter8_FallingLim , & rtP .
RateLimiter9_RisingLim , & rtP . RateLimiter9_FallingLim , & rtP .
Gain1_Gain_a1wggbqhys , & rtP . DiscretePI_Kc , & rtP . DiscretePI_Ti , & rtP
. DiscretePI_Hi , & rtP . DiscretePI_Lo , & rtP . DiscretePI_Kc_p5gypvfx1j ,
& rtP . DiscretePI_Ti_c3baatq2tq , & rtP . DiscretePI_Hi_clrmb2kvpv , & rtP .
DiscretePI_Lo_f4v111b4tf , & rtP . DiscretePI_Kc_djwdb4m1wy , & rtP .
DiscretePI_Ti_md5jahyv1n , & rtP . DiscretePI_Hi_mmkevxvu4q , & rtP .
DiscretePI_Lo_pmxz0leexm , & rtP . DiscretePI_Kc_geg1c1fr31 , & rtP .
DiscretePI_Ti_fzhzo2ofo5 , & rtP . DiscretePI_Hi_hd32nb3dx4 , & rtP .
DiscretePI_Lo_e5ennd4tjd , & rtP . Gain_Gain_au5n3t3t54 , & rtP .
Gain1_Gain_et34qjmame , & rtP . P2_Coefs [ 0 ] , & rtP . P3_Coefs [ 0 ] , &
rtP . DiscretePI_Kc_a4m4uoefrs , & rtP . DiscretePI_Ti_p2j0zc1phi , & rtP .
DiscretePI_Hi_lniehyd5nc , & rtP . DiscretePI_Lo_kbw43or5wm , & rtP .
DiscretePI_Kc_cya5ip4lvt , & rtP . DiscretePI_Ti_mjqeflcq5c , & rtP .
DiscretePI_Hi_ovtb5jvins , & rtP . DiscretePI_Lo_oiqe5mpnn5 , & rtP .
DiscretePI_Kc_acyt0oa3ay , & rtP . DiscretePI_Ti_fdbl1x51xg , & rtP .
DiscretePI_Hi_eagnldn5ck , & rtP . DiscretePI_Lo_jjfywxfpq4 , & rtP .
UnitDelay_InitialCondition , & rtP . UnitDelay_InitialCondition_irra24gzxq ,
& rtP . UnitDelay_InitialCondition_eax13q1gy5 , & rtP .
UnitDelay_InitialCondition_jds2mdg4dh , & rtP .
UnitDelay_InitialCondition_atyxdvbsf2 , & rtP .
UnitDelay_InitialCondition_do4nccx1tx , & rtP .
UnitDelay_InitialCondition_kwbvpaeu2p , & rtP .
UnitDelay_InitialCondition_ht5jlrjgzg , & rtP .
UnitDelay_InitialCondition_aqdsuyvwgd , & rtP .
UnitDelay_InitialCondition_jxvafx45id , & rtP .
UnitDelay_InitialCondition_dnaty0hwiv , & rtP .
UnitDelay_InitialCondition_i4ssjdv1x0 , & rtP .
UnitDelay_InitialCondition_l1wkjfueiw , & rtP .
UnitDelay_InitialCondition_nant221b3n , & rtP .
UnitDelay_InitialCondition_hup2ah5pmm , & rtP .
UnitDelay_InitialCondition_hrzr4dbmzu , & rtP .
UnitDelay_InitialCondition_frnu4gucc1 , & rtP . Eadj_0 , & rtP . SP17_0 , &
rtP . Ts_base , & rtP . r1_0 , & rtP . r4_0 , & rtP . r5_0 , & rtP . r6_0 , &
rtP . r7_0 , & rtP . xmv10_0 , & rtP . xmv11_0 , & rtP . xmv1_0 , & rtP .
xmv2_0 , & rtP . xmv3_0 , & rtP . xmv4_0 , & rtP . xmv6_0 , & rtP . xmv7_0 ,
& rtP . xmv8_0 , } ; static int32_T * rtVarDimsAddrMap [ ] = { ( NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , SS_DOUBLE , 0 , 0 } , {
"unsigned char" , "boolean_T" , 0 , 0 , sizeof ( boolean_T ) , SS_BOOLEAN , 0
, 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } , { rtwCAPI_VECTOR , 2 , 2 , 0 } , {
rtwCAPI_VECTOR , 4 , 2 , 0 } , { rtwCAPI_VECTOR , 6 , 2 , 0 } , {
rtwCAPI_VECTOR , 8 , 2 , 0 } , { rtwCAPI_VECTOR , 10 , 2 , 0 } , {
rtwCAPI_VECTOR , 12 , 2 , 0 } , { rtwCAPI_VECTOR , 14 , 2 , 0 } } ; static
const uint_T rtDimensionArray [ ] = { 1 , 1 , 12 , 1 , 28 , 1 , 202 , 1 , 1 ,
28 , 1 , 2 , 1 , 7 , 1 , 3 } ; static const real_T rtcapiStoredFloats [ ] = {
0.0 , 0.0005 , 0.1 } ; static const rtwCAPI_FixPtMap rtFixPtMap [ ] = { { (
NULL ) , ( NULL ) , rtwCAPI_FIX_RESERVED , 0 , 0 , 0 } , } ; static const
rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const void * ) &
rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [ 0 ] , 0 ,
0 } , { ( const void * ) & rtcapiStoredFloats [ 1 ] , ( const void * ) &
rtcapiStoredFloats [ 0 ] , 1 , 0 } , { ( const void * ) & rtcapiStoredFloats
[ 2 ] , ( const void * ) & rtcapiStoredFloats [ 0 ] , 3 , 0 } } ; static
rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals , 95 , ( NULL )
, 0 , ( NULL ) , 0 } , { rtBlockParameters , 134 , rtModelParameters , 17 } ,
{ ( NULL ) , 0 } , { rtDataTypeMap , rtDimensionMap , rtFixPtMap ,
rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float" , { 3926258508U
, 3215925013U , 3711287366U , 182737605U } , ( NULL ) , 0 , 0 } ; const
rtwCAPI_ModelMappingStaticInfo * MultiLoop_mode1_GetCAPIStaticMap ( void ) {
return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void MultiLoop_mode1_InitializeDataMapInfo ( void ) { rtwCAPI_SetVersion ( (
* rt_dataMapInfoPtr ) . mmi , 1 ) ; rtwCAPI_SetStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ; rtwCAPI_SetLoggingStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ; rtwCAPI_SetDataAddressMap ( ( *
rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ; rtwCAPI_SetVarDimsAddressMap (
( * rt_dataMapInfoPtr ) . mmi , rtVarDimsAddrMap ) ;
rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi , 0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void MultiLoop_mode1_host_InitializeDataMapInfo (
MultiLoop_mode1_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
