#include "__cf_MultiLoop_mode1.h"
#ifndef RTW_HEADER_MultiLoop_mode1_types_h_
#define RTW_HEADER_MultiLoop_mode1_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#ifndef DEFINED_TYPEDEF_FOR_struct_dnmO3v8cVV43lA5PUgdK1F_
#define DEFINED_TYPEDEF_FOR_struct_dnmO3v8cVV43lA5PUgdK1F_
typedef struct { real_T values ; } struct_dnmO3v8cVV43lA5PUgdK1F ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_OyKL6aftwn0pcQlJPIdUwG_
#define DEFINED_TYPEDEF_FOR_struct_OyKL6aftwn0pcQlJPIdUwG_
typedef struct { real_T time ; struct_dnmO3v8cVV43lA5PUgdK1F signals ; }
struct_OyKL6aftwn0pcQlJPIdUwG ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_5YfcfCysUTVFdlQRAQU5uG_
#define DEFINED_TYPEDEF_FOR_struct_5YfcfCysUTVFdlQRAQU5uG_
typedef struct { real_T values [ 12 ] ; } struct_5YfcfCysUTVFdlQRAQU5uG ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_gdUZ4hK7gOXgGkWSIorwkC_
#define DEFINED_TYPEDEF_FOR_struct_gdUZ4hK7gOXgGkWSIorwkC_
typedef struct { real_T time ; struct_5YfcfCysUTVFdlQRAQU5uG signals ; }
struct_gdUZ4hK7gOXgGkWSIorwkC ;
#endif
typedef struct P_ P ;
#endif
