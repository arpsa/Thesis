clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')

addpath('Plant')
addpath('Model')
addpath('Functions')

global Fp_0 r1_0 r2_0 r3_0 r4_0 r5_0 r6_0 r7_0 Eadj_0 SP17_0      ...
       xmv1_0 xmv2_0 xmv3_0 xmv4_0 xmv5_0 xmv6_0 xmv7_0 xmv8_0    ...
       xmv9_0 xmv10_0 xmv11_0 xmv12_0 xInitial XMV r xFinal XMEAS ...
       XMEASCOMP XMEASSTREAM XMEASRHO setpoints OpCost IDV x      ...
       Production Quality tout prev_setpoints

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.- Initialize plant at base case
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.1.- Tunable parameters
    Measurement_Noise = 0; % 0: without noise | 1: with noise
        MNoise.time           = 0;
        MNoise.signals.values = Measurement_Noise;
% 1.2.- Base case initialisation of states & simulation sampling times
    load Mode1xInitial
    Ts_base=0.0005;
    Ts_save=0.01;
% 1.3.- Initial setpoints
    setpoints.time    = 0;
    setpoints.signals.values = [21; 40; 50; 40; 2500; 10; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
    prev_setpoints = setpoints;
    % 1.4.- Initial valve positions
    u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
    for i=1:12
        iChar=int2str(i);
        eval(['xmv',iChar,'_0=u0(',iChar,');']);
    end    
% 1.5.- Initial Controlers parameters
    Fp_0   = 100;
    r1_0   = 0.251/Fp_0;
    r2_0   = 3664/Fp_0;
    r3_0   = 4509/Fp_0;
    r4_0   = 9.35/Fp_0;
    r5_0   = 0.337/Fp_0;
    r6_0   = 25.16/Fp_0;
    r7_0   = 22.95/Fp_0;
    Eadj_0 = 0;
    SP17_0 = 80.1;   
% 1.6.- Launch simulation
    u0   = setpoints.signals.values([1 4 5 6 7 8 9])';
    mode = 2;
    [yk, phi1k, phi2k, gk, geqk] = SimPlant(u0, mode);
% 1.7.- Extract data
    results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2.- Define the model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Parameters = SetParameters(); % Set the model parameters
% 2.1.- Model inputs 
    uk{1} = setpoints.signals.values([1 4 5 6 7 8 9])';
    %       m11 VLr Pr   %G C_A C_AC  Tr
    ub_u = [40  80  2800 60 70  100   140];
    lb_u = [21  65  1000 20 30   30   110]; % min for VLstr, VLsep, and vsteam chosen such that they are equal to their equality constraint.
    uk_s = (uk{1} - lb_u')./(ub_u' - lb_u') ;
% 2.2.- Initial states
    [x0s, lb, ub, x0s_x, lb_x, ub_x] = InitState(results);
% 2.3.- Finit difference step size
  delta_M =[1e-4 1e-5 1e-4 1e-5 1e-5 0.9e-4 1e-5];
%   delta_M =[1e-4 1e-5 1e-4 1e-5 1e-4 0.9e-4 1e-4];
  delta_P =[1e-5 1e-5 1e-4 1e-5 1e-5 0.9e-4 1e-5];
% 2.4.- Initialize the modifiers structure
    Modifiers = struct();
    Modifiers.type = 'none';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%








%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 3.- Nominal optimization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% x0s = [0.429170464112049;0.00442443777413749;0.451292652983815;7.02451916199140e-05;0.0950643724953205;0.0209788284425483;1.72592197274232e-12;0.132488936448862;0.0729493391107073;0.402507251923275;0.0480224420802521;0.00979952284498443;0.322178514709707;0.0538984121630274;0.00856229693684819;0.00477951711993254;0.00651847520201916;0.0557028372533504;0.515221063621242;0.363433000904011;0.0727060061521185;0.160789961977236;0.00101900406913126;0.348976778876794;0.0770122789682164;0.0131894199276581;0.478654833748111;0.539167562810232;0.325354053077957;0.117081894540241;0.132488936448939;0.0729493391107081;0.0575422972020389;0.287270803287685;0.0574694998506063;0.127094296398242;0.000821069255148429;0.296970760715384;0.0655355784508829;0.0201187419049360;0.429000000000000;0.597331322773341;0.515059416760162;0.269583781405116;0.322322322322322;0.0480224420802521;0.188188188188188;0.00979952284498443;0.322178514709707;0.0538984121630274;0.00856229693684819;0.0480293017556715;0.327417117931541;0.0655009064433500;0.144855821601113;0.000918021683902032;0.314393494483598;0.0693804315028977;0.0118823602951875;0.0666528470594112];
% x0s = x0s;
% uk  = [21;40;60;60;2500;10;63.1372549019608;51;125;1];
% uk_s = (uk - lb_u')./(ub_u' - lb_u') ;

xu0s  = [x0s*0.9; uk_s];
ub_xu = [ub ub_u];
lb_xu = [lb lb_u];


xu  = (xu0s).*(ub_xu'-lb_xu') + lb_xu';
xx = xu(1:60); 
uk = xu(61:end); 
mode = 4;

% [xus_sol, f, eflag, outpt, Last_ceq] = RunOptimization_UX_combo(xu0s, Parameters, lb_xu, ub_xu, mode, Modifiers);
[xus_sol, f, eflag, outpt, lambda] = RunOptimization_UX_combo(xu0s, Parameters, lb_xu, ub_xu, mode, Modifiers, 1, uk);
if eflag < 1
    warning('fmincon found no solution')
end

%%
xu_sol  = (xus_sol).*(ub_xu'-lb_xu') + lb_xu';
xx_sol = xu_sol(1:60); 
uk_sol = xu_sol(61:end); 
[dx, y_sol]= SimTE_2SubSystems(xx_sol, uk_sol, Parameters, Modifiers);
[phi1, phi2, g, geq] = uy2phig2(uk_sol,y_sol, mode, Modifiers,Parameters) ;



disp(' ')
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')
