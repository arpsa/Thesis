function [eq_str, y_str] = Stripper(x_str, u_str, Parameter)
% u_str = [Vpstr_sp; m11_sp; msteam_sp; Tsep; Tstr; c10]; 
% x_str = [F4; F5; F10; F11];
% y_str = [F4; F5; F10; F11; Tstr; rho_11; m11; msteam; Vliq_str; c5; c11];

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Parameters
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Cpv_A = Parameter.A.Cpv;  % [kJ/(kg �C)]
Cpv_B = Parameter.B.Cpv;  % [kJ/(kg �C)]
Cpv_C = Parameter.C.Cpv;  % [kJ/(kg �C)]
Cpv_D = Parameter.D.Cpv;  % [kJ/(kg �C)]
Cpv_E = Parameter.E.Cpv;  % [kJ/(kg �C)]
Cpv_F = Parameter.F.Cpv;  % [kJ/(kg �C)]
Cpv_G = Parameter.G.Cpv;  % [kJ/(kg �C)]
Cpv_H = Parameter.H.Cpv;  % [kJ/(kg �C)]
Cpv   = [Cpv_A Cpv_B Cpv_C Cpv_D Cpv_E Cpv_F Cpv_G Cpv_H];

Cpl_A = Parameter.A.Cpl;  % [kJ/(kg �C)]
Cpl_B = Parameter.B.Cpl;  % [kJ/(kg �C)]
Cpl_C = Parameter.C.Cpl;  % [kJ/(kg �C)]
Cpl_D = Parameter.D.Cpl;  % [kJ/(kg �C)]
Cpl_E = Parameter.E.Cpl;  % [kJ/(kg �C)]
Cpl_F = Parameter.F.Cpl;  % [kJ/(kg �C)]
Cpl_G = Parameter.G.Cpl;  % [kJ/(kg �C)]
Cpl_H = Parameter.H.Cpl;  % [kJ/(kg �C)]
Cpl   = [Cpl_A Cpl_B Cpl_C Cpl_D Cpl_E Cpl_F Cpl_G Cpl_H];

MA = Parameter.A.M;  % [kg/kmol]
MB = Parameter.B.M;  % [kg/kmol]
MC = Parameter.C.M;  % [kg/kmol]
MD = Parameter.D.M;  % [kg/kmol]
ME = Parameter.E.M;  % [kg/kmol]
MF = Parameter.F.M;  % [kg/kmol]
MG = Parameter.G.M;  % [kg/kmol]
MH = Parameter.H.M;  % [kg/kmol]

HvapD = Parameter.D.Hvap;   % [kJ/kg]
HvapE = Parameter.E.Hvap;   % [kJ/kg]
HvapF = Parameter.F.Hvap;   % [kJ/kg]
HvapG = Parameter.G.Hvap;   % [kJ/kg]
HvapH = Parameter.H.Hvap;   % [kJ/kg]

c4_A = Parameter.Stream4.c(1);
c4_B = Parameter.Stream4.c(2);
c4_C = Parameter.Stream4.c(3);
c4_D = Parameter.Stream4.c(4);
c4_E = Parameter.Stream4.c(5);
c4_F = Parameter.Stream4.c(6);
c4_G = Parameter.Stream4.c(7);
c4_H = Parameter.Stream4.c(8);
c4 = [c4_A; c4_B; c4_C; c4_D; c4_E; c4_F; c4_G; c4_H];
T4   = Parameter.Stream4.T;

rhoA = Parameter.A.rho; 
rhoB = Parameter.B.rho; 
rhoC = Parameter.C.rho; 
rhoD = Parameter.D.rho; 
rhoE = Parameter.E.rho; 
rhoF = Parameter.F.rho; 
rhoG = Parameter.G.rho; 
rhoH = Parameter.H.rho; 

cQstr = Parameter.cQstr;

R = Parameter.R; % <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  2.- Nomenclature
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% u_str = [Vpstr_sp; m11_sp; msteam_sp; Tsep; Tstr; c10]; 

Vpstr_sp  = u_str(1);
m11_sp    = u_str(2);
msteam_sp = u_str(3);
Tsep      = u_str(4);
Tstr      = u_str(5);
c10       = u_str(6:6+7);

c10_A = c10(1);
c10_B = c10(2);
c10_C = c10(3);
c10_D = c10(4);
c10_E = c10(5);
c10_F = c10(6);
c10_G = c10(7);
c10_H = c10(8);

% c11_G  = c11_G_sp/100;
msteam = msteam_sp;
m11    = m11_sp;

% Vliq_str = (Vpstr_sp*156.5/100+78.24)/35.3145;
Vliq_str = (Vpstr_sp*156.5/100+78.25)/35.3145;

c11_A = 0;
c11_B = 0;
c11_C = 0;
c11_D = 0; %(c10_D*F10 + c4_D*F4 - c5_D*F5)/F11;
c11_E = 0; %(c10_E*F10 + c4_E*F4 - c5_E*F5)/F11;
c11_F = 0; %(c10_F*F10 + c4_F*F4 - c5_F*F5)/F11;

F4  = x_str(1);
F5  = x_str(2);
F10 = x_str(3);
F11 = x_str(4);
% rho_11_temp = x_str(4);

% F5 = 411.2 ;
c5_A = c4_A*F4/F5;
c5_B = c4_B*F4/F5;
c5_C = c4_C*F4/F5;
c5_D = c10_D*F10/F5;
c5_E = c10_E*F10/F5;
c5_F = c10_F*F10/F5;
    f5G = 0; % 0.07; % 0.0746; computed from case base data available in (Downs and Vogel 1993)
    f5H = 0; % 0.04; % 0.0390;
c5_G = c10_G*F10/F5 *f5G;
c5_H = c10_H*F10/F5 *f5H;

c11_G = c10_G*F10/F11   *(1-f5G);
c11_H  = c10_H*F10/F11 *(1-f5H);
c11_H2 = 1 - c11_G;


c5  = [ c5_A;  c5_B;  c5_C;  c5_D;  c5_E;  c5_F;  c5_G;  c5_H];
c11 = [c11_A; c11_B; c11_C; c11_D; c11_E; c11_F; c11_G; c11_H];


Qstr   = cQstr * msteam;
H0Vstr = HvapD*MD*(c5_D*F5 - c4_D*F4) + HvapE*ME*(c5_E*F5 - c4_E*F4) + ...
         HvapF*MF*(c5_F*F5 - c4_F*F4) + HvapG*MG*(c5_G*F5 - c4_G*F4) + ... 
         HvapH*MH*(c5_H*F5 - c4_H*F4);
A = F10*( c10_A*Cpl_A*MA + c10_B*Cpl_B*MB + c10_C*Cpl_C*MC + c10_D*Cpl_D*MD + ...
          c10_E*Cpl_E*ME + c10_F*Cpl_F*MF + c10_G*Cpl_G*MG + c10_H*Cpl_H*MH);
B = F4 *( c4_A*Cpv_A*MA + c4_B*Cpv_B*MB + c4_C*Cpv_C*MC + c4_D*Cpv_D*MD + ...   F4* 
          c4_E*Cpv_E*ME + c4_F*Cpv_F*MF + c4_G*Cpv_G*MG + c4_H*Cpv_H*MH);
Tstr_2 = (A*Tsep + B*T4 - H0Vstr + Qstr)/(A+B); 

% F4_2 = (-A + H0Vstr - Qstr) / B;
%  F4_2


M11    = c11_A*MA + c11_B*MB + c11_C*MC + c11_D*MD + c11_E*ME + c11_F*MF + c11_G*MG + c11_H*MH ;
rho_11 = (c11_G*rhoG*MG + c11_H*rhoH*MH)/M11;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  3.- Model
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eq_str = zeros(4,1);

eq_str(1) = 1 - sum(c5);
eq_str(2) = (c11_H - c11_H2)*100;
eq_str(3) = Tstr_2 - Tstr;
eq_str(4) = (F11 - m11*rho_11 /(c11_D*MD + c11_E*ME + c11_F*MF + c11_G*MG + c11_H*MH));


% eq_str(6) = Tstr - Tstr_sp; % 72.97;
y_str = [F4; F5; F10; F11; Tstr; rho_11; m11; Vliq_str; c5; c11];


end

















