function y_c = Controllers(u_c)
% u_c = [m11_sp; Vpstr_sp; Vpsep_sp; Vpr_sp; Pr_sp; cG11_sp; c_Asp; c_ACsp; Tr_sp; vsteam];
% y_c = [m11; Vpstr; Vpsep; Vpr; Pr; cG11; c_A; c_AC; Tr; msteam; Tstr; F9];

y_c = zeros(12,1); % column vector
y_c(1)  = u_c(1); 
y_c(2)  = 50; 
y_c(3)  = 50; 
y_c(4)  = 65; 
y_c(5)  = 2800; 
y_c(6)  = u_c(2); 
y_c(7)  = u_c(3); 
y_c(8)  = u_c(4); 
y_c(9)  = u_c(5); 
% 
% y_c(10) = 1*230.31/47.446;  % case base: 230.31 kg/h for valve at 47.446%.
% y_c(11) = 65;
% % y_c(12) = 5; % Test_MA2
% % y_c(12) = 6; % Test_MA3
% y_c(12) = 7; % Test_MA4
% y_c(13) = 0.0591; % c6E
% y_c(14) = 2000; % F6 2145
% y_c(15) = 3000; % Pm3.325321882045233e+03

% Test_MA5
y_c(10) = 1*230.31/47.446;  % case base: 230.31 kg/h for valve at 47.446%.
y_c(11) = 65; % Tsrt ()
y_c(12) = 20; % Test_MA4
y_c(13) = 0.0591; % c6E
y_c(14) = 2000; % F6 
y_c(15) = 3000; % Pm3.325321882045233e+03










