function [eq, y, yy, u_c, u_r,  u_MCSSC] = SimTE_2SubSystems(x, u_c, Parameter, Modifiers)
% u_c = [m11_sp; Vpstr_sp; Vpsep_sp; Vpr_sp; Pr_sp; cG11_sp; c_Asp; c_ACsp; Tr_sp; vsteam];
% x = [];

%%     [1]   [2]   [3]   [4]   [5]
% y = [F6_m; F7_m; F8_m; F9_m; F11_m;...
%%     [6-13]  [14-21]  [22-29]  [30-37]
%      c6_m;   c7_m;     c8_m;    c11_m; ...
%%     [38]      [39]      [40]  [41]   [42]     [43]
%      Wcomp_m;  msteam_m; Tr_m; VLr_m; VLsep_m; VLstr_m; ...
%%     [44]  
%      Pr_m];

% m11_sp    = u(1);
% Vpstr_sp  = u(2);
% Vpsep_sp  = u(3);
% Vpr_sp    = u(4);
% Pr_sp     = u(5);
% cG11_sp   = u(6); 
% c_Asp     = u(7); 
% c_ACsp    = u(8);  
% Tr_sp     = u(9);  
% vsteam    = u(10); 

x_MCSSC = x(1:33);
x_r     = x(34:41);

F7_in   = x(42); 
F8_in   = x(43); 
F9_in   = x(44);   % <<<<< remove it
c6_in   = x(45:52);
c8_in   = x(53:60); 

%% ************************************************************************
%  The Model
% *************************************************************************

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  "Controllers Box"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_c = [m11_sp; Vpstr_sp; Vpsep_sp; Vpr_sp; Pr_sp; cG11_sp; c_Asp; c_ACsp; Tr_sp; vsteam];
% y_c = [m11; Vpstr; Vpsep; Vpr; Pr; cG11; c_A; c_AC; Tr; msteam; F6; Tstr];
y_c = Controllers(u_c);
%%% Modifier layer 
if     strcmp(Modifiers.type,'iMAy1')
    y_c = y_c + Modifiers.epsilon_iMAy1_yyk_3 + Modifiers.lambda_iMAy1_yyk_3*(u_c-Modifiers.uk);
elseif strcmp(Modifiers.type,'iCAy1')
    y_c = y_c + Modifiers.epsilon_iMAy1_yyk_3;
elseif strcmp(Modifiers.type,'iMAy2')
    y_c = y_c + Modifiers.epsilon_iMAy2_yyk_3 + Modifiers.lambda_iMAy2_yyk_3*(u_c-Modifiers.uuk_3);
elseif strcmp(Modifiers.type,'iCAy2')
    y_c = y_c + Modifiers.epsilon_iMAy2_yyk_3;
end
m11_m   = y_c(1);    Vpstr_m  = y_c(2);     Vpsep_m = y_c(3);     Vpr_m     = y_c(4);
Pr_m    = y_c(5);    cG11_m   = y_c(6);     c_A_m   = y_c(7);     c_AC_m    = y_c(8); 
Tr_m    = y_c(9);    msteam_m = y_c(10);    F6_m    = y_c(11);    Tstr_m    = y_c(12);
F9_m    = y_c(13);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                               %
                               %
                               %
                             %%%%%
                              %%%
                               %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reactor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_r = [Prsp; Vprsp; Trsp; F7; F6; c6];
% x_r = [c7_A; c7_B; Trsp; F7; c7_C; c7_D; c7_E; c7_F; c7_G, F6];
% y_r = [F6; Pr; Tr; Vvapr; Vliqr; Pir, c7];
% u_r = [Pr_sp; Vpr_sp; Tr_sp; F7_in; F6_in; c6_in];
u_r = [Pr_m; Vpr_m; Tr_m; F7_in;  c6_in];
[eq_r, y_r] = Reactor(x_r, u_r, Parameter);
%%% Modifier layer 
if strcmp(Modifiers.type,'iMAy1')
    y_r = y_r + Modifiers.epsilon_iMAy1_yyk_1 + Modifiers.lambda_iMAy1_yyk_1*(u_c-Modifiers.uk);
elseif strcmp(Modifiers.type,'iCAy1')
    y_r = y_r + Modifiers.epsilon_iMAy1_yyk_1;
elseif strcmp(Modifiers.type,'iMAy2')
    y_r = y_r + Modifiers.epsilon_iMAy2_yyk_1 + Modifiers.lambda_iMAy2_yyk_1*(u_r-Modifiers.uuk_1);
elseif strcmp(Modifiers.type,'iCAy2')
    y_r = y_r + Modifiers.epsilon_iMAy2_yyk_1;
end
if strcmp(Modifiers.type,'iMAy1') || strcmp(Modifiers.type,'iCAy1') || ...
   strcmp(Modifiers.type,'iMAy2') || strcmp(Modifiers.type,'iCAy2')

    SUM = max(0,y_r(3)) + max(0,y_r(4)) + max(0,y_r(5)) + max(0,y_r(6)) + ...
           max(0,y_r(7)) + max(0,y_r(8)) + max(0,y_r(9)) + max(0,y_r(10));  % Sum des y_r
    y_r(3) = max(0,y_r(3))/SUM; 
    y_r(4) = max(0,y_r(4))/SUM; 
    y_r(5) = max(0,y_r(5))/SUM; 
    y_r(6) = max(0,y_r(6))/SUM; 
    y_r(7) = max(0,y_r(7))/SUM; 
    y_r(8) = max(0,y_r(8))/SUM; 
    y_r(9) = max(0,y_r(9))/SUM; 
    y_r(10) = max(0,y_r(10))/SUM; 
end

F6_out_m = y_r(1);   VLr_m = y_r(2);   c7_m = y_r(3:10);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                               %
                               %
                               %
                             %%%%%
                              %%%
                               %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MCSSC (Mixer, Condenser, Separator, Stripper, Compressor)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_MCSSC = [c_Asp; c_ACsp; Vpsep_sp; Vpstr_sp; cG11_sp; m11_sp; msteam_sp; ...
%            F6_in; Pr_in; Tr_in; Tstr_in; F8_in; c7_in; c8_in];
% x_MCSSC = [F5; T8; F10; c5; x_m; x_sep; x_str];
% y_MCSSC = [F7; F8; F9; F11; VLsep; VLstr; m11; msteam; Tstr; Wcomp; c6; c8; c11];
u_MCSSC = [c_A_m; c_AC_m; Vpsep_m; Vpstr_m;  m11_m; msteam_m; ...
           F6_out_m; Pr_m; Tr_m; Tstr_m; F8_in; c7_m; c8_in; F9_m; c6_in(5)];
[eq_MCSSC, y_MCSSC, yy] = MCSSC_OL(x_MCSSC, u_MCSSC, Parameter);
%%% Modifier layer 
if strcmp(Modifiers.type,'iMAy1')
    y_MCSSC = y_MCSSC + Modifiers.epsilon_iMAy1_yyk_2 + Modifiers.lambda_iMAy1_yyk_2*(u_c-Modifiers.uk);
elseif strcmp(Modifiers.type,'iCAy1')
    y_MCSSC = y_MCSSC + Modifiers.epsilon_iMAy1_yyk_2;
elseif strcmp(Modifiers.type,'iMAy2')
    y_MCSSC = y_MCSSC + Modifiers.epsilon_iMAy2_yyk_2 + Modifiers.lambda_iMAy2_yyk_2*(u_MCSSC-Modifiers.uuk_2);
elseif strcmp(Modifiers.type,'iCAy2')
    y_MCSSC = y_MCSSC + Modifiers.epsilon_iMAy2_yyk_2;
end
if strcmp(Modifiers.type,'iMAy1') || strcmp(Modifiers.type,'iCAy1') || ...
   strcmp(Modifiers.type,'iMAy2') || strcmp(Modifiers.type,'iCAy2')

    SUM = max(0,y_MCSSC(11)) + max(0,y_MCSSC(12)) + max(0,y_MCSSC(13)) + max(0,y_MCSSC(14)) + ...
           max(0,y_MCSSC(15)) + max(0,y_MCSSC(16)) + max(0,y_MCSSC(17)) + max(0,y_MCSSC(18));  % Sum des y_r
    y_MCSSC(11) = max(0,y_MCSSC(11))/SUM; 
    y_MCSSC(12) = max(0,y_MCSSC(12))/SUM; 
    y_MCSSC(13) = max(0,y_MCSSC(13))/SUM; 
    y_MCSSC(14) = max(0,y_MCSSC(14))/SUM; 
    y_MCSSC(15) = max(0,y_MCSSC(15))/SUM; 
    y_MCSSC(16) = max(0,y_MCSSC(16))/SUM; 
    y_MCSSC(17) = max(0,y_MCSSC(17))/SUM; 
    y_MCSSC(18) = max(0,y_MCSSC(18))/SUM; 
    
    SUM = max(0,y_MCSSC(19)) + max(0,y_MCSSC(20)) + max(0,y_MCSSC(21)) + max(0,y_MCSSC(22)) + ...
           max(0,y_MCSSC(23)) + max(0,y_MCSSC(24)) + max(0,y_MCSSC(25)) + max(0,y_MCSSC(26));  % Sum des y_r
    y_MCSSC(19) = max(0,y_MCSSC(19))/SUM; 
    y_MCSSC(20) = max(0,y_MCSSC(20))/SUM; 
    y_MCSSC(21) = max(0,y_MCSSC(21))/SUM; 
    y_MCSSC(22) = max(0,y_MCSSC(22))/SUM; 
    y_MCSSC(23) = max(0,y_MCSSC(23))/SUM; 
    y_MCSSC(24) = max(0,y_MCSSC(24))/SUM; 
    y_MCSSC(25) = max(0,y_MCSSC(25))/SUM; 
    y_MCSSC(26) = max(0,y_MCSSC(26))/SUM; 
    
    SUM = max(0,y_MCSSC(27)) + max(0,y_MCSSC(28)) + max(0,y_MCSSC(29)) + max(0,y_MCSSC(30)) + ...
           max(0,y_MCSSC(31)) + max(0,y_MCSSC(32)) + max(0,y_MCSSC(33)) + max(0,y_MCSSC(34));  % Sum des y_r
    y_MCSSC(27) = max(0,y_MCSSC(27))/SUM; 
    y_MCSSC(28) = max(0,y_MCSSC(28))/SUM; 
    y_MCSSC(29) = max(0,y_MCSSC(29))/SUM; 
    y_MCSSC(30) = max(0,y_MCSSC(30))/SUM; 
    y_MCSSC(31) = max(0,y_MCSSC(31))/SUM; 
    y_MCSSC(32) = max(0,y_MCSSC(32))/SUM; 
    y_MCSSC(33) = max(0,y_MCSSC(33))/SUM; 
    y_MCSSC(34) = max(0,y_MCSSC(34))/SUM; 
end

F7_out_m = y_MCSSC(1);   F8_out_m = y_MCSSC(2);   F9_mm    = y_MCSSC(3);
F11_m    = y_MCSSC(4);   VLsep_m  = y_MCSSC(5);   VLstr_m  = y_MCSSC(6);
rho11_m  = y_MCSSC(7);   rho9_m   = y_MCSSC(8);   v9_m     = y_MCSSC(9);
Wcomp_m  = y_MCSSC(10);

c6_out_m = y_MCSSC(11:18);   c8_out_m = y_MCSSC(19:26);   c11_m = y_MCSSC(27:34);

%  y_MCSSC                                                              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%  ***********************************************************************
% Equalities & Outputs of the SS model
% *************************************************************************

eq = zeros(2,1); % eq is a column vector
% Interconnections equalities
eq(1)     = (F7_in - F7_out_m);
eq(2)     = (F8_in - F8_out_m);
eq(3:10)  = (c6_in - c6_out_m);
eq(11:18) = (c8_in - c8_out_m);
eq(19)    = (F6_out_m - F6_m);
eq(20)    = F9_in-0; % <<<< suprime
% SS equalities
eq = [eq; eq_r; eq_MCSSC]; % ; c11_m(7) - cG11_m/100

y = [F6_m; F7_out_m; F8_out_m; F9_m; F11_m;...
     c6_out_m; c7_m; c8_out_m; c11_m; ...
     Wcomp_m;  msteam_m; Tr_m; VLr_m; VLsep_m; VLstr_m; ...
     Pr_m; Tstr_m; m11_m; rho11_m; Vpr_m; Vpsep_m; Vpstr_m; ...
     rho9_m; v9_m];

if strcmp(Modifiers.type,'MAy')
    y = y + Modifiers.epsilon_yk + Modifiers.lambda_yk*(u_c-Modifiers.uk);
elseif strcmp(Modifiers.type,'CAy')
    y = y + Modifiers.epsilon_yk;
end

end


