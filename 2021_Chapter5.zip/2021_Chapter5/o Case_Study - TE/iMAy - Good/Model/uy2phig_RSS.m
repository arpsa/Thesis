function [phi1, phi2, g, geq] = uy2phig_RSS(u_RSS,y_RSS, mode, Parameter, Modifiers)


VLsep = y_RSS(7); %
VLstr = y_RSS(8);
Vliqr = y_RSS(9);%
rho11 = y_RSS(10);%
rho9  = y_RSS(11);%
scm9  = y_RSS(12);
Wcomp = y_RSS(13);%
c8    = y_RSS(22:29);
c11   = y_RSS(30:37); %

m11_m    = u_RSS(1);  
Pr_m     = u_RSS(5);  
Tr_m     = u_RSS(6);   
msteam_m = u_RSS(7);   


C_comp  = Wcomp*0.0536;
C_steam = msteam_m*0.0318;

MA = Parameter.A.M;
MB = Parameter.B.M;
MC = Parameter.C.M;
MD = Parameter.D.M;
ME = Parameter.E.M;
MF = Parameter.F.M;
MG = Parameter.G.M;
MH = Parameter.H.M;

M9  = c8(1)*MA + c8(2)*MB + c8(3)*MC + c8(4)*MD + c8(5)*ME + c8(6)*MF + c8(7)*MG + c8(8)*MH; 
M11 = c11(1)*MA + c11(2)*MB + c11(3)*MC + c11(4)*MD + c11(5)*ME + c11(6)*MF + c11(7)*MG + c11(8)*MH; 

C_purge = scm9*rho9/M9    * (2.206*c8(1) + 6.177*c8(3) + 22.06*c8(4) + 14.56*c8(5) +  17.89*c8(6) + 30.44*c8(7) + 22.94*c8(8));
C_prod  = m11_m*rho11/M11 * (22.06*c11(4) + 14.56*c11(5) +  17.89*c11(6));

phi1 = C_comp + C_steam + C_purge + C_prod;
phi2 = m11_m*rho11/M11*(c11(7)*62 + c11(8)*76);

g = [Pr_m-2895;
     Tr_m-150;
     Vliqr-21.3; 
     11.8-Vliqr; 
     VLsep-9; 
     3.3-VLsep;
     VLstr-6.6; 
     3.35-VLstr];

if mode == 1 || mode == 4
    geq = c11(7)*62/(c11(8)*76) - 50/50;
    if mode == 1
        geq = [geq; (m11_m*rho11/M11*(c11(7)*62 + c11(8)*76)-14076)*1e-5];
    end
elseif mode == 2 || mode == 5
    geq = c11(7)*62/(c11(8)*76) - 10/90;
    if mode == 2
        geq = [geq; (m11_m*rho11/M11*(c11(7)*62 + c11(8)*76)-14076)*1e-5];
    end
else
    geq = c11(7)*62/(c11(8)*76) - 90/10;
    if mode == 3
        geq = [geq; (m11_m*rho11/M11*(c11(7)*62 + c11(8)*76)-11111)*1e-5];
    end
end

if strcmp(Modifiers.type,'iMA')

    phi1 = phi1 + Modifiers.epsilon_iMA_phi1k + Modifiers.lambda_iMA_phi1k*(u_RSS-Modifiers.uuk_2);
    phi2 = phi2 + Modifiers.epsilon_iMA_phi2k + Modifiers.lambda_iMA_phi2k*(u_RSS-Modifiers.uuk_2);

    g    = g    + Modifiers.epsilon_iMA_gk    + Modifiers.lambda_iMA_gk    *(u_RSS-Modifiers.uuk_2);
    geq  = geq  + Modifiers.epsilon_iMA_geqk  + Modifiers.lambda_iMA_geqk  *(u_RSS-Modifiers.uuk_2);
end



