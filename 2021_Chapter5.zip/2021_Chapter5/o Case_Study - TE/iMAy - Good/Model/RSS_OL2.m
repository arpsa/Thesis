function [eq, y_RSS] = RSS_OL2(x_RSS, u_RSS, Parameter)
% u = [m11; Vpstr; Vpsep; Vpr; Pr; Tr; msteam; Tstr; F9; F8; Pm; c6; Tsep];     
% x = [x_r; x_sep; x_str; F7_temp; F10_temp];
% y = [F5; F6; F11; T8; Tsep; Psep; VLsep; VLstr; Vliqr; rho11; rho9; v9;
%      Wcomp; c5; c8; c11];


x_r   = x_RSS(1:8);
x_sep = x_RSS(9:18);
x_str = x_RSS(19:22);

F7_temp  = x_RSS(23);
F10_temp = x_RSS(24);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  "Controllers Box"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_c = [m11_sp; Vpstr_sp; Vpsep_sp; Vpr_sp; Pr_sp; cG11_sp; c_Asp; c_ACsp; Tr_sp; vsteam];
% y_c = [m11; Vpstr; Vpsep; Vpr; Pr; cG11; c_A; c_AC; Tr; msteam; F6; Tstr];
m11_m    = u_RSS(1);    
Vpstr_m  = u_RSS(2);     
Vpsep_m  = u_RSS(3);     
Vpr_m    = u_RSS(4);
Pr_m     = u_RSS(5);  
Tr_m     = u_RSS(6);   
msteam_m = u_RSS(7);   
Tstr_m   = u_RSS(8);
F9_m     = u_RSS(9);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mixer
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_m = [c_Asp; c_ACsp; F5; F6; Pr; T8; Tstr; c5; c8];
% x_m = [c6_B; c6_D; c6_E; c6_F; c6_G; F1; F2; F3; F8];
% y_m = [F1; F2; F3; F8; Tm; Pm; c6];
F8_m = u_RSS(10); 
Pm_m = u_RSS(11);
c6_m = u_RSS(12:19);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                               %
                               %
                               %
                             %%%%%
                              %%%
                               %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reactor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_r = [Prsp; Vprsp; Trsp; F7; F6; c6];
% x_r = [c7_A; c7_B; Trsp; F7; c7_C; c7_D; c7_E; c7_F; c7_G, F6];
% y_r = [F6; Vliqr; c7];
u_r = [Pr_m; Vpr_m; Tr_m; F7_temp;  c6_m];
[eq_r, y_r] = Reactor(x_r, u_r, Parameter);

F6 = y_r(1);  Vliqr = y_r(2); c7 = y_r(3:10);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                               %
                               %
                               %
                             %%%%%
                              %%%
                               %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Condensor & Separator & Compressor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_sep = [F8; F10; Tr; Tm; Pm; Pr; Vpsep_sp; c7]; 
% x_sep = [c8_A; c8_B; c8_C; c8_D; c8_E; c8_F; c8_G; Ps; F9; Tsep];
% y_sep = [F7; F9; T8; Ts; Wcomp; Vliq_s; rho9; Ps; PvapD; PvapE; PvapF; PvapG; PvapH; c8; c9; c10];
u_sep = [F8_m; F10_temp; Pm_m; Pr_m; Vpsep_m; c7]; 
[eq_sep, y_sep] = SeparatorCompressor(x_sep, u_sep, Parameter);
F7     = y_sep(1);
F9     = y_sep(2);
T8     = y_sep(3);
Tsep   = y_sep(4);
Wcomp  = y_sep(5);
VLsep  = y_sep(6);
rho9   = y_sep(7);
Psep   = y_sep(8);
c8     = y_sep(14:21);
c9     = c8;
c10    = y_sep(22:29);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                               %
                               %
                               %
                             %%%%%
                              %%%
                               %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Stripper
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Tsep_in = u_RSS(20);
% u_str = [Vpstr_sp; m11_sp; msteam_sp; Tsep; Tstr; c10]; 
% x_str = [F4; F5; F10; F11];
% y_str = [F4; F5; F10; F11; Tstr; rho_11; m11; msteam; Vliq_str; c5; c11];


u_str = [Vpstr_m; m11_m; msteam_m; Tsep_in; Tstr_m; c10];
[eq_str, y_str] = Stripper(x_str, u_str, Parameter);
F4    = y_str(1); 
F5    = y_str(2); 
F10   = y_str(3); 
F11   = y_str(4); 
rho11 = y_str(6); 
m11   = y_str(7);  
VLstr = y_str(8); 
c5    = y_str(9:16); 
c11   = y_str(17:24);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

MA = Parameter.A.M;
MB = Parameter.B.M;
MC = Parameter.C.M;
MD = Parameter.D.M;
ME = Parameter.E.M;
MF = Parameter.F.M;
MG = Parameter.G.M;
MH = Parameter.H.M;


M9 = c9(1)*MA + c9(2)*MB + c9(3)*MC + c9(4)*MD + c9(5)*ME + c9(6)*MF + c9(7)*MG + c9(8)*MH; 
v9  = F9*M9/rho9;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eq = zeros(3,1);
eq(1) = F7  - F7_temp;
eq(2) = F10 - F10_temp;
eq(3) = F9  - F9_m;
eq = [eq; eq_r; eq_sep; eq_str];


y_RSS = zeros(37,1);
y_RSS(1)  = F5; %
y_RSS(2)  = F6; %
y_RSS(3)  = F11;  %
y_RSS(4)  = T8; %
y_RSS(5)  = Tsep;
y_RSS(6)  = Psep; %
y_RSS(7)  = VLsep; %
y_RSS(8)  = VLstr;
y_RSS(9) = Vliqr;%
y_RSS(10) = rho11;%
    y_RSS(11) = rho9;%
    y_RSS(12) = v9;
y_RSS(13)     = Wcomp;%
y_RSS(14:21)  = c5; %
y_RSS(22:29)  = c8; %
y_RSS(30:37)  = c11; %

