function [eq_r, y_r] = Reactor(x_r, u_r, Parameter)
% u_r = [Prsp; lrsp; Trsp; F7; F6; c6];
% x_r = [c7_A; c7_B; c7_C; c7_D; c7_E; c7_F; c7_G];
% y_r = [F6; Pr; Tr; Vvapr; Vliqr; lr; c7];


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Parameters
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a1  = Parameter.a1;
a2  = Parameter.a2;
a3  = Parameter.a3;
a4  = Parameter.a4;
a5  = Parameter.a5;
a6  = Parameter.a6;
a7  = Parameter.a7;
a8  = Parameter.a8;
a9  = Parameter.a9;
a10 = Parameter.a10;

k1 = Parameter.k1;
k2 = Parameter.k2;
k3 = Parameter.k3;
% k4 = Parameter.k4;

E1 = Parameter.E1;
E2 = Parameter.E2;
E3 = Parameter.E3;
% E4 = Parameter.E4;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  2.- Nomenclature
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Prsp  = u_r(1);
Vprsp = u_r(2);
Trsp  = u_r(3);
F7    = u_r(4);
c6    = u_r(5:5+7);

Tr    = Trsp;
Pr    = Prsp;
Vliqr = (Vprsp*666.7/100+84.6)/35.3145;
Vvapr = 36.8 - Vliqr;

c7_A = x_r(1);
c7_B = x_r(2);
c7_C = x_r(3);
c7_D = x_r(4);
c7_E = x_r(5);
c7_F = x_r(6);
c7_G = x_r(7);
c7_H = 1 - (c7_A + c7_B + c7_C + c7_D + c7_E + c7_F + c7_G);
c7   = [c7_A; c7_B; c7_C; c7_D; c7_E; c7_F; c7_G; c7_H];

F6 = x_r(8);
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  3.- Model
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PAr = Pr*c7_A;
PBr = Pr*c7_B;
PCr = Pr*c7_C;
PDr = Pr*c7_D;
PEr = Pr*c7_E;
PFr = Pr*c7_F;
PGr = Pr*c7_G;
PHr = Pr*c7_H;
Pir = [PAr; PBr; PCr; PDr; PEr; PFr; PGr; PHr];

R1 = exp(k1-E1/(1.987*(Tr+273.15))) * Vvapr * PAr^(a1)*PCr^(a2)*PDr^(a3);
R2 = exp(k2-E2/(1.987*(Tr+273.15))) * Vvapr * PAr^(a4)*PCr^(a5)*PEr^(a6);
R3 = exp(k3-E3/(1.987*(Tr+273.15))) * Vvapr * PAr^(a7)*(PEr^(a8) + 0.77*PDr^(a10)); 
% R4 = exp(k4-E4/(1.987*(Tr+273.15))) * Vvapr * PAr^(a9)*PDr^(a10);

eq_r = zeros(8,1);
% eq_r(1) = c6(1)*F6 - c7_A*F7 - R1 - R2 - R3;
% eq_r(2) = c6(2)*F6 - c7_B*F7;
% eq_r(3) = c6(3)*F6 - c7_C*F7 - R1 - R2;
% eq_r(4) = c6(4)*F6 - c7_D*F7 - R1 - 1.5*R4;
% eq_r(5) = c6(5)*F6 - c7_E*F7 - R2 - R3;
% eq_r(6) = c6(6)*F6 - c7_F*F7 + R3 + R4;
% eq_r(7) = c6(7)*F6 - c7_G*F7 + R1;
% eq_r(8) = c6(8)*F6 - c7_H*F7 + R2;
eq_r(1) = c6(1)*F6 - c7_A*F7 - R1 - R2 - 1/3*R3;
eq_r(2) = c6(2)*F6 - c7_B*F7;
eq_r(3) = c6(3)*F6 - c7_C*F7 - R1 - R2;
eq_r(4) = c6(4)*F6 - c7_D*F7 - R1 - R3;
eq_r(5) = c6(5)*F6 - c7_E*F7 - R2 - 1/3*R3;
eq_r(6) = c6(6)*F6 - c7_F*F7 + R3;
eq_r(7) = c6(7)*F6 - c7_G*F7 + R1;
eq_r(8) = c6(8)*F6 - c7_H*F7 + R2;
% 
% eq_r(9) = min([0, c7_H]);

% Vvap et Pir ont ete supprime
y_r  = [F6; Vliqr; c7];

end

















