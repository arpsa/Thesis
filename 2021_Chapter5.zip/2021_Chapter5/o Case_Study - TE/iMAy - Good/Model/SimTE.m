function [eq, y, eq2] = SimTE(x, u, Parameter)
% u = []; 
% x = [];
% y = [];

m11_sp   = u(1);
Vpstr_sp = u(2);
Vpsep_sp = u(3);
Vpr_sp   = u(4);
Pr_sp    = u(5);
c_Asp    = u(6);
c_ACsp   = u(7);
Tr_sp    = u(8);
msteam   = u(9);
cG11_sp  = u(10);


Tstr  = 65.731; % [C]
F6_sp = 1950;

c5_A = x(1); c5_B = x(2); c5_C = x(3); c5_D = x(4); c5_E = x(5);
c5_F = x(6); c5_G = x(7); 
c5_H = 1- (c5_A+ c5_B+ c5_C+ c5_D+ c5_E+ c5_F+ c5_G);
c5 = [c5_A; c5_B; c5_C; c5_D; c5_E; c5_F; c5_G; c5_H];

c8_A = x(8); c8_B = x(9); c8_C = x(10); c8_D = x(11); c8_E = x(12);
c8_F = x(13); c8_G = x(14); 
c8_H =  1- (c8_A+ c8_B+ c8_C+ c8_D+ c8_E+ c8_F+ c8_G);
c8 = [c8_A; c8_B; c8_C; c8_D; c8_E; c8_F; c8_G; c8_H];

F5   = x(15);
% F6   = x(16);
F7   = x(16);
% F8   = x(18);  % <<<<<<<<<<<
F10  = x(17);
T8   = x(18);


x_m   = x(19:27);
x_r   = x(28:34);
x_sep = x(35:44);
x_str = x(45:48);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mixer
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_m = [c_Asp; c_ACsp; F5; F6; Pr; T8; Tstr; c5; c8];
% x_m = [c6_B; c6_D; c6_E; c6_F; c6_G; F1; F2; F3; F8];
% y_m = [F1; F2; F3; F8; Tm; Pm; c6];
u_m = [c_Asp; c_ACsp; F5; F6_sp; Pr_sp; T8; Tstr; c5; c8];
[eq_m, y_m] = Mixer(x_m, u_m, Parameter);

F1 = y_m(1); F2 = y_m(2); F3 = y_m(3); F8 = y_m(4); Tm = y_m(5); Pm = y_m(6);
c6 = y_m(7:7+7);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                               %
                               %
                               %
                             %%%%%
                              %%%
                               %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reactor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_r = [Prsp; Vprsp; Trsp; F7; c6];
% x_r = [c7_A; c7_B; Trsp; F7; c7_C; c7_D; c7_E; c7_F; c7_G, F6];
% y_r = [F6; Pr; Tr; Vvapr; Vliqr; Pir, c7];
F6 = 1950;
u_r = [Pr_sp; Vpr_sp; Tr_sp; F7; F6; c6];
[eq_r, y_r] = Reactor(x_r, u_r, Parameter);

F6_2 = y_r(1); Pr = y_r(2); Tr = y_r(3); VLr = y_r(4);
c7 = y_r(5:12);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                               %
                               %
                               %
                             %%%%%
                              %%%
                               %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Condensor & Separator & Compressor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_sep = [F8; F10; Tr; Tm; Pm; Pr; Vpsep_sp; c7]; 
% x_sep = [c8_A; c8_B; c8_C; c8_D; c8_E; c8_F; c8_G; Ps; F9; Tsep];
% y_sep = [F7; F8; F9; T8; Ts; Wcomp; Vliq_s; rho9; Ps; PvapD; PvapE; PvapF; PvapG; PvapH; c8; c9; c10];
u_sep = [F8; F10; Tr; Tm; Pm; Pr; Vpsep_sp; c7]; 
[eq_sep, y_sep] = SeparatorCompressor(x_sep, u_sep, Parameter);
F7_2   = y_sep(1);
% F8_2   = y_sep(2);
F9     = y_sep(3);
T8_2   = y_sep(4);
Tsep   = y_sep(5);
Wcomp  = y_sep(6);
VLsep = y_sep(7);
rho9   = y_sep(8);
Psep   = y_sep(9);
c8_2   = y_sep(15:15+7);
c9     = y_sep(23:23+7);
c10    = y_sep(31:31+7);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                               %
                               %
                               %
                             %%%%%
                              %%%
                               %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Stripper
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_str = [Vpstr_sp; m11_sp; msteam_sp; Tsep; Tstr; c10]; 
% x_str = [F4; F5; F10; F11];
% y_str = [F4; F5; F10; F11; Tstr; rho_11; m11; msteam; Vliq_str; c5; c11];
u_str = [Vpstr_sp; m11_sp; msteam; Tsep; Tstr; c10]; 
[eq_str, y_str] = Stripper(x_str, u_str, Parameter);
F4       = y_str(1); 
F5_2     = y_str(2); 
F10_2    = y_str(3); 
F11      = y_str(4); 
% Tstr     = y_str(5); 
rho11    = y_str(6); 
m11      = y_str(7); 
% msteam   = y_str(8); 
VLstr    = y_str(9); 
c5_2     = y_str(10:10+7); 
c11      = y_str(18:18+7); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%     1-8       9-16     17       18       19          21        22     23-30 31-38  39-47  47-52     

eq = [c5-c5_2; c8-c8_2; F5-F5_2; F6_sp-F6_2; F7-F7_2;  F10-F10_2; T8-T8_2; eq_m; eq_r; eq_sep; eq_str; c11(7) - cG11_sp/100];
% eq = [c5-c5_2; c8-c8_2; F5-F5_2; F6-F6_2; F7-F7_2;  F10-F10_2; T8-T8_2; eq_m; eq_r; eq_sep; eq_str;  F1-11.03 ];F1-11.03;


%     1   2   3   4   5   6   7   8   9   10   11    
% y = [F1; F2; F3; F4; F5; F6; F7; F8; F9; F10; F11; ...
% ... 12-19  20-27  28- 35  36-43  44-51  52-59  60-67
%     c5;    c6;     c7;    c8;    c9;    c10;   c11;...
% ... 68      69      70  71  72   73     74     75
%     Wcomp;  msteam; Pr; Tr; VLr; VLsep; VLstr; c11_G_kg;...
% ... 76  77    78
%     Pr; Psep; Pm];

y = [F1; F2; F3; F4; F5; F6_sp; F7; F8; F9; F10; F11;...
     c5; c6; c7; c8; c9; c10; c11; ...
     Wcomp;  msteam; Pr; Tr; VLr; VLsep; VLstr; 0; ...
     Pr; Psep; Pm];

% eq2 = c5-c5_2; % ok
% eq2 = c8-c8_2; % ok
% eq2 = [F5-F5_2; F6-F6_2; F7-F7_2; F10-F10_2; T8-T8_2]; % ok
eq2 = eq_str; 

end


