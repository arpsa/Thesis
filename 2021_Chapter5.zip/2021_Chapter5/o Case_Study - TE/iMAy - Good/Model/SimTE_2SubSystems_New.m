function [eq, y_mmm, y_c, y_RSS, y_m, u_TE, u_RSS, u_m, y, y_RSSn] = SimTE_2SubSystems_New(x_TEs, u_TE, Parameter, Modifiers,Derivatives_P, lb_TE, ub_TE)
% u_c = [m11_sp; Vpstr_sp; Vpsep_sp; Vpr_sp; Pr_sp; cG11_sp; c_Asp; c_ACsp; Tr_sp; vsteam];
% x = [];

x_TE = (x_TEs).*(ub_TE'-lb_TE') + lb_TE';
       

x_RSS = x_TE(1:24);
x_m   = x_TE(25:33);

F8_temp   = x_TE(34);
Pm_temp   = x_TE(35);
Tsep_temp = x_TE(36);
c6_temp   = x_TE(37:44);
F9_inin   = x_TE(45);
%% ************************************************************************
%  The Model
% *************************************************************************

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  "Controllers Box"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_c = [m11_sp; Vpstr_sp; Vpsep_sp; Vpr_sp; Pr_sp; cG11_sp; c_Asp; c_ACsp; Tr_sp; vsteam];
% y_c = [m11; Vpstr; Vpsep; Vpr; Pr; cG11; c_A; c_AC; Tr; msteam; F6; Tstr];
y_c = Controllers(u_TE);
m11 = y_c(1);    Vpstr  = y_c(2);     Vpsep = y_c(3);     Vpr  = y_c(4);
Pr  = y_c(5);    cG11   = y_c(6);     c_A   = y_c(7);     c_AC = y_c(8); 
Tr  = y_c(9);    msteam = y_c(10);    Tstr  = y_c(11);    F9   = y_c(12);
c6E = y_c(13);   Pm_2 = y_c(15);
%%% Modifier layer 
if     strcmp(Modifiers.type,'iMAy1')
    y_c = y_c + Modifiers.epsilon_iMAy1_yyk_1 + Modifiers.lambda_iMAy1_yyk_1*(u_TE-Modifiers.uk);
elseif strcmp(Modifiers.type,'iCAy1')
    y_c = y_c + Modifiers.epsilon_iMAy1_yyk_1;
elseif strcmp(Modifiers.type,'iMAy2')
    y_c = y_c + Modifiers.epsilon_iMAy2_yyk_1 + Modifiers.lambda_iMAy2_yyk_1*(u_TE-Modifiers.uuk_1);
elseif strcmp(Modifiers.type,'iCAy2')
    y_c = y_c + Modifiers.epsilon_iMAy2_yyk_1;
elseif strcmp(Modifiers.type,'iMA1')
    y_c = y_c + Modifiers.epsilon_iMA1_yyk_1 + Modifiers.lambda_iMA1_yyk_1*(u_TE-Modifiers.uk);
elseif strcmp(Modifiers.type,'iMA2')
    y_c = y_c + Modifiers.epsilon_iMA2_yyk_1 + Modifiers.lambda_iMA2_yyk_1*(u_TE-Modifiers.uuk_1);
end
m11_m = y_c(1);    Vpstr_m  = y_c(2);     Vpsep_m = y_c(3);     Vpr_m  = y_c(4);
Pr_m  = y_c(5);    cG11_m   = y_c(6);     c_A_m   = y_c(7);     c_AC_m = y_c(8); 
Tr_m  = y_c(9);    msteam_m = y_c(10);    Tstr_m  = y_c(11);    F9_m   = y_c(12);
c6E_m = y_c(13);   F6_m_2 = y_c(14);      Pm_m_2 = y_c(15);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                               %
                               %
                               %
                             %%%%%
                              %%%
                               %
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RSS (Reactor, Separator, Stripper)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u = [m11; Vpstr; Vpsep; Vpr; Pr; Tr; msteam; Tstr; F9; F8; Pm; c6; Tsep];     
% x = [x_r; x_sep; x_str; F7_temp; F10_temp];
% y = [];    
% if strcmp(Modifiers.type,'iMAy2') || strcmp(Modifiers.type,'iCAy2') || strcmp(Modifiers.type,'iMA')
u_RSS = [m11_m; Vpstr_m; Vpsep_m; Vpr_m; Pr_m; Tr_m; msteam_m; Tstr_m; ...
         F9_m; F8_temp; Pm_m_2; c6_temp; Tsep_temp];  
% else
% u_RSS = [m11_m; Vpstr_m; Vpsep_m; Vpr_m; Pr_m; Tr_m; msteam_m; Tstr_m; ...
%          F9_m; F8_temp; Pm_temp; c6_temp; Tsep_temp];   
% end
% u_RSS = Derivatives_P.uuk_2;
[eq_RSS, y_RSS] = RSS_OL(x_RSS, u_RSS, Parameter);
F5    = y_RSS(1);    F6    = y_RSS(2);    F11   = y_RSS(3);    T8    = y_RSS(4) ;   
Tsep  = y_RSS(5);    Psep  = y_RSS(6);    VLsep = y_RSS(7);    VLstr = y_RSS(8);    
VLr   = y_RSS(9);    rho11 = y_RSS(10);   rho9  = y_RSS(11);   scm9    = y_RSS(12);   
Wcomp = y_RSS(13); 
c5 = y_RSS(14:21);    c8 = y_RSS(22:29);    c11 = y_RSS(30:37);  
y_RSSn = y_RSS;
% Modifiers layer
if strcmp(Modifiers.type,'iMAy1')
    y_RSS = y_RSS + Modifiers.epsilon_iMAy1_yyk_2 + Modifiers.lambda_iMAy1_yyk_2*(u_TE-Modifiers.uk);
elseif strcmp(Modifiers.type,'iCAy1')
    y_RSS = y_RSS + Modifiers.epsilon_iMAy1_yyk_2;
elseif strcmp(Modifiers.type,'iMAy2')
    y_RSS = y_RSS + Modifiers.epsilon_iMAy2_yyk_2 + Modifiers.lambda_iMAy2_yyk_2*(u_RSS-Modifiers.uuk_2);
elseif strcmp(Modifiers.type,'iCAy2')
    y_RSS = y_RSS + Modifiers.epsilon_iMAy2_yyk_2;
elseif strcmp(Modifiers.type,'iMA1')
    y_RSS = y_RSS + Modifiers.epsilon_iMA1_yyk_2 + Modifiers.lambda_iMA1_yyk_2*(u_TE-Modifiers.uk);
elseif strcmp(Modifiers.type,'iMA2')
    y_RSS = y_RSS + Modifiers.epsilon_iMA2_yyk_2 + Modifiers.lambda_iMA2_yyk_2*(u_RSS-Modifiers.uuk_2);
end  
if strcmp(Modifiers.type,'iMAy1') || strcmp(Modifiers.type,'iCAy1') || ...
   strcmp(Modifiers.type,'iMAy2') || strcmp(Modifiers.type,'iCAy2') || ...
   strcmp(Modifiers.type,'iMA1') || strcmp(Modifiers.type,'iMA2')
            SUM = y_RSS(14) + y_RSS(15) + y_RSS(16) + y_RSS(17) + ...
                  y_RSS(18) + y_RSS(19) + y_RSS(20) + y_RSS(21); 
            y_RSS(14) = y_RSS(14)/SUM; 
            y_RSS(15) = y_RSS(15)/SUM; 
            y_RSS(16) = y_RSS(16)/SUM; 
            y_RSS(17) = y_RSS(17)/SUM; 
            y_RSS(18) = y_RSS(18)/SUM; 
            y_RSS(19) = y_RSS(19)/SUM; 
            y_RSS(20) = y_RSS(20)/SUM; 
            y_RSS(21) = y_RSS(21)/SUM;  
            SUM = y_RSS(22) + y_RSS(23) + y_RSS(24) + y_RSS(25) + ...
                  y_RSS(26) + y_RSS(27) + y_RSS(28) + y_RSS(29); 
            y_RSS(22) = y_RSS(22)/SUM; 
            y_RSS(23) = y_RSS(23)/SUM; 
            y_RSS(24) = y_RSS(24)/SUM; 
            y_RSS(25) = y_RSS(25)/SUM; 
            y_RSS(26) = y_RSS(26)/SUM; 
            y_RSS(27) = y_RSS(27)/SUM; 
            y_RSS(28) = y_RSS(28)/SUM; 
            y_RSS(29) = y_RSS(29)/SUM; 
            SUM = y_RSS(30) + y_RSS(31) + y_RSS(32) + y_RSS(33) + ...
                  y_RSS(34) + y_RSS(35) + y_RSS(36) + y_RSS(37) ;  
            y_RSS(30) = y_RSS(30)/SUM; 
            y_RSS(31) = y_RSS(31)/SUM; 
            y_RSS(32) = y_RSS(32)/SUM; 
            y_RSS(33) = y_RSS(33)/SUM; 
            y_RSS(34) = y_RSS(34)/SUM; 
            y_RSS(35) = y_RSS(35)/SUM; 
            y_RSS(36) = y_RSS(36)/SUM; 
            y_RSS(37) = y_RSS(37)/SUM;  
end      

F5_m    = y_RSS(1);    F6_m    = y_RSS(2);    F11_m   = y_RSS(3);    T8_m    = y_RSS(4) ;   
Tsep_m  = y_RSS(5);    Psep_m  = y_RSS(6);    VLsep_m = y_RSS(7);    VLstr_m = y_RSS(8);    
VLr_m   = y_RSS(9);    rho11_m = y_RSS(10);   rho9_m  = y_RSS(11);   scm9_m    = y_RSS(12);   
Wcomp_m = y_RSS(13); 

c5_m = y_RSS(14:21);    c8_m = y_RSS(22:29);    c11_m = y_RSS(30:37);  


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mixer
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% u_m = [c_Asp; c_ACsp; F5; F6; Pr; T8; Tstr; c5; c8; c6_D];
% x_m = [c6_B; c6_D; c6_E; c6_F; c6_G; F1; F2; F3; F8];
% y_m = [F1; F2; F3; F8; Tm; Pm; c6];
u_m = [c_A_m; c_AC_m; F5_m; F6_m; Pr_m; T8_m; Tstr_m; c5_m; c8_m; c6_temp(5)];
% u_m = Derivatives_P.uuk_3;
[eq_m, y_m, F1,F2,F3] = Mixer(x_m, u_m, Parameter);
% c6_m = y_m(4:11); F8_m = y_m(1); 
c6 = y_m(4:11); F8 = y_m(1);
Tm = y_m(2);  Pm = y_m(3); 
% Modifiers layer

if strcmp(Modifiers.type,'iMAy1')
    y_m = y_m + Modifiers.epsilon_iMAy1_yyk_3 + Modifiers.lambda_iMAy1_yyk_3*(u_TE-Modifiers.uk);
elseif strcmp(Modifiers.type,'iCAy1')
    y_m = y_m + Modifiers.epsilon_iMAy1_yyk_3;
elseif strcmp(Modifiers.type,'iMAy2')
    y_m = y_m + Modifiers.epsilon_iMAy2_yyk_3 + Modifiers.lambda_iMAy2_yyk_3*(u_m-Modifiers.uuk_3);
elseif strcmp(Modifiers.type,'iCAy2')
    y_m = y_m + Modifiers.epsilon_iMAy2_yyk_3;
elseif strcmp(Modifiers.type,'iMA1')
    y_m = y_m + Modifiers.epsilon_iMA1_yyk_3 + Modifiers.lambda_iMA1_yyk_3*(u_TE-Modifiers.uk);
elseif strcmp(Modifiers.type,'iMA2')
    y_m = y_m + Modifiers.epsilon_iMA2_yyk_3 + Modifiers.lambda_iMA2_yyk_3*(u_m-Modifiers.uuk_3);
end  
if strcmp(Modifiers.type,'iMAy1') || strcmp(Modifiers.type,'iCAy1') || ...
   strcmp(Modifiers.type,'iMAy2') || strcmp(Modifiers.type,'iCAy2') || ...
   strcmp(Modifiers.type,'iMA1') || strcmp(Modifiers.type,'iMA2') 
   
    SUM = y_m(4) + y_m(5) + y_m(6) + y_m(7) + ...
          y_m(8) + y_m(9) + y_m(10) + y_m(11);  % Sum des y_m
    y_m(4) = y_m(4)/SUM; 
    y_m(5) = y_m(5)/SUM; 
    y_m(6) = y_m(6)/SUM; 
    y_m(7) = y_m(7)/SUM; 
    y_m(8) = y_m(8)/SUM; 
    y_m(9) = y_m(9)/SUM; 
    y_m(10) = y_m(10)/SUM; 
    y_m(11) = y_m(11)/SUM; 
end
Tm_m = y_m(2);  Pm_m = y_m(3);
c6_m = y_m(4:11); F8_m = y_m(1);

%%  ***********************************************************************
% Equalities & Outputs of the SS model
% *************************************************************************

eq = zeros(2,1); % eq is a column vector ; c11_m(7) - cG11/100
eq(1)    = (F8_temp   - F8_m)*100;
eq(2)    = (Pm_temp   - Pm_m)*100;
eq(3)    = (Tsep_temp - Tsep_m)*100;
eq(4:11) = (c6_temp - c6_m)*100;
eq(12) = F9_inin - 10;
eq(13) = sum(c6_temp) - 1;
eq(14) = (F6_m_2 - F6_m)*100;

eq = [eq; eq_m; eq_RSS; 0; 0]; 

y_mmm = [F5_m;  F6_m;  F8_m; F9_m; F11_m;...
     c5_m; c6_m;  c8_m; c11_m; ...
     Wcomp_m;  msteam_m; Tr_m; VLr_m; VLsep_m; VLstr_m; ...
     Pr_m; Psep_m; Tstr_m; m11_m; rho11_m; Vpr_m; Vpsep_m; Vpstr_m; ...
     rho9_m; scm9_m; Tsep_m; 0; Pm_m; F1; F2; F3];

y = [F5;  F6;  F8; F9; F11;...
     c5; c6;  c8; c11; ...
     Wcomp;  msteam; Tr; VLr; VLsep; VLstr; ...
     Pr; Psep; Tstr; m11; rho11; Vpr; Vpsep; Vpstr; ...
     rho9; scm9; Tsep; 0; Pm; F1; F2; F3]; 
 
if strcmp(Modifiers.type,'MAy')
    y = y + Modifiers.epsilon_yk + Modifiers.lambda_yk*(u_TE-Modifiers.uk);
elseif strcmp(Modifiers.type,'CAy')
    y = y + Modifiers.epsilon_yk;
end

end


