function [eq_m, y_m, F1, F2, F3] = Mixer(x_m, u_m, Parameter)
% u_m = [c_Asp; c_ACsp; F5; F6; Pr; T8; Tstr; c5; c8];
% x_m = [c6_B; c6_D; c6_E; c6_F; c6_G; F1; F2; F3; F8];
% y_m = [F8; Tm; Pm; c6];

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Parameters
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% x_m = x_ms.*(ub'-lb')+lb';
% x0s = (x0-lb')./(ub-lb);


c1 = Parameter.Stream1.c;  % [molar fraction]
    c1_A = c1(1);
    c1_B = c1(2);
    c1_C = c1(3);
    c1_D = c1(4);
    c1_E = c1(5);
    c1_F = c1(6);
    c1_G = c1(7);
    c1_H = c1(8);
T1 = Parameter.Stream1.T;  % [�C]
c2 = Parameter.Stream2.c;  % [molar fraction]
    c2_A = c2(1);
    c2_B = c2(2);
    c2_C = c2(3);
    c2_D = c2(4);
    c2_E = c2(5);
    c2_F = c2(6);
    c2_G = c2(7);
    c2_H = c2(8);
T2 = Parameter.Stream2.T;  % [�C]
c3 = Parameter.Stream3.c;  % [molar fraction]
    c3_A = c3(1);
    c3_B = c3(2);
    c3_C = c3(3);
    c3_D = c3(4);
    c3_E = c3(5);
    c3_F = c3(6);
    c3_G = c3(7);
    c3_H = c3(8);
T3 = Parameter.Stream3.T;  % [�C]

Cpv_A = Parameter.A.Cpv;  % [kJ/(kg �C)]
Cpv_B = Parameter.B.Cpv;  % [kJ/(kg �C)]
Cpv_C = Parameter.C.Cpv;  % [kJ/(kg �C)]
Cpv_D = Parameter.D.Cpv;  % [kJ/(kg �C)]
Cpv_E = Parameter.E.Cpv;  % [kJ/(kg �C)]
Cpv_F = Parameter.F.Cpv;  % [kJ/(kg �C)]
Cpv_G = Parameter.G.Cpv;  % [kJ/(kg �C)]
Cpv_H = Parameter.H.Cpv;  % [kJ/(kg �C)]
Cpv   = [Cpv_A Cpv_B Cpv_C Cpv_D Cpv_E Cpv_F Cpv_G Cpv_H];

MA = Parameter.A.M;  % [kg/kmol]
MB = Parameter.B.M;  % [kg/kmol]
MC = Parameter.C.M;  % [kg/kmol]
MD = Parameter.D.M;  % [kg/kmol]
ME = Parameter.E.M;  % [kg/kmol]
MF = Parameter.F.M;  % [kg/kmol]
MG = Parameter.G.M;  % [kg/kmol]
MH = Parameter.H.M;  % [kg/kmol]

v6 = Parameter.v6;  % [kmol/(h.MPa^(1/2))]

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  2.- Nomenclature
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
c_Asp  = u_m(1);
c_ACsp = u_m(2);
F5     = u_m(3);
F6     = u_m(4);
Pr     = u_m(5);
T8     = u_m(6);
Tstr   = u_m(7);
c5     = u_m(8:8+7);
    c5_A = u_m(8);
    c5_B = u_m(9);
    c5_C = u_m(10);
    c5_D = u_m(11);
    c5_E = u_m(12);
    c5_F = u_m(13);
    c5_G = u_m(14);
    c5_H = u_m(15);
c8     = u_m(16:16+7);
    c8_A = u_m(16);
    c8_B = u_m(17);
    c8_C = u_m(18);
    c8_D = u_m(19);
    c8_E = u_m(20);
    c8_F = u_m(21);
    c8_G = u_m(22);
    c8_H = u_m(23);
c6_E2 = u_m(24);
    
c6_A = c_ACsp*c_Asp/(100*100); % ((100-c_Asp)*c_ACsp/10000*c_Asp)/(100-c_Asp);
c6_B = x_m(1);
c6_C = c_ACsp/100-c6_A; %(100-c_Asp)*c_ACsp/10000;
c6_D = x_m(2);
c6_E = x_m(3);
c6_F = x_m(4);
c6_G = x_m(5);
c6_H = 1 - (c6_A + c6_B + c6_C + c6_D + c6_E + c6_F + c6_G);
c6   = [c6_A; c6_B; c6_C; c6_D; c6_E; c6_F; c6_G; c6_H];

F1 = x_m(6);
F2 = x_m(7);
F3 = x_m(8);
F8 = x_m(9);


% c6_A = x_m(1);
% c6_B = x_m(2);
% c6_C = x_m(3);
% c6_D = x_m(4);
% c6_E = x_m(5);
% c6_F = x_m(6);
% c6_G = x_m(7);
% c6_H = 1 - (c6_A + c6_B + c6_C + c6_D + c6_E + c6_F + c6_G);
% c6   = [c6_A; c6_B; c6_C; c6_D; c6_E; c6_F; c6_G; c6_H];
% 
% F1 = x_m(8);
% F2 = x_m(9);
% F3 = x_m(10);
% F8 = x_m(11);

Ctot1 = Cpv_A*c1_A*MA + Cpv_B*c1_B*MB + Cpv_C*c1_C*MC + Cpv_D*c1_D*MD + Cpv_E*c1_E*ME + Cpv_F*c1_F*MF + Cpv_G*c1_G*MG + Cpv_H*c1_H*MH;
Ctot2 = Cpv_A*c2_A*MA + Cpv_B*c2_B*MB + Cpv_C*c2_C*MC + Cpv_D*c2_D*MD + Cpv_E*c2_E*ME + Cpv_F*c2_F*MF + Cpv_G*c2_G*MG + Cpv_H*c2_H*MH;
Ctot3 = Cpv_A*c3_A*MA + Cpv_B*c3_B*MB + Cpv_C*c3_C*MC + Cpv_D*c3_D*MD + Cpv_E*c3_E*ME + Cpv_F*c3_F*MF + Cpv_G*c3_G*MG + Cpv_H*c3_H*MH;
Ctot5 = Cpv_A*c5_A*MA + Cpv_B*c5_B*MB + Cpv_C*c5_C*MC + Cpv_D*c5_D*MD + Cpv_E*c5_E*ME + Cpv_F*c5_F*MF + Cpv_G*c5_G*MG + Cpv_H*c5_H*MH;
Ctot6 = Cpv_A*c6_A*MA + Cpv_B*c6_B*MB + Cpv_C*c6_C*MC + Cpv_D*c6_D*MD + Cpv_E*c6_E*ME + Cpv_F*c6_F*MF + Cpv_G*c6_G*MG + Cpv_H*c6_H*MH;
Ctot8 = Cpv_A*c8_A*MA + Cpv_B*c8_B*MB + Cpv_C*c8_C*MC + Cpv_D*c8_D*MD + Cpv_E*c8_E*ME + Cpv_F*c8_F*MF + Cpv_G*c8_G*MG + Cpv_H*c8_H*MH;

Tm = (F1*T1*Ctot1 + F2*T2*Ctot2 + F3*T3*Ctot3 + F5*Tstr*Ctot5 + F8*T8*Ctot8)/...
     (F1*Ctot1 + F2*Ctot2 + F3*Ctot3 + F5*Ctot5 + F8*Ctot8);
Pm = (F6/v6)^2*1e3 + Pr;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  3.- Model
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eq_m = zeros(9,1);
% F5
% c1_A*F1 
% c2_A*F2 
% c3_A*F3 
% c5_A
% F5 
% c8_A*F8 
% c6_A*F6
eq_m(1) = c1_A*F1 + c2_A*F2 + c3_A*F3 + c5_A*F5 + c8_A*F8 - c6_A*F6;
eq_m(2) = c1_B*F1 + c2_B*F2 + c3_B*F3 + c5_B*F5 + c8_B*F8 - c6_B*F6;
eq_m(3) = c1_C*F1 + c2_C*F2 + c3_C*F3 + c5_C*F5 + c8_C*F8 - c6_C*F6;
eq_m(4) = c1_D*F1 + c2_D*F2 + c3_D*F3 + c5_D*F5 + c8_D*F8 - c6_D*F6;
eq_m(5) = c1_E*F1 + c2_E*F2 + c3_E*F3 + c5_E*F5 + c8_E*F8 - c6_E*F6;
eq_m(6) = c1_F*F1 + c2_F*F2 + c3_F*F3 + c5_F*F5 + c8_F*F8 - c6_F*F6;
eq_m(7) = c1_G*F1 + c2_G*F2 + c3_G*F3 + c5_G*F5 + c8_G*F8 - c6_G*F6;
eq_m(8) = c1_H*F1 + c2_H*F2 + c3_H*F3 + c5_H*F5 + c8_H*F8 - c6_H*F6;
% eq_m(9) = F1 + F2 + F3 + F5 + F8 - F6;
eq_m(10) = c6_E - c6_E2;


% eq_m(3) = 0;
% 
% -(c1*F1 + c2*F2 + c3*F3 + c5*F5 - c6*F6)./c8

y_m  = [F8; Tm; Pm; c6];

end