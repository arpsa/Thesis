function [eq_sep, y_sep] = SeparatorCompressor(x_sep, u_sep, Parameters)
% u_sep = [F8; F10; Tr; Tm; Pm; Pr; Vpsep_sp; c7]; 
% x_sep = [c8_A; c8_B; c8_C; c8_D; c8_E; c8_F; c8_G; Ps; F9; Tsep];
% y_sep = [F7; F9; T8; Ts; Wcomp; Vliq_s; rho9; Ps; PvapD; PvapE; PvapF; PvapG; PvapH; c8; c9; c10];

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Parameters
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Cpv_A = Parameters.A.Cpv;  % [kJ/(kg �C)]
Cpv_B = Parameters.B.Cpv;  % [kJ/(kg �C)]
Cpv_C = Parameters.C.Cpv;  % [kJ/(kg �C)]
Cpv_D = Parameters.D.Cpv;  % [kJ/(kg �C)]
Cpv_E = Parameters.E.Cpv;  % [kJ/(kg �C)]
Cpv_F = Parameters.F.Cpv;  % [kJ/(kg �C)]
Cpv_G = Parameters.G.Cpv;  % [kJ/(kg �C)]
Cpv_H = Parameters.H.Cpv;  % [kJ/(kg �C)]

Cpl_A = Parameters.A.Cpl;  % [kJ/(kg �C)]
Cpl_B = Parameters.B.Cpl;  % [kJ/(kg �C)]
Cpl_C = Parameters.C.Cpl;  % [kJ/(kg �C)]
Cpl_D = Parameters.D.Cpl;  % [kJ/(kg �C)]
Cpl_E = Parameters.E.Cpl;  % [kJ/(kg �C)]
Cpl_F = Parameters.F.Cpl;  % [kJ/(kg �C)]
Cpl_G = Parameters.G.Cpl;  % [kJ/(kg �C)]
Cpl_H = Parameters.H.Cpl;  % [kJ/(kg �C)]

HvapD = Parameters.D.Hvap; % [kJ/kg]
HvapE = Parameters.E.Hvap; % [kJ/kg]
HvapF = Parameters.F.Hvap; % [kJ/kg]
HvapG = Parameters.G.Hvap; % [kJ/kg]
HvapH = Parameters.H.Hvap; % [kJ/kg]


v7  = Parameters.v7; % [kmol/(h.MPa^(1/2))]
pv9 = Parameters.pv9; % [kmol/(h.MPa^(1/2))]

AD = Parameters.D.A;  % [-]
BD = Parameters.D.B;  % [-]
CD = Parameters.D.c;  % [-]

AE = Parameters.E.A;  % [-]
BE = Parameters.E.B;  % [-]
CE = Parameters.E.C;  % [-]

AF = Parameters.F.A;  % [-]
BF = Parameters.F.B;  % [-]
CF = Parameters.F.C;  % [-]

AG = Parameters.G.A;  % [-]
BG = Parameters.G.B;  % [-]
CG = Parameters.G.C;  % [-]

AH = Parameters.H.A;  % [-]
BH = Parameters.H.B;  % [-]
CH = Parameters.H.C;  % [-]

MA = Parameters.A.M;  % [kg/kmol]
MB = Parameters.B.M;  % [kg/kmol]
MC = Parameters.C.M;  % [kg/kmol]
MD = Parameters.D.M;  % [kg/kmol]
ME = Parameters.E.M;  % [kg/kmol]
MF = Parameters.F.M;  % [kg/kmol]
MG = Parameters.G.M;  % [kg/kmol]
MH = Parameters.H.M;  % [kg/kmol]

Pout = Parameters.Pout; % [MPa]

R = Parameters.R; % [m3.kPa/(K.kmol)]

rhoA = Parameters.A.rho;   % [kg/m3]
rhoB = Parameters.B.rho;   % [kg/m3]
rhoC = Parameters.C.rho;   % [kg/m3]
rhoD = Parameters.D.rho;   % [kg/m3]
rhoE = Parameters.E.rho;   % [kg/m3]
rhoF = Parameters.F.rho;   % [kg/m3]
rhoG = Parameters.G.rho;   % [kg/m3]
rhoH = Parameters.H.rho;   % [kg/m3]

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  2.- Nomenclature
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

F8   = u_sep(1);
F10  = u_sep(2);
Pm   = u_sep(3);
Pr   = u_sep(4);
Vpsep_sp = u_sep(5);
c7   = u_sep(6:13);

c7_A = c7(1);
c7_B = c7(2);
c7_C = c7(3);
c7_D = c7(4);
c7_E = c7(5);
c7_F = c7(6);
c7_G = c7(7);
c7_H = c7(8);

Vliq_s = (Vpsep_sp*290/100+27.5)/35.3145;

c8_A = x_sep(1);
c8_B = x_sep(2);
c8_C = x_sep(3);
c8_D = x_sep(4);
c8_E = x_sep(5);
c8_F = x_sep(6);
c8_G = x_sep(7);
c8_H = 1 - (c8_A + c8_B + c8_C + c8_D + c8_E + c8_F + c8_G);
c8   = [c8_A; c8_B; c8_C; c8_D; c8_E; c8_F; c8_G; c8_H];
c9   = c8;

M8      = MA*c8_A + MB*c8_B + MC*c8_C + MD*c8_D + ME*c8_E + MF*c8_F + MG*c8_G + MH*c8_H; 
Cpvap8  = (Cpv_A*c8_A*MA + Cpv_B*c8_B*MB + Cpv_C*c8_C*MC + Cpv_D*c8_D*MD + ...
             Cpv_E*c8_E*ME + Cpv_F*c8_F*MF + Cpv_G*c8_G*MG + Cpv_H*c8_H*MH)/M8; 
% M7      = MA*c7_A + MB*c7_B + MC*c7_C + MD*c7_D + ME*c7_E + MF*c7_F + MG*c7_G + MH*c7_H; 
% Cpvap7  = (Cpv_A*c7_A*MA + Cpv_B*c7_B*MB + Cpv_C*c7_C*MC + Cpv_D*c7_D*MD + ...
%              Cpv_E*c7_E*ME + Cpv_F*c7_F*MF + Cpv_G*c7_G*MG + Cpv_H*c7_H*MH)/M7; 
         
Ps = x_sep(8);
F9 = x_sep(9);
% F8  = F89;
% Ts  = x_sep(10);
Ts  = x_sep(10); % Tr-40;

PvapD = exp(AD + BD/(CD+Ts))*1e-3;
PvapE = exp(AE + BE/(CE+Ts))*1e-3;
PvapF = exp(AF + BF/(CF+Ts))*1e-3;
PvapG = exp(AG + BG/(CG+Ts))*1e-3;
PvapH = exp(AH + BH/(CH+Ts))*1e-3;

c10_A = 0;
c10_B = 0;
c10_C = 0;
c10_D = c8_D*Ps/PvapD;
c10_E = c8_E*Ps/PvapE;
c10_F = c8_F*Ps/PvapF;
c10_G = c8_G*Ps/PvapG;
c10_H = c8_H*Ps/PvapH;
c10 = [c10_A; c10_B; c10_C; c10_D; c10_E; c10_F; c10_G; c10_H];

% if Pr*1e-3-Ps*1e-3 > 0
F7     = 5.5e3*sqrt(abs(Pr*1e-3-Ps*1e-3));
% else
%   F7 = 0;  
% end

% F7
rho9   = (100000*(MA*c8_A + MB*c8_B + MC*c8_C + MD*c8_D + ME*c8_E + MF*c8_F + MG*c8_G + MH*c8_H)) / ((273.15)*R) * 1000;

T8     = Ts*(Pm/Ps)^(8.314/(M8*Cpvap8)); % 8.314 kJ/(K.kg)
% Vliq_s = (Vpsep_sp*290/100+27.5)/35.3145;

Wcomp  =  Cpvap8*(T8-Ts)*F8*M8/3600*1/0.3;

% M10     = MA*c10_A + MB*c10_B + MC*c10_C + MD*c10_D + ME*c10_E + MF*c10_F + MG*c10_G + MH*c10_H; 
% Hvap10  = (HvapD*c10_D*MD + HvapE*c10_E*ME + HvapF*c10_F*MF + HvapG*c10_G*MG + HvapH*c10_H*MH)/M10; 
 
v9 = F9/(0.2369*sqrt(Ps*1e-3-0.1013));

scm9_h = F9*1000*8.314*273.15/101325;

eq_sep = zeros(9,1);
eq_sep(1) = 1-(c10_D+c10_E+c10_F+c10_G+c10_H);
% eq_sep(2) = abs(real(c7_A*F7 - c8_A*(F8+F9) - c10_A*F10)) + abs(imag(c7_A*F7 - c8_A*(F8+F9) - c10_A*F10));
% eq_sep(3) = abs(real(c7_B*F7 - c8_B*(F8+F9) - c10_B*F10)) + abs(imag(c7_B*F7 - c8_B*(F8+F9) - c10_B*F10));
% eq_sep(4) = abs(real(c7_C*F7 - c8_C*(F8+F9) - c10_C*F10)) + abs(imag(c7_C*F7 - c8_C*(F8+F9) - c10_C*F10));
% eq_sep(5) = abs(real(c7_D*F7 - c8_D*(F8+F9) - c10_D*F10)) + abs(imag(c7_D*F7 - c8_D*(F8+F9) - c10_D*F10));
% eq_sep(6) = abs(real(c7_E*F7 - c8_E*(F8+F9) - c10_E*F10)) + abs(imag(c7_E*F7 - c8_E*(F8+F9) - c10_E*F10));
% eq_sep(7) = abs(real(c7_F*F7 - c8_F*(F8+F9) - c10_F*F10)) + abs(imag(c7_F*F7 - c8_F*(F8+F9) - c10_F*F10));
% eq_sep(8) = abs(real(c7_G*F7 - c8_G*(F8+F9) - c10_G*F10)) + abs(imag(c7_G*F7 - c8_G*(F8+F9) - c10_G*F10));
% eq_sep(9) = abs(real(c7_H*F7 - c8_H*(F8+F9) - c10_H*F10)) + abs(imag(c7_H*F7 - c8_H*(F8+F9) - c10_H*F10));

eq_sep(2) = c7_A*F7 - c8_A*(F8+F9) - c10_A*F10;
eq_sep(3) = c7_B*F7 - c8_B*(F8+F9) - c10_B*F10;
eq_sep(4) = c7_C*F7 - c8_C*(F8+F9) - c10_C*F10;
eq_sep(5) = c7_D*F7 - c8_D*(F8+F9) - c10_D*F10;
eq_sep(6) = c7_E*F7 - c8_E*(F8+F9) - c10_E*F10;
eq_sep(7) = c7_F*F7 - c8_F*(F8+F9) - c10_F*F10;
eq_sep(8) = c7_G*F7 - c8_G*(F8+F9) - c10_G*F10;
eq_sep(9) = c7_H*F7 - c8_H*(F8+F9) - c10_H*F10;

% eq_sep



y_sep = [F7; F9; T8; Ts; Wcomp; Vliq_s; rho9; Ps; PvapD; PvapE; PvapF; PvapG; PvapH; c8; c10; v9; scm9_h];

end








