function [x_m, x_sep, x_str, x_r, ub_m,lb_m , ub_r,lb_r , ub_sep,lb_sep  , ub_str,lb_str , x_RSS , ub_RSS,lb_RSS , x_TE , ub_TE,lb_TE  ] = InitState(results)

% [x0s, lb, ub, x0s_x, lb_x, ub_x, x0_x]

F9_max = 60;

    x_m   = [results.xmeascomp.c6_B; results.xmeascomp.c6_D; results.xmeascomp.c6_E; results.xmeascomp.c6_F; results.xmeascomp.c6_G; results.xmeasstream.F1; results.xmeasstream.F2; results.xmeasstream.F3; results.xmeasstream.F8]*1; 
    x_sep = [ results.xmeascomp.c8_A; results.xmeascomp.c8_B;results.xmeascomp.c8_C; results.xmeascomp.c8_D; results.xmeascomp.c8_E; results.xmeascomp.c8_F; results.xmeascomp.c8_G; ...
              results.xmeas.Pr-200   ; results.xmeasstream.F9; results.xmeas.Tsep ]; 
%             results.xmeas.Psep   ; results.xmeasstream.F9; results.xmeas.Tsep ]; 
    x_str = [results.xmeasstream.F4; results.xmeasstream.F5; results.xmeasstream.F10; results.xmeasstream.F11]; 
    x_r   = [results.xmeascomp.c7_A; results.xmeascomp.c7_B; results.xmeascomp.c7_C; results.xmeascomp.c7_D; results.xmeascomp.c7_E; results.xmeascomp.c7_F; results.xmeascomp.c7_G; results.xmeasstream.F6]; 
    
    ub_m  = [0.999 0.999 0.999 0.999 0.999 5000 5000 5000 5000];
    lb_m  = [0     0     0     0     0        0    0    0    0];
    
    ub_r  = [0.999 0.999 0.999 0.999 0.999 0.999 0.999 5000];
    lb_r  = [0     0     0     0     0     0     0        0];
    
    ub_sep = [0.9 0.9 0.9 0.9 0.9 0.9 0.9 5000 F9_max 200];
    lb_sep = [0   0   0   0   0   0   0      1    0      0];
    
    ub_str = [5000  5000  5000  5000];
    lb_str = [   1   1     1     1];
    
    x_RSS = [x_r; x_sep; x_str; results.xmeasstream.F7; results.xmeasstream.F10];
        ub_x = [5000 5000];
        lb_x = [   1    1];
    ub_RSS = [ub_r ub_sep ub_str ub_x];
    lb_RSS = [lb_r lb_sep lb_str lb_x];
    
    
%     x0_x2 = [results.xmeasstream.F8; results.xmeas.Pstr; results.xmeas.Tsep;  ...
    x0_x2 = [results.xmeasstream.F8; results.xmeas.Pr+200; results.xmeas.Tsep;  ...
             results.xmeascomp.c6_A; results.xmeascomp.c6_B; results.xmeascomp.c6_C ; ...
             results.xmeascomp.c6_D; results.xmeascomp.c6_E; results.xmeascomp.c6_F ; ...
             results.xmeascomp.c6_G; results.xmeascomp.c6_H; results.xmeasstream.F9]; 
    ub_x2 = [5000 5000 300 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 F9_max];
    lb_x2 = [   1    0  10 0     0     0     0     0     0     0     0     0];
    x_TE =  [x_RSS; x_m; x0_x2];
    ub_TE = [ub_RSS ub_m ub_x2]; %
    lb_TE = [lb_RSS lb_m lb_x2]; %

end