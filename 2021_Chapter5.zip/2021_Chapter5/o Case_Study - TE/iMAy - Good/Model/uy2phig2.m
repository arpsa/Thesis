function [phi1, phi2, g, geq] = uy2phig2(u,y, mode, Modifiers,Parameter, u_RSS)
%%     [1]   [2]   [3]   [4]   [5]
% y = [F6_m; F7_m; F8_m; F9_m; F11_m;...
%%     [6-13]  [14-21]  [22-29]  [30-37]
%      c6_m;   c7_m;     c8_m;    c11_m; ...
%%     [38]      [39]      [40]  [41]   [42]     [43]
%      Wcomp_m;  msteam_m; Tr_m; VLr_m; VLsep_m; VLstr_m; ...
%%     [44]  
%      Pr_m];
 
C_comp  = y(38)*0.0536;
C_steam = y(39)*0.0318;

MA = Parameter.A.M;
MB = Parameter.B.M;
MC = Parameter.C.M;
MD = Parameter.D.M;
ME = Parameter.E.M;
MF = Parameter.F.M;
MG = Parameter.G.M;
MH = Parameter.H.M;

M9  = y(22)*MA + y(23)*MB + y(24)*MC + y(25)*MD + y(26)*ME + y(27)*MF + y(28)*MG + y(29)*MH; 
M11 = y(30)*MA + y(31)*MB + y(32)*MC + y(33)*MD + y(34)*ME + y(35)*MF + y(36)*MG + y(37)*MH; 

C_purge = y(53)*y(52)/M9*(2.206*y(22) + 6.177*y(24) + 22.06*y(25) + 14.56*y(26) +  17.89*y(27) + 30.44*y(28) + 22.94*y(29));
C_prod  = y(47)*y(48)/M11*(22.06*y(33) + 14.56*y(34) +  17.89*y(35));

phi1 = C_comp + C_steam + C_purge + C_prod;
phi2 = -y(47)*y(48)/M11*(y(36)*62 + y(37)*76);

g = [y(44)-2895;
     y(40)-150;
     y(41)-21.3; 
     11.8-y(41); 
     y(42)-9; 
     3.3-y(42);
     y(43)-6.6; 
     3.35-y(43)];

if mode == 1 || mode == 4
    geq = y(36)*62/(y(37)*76) - 50/50;
    if mode == 1
        geq = [geq; (y(47)*y(48)/M11*(y(36)*62 + y(37)*76)-14076)*1e-5];
%         g = [g; 14076-(y(47)*y(48)/M11*(y(36)*62 + y(37)*76))*1e-5];
%         geq = [geq; y(47)*y(48)/M11*(y(36)*62 + y(37)*76)-14076];
    end
elseif mode == 2 || mode == 5
    geq = y(36)*62/(y(37)*76) - 10/90;
    if mode == 2
        geq = [geq; y(47)*y(48)/M11*(y(36)*62 + y(37)*76)-14076];
%         g = [g; 14076-y(47)*y(48)/M11*(y(36)*62 + y(37)*76)];
    end
else
    geq = y(36)*62/(y(37)*76) - 90/10;
    if mode == 3
        geq = [geq; y(46)*y(47)/M11*(y(36)*62 + y(37)*76)-11111];
%         g = [g; 11111-y(46)*y(47)/M11*(y(36)*62 + y(37)*76)];
    end
end



if strcmp(Modifiers.type,'MA')
    phi1 = phi1 + Modifiers.epsilon_phi1k + Modifiers.lambda_phi1k'*(u-Modifiers.uk);
    phi2 = phi2 + Modifiers.epsilon_phi2k + Modifiers.lambda_phi2k'*(u-Modifiers.uk);

    g    = g    + Modifiers.epsilon_gk    + Modifiers.lambda_gk    *(u-Modifiers.uk);
    geq  = geq  + Modifiers.epsilon_geqk  + Modifiers.lambda_geqk  *(u-Modifiers.uk);
elseif strcmp(Modifiers.type,'CA')
    phi1 = phi1 + Modifiers.epsilon_phi1k;
    phi2 = phi2 + Modifiers.epsilon_phi2k;
    g    = g    + Modifiers.epsilon_gk;
    geq  = geq  + Modifiers.epsilon_geqk;
elseif strcmp(Modifiers.type,'iMA1')
    
    phi1 = phi1 + Modifiers.epsilon_iMA1_phi1k + Modifiers.lambda_iMA1_phi1k'*(u-Modifiers.uk);
    phi2 = phi2 + Modifiers.epsilon_iMA1_phi2k + Modifiers.lambda_iMA1_phi2k'*(u-Modifiers.uk);

    g    = g    + Modifiers.epsilon_iMA1_gk    + Modifiers.lambda_iMA1_gk    *(u-Modifiers.uk);
    geq  = geq  + Modifiers.epsilon_iMA1_geqk  + Modifiers.lambda_iMA1_geqk  *(u-Modifiers.uk);
elseif strcmp(Modifiers.type,'iMA2')
    phi1 = phi1 + Modifiers.epsilon_iMA2_phi1k + Modifiers.lambda_iMA2_phi1k'*(u_RSS-Modifiers.uuk_2);
    phi2 = phi2 + Modifiers.epsilon_iMA2_phi2k + Modifiers.lambda_iMA2_phi2k'*(u_RSS-Modifiers.uuk_2);

    g    = g    + Modifiers.epsilon_iMA2_gk    + Modifiers.lambda_iMA2_gk    *(u_RSS-Modifiers.uuk_2);
    geq  = geq  + Modifiers.epsilon_iMA2_geqk  + Modifiers.lambda_iMA2_geqk  *(u_RSS-Modifiers.uuk_2);
end










