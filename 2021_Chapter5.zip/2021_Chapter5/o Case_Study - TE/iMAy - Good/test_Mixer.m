clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')

addpath('Plant')
addpath('Model')
addpath('Functions')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.- Initialize plant at base case
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.1.- Tunable parameters
    Measurement_Noise = 0; % 0: without noise | 1: with noise
        MNoise.time           = 0;
        MNoise.signals.values = Measurement_Noise;
% 1.2.- Base case initialisation of states & simulation sampling times
    load Mode1xInitial
    Ts_base=0.0005;
    Ts_save=0.01;
% 1.3.- Initial setpoints
    setpoints.time    = 0;
    setpoints.signals.values = [21; 50; 50; 50; 2800; 53.8; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
            setpoints.signals.values = [22.89; 50; 50; 65; 2800; 53.83; 63.21; 50.97; 122.9; 1; 1; 100]';
        setpoints.signals.values = [22.89; 50; 50; 65; 2800; 53.83; 63.21; 50.97; 122.9; 1; 1; 100]';
prev_setpoints = setpoints;
% 1.4.- Initial valve positions
    u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
    for i=1:12
        iChar=int2str(i);
        eval(['xmv',iChar,'_0=u0(',iChar,');']);
    end
% 1.5.- Initial Controlers parameters
    Fp_0   = 100;
    r1_0   = 0.251/Fp_0;
    r2_0   = 3664/Fp_0;
    r3_0   = 4509/Fp_0;
    r4_0   = 9.35/Fp_0;
    r5_0   = 0.337/Fp_0;
    r6_0   = 25.16/Fp_0;
    r7_0   = 22.95/Fp_0;
    Eadj_0 = 0;
    SP17_0 = 80.1;
    
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2.- Lauch simulation
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sim('MultiLoop_mode1')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % 3.- Extract data
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost);


%% Initialization model with plant values
PBstruct   = ProblemStructure();
Parameters = SetParameters();

% u_m = [c_Asp; c_ACsp; F5; F6; F8; Pr; T8; Tstr; c5; c8];
% x_m = [c6_B; c6_D; c6_E; c6_F; c6_G];
% y_m = [F1; F2; F3; Tm; Pm; c6];
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Inputs definition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs variables
c_Asp  = results.u.c_Asp;
c_ACsp = results.u.c_ACsp;
F5     = results.xmeasstream.F5; % [kmol/h]
F6     = results.xmeasstream.F6; % [kmol/h]
F8     = results.xmeasstream.F8; % [kmol/h]
Pr     = results.xmeas.Pr;       % [kPa]
T8     = results.xmeas.Tsep;     % [C]
Tstr   = results.xmeas.Tstr ;
c5     = [results.xmeascomp.c5_A; results.xmeascomp.c5_B; results.xmeascomp.c5_C; ...
          results.xmeascomp.c5_D; results.xmeascomp.c5_E; results.xmeascomp.c5_F; ...
          results.xmeascomp.c5_G; results.xmeascomp.c5_H];
c8     = [results.xmeascomp.c8_A; results.xmeascomp.c8_B; results.xmeascomp.c8_C; ...
          results.xmeascomp.c8_D; results.xmeascomp.c8_E; results.xmeascomp.c8_F; ...
          results.xmeascomp.c8_G; results.xmeascomp.c8_H];
      
u_m = zeros(24,1);
u_m(1)     = c_Asp;
u_m(2)     = c_ACsp;
u_m(3)     = F5;
u_m(4)     = F6;
u_m(5)     = Pr; % [MPa]
u_m(6)     = T8;
u_m(7)     = Tstr;
u_m(8:15)  = c5;
u_m(16:23) = c8;
u_m(24)    = results.xmeascomp.c6_D;

% x_m = x_m = [c6_B; c6_D; c6_E; c6_F; c6_G; F1; F2; F3];
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
% x0 = [results.xmeascomp.c6_A;results.xmeascomp.c6_B;results.xmeascomp.c6_C; results.xmeascomp.c6_D; results.xmeascomp.c6_E; results.xmeascomp.c6_F; results.xmeascomp.c6_G; results.xmeasstream.F1; results.xmeasstream.F2; results.xmeasstream.F3; results.xmeasstream.F8]*1; 
x0 = [results.xmeascomp.c6_B; results.xmeascomp.c6_D; results.xmeascomp.c6_E; results.xmeascomp.c6_F; results.xmeascomp.c6_G; results.xmeasstream.F1; results.xmeasstream.F2; results.xmeasstream.F3; results.xmeasstream.F5; results.xmeasstream.F8]*1.0; 

PBstruct   = ProblemStructure();
x_sol = fsolve(@(x_m) Mixer(x_m, u_m, Parameters), x0, PBstruct.fsolve_options);
[test, y_m] = Mixer(x_sol, u_m, Parameters);

% ub = [0.99 0.99 0.99 0.99 0.99 0.99 1000 1000 2000 2000];
% lb = [0    0     0    0   0     0      0    0    0    0];
% x_sol = lsqnonlin(@(x_m) Mixer(x_m, u_m, Parameters), x0, lb, ub, PBstruct.lsqnonlin_options);
% [test, y_m] = Mixer(x_sol, u_m, Parameters);

test
%  u_m2 = u_m
 
% y_m = [F1; F2; F3; Tm; Pm; c6];
%%
disp(['F8   Plant: ',num2str(results.xmeasstream.F8,4), '   Model: ', num2str(y_m(1),4)])
disp(['Tm   Model: ', num2str(y_m(2),4)])
disp(['Pm   Model: ', num2str(y_m(3),4)])
disp(['c6_A Plant: ',num2str(results.xmeascomp.c6_A,4), '   Model: ', num2str(y_m(4),4)])
disp(['c6_B Plant: ',num2str(results.xmeascomp.c6_B,4), '   Model: ', num2str(y_m(5),4)])
disp(['c6_C Plant: ',num2str(results.xmeascomp.c6_C,4), '   Model: ', num2str(y_m(6),4)])
disp(['c6_D Plant: ',num2str(results.xmeascomp.c6_D,4), '   Model: ', num2str(y_m(7),4)])
disp(['c6_E Plant: ',num2str(results.xmeascomp.c6_E,4), '   Model: ', num2str(y_m(8),4)])
disp(['c6_F Plant: ',num2str(results.xmeascomp.c6_F,4), '   Model: ', num2str(y_m(9),4)])
disp(['c6_G Plant: ',num2str(results.xmeascomp.c6_G,4), '   Model: ', num2str(y_m(10),4)])
disp(['c6_H Plant: ',num2str(results.xmeascomp.c6_H,4),'   Model: ', num2str(y_m(11),4)])
% disp(['Pm   Plant: ',num2str(x0(5)), '   Model: ', num2str(y_m(5))])

disp(' ')
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')



