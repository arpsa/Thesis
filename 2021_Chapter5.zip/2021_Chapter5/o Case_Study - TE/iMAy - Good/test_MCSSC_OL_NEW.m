clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')

addpath('Plant')
addpath('Model')
addpath('Functions')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.- Initialize plant at base case
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.1.- Tunable parameters
    Measurement_Noise = 0; % 0: without noise | 1: with noise
        MNoise.time           = 0;
        MNoise.signals.values = Measurement_Noise;
% 1.2.- Base case initialisation of states & simulation sampling times
    load Mode1xInitial
    Ts_base=0.0005;
    Ts_save=0.01;
% 1.3.- Initial setpoints
    setpoints.time    = 0;
    setpoints.signals.values = [21; 40; 60; 60; 2500; 10; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
        setpoints.signals.values = [21; 50; 50; 65; 2500; 10; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
%     setpoints.signals.values = [26; 50; 50; 65; 2800; 50; 100*36.4/(36.4+22.36); (36.4+22.36); 122; 1; 1; 100]';
prev_setpoints = setpoints;
    %     setpoints.signals.values = [18; 60; 60; 60; 2500; 10; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
% 1.4.- Initial valve positions
    u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
    for i=1:12
        iChar=int2str(i);
        eval(['xmv',iChar,'_0=u0(',iChar,');']);
    end
% 1.5.- Initial Controlers parameters
    Fp_0   = 100;
    r1_0   = 0.251/Fp_0;
    r2_0   = 3664/Fp_0;
    r3_0   = 4509/Fp_0;
    r4_0   = 9.35/Fp_0;
    r5_0   = 0.337/Fp_0;
    r6_0   = 25.16/Fp_0;
    r7_0   = 22.95/Fp_0;
    Eadj_0 = 0;
    SP17_0 = 80.1;
    
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2.- Lauch simulation
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sim('MultiLoop_mode1')

% %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % 3.- Extract data
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost);

%% Initialization model with plant values
Parameters = SetParameters();

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Inputs definition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs variables

Tstr     = results.xmeas.Tstr;
m11_sp   = setpoints.signals.values(1);
Vpstr_sp = setpoints.signals.values(2);
Vpsep_sp = setpoints.signals.values(3);
Vpr_sp = setpoints.signals.values(3);
msteam   = results.xmeas.m_steam ;
cG11_sp  = setpoints.signals.values(6);  
F6       = results.xmeasstream.F6;     
F8       = results.xmeasstream.F8;   
F9       = results.xmeasstream.F9;   
c_Asp    = setpoints.signals.values(7);
c_ACsp   = setpoints.signals.values(8);
Pr_sp    = setpoints.signals.values(5);
Tr_sp    = setpoints.signals.values(9);
c7     = [results.xmeascomp.c7_A; results.xmeascomp.c7_B; results.xmeascomp.c7_C; ...
          results.xmeascomp.c7_D; results.xmeascomp.c7_E; results.xmeascomp.c7_F; ...
          results.xmeascomp.c7_G; results.xmeascomp.c7_H];
c8     = [results.xmeascomp.c8_A; results.xmeascomp.c8_B; results.xmeascomp.c8_C; ...
          results.xmeascomp.c8_D; results.xmeascomp.c8_E; results.xmeascomp.c8_F; ...
          results.xmeascomp.c8_G; results.xmeascomp.c8_H];


% u_MCSSC = [c_Asp; c_ACsp; Vpsep_sp; Vpstr_sp; cG11_sp; m11_sp; msteam_sp; ...
%            F6_in; Pr_in; Tr_in; Tstr_in; F8_in; c7_in; c8_in];

u_MCSSC = zeros(30,1);
u_MCSSC(1)  = m11_sp;
u_MCSSC(2)  = Vpstr_sp;
u_MCSSC(3)  = Vpsep_sp;
u_MCSSC(4)  = Vpr_sp;
u_MCSSC(5)  = Pr_sp;
u_MCSSC(6)  = cG11_sp;
u_MCSSC(7)  = c_Asp;
u_MCSSC(8)  = c_ACsp;
u_MCSSC(9)  = Tr_sp;         
u_MCSSC(10) = msteam;
u_MCSSC(11) = F6;
u_MCSSC(12) = Tstr;  
u_MCSSC(13) = Vpr_sp;
u_MCSSC(14:21) = c7;
u_MCSSC(22)    = F8;
u_MCSSC(23:30) = c8;

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    
PBstruct   = ProblemStructure();


x_m   = [results.xmeascomp.c6_B; results.xmeascomp.c6_D; results.xmeascomp.c6_E; results.xmeascomp.c6_F; results.xmeascomp.c6_G; results.xmeasstream.F1; results.xmeasstream.F2; results.xmeasstream.F3; results.xmeasstream.F8]*1; 
x_sep = [ results.xmeascomp.c8_A; results.xmeascomp.c8_B;results.xmeascomp.c8_C; results.xmeascomp.c8_D; results.xmeascomp.c8_E; results.xmeascomp.c8_F; results.xmeascomp.c8_G; ...
          results.xmeas.Psep   ; results.xmeasstream.F9; results.xmeas.Tsep ]; 
x_str = [results.xmeasstream.F4; results.xmeasstream.F5; results.xmeasstream.F10; results.xmeasstream.F11]; 
ub_m   = [0.999 0.999 0.999 0.999 0.999 3000 3000 3000 3000];
lb_m   = [0     0     0     0     0        0    0    0    0];
ub_sep = [0.9 0.9 0.9 0.9 0.9 0.9 0.9 5000 50 150];
lb_sep = [0   0   0   0   0   0   0   2000  0  60];
ub_str = [3000  3000  3000  3000];
lb_str = [   1     1     1     1];

x0 = [results.xmeascomp.c5_A; results.xmeascomp.c5_B; results.xmeascomp.c5_C; ...
      results.xmeascomp.c5_D; results.xmeascomp.c5_E; results.xmeascomp.c5_F; ...
      results.xmeascomp.c5_G;  ...
      results.xmeasstream.F5;  results.xmeasstream.F10; results.xmeas.Tstr; ...
      x_m; x_sep; x_str;  ...
      results.xmeascomp.c8_A; results.xmeascomp.c8_B; results.xmeascomp.c8_C; ...
      results.xmeascomp.c8_D; results.xmeascomp.c8_E; results.xmeascomp.c8_F; ...
      results.xmeascomp.c8_G;...
      results.xmeasstream.F8];
% x0 = [results.xmeascomp.c5_A; results.xmeascomp.c5_B; results.xmeascomp.c5_C; ...
%       results.xmeascomp.c5_D; results.xmeascomp.c5_E; results.xmeascomp.c5_F; ...
%       results.xmeascomp.c5_G;  ...
%       results.xmeasstream.F5;  results.xmeasstream.F10; results.xmeas.Tstr; ...
%       x_m; x_sep; x_str];
ub_x = [0.999 0.999 0.999 0.999 0.999 0.999 0.999 3000 3000 200];
lb_x = [0     0     0     0     0     0     0        1    1  20];
ub_x2 = [0.999 0.999 0.999 0.999 0.999 0.999 0.999 3000];
lb_x2 = [0     0     0     0     0     0     0        1];


ub = [ub_x ub_m ub_sep ub_str ub_x2];
lb = [lb_x lb_m lb_sep lb_str lb_x2];
% ub = [ub_x ub_m ub_sep ub_str];
% lb = [lb_x lb_m lb_sep lb_str];

x0s = (x0 - lb')./(ub' - lb') ;

x0s = x0s*0.1; 


% u_MCSSC = [65.9042797608259;56.5425975288809;49.9999999994850;50.0000000004048;22.3794086572176;4.57056564791952;2252.78934366002;2800.00000000000;120.699915345647;67.7329310086733;1595.09034533480;0.344550402830288;0.152528438678449;0.125578138674150;0.00750493571046497;0.131273187269552;0.0335394279451058;0.122987827624037;0.0820376412679533;0.396242469270730;0.175411912682389;0.144418324128841;0.00843227604750122;0.138172016357487;0.0353020329820857;0.0677198771226701;0.0343010914082954;11.4799205814084;0.0548055460474167];

% [xs_sol, ~, ~, ~, dx] = SolveMCSSC_OL(x0s, u_MCSSC, Parameters, lb, ub, PBstruct.fmincon_options_2);
x_sol = lsqnonlin(@(x_MCSSC) MCSSC_OL_NEW(x_MCSSC, u_MCSSC, Parameters), x0, lb, ub, PBstruct.lsqnonlin_options);

%
% x_sol  = (xs_sol).*(ub'-lb') + lb';
[test, y_MCSSC, yy] = MCSSC_OL_NEW(x_sol, u_MCSSC, Parameters);
max(test)

%%
% y_MCSSC = [F7; F8; F9; F11; VLsep; VLstr; m11; msteam; Tstr; Wcomp; c6; c8; c11];


disp(['F1   Plant: ',num2str(results.xmeasstream.F1,4), '   Model: ', num2str(yy(1),4)])
disp(['F2   Plant: ',num2str(results.xmeasstream.F2,4), '   Model: ', num2str(yy(2),4)])
disp(['F3   Plant: ',num2str(results.xmeasstream.F3,4), '   Model: ', num2str(yy(3),4)])
disp(['F4   Plant: ',num2str(results.xmeasstream.F4,4), '   Model: ', num2str(yy(4),4)])
disp(['F5   Plant: ',num2str(results.xmeasstream.F5,4), '   Model: ', num2str(yy(5),4)])
disp(['F6   Plant: ',num2str(results.xmeasstream.F6,4), '   Model: ', num2str(yy(6),4)])
disp(['F7   Plant: ',num2str(results.xmeasstream.F7,4), '   Model: ', num2str(yy(7),4)])
disp(['F8   Plant: ',num2str(results.xmeasstream.F8,4), '   Model: ', num2str(yy(8),4)])
disp(['F9   Plant: ',num2str(results.xmeasstream.F9,4), '   Model: ', num2str(yy(9),4)])
disp(['F10  Plant: ',num2str(results.xmeasstream.F10,4),'   Model: ', num2str(yy(10),4)])
disp(['F11  Plant: ',num2str(results.xmeasstream.F11,4),'   Model: ', num2str(yy(11),4)])
% 
disp(' ')
disp(['c5_A Plant: ',num2str(results.xmeascomp.c5_A,4), '   Model: ', num2str(yy(12),4)])
disp(['c5_B Plant: ',num2str(results.xmeascomp.c5_B,4), '   Model: ', num2str(yy(13),4)])
disp(['c5_C Plant: ',num2str(results.xmeascomp.c5_C,4), '   Model: ', num2str(yy(14),4)])
disp(['c5_D Plant: ',num2str(results.xmeascomp.c5_D,4), '   Model: ', num2str(yy(15),4)])
disp(['c5_E Plant: ',num2str(results.xmeascomp.c5_E,4), '   Model: ', num2str(yy(16),4)])
disp(['c5_F Plant: ',num2str(results.xmeascomp.c5_F,4), '   Model: ', num2str(yy(17),4)])
disp(['c5_G Plant: ',num2str(results.xmeascomp.c5_G,4), '   Model: ', num2str(yy(18),4)])
disp(['c5_H Plant: ',num2str(results.xmeascomp.c5_H,4), '   Model: ', num2str(yy(19),4)])
%  
disp(' ')
disp(['c6_A Plant: ',num2str(results.xmeascomp.c6_A,4), '   Model: ', num2str(yy(20),4)])
disp(['c6_B Plant: ',num2str(results.xmeascomp.c6_B,4), '   Model: ', num2str(yy(21),4)])
disp(['c6_C Plant: ',num2str(results.xmeascomp.c6_C,4), '   Model: ', num2str(yy(22),4)])
disp(['c6_D Plant: ',num2str(results.xmeascomp.c6_D,4), '   Model: ', num2str(yy(23),4)])
disp(['c6_E Plant: ',num2str(results.xmeascomp.c6_E,4), '   Model: ', num2str(yy(24),4)])
disp(['c6_F Plant: ',num2str(results.xmeascomp.c6_F,4), '   Model: ', num2str(yy(25),4)])
disp(['c6_G Plant: ',num2str(results.xmeascomp.c6_G,4), '   Model: ', num2str(yy(26),4)])
disp(['c6_H Plant: ',num2str(results.xmeascomp.c6_H,4), '   Model: ', num2str(yy(27),4)])
%  
disp(' ')
disp(['c7_A Plant: ',num2str(results.xmeascomp.c7_A,4), '   Model: ', num2str(yy(28),4)])
disp(['c7_B Plant: ',num2str(results.xmeascomp.c7_B,4), '   Model: ', num2str(yy(29),4)])
disp(['c7_C Plant: ',num2str(results.xmeascomp.c7_C,4), '   Model: ', num2str(yy(30),4)])
disp(['c7_D Plant: ',num2str(results.xmeascomp.c7_D,4), '   Model: ', num2str(yy(31),4)])
disp(['c7_E Plant: ',num2str(results.xmeascomp.c7_E,4), '   Model: ', num2str(yy(32),4)])
disp(['c7_F Plant: ',num2str(results.xmeascomp.c7_F,4), '   Model: ', num2str(yy(33),4)])
disp(['c7_G Plant: ',num2str(results.xmeascomp.c7_G,4), '   Model: ', num2str(yy(34),4)])
disp(['c7_H Plant: ',num2str(results.xmeascomp.c7_H,4), '   Model: ', num2str(yy(35),4)])
%  
disp(' ')
disp(['c8_A Plant: ',num2str(results.xmeascomp.c8_A,4), '   Model: ', num2str(yy(36),4)])
disp(['c8_B Plant: ',num2str(results.xmeascomp.c8_B,4), '   Model: ', num2str(yy(37),4)])
disp(['c8_C Plant: ',num2str(results.xmeascomp.c8_C,4), '   Model: ', num2str(yy(38),4)])
disp(['c8_D Plant: ',num2str(results.xmeascomp.c8_D,4), '   Model: ', num2str(yy(39),4)])
disp(['c8_E Plant: ',num2str(results.xmeascomp.c8_E,4), '   Model: ', num2str(yy(40),4)])
disp(['c8_F Plant: ',num2str(results.xmeascomp.c8_F,4), '   Model: ', num2str(yy(41),4)])
disp(['c8_G Plant: ',num2str(results.xmeascomp.c8_G,4), '   Model: ', num2str(yy(42),4)])
disp(['c8_H Plant: ',num2str(results.xmeascomp.c8_H,4), '   Model: ', num2str(yy(43),4)])
 
disp(' ')
disp(['c10_A Plant: ',num2str(results.xmeascomp.c10_A,4), '   Model: ', num2str(yy(44),4)])
disp(['c10_B Plant: ',num2str(results.xmeascomp.c10_B,4), '   Model: ', num2str(yy(45),4)])
disp(['c10_C Plant: ',num2str(results.xmeascomp.c10_C,4), '   Model: ', num2str(yy(46),4)])
disp(['c10_D Plant: ',num2str(results.xmeascomp.c10_D,4), '   Model: ', num2str(yy(47),4)])
disp(['c10_E Plant: ',num2str(results.xmeascomp.c10_E,4), '   Model: ', num2str(yy(48),4)])
disp(['c10_F Plant: ',num2str(results.xmeascomp.c10_F,4), '   Model: ', num2str(yy(49),4)])
disp(['c10_G Plant: ',num2str(results.xmeascomp.c10_G,4), '   Model: ', num2str(yy(50),4)])
disp(['c10_H Plant: ',num2str(results.xmeascomp.c10_H,4), '   Model: ', num2str(yy(51),4)])
 sum(yy(44:51))
disp(' ')
disp(['c11_A Plant: ',num2str(results.xmeascomp.c11_A,4), '   Model: ', num2str(yy(52),4)])
disp(['c11_B Plant: ',num2str(results.xmeascomp.c11_B,4), '   Model: ', num2str(yy(53),4)])
disp(['c11_C Plant: ',num2str(results.xmeascomp.c11_C,4), '   Model: ', num2str(yy(54),4)])
disp(['c11_D Plant: ',num2str(results.xmeascomp.c11_D,4), '   Model: ', num2str(yy(55),4)])
disp(['c11_E Plant: ',num2str(results.xmeascomp.c11_E,4), '   Model: ', num2str(yy(56),4)])
disp(['c11_F Plant: ',num2str(results.xmeascomp.c11_F,4), '   Model: ', num2str(yy(57),4)])
disp(['c11_G Plant: ',num2str(results.xmeascomp.c11_G,4), '   Model: ', num2str(yy(58),4)])
disp(['c11_H Plant: ',num2str(results.xmeascomp.c11_H,4), '   Model: ', num2str(yy(59),4)])
 sum(yy(52:59))
disp(' ')
disp(['Pr Plant: ',num2str(setpoints.signals.values(5),4), '   Model: ', num2str(yy(60),4)])
disp(['Pm Plant: ',num2str(results.xmeas.Pstr,4), '   Model: ', num2str(yy(61),4)])



disp(' ')
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')



