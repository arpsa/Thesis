clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')

% delete(gcp('nocreate'))
addpath('Plant')
addpath('Model')
addpath('Functions')
 warning('on','all')
global Fp_0 r1_0 r2_0 r3_0 r4_0 r5_0 r6_0 r7_0 Eadj_0 SP17_0      ...
       xmv1_0 xmv2_0 xmv3_0 xmv4_0 xmv5_0 xmv6_0 xmv7_0 xmv8_0    ...
       xmv9_0 xmv10_0 xmv11_0 xmv12_0 xInitial XMV r xFinal XMEAS ...
       XMEASCOMP XMEASSTREAM XMEASRHO setpoints OpCost IDV x      ...
       Production Quality tout prev_setpoints
%%
KK = [0.3];
% Results = struct();   
for Method = [6 ] %  3 3 4 5 6 2 
    for iK =  [1 ] %
    K    = KK(iK);
    
    disp(' ')
    disp('*************************************************************')
    disp(['Method : ',num2str(Method)])
    disp(' ')
    
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.- Initialize plant at base case
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.1.- Tunable parameters
    Measurement_Noise = 0; % 0: without noise | 1: with noise
        MNoise.time           = 0;
        MNoise.signals.values = Measurement_Noise;
% 1.2.- Base case initialisation of states & simulation sampling times
    load Mode1xInitial
    Ts_base=0.0005;
    Ts_save=0.01;
% 1.3.- Initial setpoints 
    setpoints.time    = 0;
    setpoints.signals.values = [22.95; 50; 50; 65; 2800; 53.72; 100*32.19/(32.19+26.38); 32.19+26.38; 120.4; 1; 1; 100]';
    setpoints.signals.values = [20; 50; 50; 65; 2800; 39; 55; 59; 120; 1; 1; 100]';
    setpoints.signals.values = [20; 50; 50; 65; 2800; 30;60; 50; 120; 1; 1; 100]';
    prev_setpoints = setpoints;
    % 1.4.- Initial valve positions
    u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
    for i=1:12
        iChar=int2str(i);
        eval(['xmv',iChar,'_0=u0(',iChar,');']);
    end    
% 1.5.- Initial Controlers parameters
    Fp_0   = 100;
    r1_0   = 0.251/Fp_0;
    r2_0   = 3664/Fp_0;
    r3_0   = 4509/Fp_0;
    r4_0   = 9.35/Fp_0;
    r5_0   = 0.337/Fp_0;
    r6_0   = 25.16/Fp_0;
    r7_0   = 22.95/Fp_0;
    Eadj_0 = 0;
    SP17_0 = 80.1;   
% 1.6.- Launch simulation
    uk{1}   = setpoints.signals.values([1 6 7 8 9])';
    mode = 1;
    [yk, phi1k, phi2k, gk, geqk] = SimPlant(uk{1}, mode);
% 1.7.- Extract data
    results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2.- Define the model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Parameters = SetParameters(); % Set the model parameters
% 2.1.- Model inputs 
    uk{1} = setpoints.signals.values([1 6 7 8 9])';
    %       m11 %G C_A C_AC  Tr
    ub_u = [40  95 70  70   150];
    lb_u = [17   5 30  30   100]; 
    
    uk_s = (uk{1} - lb_u')./(ub_u' - lb_u') ;
% 2.2.- Initial states
    [x_m, x_sep, x_str, x_r, ub_m, lb_m, ub_r, lb_r, ub_sep, lb_sep, ...
     ub_str, lb_str, x_RSS, ub_RSS, lb_RSS, x_TE, ub_TE, lb_TE] = InitState(results);
    ub_xu = [ub_TE ub_u];
    lb_xu = [lb_TE lb_u];
    x_TEs = (x_TE - lb_TE')./(ub_TE' - lb_TE') ;
% 2.3.- Finit difference step size
% FD 1
  delta_M =[1e-4 1e-5 1e-4 0.9e-4 1e-4];
  delta_P =[1e-5 1e-5 1e-5 0.9e-4 1e-5];
%% 2.4.- Initialize the modifiers structure
    Modifiers{1} = struct();
    Modifiers{1}.type = 'none';
    Modifiers{1}.type_for_derivative = 'none';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% K    = 1;
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 3.- Algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 load initialisation_good      
    for k = 1:30
        if     Method == 1
            Modifiers{k}.type_for_derivative = 'MA'; 
        elseif Method == 11
            Modifiers{k}.type_for_derivative = 'CA'; 
        elseif Method == 2
            Modifiers{k}.type_for_derivative = 'MAy'; 
        elseif Method == 22
            Modifiers{k}.type_for_derivative = 'CAy'; 
        elseif Method == 3
            Modifiers{k}.type_for_derivative = 'iMAy1'; 
        elseif Method == 33
            Modifiers{k}.type_for_derivative = 'iCAy1'; 
        elseif Method == 4
            Modifiers{k}.type_for_derivative = 'iMAy2'; 
        elseif Method == 44
            Modifiers{k}.type_for_derivative = 'iCAy2'; 
        elseif Method == 5
            Modifiers{k}.type_for_derivative = 'iMA1'; 
        elseif Method == 6
            Modifiers{k}.type_for_derivative = 'iMA2'; 
        end
        disp(['Iteration : ',num2str(k)]);
        tic
        %% 3.1.- Measure the plant values and gradients
        uk_s = (uk{k} - lb_u')./(ub_u' - lb_u');
        Derivatives_P = derivatives_P(uk_s, uk{k}, delta_P, ub_u, lb_u, mode, Method);
        disp('     Derivatives Plant: ok')
        t = toc;
        disp(['       Time: ',num2str(t)]);
        %% 3.2.- Compute the model values and gradients
        tic
        Modifiers{k}.type = 'none';
        Derivatives_M = derivatives_M(uk_s, uk{k}, delta_M, Parameters, Modifiers{k}, Derivatives_P, ub_u, lb_u, x_TEs, lb_TE, ub_TE, x_m, lb_m, ub_m, x_RSS, lb_RSS, ub_RSS, mode, Derivatives_P);
        disp('     Derivatives Model: ok')
        t = toc;
        disp(['       Time: ',num2str(t)]);
        
        %% 3.3.- Compute the modifiers
        if Method == 1
            Modifiers{k}.type = 'MA'; 
            Modifiers{k}.uk   =  Derivatives_P.uk;
            Modifiers{k}.epsilon_phi1k = (Derivatives_P.phi1k     - Derivatives_M.phi1k     );
            Modifiers{k}.epsilon_phi2k = (Derivatives_P.phi2k     - Derivatives_M.phi2k     );
            Modifiers{k}.epsilon_gk    = (Derivatives_P.gk        - Derivatives_M.gk        );
            Modifiers{k}.epsilon_geqk  = (Derivatives_P.geqk      - Derivatives_M.geqk      );             
            Modifiers{k}.lambda_geqk   = (Derivatives_P.dgeqk_du  - Derivatives_M.dgeqk_du  );
            Modifiers{k}.lambda_gk     = (Derivatives_P.dgk_du    - Derivatives_M.dgk_du    ); 
            Modifiers{k}.lambda_phi2k  = (Derivatives_P.dphi2k_du - Derivatives_M.dphi2k_du );
            Modifiers{k}.lambda_phi1k  = (Derivatives_P.dphi1k_du - Derivatives_M.dphi1k_du );  
        elseif Method == 2
            Modifiers{k}.type = 'MAy'; 
            Modifiers{k}.uk         =  Derivatives_P.uk;
            Modifiers{k}.epsilon_yk = (Derivatives_P.yk     - Derivatives_M.yk    );
            Modifiers{k}.lambda_yk  = (Derivatives_P.dyk_du - Derivatives_M.dyk_du);
        elseif Method == 3
            Modifiers{k}.type = 'iMAy1'; 
            Modifiers{k}.uk   =  Derivatives_P.uk;
            Modifiers{k}.epsilon_iMAy1_yyk_1 = (Derivatives_P.yyk_1     - Derivatives_M.yyk_1_corr   );
            Modifiers{k}.epsilon_iMAy1_yyk_2 = (Derivatives_P.yyk_2     - Derivatives_M.yyk_2_corr   );
            Modifiers{k}.epsilon_iMAy1_yyk_3 = (Derivatives_P.yyk_3     - Derivatives_M.yyk_3_corr   );
            Modifiers{k}.lambda_iMAy1_yyk_1  = (Derivatives_P.dyyk_1_du - Derivatives_M.dyyk_1_du_corr);
            Modifiers{k}.lambda_iMAy1_yyk_2  = (Derivatives_P.dyyk_2_du - Derivatives_M.dyyk_2_du_corr);
            Modifiers{k}.lambda_iMAy1_yyk_3  = (Derivatives_P.dyyk_3_du - Derivatives_M.dyyk_3_du_corr);
        elseif Method == 4
            Modifiers{k}.type  = 'iMAy2'; 
            Modifiers{k}.uk    =  Derivatives_P.uk;
            Modifiers{k}.uuk_1 =  Derivatives_P.uuk_1;
            Modifiers{k}.uuk_2 =  Derivatives_P.uuk_2;
            Modifiers{k}.uuk_3 =  Derivatives_P.uuk_3;
            Modifiers{k}.epsilon_iMAy2_yyk_1 = (Derivatives_P.yyk_1       - Derivatives_M.yyk_1_corr );
            Modifiers{k}.epsilon_iMAy2_yyk_2 = (Derivatives_P.yyk_2       - Derivatives_M.yyk_2_corr );
            Modifiers{k}.epsilon_iMAy2_yyk_3 = (Derivatives_P.yyk_3       - Derivatives_M.yyk_3_corr );
            Modifiers{k}.lambda_iMAy2_yyk_1  = (Derivatives_P.dyyk_1_duu1 - Derivatives_M.dyyk_1_duu1);
            Modifiers{k}.lambda_iMAy2_yyk_2  = (Derivatives_P.dyyk_2_duu2 - Derivatives_M.dyyk_2_duu2);
            Modifiers{k}.lambda_iMAy2_yyk_3  = (Derivatives_P.dyyk_3_duu3 - Derivatives_M.dyyk_3_duu3);
        elseif Method == 5
            Modifiers{k}.type = 'iMA1'; 
            Modifiers{k}.uk   =  Derivatives_P.uk;
            Modifiers{k}.epsilon_iMA1_yyk_1 = (Derivatives_P.yyk_1     - Derivatives_M.yyk_1_corr   );
            Modifiers{k}.epsilon_iMA1_yyk_2 = (Derivatives_P.yyk_2     - Derivatives_M.yyk_2_corr   );
            Modifiers{k}.epsilon_iMA1_yyk_3 = (Derivatives_P.yyk_3     - Derivatives_M.yyk_3_corr   );
            Modifiers{k}.lambda_iMA1_yyk_1  = (Derivatives_P.dyyk_1_du - Derivatives_M.dyyk_1_du_corr);
            Modifiers{k}.lambda_iMA1_yyk_2  = (Derivatives_P.dyyk_2_du - Derivatives_M.dyyk_2_du_corr);
            Modifiers{k}.lambda_iMA1_yyk_3  = (Derivatives_P.dyyk_3_du - Derivatives_M.dyyk_3_du_corr);
        
            Modifiers{k}.epsilon_iMA1_phi1k = (Derivatives_P.phi1k     - Derivatives_M.phi1k_corr     );
            Modifiers{k}.epsilon_iMA1_phi2k = (Derivatives_P.phi2k     - Derivatives_M.phi2k_corr     );
            Modifiers{k}.epsilon_iMA1_gk    = (Derivatives_P.gk        - Derivatives_M.gk_corr        );
            Modifiers{k}.epsilon_iMA1_geqk  = (Derivatives_P.geqk      - Derivatives_M.geqk_corr      );             
            Modifiers{k}.lambda_iMA1_geqk   = (Derivatives_P.dgeqk_du  - Derivatives_M.dgeqk_du_corr  );
            Modifiers{k}.lambda_iMA1_gk     = (Derivatives_P.dgk_du    - Derivatives_M.dgk_du_corr    ); 
            Modifiers{k}.lambda_iMA1_phi2k  = (Derivatives_P.dphi2k_du - Derivatives_M.dphi2k_du_corr' );
            Modifiers{k}.lambda_iMA1_phi1k  = (Derivatives_P.dphi1k_du - Derivatives_M.dphi1k_du_corr' );
            
        elseif Method == 6
            Modifiers{k}.type = 'iMA2';
            Modifiers{k}.uk    =  Derivatives_P.uk;
            Modifiers{k}.uuk_1 =  Derivatives_P.uuk_1;
            Modifiers{k}.uuk_2 =  Derivatives_P.uuk_2;
            Modifiers{k}.uuk_3 =  Derivatives_P.uuk_3;
            Modifiers{k}.epsilon_iMA2_yyk_1 = (Derivatives_P.yyk_1       - Derivatives_M.yyk_1_corr );
            Modifiers{k}.epsilon_iMA2_yyk_2 = (Derivatives_P.yyk_2       - Derivatives_M.yyk_2_corr );
            Modifiers{k}.epsilon_iMA2_yyk_3 = (Derivatives_P.yyk_3       - Derivatives_M.yyk_3_corr );
            Modifiers{k}.lambda_iMA2_yyk_1  = (Derivatives_P.dyyk_1_duu1 - Derivatives_M.dyyk_1_duu1);
            Modifiers{k}.lambda_iMA2_yyk_2  = (Derivatives_P.dyyk_2_duu2 - Derivatives_M.dyyk_2_duu2);
            Modifiers{k}.lambda_iMA2_yyk_3  = (Derivatives_P.dyyk_3_duu3 - Derivatives_M.dyyk_3_duu3);
            
            Modifiers{k}.epsilon_iMA2_phi1k = (Derivatives_P.phi1k     - Derivatives_M.phi1k_corr     );
            Modifiers{k}.epsilon_iMA2_phi2k = (Derivatives_P.phi2k     - Derivatives_M.phi2k_corr     );
            Modifiers{k}.epsilon_iMA2_gk    = (Derivatives_P.gk        - Derivatives_M.gk_corr        );
            Modifiers{k}.epsilon_iMA2_geqk  = (Derivatives_P.geqk      - Derivatives_M.geqk_corr      );                
            Modifiers{k}.lambda_iMA2_geqk   = (Derivatives_P.dgeqk_duu2  - Derivatives_M.dgeq_duu2_corr  );
            Modifiers{k}.lambda_iMA2_gk     = (Derivatives_P.dgk_duu2    - Derivatives_M.dg_duu2_corr    ); 
            Modifiers{k}.lambda_iMA2_phi2k  = (Derivatives_P.dphi2k_duu2' - Derivatives_M.dphi2_duu2_corr' );
            Modifiers{k}.lambda_iMA2_phi1k  = (Derivatives_P.dphi1k_duu2' - Derivatives_M.dphi1_duu2_corr' );
            
        end
        %% 3.4.- Solve the modified model-based optimization problem
        %%
        tic
        eflag = -1;
        temp = 1;
        PBstruct   = ProblemStructure();
        xu0s = [x_TEs_test ;uk_s_test];
%         for temp = [1 0.99 ] %0.9 0.8 1.1
%             if eflag < 1
%                 try
%                 [xus_sol, f, eflag, outpt, lambda, dx] = RunOptimization_UX_NEW(xu0s*temp, Parameters, lb_xu, ub_xu, mode, Modifiers{k}, K, uk{k}, Derivatives_P, lb_TE, ub_TE);
%                 end
%             end
%         end
tic
temp = 1;
%         for temp = [1 0.99 0.9] % 0.8 1.1
%             if eflag < 0
%                 try
                [xus_sol, f, eflag, outpt, lambda, dx] = RunOptimization_UX_NEW2(xu0s*temp, Parameters, lb_xu, ub_xu, mode, Modifiers{k}, K, uk{k}, Derivatives_P, lb_TE, ub_TE);
%                 end
%             end
%         end

        toc 
%         for temp = [1 0.99 0.9 0.8 1.1]
%             if eflag < 1
%                 xu0s = [x_TEs ;uk_s];
%                 try
%                 [xus_sol, f, eflag, outpt, lambda, dx] = RunOptimization_UX_NEW(xu0s*temp, Parameters, lb_xu, ub_xu, mode, Modifiers{k}, K, uk{k}, Derivatives_P, lb_TE, ub_TE);
%                 end
%             end
%         end
        xu_sol = (xus_sol).*(ub_xu'-lb_xu') + lb_xu';
        x_sol   = xu_sol(1:45);
        uk_sol = xu_sol(46:50);
        if eflag < 1
            warning('fmincon found no solution')
        end
        
        %% 3.5.- Filtering step
        uk{k+1} = K*(uk_sol-uk{k}) + uk{k};
        disp(['otp targeted: ',num2str(uk_sol(1)), '  ',num2str(uk_sol(2)), '  ',num2str(uk_sol(3)), '  ',num2str(uk_sol(4)), '  ',num2str(uk_sol(5))]); 
        %% (3.6.- Save data for the plots)
        Results{Method,iK}.phik(1,k)  = Derivatives_P.phi1k;
        Results{Method,iK}.phi2k(1,k) = Derivatives_P.phi2k;
        Results{Method,iK}.gk2(:,k)   = Derivatives_P.gk;
        Results{Method,iK}.geqk2(:,k) = Derivatives_P.geqk;
        Results{Method,iK}.uk(:,k)    = Derivatives_P.uk;
        Results{Method,iK}.uk(:,k+1)  = uk{k+1};
        Results{Method,iK}.yk(:,k)    = Derivatives_P.yk;
        
        
        Results{Method,iK}.K   = K;
    %%
        figure(1)
        subplot(1,5,1)
        plot(0:k, Results{Method,iK}.uk(1,(1:k+1)))
        
        subplot(1,5,2)
        plot(0:k, Results{Method,iK}.uk(2,(1:k+1)))
        subplot(1,5,3)
        plot(0:k, Results{Method,iK}.uk(3,(1:k+1)))
        subplot(1,5,4)
        plot(0:k, Results{Method,iK}.uk(4,(1:k+1)))
        subplot(1,5,5)
        plot(0:k, Results{Method,iK}.uk(5,(1:k+1)))
        
        figure(2)
        subplot(1,3,1)
        plot(0:k-1, Results{Method,iK}.gk2(2,(1:k)))
        subplot(1,3,2)
        plot(0:k-1, Results{Method,iK}.geqk2(1,(1:k)))
        if mode < 4
            subplot(1,3,3)
            plot(0:k-1, Results{Method,iK}.geqk2(2,(1:k)))
        end
        figure(3)
        plot( Results{Method,iK}.phik(1,:))
        title('phi')
        pause(2)
    end
    end
end
%%
Results_file_name = 'Test_MA5';
save(Results_file_name, 'Results')


%%

disp('  ')
disp('-------------- E N D --------------')
disp('  ')
