clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')

addpath('Plant')
addpath('Model')
addpath('Functions')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.- Initialize plant at base case
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.1.- Tunable parameters
    Measurement_Noise = 0; % 0: without noise | 1: with noise
        MNoise.time           = 0;
        MNoise.signals.values = Measurement_Noise;
% 1.2.- Base case initialisation of states & simulation sampling times
    load Mode1xInitial
    Ts_base=0.0005;
    Ts_save=0.01;
% 1.3.- Initial setpoints
    setpoints.time    = 0;
%     setpoints.signals.values = [21; 50; 50; 50; 2800; 53.8; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
%     setpoints.signals.values = [18; 40; 60; 60; 2500; 53.8; 100*32.2/(32.2+18.8); 32.2+18.8; 115; 1; 1; 100]';
    setpoints.signals.values = [21; 40; 60; 60; 2500; 10; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
% 1.4.- Initial valve positions
    u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
    for i=1:12
        iChar=int2str(i);
        eval(['xmv',iChar,'_0=u0(',iChar,');']);
    end
% 1.5.- Initial Controlers parameters
    Fp_0   = 100;
    r1_0   = 0.251/Fp_0;
    r2_0   = 3664/Fp_0;
    r3_0   = 4509/Fp_0;
    r4_0   = 9.35/Fp_0;
    r5_0   = 0.337/Fp_0;
    r6_0   = 25.16/Fp_0;
    r7_0   = 22.95/Fp_0;
    Eadj_0 = 0;
    SP17_0 = 80.1;
    
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2.- Lauch simulation
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sim('MultiLoop_mode1')

% %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % 3.- Extract data
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints);


%% Initialization model with plant values
PBstruct   = ProblemStructure();
Parameters = SetParameters();

% u_m = [c_Asp; c_ACsp; F5; F6; F8; Pr; T8; Tstr; c5; c8];
% x_m = [c6_B; c6_D; c6_E; c6_F; c6_G];
% y_m = [F1; F2; F3; Tm; Pm; c6];
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Inputs definition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs variables
m11_sp   = setpoints.signals.values(1);
Vpstr_sp = setpoints.signals.values(2);
Vpsep_sp = setpoints.signals.values(3);
Vpr_sp   = setpoints.signals.values(4);
Pr_sp    = setpoints.signals.values(5);
Tstr     = results.xmeas.Tstr;
c_Asp    = setpoints.signals.values(7);
c_ACsp   = setpoints.signals.values(8);
Tr_sp    = setpoints.signals.values(9);
msteam   = results.xmeas.m_steam ;
cG11_sp  = setpoints.signals.values(6);
F6       = results.xmeasstream.F6;


u(1)  = m11_sp;
u(2)  = Vpstr_sp;
u(3)  = Vpsep_sp;
u(4)  = Vpr_sp;
u(5)  = Pr_sp;
u(6)  = Tstr; 
u(7)  = c_Asp;
u(8)  = c_ACsp;
u(9)  = Tr_sp;
u(10) = msteam;
u(11) = cG11_sp;
u(12) = F6;

% x_m = x_m = [c6_B; c6_D; c6_E; c6_F; c6_G; F1; F2; F3];
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
tic
x0_m = [results.xmeascomp.c6_B; results.xmeascomp.c6_D; results.xmeascomp.c6_E; results.xmeascomp.c6_F; results.xmeascomp.c6_G; results.xmeasstream.F1; results.xmeasstream.F2; results.xmeasstream.F3; results.xmeasstream.F8]; 
ub_m = [0.999 0.999 0.999 0.999 0.999 2000 2000 2000 5000];
lb_m = [0     0     0     0     0        1    1    1    1];

x0_r = [results.xmeascomp.c7_A; results.xmeascomp.c7_B; results.xmeascomp.c7_C; results.xmeascomp.c7_D; results.xmeascomp.c7_E; results.xmeascomp.c7_F; results.xmeascomp.c7_G; results.xmeasstream.F6]; 
ub_r = [0.999 0.999 0.999 0.999 0.999 0.999 0.999 5000];
lb_r = [0     0     0     0     0     0     0      100];

x0_sep = [ results.xmeascomp.c8_A; results.xmeascomp.c8_B;results.xmeascomp.c8_C; results.xmeascomp.c8_D; results.xmeascomp.c8_E; results.xmeascomp.c8_F; results.xmeascomp.c8_G; ...
           results.xmeas.Psep   ; results.xmeasstream.F9; results.xmeas.Tsep ]; 
ub_sep = [0.999 0.999 0.999 0.999 0.999 0.999 0.999 4000  100 200];
lb_sep = [0     0     0     0     0     0     0      100    0  30];
    
x0_str = [results.xmeasstream.F4; results.xmeasstream.F5; results.xmeasstream.F10; results.xmeasstream.F11]; 
ub_str = [1500  1500  1500  1500];
lb_str = [   1     1     1     1];
 


% x0 = [results.xmeascomp.c5_B; results.xmeascomp.c5_A; results.xmeascomp.c5_C; results.xmeascomp.c5_D; results.xmeascomp.c5_E; results.xmeascomp.c5_F; results.xmeascomp.c5_G; ...
%       results.xmeascomp.c8_A; results.xmeascomp.c8_B; results.xmeascomp.c8_C; results.xmeascomp.c8_D; results.xmeascomp.c8_E; results.xmeascomp.c8_F; results.xmeascomp.c8_G; ...
%       results.xmeasstream.F5; results.xmeasstream.F6; results.xmeasstream.F7; results.xmeasstream.F10; results.xmeas.Tsep;...
%       x0_m; ...
%       x0_r; ...
%       x0_sep; ...
%       x0_str];
%   
% x0 = x0*0.5;

load xx0

ub_x = [0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 1500 5000 5000 5000 200];
lb_x = [0     0     0     0     0     0     0     0     0     0     0     0     0     0     1    100   100    1  30];

ub = [ub_x ub_m ub_r ub_sep ub_str];
lb = [lb_x lb_m lb_r lb_sep lb_str];

PBstruct   = ProblemStructure();
%%
x0s = (x0 - lb')./(ub' - lb') ;
ubs =  ones(1,length(ub));
lbs = zeros(1,length(ub));
% ubs = 2*ones(1,length(ub));
% lbs = ones(1,length(ub));
tic
PBstruct   = ProblemStructure();
% xs_sol = lsqnonlin(@(xs) SimTE(xs, u, Parameters, ub, lb),x0s,lbs,ubs,PBstruct.lsqnonlin_options);
xs_sol = RunOptimization(x0s, u, Parameters, lbs, ubs,lb, ub, PBstruct.fmincon_options);
toc
[test, y, test2] = SimTE(xs_sol, u, Parameters, ub, lb);
%%
toc

disp(['F1   Plant: ',num2str(results.xmeasstream.F1,4),  '   Model: ', num2str(y(1),4)])
disp(['F2   Plant: ',num2str(results.xmeasstream.F2,4),  '   Model: ', num2str(y(2),4)])
disp(['F3   Plant: ',num2str(results.xmeasstream.F3,4),  '   Model: ', num2str(y(3),4)])
disp(['F4   Plant: ',num2str(results.xmeasstream.F4,4),  '   Model: ', num2str(y(4),4)])
disp(['F5   Plant: ',num2str(results.xmeasstream.F5,4),  '   Model: ', num2str(y(5),4)])
disp(['F6   Plant: ',num2str(results.xmeasstream.F6,4),  '   Model: ', num2str(y(6),4)])
disp(['F7   Plant: ',num2str(results.xmeasstream.F7,4),  '   Model: ', num2str(y(7),4)])
disp(['F8   Plant: ',num2str(results.xmeasstream.F8,4),  '   Model: ', num2str(y(8),4)])
disp(['F9   Plant: ',num2str(results.xmeasstream.F9,4),  '   Model: ', num2str(y(9),4)])
disp(['F10  Plant: ',num2str(results.xmeasstream.F10,4), '   Model: ', num2str(y(10),4)])
disp(['F11  Plant: ',num2str(results.xmeasstream.F11,4), '   Model: ', num2str(y(11),4)])

disp(' ')
disp(['c5_A Plant: ',num2str(results.xmeascomp.c5_A,4), '   Model: ', num2str(y(12),4)])
disp(['c5_B Plant: ',num2str(results.xmeascomp.c5_B,4), '   Model: ', num2str(y(13),4)])
disp(['c5_C Plant: ',num2str(results.xmeascomp.c5_C,4), '   Model: ', num2str(y(14),4)])
disp(['c5_D Plant: ',num2str(results.xmeascomp.c5_D,4), '   Model: ', num2str(y(15),4)])
disp(['c5_E Plant: ',num2str(results.xmeascomp.c5_E,4), '   Model: ', num2str(y(16),4)])
disp(['c5_F Plant: ',num2str(results.xmeascomp.c5_F,4), '   Model: ', num2str(y(17),4)])
disp(['c5_G Plant: ',num2str(results.xmeascomp.c5_G,4), '   Model: ', num2str(y(18),4)])
disp(['c5_H Plant: ',num2str(results.xmeascomp.c5_H,4), '   Model: ', num2str(y(19),4)])

disp(' ')
disp(['c6_A Plant: ',num2str(results.xmeascomp.c6_A,4), '   Model: ', num2str(y(20),4)])
disp(['c6_B Plant: ',num2str(results.xmeascomp.c6_B,4), '   Model: ', num2str(y(21),4)])
disp(['c6_C Plant: ',num2str(results.xmeascomp.c6_C,4), '   Model: ', num2str(y(22),4)])
disp(['c6_D Plant: ',num2str(results.xmeascomp.c6_D,4), '   Model: ', num2str(y(23),4)])
disp(['c6_E Plant: ',num2str(results.xmeascomp.c6_E,4), '   Model: ', num2str(y(24),4)])
disp(['c6_F Plant: ',num2str(results.xmeascomp.c6_F,4), '   Model: ', num2str(y(25),4)])
disp(['c6_G Plant: ',num2str(results.xmeascomp.c6_G,4), '   Model: ', num2str(y(26),4)])
disp(['c6_H Plant: ',num2str(results.xmeascomp.c6_H,4), '   Model: ', num2str(y(27),4)])

disp(' ')
disp(['c7_A Plant: ',num2str(results.xmeascomp.c7_A,4), '   Model: ', num2str(y(28),4)])
disp(['c7_B Plant: ',num2str(results.xmeascomp.c7_B,4), '   Model: ', num2str(y(29),4)])
disp(['c7_C Plant: ',num2str(results.xmeascomp.c7_C,4), '   Model: ', num2str(y(30),4)])
disp(['c7_D Plant: ',num2str(results.xmeascomp.c7_D,4), '   Model: ', num2str(y(31),4)])
disp(['c7_E Plant: ',num2str(results.xmeascomp.c7_E,4), '   Model: ', num2str(y(32),4)])
disp(['c7_F Plant: ',num2str(results.xmeascomp.c7_F,4), '   Model: ', num2str(y(33),4)])
disp(['c7_G Plant: ',num2str(results.xmeascomp.c7_G,4), '   Model: ', num2str(y(34),4)])
disp(['c7_H Plant: ',num2str(results.xmeascomp.c7_H,4), '   Model: ', num2str(y(35),4)])

disp(' ')
disp(['c8_A Plant: ',num2str(results.xmeascomp.c8_A,4), '   Model: ', num2str(y(36),4)])
disp(['c8_B Plant: ',num2str(results.xmeascomp.c8_B,4), '   Model: ', num2str(y(37),4)])
disp(['c8_C Plant: ',num2str(results.xmeascomp.c8_C,4), '   Model: ', num2str(y(38),4)])
disp(['c8_D Plant: ',num2str(results.xmeascomp.c8_D,4), '   Model: ', num2str(y(39),4)])
disp(['c8_E Plant: ',num2str(results.xmeascomp.c8_E,4), '   Model: ', num2str(y(40),4)])
disp(['c8_F Plant: ',num2str(results.xmeascomp.c8_F,4), '   Model: ', num2str(y(41),4)])
disp(['c8_G Plant: ',num2str(results.xmeascomp.c8_G,4), '   Model: ', num2str(y(42),4)])
disp(['c8_H Plant: ',num2str(results.xmeascomp.c8_H,4), '   Model: ', num2str(y(43),4)])

disp(' ')
disp(['c9_A Plant: ',num2str(results.xmeascomp.c9_A,4), '   Model: ', num2str(y(44),4)])
disp(['c9_B Plant: ',num2str(results.xmeascomp.c9_B,4), '   Model: ', num2str(y(45),4)])
disp(['c9_C Plant: ',num2str(results.xmeascomp.c9_C,4), '   Model: ', num2str(y(46),4)])
disp(['c9_D Plant: ',num2str(results.xmeascomp.c9_D,4), '   Model: ', num2str(y(47),4)])
disp(['c9_E Plant: ',num2str(results.xmeascomp.c9_E,4), '   Model: ', num2str(y(48),4)])
disp(['c9_F Plant: ',num2str(results.xmeascomp.c9_F,4), '   Model: ', num2str(y(49),4)])
disp(['c9_G Plant: ',num2str(results.xmeascomp.c9_G,4), '   Model: ', num2str(y(50),4)])
disp(['c9_H Plant: ',num2str(results.xmeascomp.c9_H,4), '   Model: ', num2str(y(51),4)])

disp(' ')
disp(['c10_A Plant: ',num2str(results.xmeascomp.c10_A,4), '   Model: ', num2str(y(52),4)])
disp(['c10_B Plant: ',num2str(results.xmeascomp.c10_B,4), '   Model: ', num2str(y(53),4)])
disp(['c10_C Plant: ',num2str(results.xmeascomp.c10_C,4), '   Model: ', num2str(y(54),4)])
disp(['c10_D Plant: ',num2str(results.xmeascomp.c10_D,4), '   Model: ', num2str(y(55),4)])
disp(['c10_E Plant: ',num2str(results.xmeascomp.c10_E,4), '   Model: ', num2str(y(56),4)])
disp(['c10_F Plant: ',num2str(results.xmeascomp.c10_F,4), '   Model: ', num2str(y(57),4)])
disp(['c10_G Plant: ',num2str(results.xmeascomp.c10_G,4), '   Model: ', num2str(y(58),4)])
disp(['c10_H Plant: ',num2str(results.xmeascomp.c10_H,4), '   Model: ', num2str(y(59),4)])

disp(' ')
disp(['c11_A Plant: ',num2str(results.xmeascomp.c11_A,4), '   Model: ', num2str(y(60),4)])
disp(['c11_B Plant: ',num2str(results.xmeascomp.c11_B,4), '   Model: ', num2str(y(61),4)])
disp(['c11_C Plant: ',num2str(results.xmeascomp.c11_C,4), '   Model: ', num2str(y(62),4)])
disp(['c11_D Plant: ',num2str(results.xmeascomp.c11_D,4), '   Model: ', num2str(y(63),4)])
disp(['c11_E Plant: ',num2str(results.xmeascomp.c11_E,4), '   Model: ', num2str(y(64),4)])
disp(['c11_F Plant: ',num2str(results.xmeascomp.c11_F,4), '   Model: ', num2str(y(65),4)])
disp(['c11_G Plant: ',num2str(results.xmeascomp.c11_G,4), '   Model: ', num2str(y(66),4)])
disp(['c11_H Plant: ',num2str(results.xmeascomp.c11_H,4), '   Model: ', num2str(y(67),4)])

disp(' ')
disp(['tsep Plant: ',num2str(results.xmeas.Tsep,4), '   Model: ', num2str(y(68),4)])

disp(' ')
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')
