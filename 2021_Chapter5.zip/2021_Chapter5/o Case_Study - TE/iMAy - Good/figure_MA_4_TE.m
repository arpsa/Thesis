load Test_MA5
Results2 = Results;
load Test2_total3
Ki = 3;
k = 30; 

%%  PHI
figure
% subaxis(2,4,1, 'Spacing', 0.03, 'Padding', 0, 'Margin', 0, 'SpacingVert', 0.03);
subplot(2,4,1)
hold on
p1 = plot(0:k-1, Results2{1,1}.phik(1:k), 'bo', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
p2 = plot(0:k-1, Results{3,Ki}.phik(1:k), 'mo', 'Color','m', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','m');
p3 = plot(0:k-1, Results{4,Ki}.phik(1:k), 'ko', 'Color','k', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','k');
p4 = plot(0:k-1, Results{3,Ki}.phik(end)*ones(1,k), 'g', 'Color','g', 'LineStyle','-', 'LineWidth', 2);
p4 = plot(0:k-1, ones(1,k), 'r', 'Color','r', 'LineStyle','--', 'LineWidth', 2);
 hLegend = legend( 'MA','IMA-A','IMA-B','Optimum', 'Equality constraint','location', 'NorthEast');
 ylim([105 380])
 xlim([0 30])
%     hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$\phi$ [\$/h]');
%     set([hXLabel, hYLabel],'FontSize', 29 ,'Interpreter','LaTex');
    set(hYLabel,'FontSize', 29 ,'Interpreter','LaTex');
    set(gca,'FontSize',29);
    set(hLegend,'FontSize', 21 ,'Interpreter','LaTex');
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gca,'XTickLabel',[])
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=16; y_width=14;  
%     set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['TE_',num2str(Ki),'_phi'])


%  GEQ 1
% figure
subplot(2,4,2)
hold on
p1 = plot(0:k-1, Results2{1,1}.geqk2(1,(1:k)) + 1 , 'bo', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
p2 = plot(0:k-1, Results{3,Ki}.geqk2(1,(1:k)) + 1, 'mo', 'Color','m', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','m');
p3 = plot(0:k-1, Results{4,Ki}.geqk2(1,(1:k)) + 1 , 'ko', 'Color','k', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','k');
p4 = plot(0:k-1, Results{3,Ki}.geqk2(1,end)*ones(1,k) + 1, 'r', 'Color','r', 'LineStyle','--', 'LineWidth', 2);
    ylim([0 2.5])
    
 xlim([0 30])
%     hXLabel = xlabel('Iterations');
    hYLabel = ylabel('Quality [-]');
%     set([hXLabel, hYLabel],'FontSize', 29 ,'Interpreter','LaTex');
    set([hYLabel],'FontSize', 29 ,'Interpreter','LaTex');
    set(gca,'FontSize',29);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gca,'XTickLabel',[])
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=16; y_width=14;  
%     set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['TE_',num2str(Ki),'_geq1'])

%  GEQ 2
% figure
subplot(2,4,3)
hold on
p1 = plot(0:k-1, Results2{1,1}.geqk2(2,(1:k))*1e5 + 14076, 'bo', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
p2 = plot(0:k-1, Results{3,Ki}.geqk2(2,(1:k))*1e5 + 14076, 'mo', 'Color','m', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','m');
p3 = plot(0:k-1, Results{4,Ki}.geqk2(2,(1:k))*1e5 + 14076, 'ko', 'Color','k', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','k');
p4 = plot(0:k-1, Results{3,Ki}.geqk2(2,end)*ones(1,k)*1e5 + 14076, 'r', 'Color','r', 'LineStyle','--', 'LineWidth', 2);
 xlim([0 30])
%     hXLabel = xlabel('Iterations');
    hYLabel = ylabel(' Production [kg/h]');
%     set([hXLabel, hYLabel],'FontSize', 29 ,'Interpreter','LaTex');
    set([hYLabel],'FontSize', 29 ,'Interpreter','LaTex');
    set(gca,'FontSize',29);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gca,'XTickLabel',[])
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=16; y_width=14;  
%     set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['TE_',num2str(Ki),'_geq2'])

%  u1
% figure
subplot(2,4,4)
% p1 = plot( Results{2}.uk(1,(1:k)), 'k');
hold on
p1 = plot(0:k, Results2{1,1}.uk(1,(1:k+1)), 'bo', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
p3 = plot(0:k, Results{3,Ki}.uk(1,(1:k+1)), 'mo', 'Color','m', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','m');
p2 = plot(0:k, Results{4,Ki}.uk(1,(1:k+1)), 'ko', 'Color','k', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','k');
p4 = plot(0:k, Results{4,Ki}.uk(1,k+1)*ones(1,k+1), 'g', 'Color','g', 'LineStyle','-', 'LineWidth', 2);
%     hXLabel = xlabel('Iterations');
    hYLabel = ylabel(' $m_{11}^{sp}$ [kg/h]');
     xlim([0 30])
%     set([hXLabel, hYLabel],'FontSize', 29 ,'Interpreter','LaTex');
    set([hYLabel],'FontSize', 29 ,'Interpreter','LaTex');
    set(gca,'FontSize',29);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gca,'XTickLabel',[])
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=16; y_width=14;  
%     set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['TE_',num2str(Ki),'_u1'])
    
%  u2
% figure
subplot(2,4,5)
hold on
p1 = plot(0:k, Results2{1,1}.uk(2,(1:k+1)), 'bo', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
p2 = plot(0:k, Results{3,Ki}.uk(2,(1:k+1)), 'mo', 'Color','m', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','m');
p3 = plot(0:k, Results{4,Ki}.uk(2,(1:k+1)), 'ko', 'Color','k', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','k');
p4 = plot(0:k, Results{4,Ki}.uk(2,k+1)*ones(1,k+1), 'g', 'Color','g', 'LineStyle','-', 'LineWidth', 2);
    ylim([0 80])
    xlim([0 30])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel(' $\% G^{sp}$ [-]');
    set([hXLabel, hYLabel],'FontSize', 29 ,'Interpreter','LaTex');
    set(gca,'FontSize',29);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=16; y_width=14;  
%     set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['TE_',num2str(Ki),'_u2'])
    
%  u3
% figure
subplot(2,4,6)
% p1 = plot( Results{2}.uk(3,(1:k)), 'k');
hold on
p1 = plot(0:k, Results2{1,1}.uk(3,(1:k+1)), 'bo', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
p2 = plot(0:k, Results{3,Ki}.uk(3,(1:k+1)), 'mo', 'Color','m', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','m');
p3 = plot(0:k, Results{4,Ki}.uk(3,(1:k+1)), 'ko', 'Color','k', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','k');
p4 = plot(0:k, (Results{3,Ki}.uk(3,k+1)+Results{3,Ki}.uk(3,k))/2*ones(1,k+1), 'g', 'Color','g', 'LineStyle','-', 'LineWidth', 2);
	xlim([0 30])    
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel(' $c_A^{sp}$ [-]');
    set([hXLabel, hYLabel],'FontSize', 29 ,'Interpreter','LaTex');
    set(gca,'FontSize',29);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=16; y_width=14;  
%     set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['TE_',num2str(Ki),'_u3']);
    
%  u4
% figure
subplot(2,4,7)
% p1 = plot( Results{2}.uk(4,(1:k)), 'k');
hold on
p1 = plot(0:k, Results2{1,1}.uk(4,(1:k+1)), 'bo', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
p2 = plot(0:k, Results{3,Ki}.uk(4,(1:k+1)), 'mo', 'Color','m', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','m');
p3 = plot(0:k, Results{4,Ki}.uk(4,(1:k+1)), 'ko', 'Color','k', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','k');
p4 = plot(0:k, (Results{3,Ki}.uk(4,k+1)+Results{3,Ki}.uk(4,k))/2*ones(1,k+1), 'g', 'Color','g', 'LineStyle','-', 'LineWidth', 2);
    xlim([0 30])    
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel(' $c_{AC}^{sp}$ [-]');
    set([hXLabel, hYLabel],'FontSize', 29 ,'Interpreter','LaTex');
    set(gca,'FontSize',29);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=16; y_width=14;  
%     set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['TE_',num2str(Ki),'_u4']);
    
%  u5
% figure
subplot(2,4,8)
% figure
% p1 = plot( Results{2}.uk(4,(1:k)), 'k');
hold on
p1 = plot(0:k, Results2{1,1}.uk(5,(1:k+1)), 'bo', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
p2 = plot(0:k, Results{3,Ki}.uk(5,(1:k+1)), 'mo', 'Color','m', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','m');
p3 = plot(0:k, Results{4,Ki}.uk(5,(1:k+1)), 'ko', 'Color','k', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','k');
p4 = plot(0:k, (Results{3,Ki}.uk(5,k+1)+Results{3,Ki}.uk(5,k))/2*ones(1,k+1), 'g', 'Color','g', 'LineStyle','-', 'LineWidth', 2);
    xlim([0 30])    
    ylim([115 135])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel(' $T_r$ [$^o$C]');
    set([hXLabel, hYLabel],'FontSize', 29 ,'Interpreter','LaTex');
    set(gca,'FontSize',29);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=16; y_width=14;  
%     set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['TE_',num2str(Ki),'_u5']);

    set(gcf, 'PaperUnits', 'centimeters');
    x_width=16*4.4; y_width=14*2.2;  
    set(gcf, 'PaperPosition', [0 0 x_width y_width]);
    print('-painters','-depsc','TE_Results')
%% distance to optimum:
% % 
%     u_opt = (Results{3,Ki}.uk(:,end)+Results{3,Ki}.uk(:,end-1))/2;
% for i = 1:k
%     dist_iMAy1(i) =  norm(abs(u_opt-Results{3}.uk(:,i))./abs(u_opt));
%     dist_iMAy2(i) =  norm(abs(u_opt-Results{4}.uk(:,i))./abs(u_opt));
%     dist_iMA1(i) =  norm(abs(u_opt-Results{5}.uk(:,i))./abs(u_opt));
%     dist_iMA2(i) =  norm(abs(u_opt-Results{6}.uk(:,i))./abs(u_opt));
% end
% 
% figure
% semilogy(dist_iMAy1, '--m')
% hold on
% semilogy(dist_iMAy2, '-m')
% semilogy(dist_iMA1, '--k')
% semilogy(dist_iMA2, '-k')







