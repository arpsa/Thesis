clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')

addpath('Plant')
addpath('Model')
addpath('Functions')




%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.- Initialize plant at base case
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.1.- Tunable parameters
    Measurement_Noise = 0; % 0: without noise | 1: with noise
        MNoise.time           = 0;
        MNoise.signals.values = Measurement_Noise;
% 1.2.- Base case initialisation of states & simulation sampling times
    load Mode1xInitial
    Ts_base=0.0005;
    Ts_save=0.01;
% 1.3.- Initial setpoints
    setpoints.time    = 0;
    % mode 1
%     1.- m11_sp      5.- Pr_sp     9.- Tr_sp
%     2.- Vpstr_sp    6.- cG11_sp  10.- v_recycle
%     3.- Vpsep_sp    7.- c_Asp    11.- steam_valve
%     4.- Vpr_sp      8.- c_ACsp   12.- omega_r
%     setpoints.signals.values = [22.89; 50; 50; 65; 2800; 53.83; 100*32.19/(32.19+26.38); 32.19+26.38; 122.9; 1; 1; 100]';
    setpoints.signals.values = [21; 40; 60; 60; 2500; 10; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
prev_setpoints = setpoints;
% 1.4.- Initial valve positions
   u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
%      u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
    for i=1:12
        iChar=int2str(i);
        eval(['xmv',iChar,'_0=u0(',iChar,');']);
    end
% 1.5.- Initial Controlers parameters
    Fp_0   = 100;
    r1_0   = 0.251/Fp_0;
    r2_0   = 3664/Fp_0;
    r3_0   = 4509/Fp_0;
    r4_0   = 9.35/Fp_0;
    r5_0   = 0.337/Fp_0;
    r6_0   = 25.16/Fp_0;
    r7_0   = 22.95/Fp_0;
    Eadj_0 = 0;
    SP17_0 = 80.1;
    
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2.- Lauch simulation
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sim('MultiLoop_mode1')

%% %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % 3.- Extract data
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost);


%% Initialization model with plant values
PBstruct   = ProblemStructure();
Parameters = SetParameters();

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Inputs definition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs variables
m11_sp   = setpoints.signals.values(1);
Vpstr_sp = setpoints.signals.values(2);
Vpsep_sp = setpoints.signals.values(3);
Vpr_sp   = setpoints.signals.values(4);
Pr_sp    = setpoints.signals.values(5);
cG11_sp  = setpoints.signals.values(6);
c_Asp    = setpoints.signals.values(7);
c_ACsp   = setpoints.signals.values(8);
Tr_sp    = setpoints.signals.values(9);
vsteam   = setpoints.signals.values(10);
F6       = results.xmeasstream.F6;

u = zeros(5,1);
u(1)  = m11_sp;
% u(2)  = Vpr_sp;
% u(3)  = Pr_sp;
u(2) = cG11_sp;
u(3)  = c_Asp;
u(4)  = c_ACsp;
u(5)  = Tr_sp;
% u(10) = vsteam;


% x_m = x_m = [c6_B; c6_D; c6_E; c6_F; c6_G; F1; F2; F3];
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
tic
x_m   = [results.xmeascomp.c6_B; results.xmeascomp.c6_D; results.xmeascomp.c6_E; results.xmeascomp.c6_F; results.xmeascomp.c6_G; results.xmeasstream.F1; results.xmeasstream.F2; results.xmeasstream.F3; results.xmeasstream.F8]*1; 
x_sep = [ results.xmeascomp.c8_A; results.xmeascomp.c8_B;results.xmeascomp.c8_C; results.xmeascomp.c8_D; results.xmeascomp.c8_E; results.xmeascomp.c8_F; results.xmeascomp.c8_G; ...
          results.xmeas.Psep   ; results.xmeasstream.F9; results.xmeas.Tsep ]; 
x_str = [results.xmeasstream.F4; results.xmeasstream.F5; results.xmeasstream.F10; results.xmeasstream.F11]; 
ub_m   = [0.999 0.999 0.999 0.999 0.999 3000 3000 3000 3000];
lb_m   = [0     0     0     0     0        0    0    0    0];
ub_sep = [0.9 0.9 0.9 0.9 0.9 0.9 0.9 5000 50 150];
lb_sep = [0   0   0   0   0   0   0      1  0  60];
ub_str = [3000  3000  3000  3000];
lb_str = [   1     1     1     1];

x0_MCSSC = [results.xmeascomp.c5_A; results.xmeascomp.c5_B; results.xmeascomp.c5_C; ...
      results.xmeascomp.c5_D; results.xmeascomp.c5_E; results.xmeascomp.c5_F; ...
      results.xmeascomp.c5_G;  ...
      results.xmeasstream.F5;  results.xmeasstream.F10; results.xmeas.Tstr; ...
      x_m; x_sep; x_str];
ub_x = [0.999 0.999 0.999 0.999 0.999 0.999 0.999 3000 3000 200];
lb_x = [0     0     0     0     0     0     0        1    1  20];

ub_MCSSC = [ub_x ub_m ub_sep ub_str];
lb_MCSSC = [lb_x lb_m lb_sep lb_str];


x0_r = [results.xmeascomp.c7_A; results.xmeascomp.c7_B; results.xmeascomp.c7_C; results.xmeascomp.c7_D; results.xmeascomp.c7_E; results.xmeascomp.c7_F; results.xmeascomp.c7_G; F6]; 
ub_r = [0.999 0.999 0.999 0.999 0.999 0.999 0.999 5000];
lb_r = [0     0     0     0     0     0     0        0];

x0_x2 = [results.xmeasstream.F7; results.xmeasstream.F8; results.xmeasstream.F9; ...
         results.xmeascomp.c6_A; results.xmeascomp.c6_B; results.xmeascomp.c6_C ; ...
         results.xmeascomp.c6_D; results.xmeascomp.c6_E; results.xmeascomp.c6_F ; ...
         results.xmeascomp.c6_G; results.xmeascomp.c6_H; ...
         results.xmeascomp.c8_A; results.xmeascomp.c8_B; results.xmeascomp.c8_C ; ...
         results.xmeascomp.c8_D; results.xmeascomp.c8_E; results.xmeascomp.c8_F ; ...
         results.xmeascomp.c8_G; results.xmeascomp.c8_H]; 
ub_x2 = [3000 3000 100 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999];
lb_x2 = [   1    1   0 0     0     0     0     0     0     0     0     0     0     0     0     0     0     0     0    ];


x0 = [x0_MCSSC; x0_r; x0_x2];
ub = [ub_MCSSC ub_r ub_x2]; %
lb = [lb_MCSSC lb_r lb_x2]; %

PBstruct   = ProblemStructure();
%%
clc
x0s = (x0 - lb')./(ub' - lb') ;
x0s = x0s*0.5;
tic
PBstruct   = ProblemStructure();
Modifiers.type = 'none';
xs_sol = RunOptimization_2SubSystems(x0s, u, Parameters,lb, ub, Modifiers);
toc
x_sol  = (xs_sol).*(ub'-lb') + lb';
[test, y, yy] = SimTE_2SubSystems(x_sol, u, Parameters, Modifiers);
toc

mode = 1;
[phi1, phi2, g, geq] = uy2phig2(u, y, mode, Modifiers,Parameters);

%%
disp(['F1   Plant: ',num2str(results.xmeasstream.F1,4), '   Model: ', num2str(yy(1),4)])
disp(['F2   Plant: ',num2str(results.xmeasstream.F2,4), '   Model: ', num2str(yy(2),4)])
disp(['F3   Plant: ',num2str(results.xmeasstream.F3,4), '   Model: ', num2str(yy(3),4)])
disp(['F4   Plant: ',num2str(results.xmeasstream.F4,4), '   Model: ', num2str(yy(4),4)])
disp(['F5   Plant: ',num2str(results.xmeasstream.F5,4), '   Model: ', num2str(yy(5),4)])
disp(['F6   Plant: ',num2str(results.xmeasstream.F6,4), '   Model: ', num2str(yy(6),4)])
disp(['F7   Plant: ',num2str(results.xmeasstream.F7,4), '   Model: ', num2str(yy(7),4)])
disp(['F8   Plant: ',num2str(results.xmeasstream.F8,4), '   Model: ', num2str(yy(8),4)])
disp(['F9   Plant: ',num2str(results.xmeasstream.F9,4), '   Model: ', num2str(yy(9),4)])
disp(['F10  Plant: ',num2str(results.xmeasstream.F10,4),'   Model: ', num2str(yy(10),4)])
disp(['F11  Plant: ',num2str(results.xmeasstream.F11,4),'   Model: ', num2str(yy(11),4)])

disp(' ')
disp(['c5_A Plant: ',num2str(results.xmeascomp.c5_A,4), '   Model: ', num2str(yy(12),4)])
disp(['c5_B Plant: ',num2str(results.xmeascomp.c5_B,4), '   Model: ', num2str(yy(13),4)])
disp(['c5_C Plant: ',num2str(results.xmeascomp.c5_C,4), '   Model: ', num2str(yy(14),4)])
disp(['c5_D Plant: ',num2str(results.xmeascomp.c5_D,4), '   Model: ', num2str(yy(15),4)])
disp(['c5_E Plant: ',num2str(results.xmeascomp.c5_E,4), '   Model: ', num2str(yy(16),4)])
disp(['c5_F Plant: ',num2str(results.xmeascomp.c5_F,4), '   Model: ', num2str(yy(17),4)])
disp(['c5_G Plant: ',num2str(results.xmeascomp.c5_G,4), '   Model: ', num2str(yy(18),4)])
disp(['c5_H Plant: ',num2str(results.xmeascomp.c5_H,4), '   Model: ', num2str(yy(19),4)])
%  sum(yy(12:19))
disp(' ')
disp(['c6_A Plant: ',num2str(results.xmeascomp.c6_A,4), '   Model: ', num2str(yy(20),4)])
disp(['c6_B Plant: ',num2str(results.xmeascomp.c6_B,4), '   Model: ', num2str(yy(21),4)])
disp(['c6_C Plant: ',num2str(results.xmeascomp.c6_C,4), '   Model: ', num2str(yy(22),4)])
disp(['c6_D Plant: ',num2str(results.xmeascomp.c6_D,4), '   Model: ', num2str(yy(23),4)])
disp(['c6_E Plant: ',num2str(results.xmeascomp.c6_E,4), '   Model: ', num2str(yy(24),4)])
disp(['c6_F Plant: ',num2str(results.xmeascomp.c6_F,4), '   Model: ', num2str(yy(25),4)])
disp(['c6_G Plant: ',num2str(results.xmeascomp.c6_G,4), '   Model: ', num2str(yy(26),4)])
disp(['c6_H Plant: ',num2str(results.xmeascomp.c6_H,4), '   Model: ', num2str(yy(27),4)])
% sum(yy(20:27))
disp(' ')
disp(['c7_A Plant: ',num2str(results.xmeascomp.c7_A,4), '   Model: ', num2str(yy(28),4)])
disp(['c7_B Plant: ',num2str(results.xmeascomp.c7_B,4), '   Model: ', num2str(yy(29),4)])
disp(['c7_C Plant: ',num2str(results.xmeascomp.c7_C,4), '   Model: ', num2str(yy(30),4)])
disp(['c7_D Plant: ',num2str(results.xmeascomp.c7_D,4), '   Model: ', num2str(yy(31),4)])
disp(['c7_E Plant: ',num2str(results.xmeascomp.c7_E,4), '   Model: ', num2str(yy(32),4)])
disp(['c7_F Plant: ',num2str(results.xmeascomp.c7_F,4), '   Model: ', num2str(yy(33),4)])
disp(['c7_G Plant: ',num2str(results.xmeascomp.c7_G,4), '   Model: ', num2str(yy(34),4)])
disp(['c7_H Plant: ',num2str(results.xmeascomp.c7_H,4), '   Model: ', num2str(yy(35),4)])
 sum(yy(28:35))
disp(' ')
disp(['c8_A Plant: ',num2str(results.xmeascomp.c8_A,4), '   Model: ', num2str(yy(36),4)])
disp(['c8_B Plant: ',num2str(results.xmeascomp.c8_B,4), '   Model: ', num2str(yy(37),4)])
disp(['c8_C Plant: ',num2str(results.xmeascomp.c8_C,4), '   Model: ', num2str(yy(38),4)])
disp(['c8_D Plant: ',num2str(results.xmeascomp.c8_D,4), '   Model: ', num2str(yy(39),4)])
disp(['c8_E Plant: ',num2str(results.xmeascomp.c8_E,4), '   Model: ', num2str(yy(40),4)])
disp(['c8_F Plant: ',num2str(results.xmeascomp.c8_F,4), '   Model: ', num2str(yy(41),4)])
disp(['c8_G Plant: ',num2str(results.xmeascomp.c8_G,4), '   Model: ', num2str(yy(42),4)])
disp(['c8_H Plant: ',num2str(results.xmeascomp.c8_H,4), '   Model: ', num2str(yy(43),4)])

disp(' ')
disp(['c10_A Plant: ',num2str(results.xmeascomp.c10_A,4), '   Model: ', num2str(yy(44),4)])
disp(['c10_B Plant: ',num2str(results.xmeascomp.c10_B,4), '   Model: ', num2str(yy(45),4)])
disp(['c10_C Plant: ',num2str(results.xmeascomp.c10_C,4), '   Model: ', num2str(yy(46),4)])
disp(['c10_D Plant: ',num2str(results.xmeascomp.c10_D,4), '   Model: ', num2str(yy(47),4)])
disp(['c10_E Plant: ',num2str(results.xmeascomp.c10_E,4), '   Model: ', num2str(yy(48),4)])
disp(['c10_F Plant: ',num2str(results.xmeascomp.c10_F,4), '   Model: ', num2str(yy(49),4)])
disp(['c10_G Plant: ',num2str(results.xmeascomp.c10_G,4), '   Model: ', num2str(yy(50),4)])
disp(['c10_H Plant: ',num2str(results.xmeascomp.c10_H,4), '   Model: ', num2str(yy(51),4)])

disp(' ')
disp(['c11_A Plant: ',num2str(results.xmeascomp.c11_A,4), '   Model: ', num2str(yy(52),4)])
disp(['c11_B Plant: ',num2str(results.xmeascomp.c11_B,4), '   Model: ', num2str(yy(53),4)])
disp(['c11_C Plant: ',num2str(results.xmeascomp.c11_C,4), '   Model: ', num2str(yy(54),4)])
disp(['c11_D Plant: ',num2str(results.xmeascomp.c11_D,4), '   Model: ', num2str(yy(55),4)])
disp(['c11_E Plant: ',num2str(results.xmeascomp.c11_E,4), '   Model: ', num2str(yy(56),4)])
disp(['c11_F Plant: ',num2str(results.xmeascomp.c11_F,4), '   Model: ', num2str(yy(57),4)])
disp(['c11_G Plant: ',num2str(results.xmeascomp.c11_G,4), '   Model: ', num2str(yy(58),4)])
disp(['c11_H Plant: ',num2str(results.xmeascomp.c11_H,4), '   Model: ', num2str(yy(59),4)])

disp(' ')
disp(['Tr   Plant: ',num2str(results.xmeas.Tr,4),   '   Model: ', num2str(y(40),4)])

disp(' ')
disp(['VLr   Plant: ',num2str(results.xmeas.Vlr,4),  '   Model: ', num2str(y(41),4)])
disp(['VLsep Plant: ',num2str(results.xmeas.Vlsep,4),'   Model: ', num2str(y(42),4)])
disp(['VLstr Plant: ',num2str(results.xmeas.Vlstr,4),'   Model: ', num2str(y(43),4)]) 

disp(' ')
disp(['Pr   Plant: ',num2str(results.xmeas.Pr,4),  '   Model: ', num2str(y(44),4)])

disp(' ')
disp(['OPEX  Plant: ',num2str(results.OPEX,4),  '   Model: ', num2str(phi1,4)])
disp(['PRate Plant: ',num2str(-results.PRate,6), '   Model: ', num2str(-phi2,6)])



disp(' ')
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')
