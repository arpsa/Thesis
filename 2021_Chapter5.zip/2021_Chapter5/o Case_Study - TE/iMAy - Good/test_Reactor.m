clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')

addpath('Plant')
addpath('Model')
addpath('Functions')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.- Initialize plant at base case
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.1.- Tunable parameters
    Measurement_Noise = 0; % 0: without noise | 1: with noise
        MNoise.time           = 0;
        MNoise.signals.values = Measurement_Noise;
% 1.2.- Base case initialisation of states & simulation sampling times
    load Mode1xInitial
    Ts_base=0.0005;
    Ts_save=0.01;
% 1.3.- Initial setpoints
    setpoints.time    = 0;
    setpoints.signals.values = [21; 50; 50; 50; 2800; 53.8; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
    prev_setpoints = setpoints;
% 1.4.- Initial valve positions
    u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
    for i=1:12
        iChar=int2str(i);
        eval(['xmv',iChar,'_0=u0(',iChar,');']);
    end
% 1.5.- Initial Controlers parameters
    Fp_0   = 100;
    r1_0   = 0.251/Fp_0;
    r2_0   = 3664/Fp_0;
    r3_0   = 4509/Fp_0;
    r4_0   = 9.35/Fp_0;
    r5_0   = 0.337/Fp_0;
    r6_0   = 25.16/Fp_0;
    r7_0   = 22.95/Fp_0;
    Eadj_0 = 0;
    SP17_0 = 80.1;
    
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2.- Lauch simulation
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sim('MultiLoop_mode1')

% %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % 3.- Extract data
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost);


%% Initialization model with plant values
Parameters = SetParameters();

% u_r = [Prsp; lrsp; Trsp; F7; F6; c6];
% x_r = [c7_A; c7_B; c7_C; c7_D; c7_E; c7_F; c7_G];
% y_r = [F6; Pr; Tr; Vvapr; Vliqr; lr; Pir, c7];

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Inputs definition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs variables
Pr_sp   = results.u.Pr_sp;
Vpr_sp = results.u.Vpr_sp;
Tr_sp  = results.u.Tr_sp;
F7     = results.xmeasstream.F7;
F6     = results.xmeasstream.F6;
c6     = [results.xmeascomp.c6_A; results.xmeascomp.c6_B; results.xmeascomp.c6_C; ...
          results.xmeascomp.c6_D; results.xmeascomp.c6_E; results.xmeascomp.c6_F; ...
          results.xmeascomp.c6_G; results.xmeascomp.c6_H];

u_r = zeros(12,1);
u_r(1)     = Pr_sp;
u_r(2)     = Vpr_sp;
u_r(3)     = Tr_sp;
u_r(4)     = F7;
u_r(5:5+7) = c6;

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
x0 = [results.xmeascomp.c7_A; results.xmeascomp.c7_B; results.xmeascomp.c7_C; results.xmeascomp.c7_D; results.xmeascomp.c7_E; results.xmeascomp.c7_F; results.xmeascomp.c7_G; F6]; 
x0 = x0*00.0;
PBstruct   = ProblemStructure();

ub = [0.9 0.9 0.9 0.9 0.9 0.9 0.9 5000];
lb = [0   0   0   0   0   0   0      0];
x_sol = lsqnonlin(@(x_r) Reactor(x_r, u_r, Parameters), x0, lb, ub, PBstruct.lsqnonlin_options);

[test, y_r] = Reactor(x_sol, u_r, Parameters);

%%
% y_r = [F6; Pr; Tr; Vliqr; c7];
disp(['F6     Plant: ',num2str(results.xmeasstream.F6,4),'   Model: ', num2str(y_r(1),4)])
disp(['Vliqr  Plant: ',num2str(results.xmeas.Vlr),       '   Model: ', num2str(y_r(2),4)])
disp(['c7_A   Plant: ',num2str(results.xmeascomp.c7_A,4),'   Model: ', num2str(y_r(3),4)])
disp(['c7_B   Plant: ',num2str(results.xmeascomp.c7_B,4),'   Model: ', num2str(y_r(4),4)])
disp(['c7_C   Plant: ',num2str(results.xmeascomp.c7_C,4),'   Model: ', num2str(y_r(5),4)])
disp(['c7_D   Plant: ',num2str(results.xmeascomp.c7_D,4),'   Model: ', num2str(y_r(6),4)])
disp(['c7_E   Plant: ',num2str(results.xmeascomp.c7_E,4),'   Model: ', num2str(y_r(7),4)])
disp(['c7_F   Plant: ',num2str(results.xmeascomp.c7_F,4),'   Model: ', num2str(y_r(8),4)])
disp(['c7_G   Plant: ',num2str(results.xmeascomp.c7_G,4),'   Model: ', num2str(y_r(9),4)])
disp(['c7_H   Plant: ',num2str(results.xmeascomp.c7_H,4),'   Model: ', num2str(y_r(10),4)])


disp(' ')
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')



