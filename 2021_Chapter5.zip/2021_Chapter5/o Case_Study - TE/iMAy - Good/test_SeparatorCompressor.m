clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')

addpath('Plant')
addpath('Model')
addpath('Functions')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.- Initialize plant at base case
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.1.- Tunable parameters
    Measurement_Noise = 1; % 0: without noise | 1: with noise
        MNoise.time           = 0;
        MNoise.signals.values = Measurement_Noise;
% 1.2.- Base case initialisation of states & simulation sampling times
    load Mode1xInitial
    Ts_base=0.0005;
    Ts_save=0.01;
% 1.3.- Initial setpoints
    setpoints.time    = 0;
    setpoints.signals.values = [20; 50; 50; 50; 2800; 53.8; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
%     setpoints.signals.values = [18; 45; 62; 40; 2500; 53.8; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
% 1.4.- Initial valve positions
    u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
    for i=1:12
        iChar=int2str(i);
        eval(['xmv',iChar,'_0=u0(',iChar,');']);
    end
% 1.5.- Initial Controlers parameters
    Fp_0   = 100;
    r1_0   = 0.251/Fp_0;
    r2_0   = 3664/Fp_0;
    r3_0   = 4509/Fp_0;
    r4_0   = 9.35/Fp_0;
    r5_0   = 0.337/Fp_0;
    r6_0   = 25.16/Fp_0;
    r7_0   = 22.95/Fp_0;
    Eadj_0 = 0;
    SP17_0 = 80.1;
    
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2.- Lauch simulation
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sim('MultiLoop_mode1')

% %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % 3.- Extract data
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints);


%% Initialization model with plant values
Parameters = SetParameters();

% u_sep = [F6; F10; Tr; Tm; Pm; Pr; Vpsep_sp; c7]; 
% x_sep = [c8_A; c8_B; c8_C; c8_D; c8_E; c8_F; c8_G; c10_D; c10_E; c10_F; c10_G; v9; F8];
% y_sep = [F7; F8; F9; T8; Ts; Wcomp; Vliq_s; ls; Cpvap8; rho9; Ps; PvapD; PvapE; PvapF; PvapG; PvapH; c8; c9; c10];


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Inputs definition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs variables
F8       = results.xmeasstream.F8;
F10      = results.xmeasstream.F10;
Tr       = results.xmeas.Tr;
Tm       = results.xmeas.Tstr; % approx
Pm       = results.xmeas.Pstr;
Pr       = results.xmeas.Pr;
Vpsep_sp = results.xmeas.Vlsep_percent;
c7       = [results.xmeascomp.c7_A; results.xmeascomp.c7_B; results.xmeascomp.c7_C; ...
            results.xmeascomp.c7_D; results.xmeascomp.c7_E; results.xmeascomp.c7_F; ...
            results.xmeascomp.c7_G; results.xmeascomp.c7_H]; 

u_sep = zeros(14,1);
u_sep(1)     = F8;
u_sep(2)     = F10;
u_sep(3)     = Tr;
u_sep(4)     = Tm;
u_sep(5)     = Pm;
u_sep(6)     = Pr;
u_sep(7)     = Vpsep_sp;
u_sep(8:8+7) = c7;


%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
% x_sep = [c8_A; c8_B; c8_C; c8_D; c8_E; c8_F; c8_G; Ps; F9; Tsep];

x0 = [ results.xmeascomp.c8_A; results.xmeascomp.c8_B;results.xmeascomp.c8_C; results.xmeascomp.c8_D; results.xmeascomp.c8_E; results.xmeascomp.c8_F; results.xmeascomp.c8_G; ...
      results.xmeas.Psep   ; results.xmeasstream.F9; results.xmeas.Tsep ]; 
x0 = x0*0.9;

PBstruct   = ProblemStructure();

ub = [0.9 0.9 0.9 0.9 0.9 0.9 0.9 5000 50   150];
lb = [0   0   0   0   0   0   0   1000  0.1  60];
x_sol = lsqnonlin(@(x_sep) SeparatorCompressor(x_sep, u_sep, Parameters),x0,lb,ub,PBstruct.lsqnonlin_options);
% x_sol = fsolve(@(x_sep) SeparatorCompressor(x_sep, u_sep, Parameters), x0, PBstruct.fsolve_options);
[test, y_sep] = SeparatorCompressor(x_sol, u_sep, Parameters);
test
%%
% y_sep = [F7; F8; F9; T8; Ts; Wcomp; Vliq_s; rho9; Ps; PvapD; PvapE; PvapF; PvapG; PvapH; c8; c9; c10, v9];
disp(['F7     Plant: ',num2str(results.xmeasstream.F7,4),'   Model: ', num2str(y_sep(1),4)])
disp(['F8     Plant: ',num2str(results.xmeasstream.F8,4),'   Model: ', num2str(y_sep(2),4)])
disp(['F9     Plant: ',num2str(results.xmeasstream.F9,4),'   Model: ', num2str(y_sep(3),4)])
disp(['T8     Plant: ',num2str(results.xmeas.Tsep,4)      ,'   Model: ', num2str(y_sep(4),4)])
disp(['Ts     Plant: ',num2str(results.xmeas.Tsep,4)      ,'   Model: ', num2str(y_sep(5),4)])
disp(['Wcomp  Plant: ',num2str(results.xmeas.W_comp,4)    ,'   Model: ', num2str(y_sep(6),4)])
disp(['Vliq_s Plant: ',num2str(results.xmeas.Vlsep,4)     ,'   Model: ', num2str(y_sep(7),4)])
disp(['rho9   Plant: ',num2str(results.xmeasrho.rho_9,4)  ,'   Model: ', num2str(y_sep(8),4)])
disp(['Ps     Plant: ',num2str(results.xmeas.Psep,4)      ,'   Model: ', num2str(y_sep(9),4)])
disp(['v9     Plant: ',num2str(results.xmv.v9,4)      ,'   Model: ', num2str(y_sep(end),4)])

disp(' ')

disp(['c8_A   Plant: ',num2str(results.xmeascomp.c8_A,4)  ,'   Model: ', num2str(y_sep(15),4)])
disp(['c8_B   Plant: ',num2str(results.xmeascomp.c8_B,4)  ,'   Model: ', num2str(y_sep(16),4)])
disp(['c8_C   Plant: ',num2str(results.xmeascomp.c8_C,4)  ,'   Model: ', num2str(y_sep(17),4)])
disp(['c8_D   Plant: ',num2str(results.xmeascomp.c8_D,4)  ,'   Model: ', num2str(y_sep(18),4)])
disp(['c8_E   Plant: ',num2str(results.xmeascomp.c8_E,4)  ,'   Model: ', num2str(y_sep(19),4)])
disp(['c8_F   Plant: ',num2str(results.xmeascomp.c8_F,4)  ,'   Model: ', num2str(y_sep(20),4)])
disp(['c8_G   Plant: ',num2str(results.xmeascomp.c8_G,4)  ,'   Model: ', num2str(y_sep(21),4)])
disp(['c8_H   Plant: ',num2str(results.xmeascomp.c8_H,4)  ,'   Model: ', num2str(y_sep(22),4)])

disp(' ')

disp(['c10_A   Plant: ',num2str(results.xmeascomp.c10_A,4)  ,'   Model: ', num2str(y_sep(31),4)])
disp(['c10_B   Plant: ',num2str(results.xmeascomp.c10_B,4)  ,'   Model: ', num2str(y_sep(32),4)])
disp(['c10_C   Plant: ',num2str(results.xmeascomp.c10_C,4)  ,'   Model: ', num2str(y_sep(33),4)])
disp(['c10_D   Plant: ',num2str(results.xmeascomp.c10_D,4)  ,'   Model: ', num2str(y_sep(34),4)])
disp(['c10_E   Plant: ',num2str(results.xmeascomp.c10_E,4)  ,'   Model: ', num2str(y_sep(35),4)])
disp(['c10_F   Plant: ',num2str(results.xmeascomp.c10_F,4)  ,'   Model: ', num2str(y_sep(36),4)])
disp(['c10_G   Plant: ',num2str(results.xmeascomp.c10_G,4)  ,'   Model: ', num2str(y_sep(37),4)])
disp(['c10_H   Plant: ',num2str(results.xmeascomp.c10_H,4)  ,'   Model: ', num2str(y_sep(38),4)])

disp(' ')

disp(['PvapD      Model: ', num2str(y_sep(10),4)])
disp(['PvapE      Model: ', num2str(y_sep(11),4)])
disp(['PvapF      Model: ', num2str(y_sep(12),4)])
disp(['PvapG      Model: ', num2str(y_sep(13),4)])
disp(['PvapH      Model: ', num2str(y_sep(14),4)])

disp(' ')
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')



