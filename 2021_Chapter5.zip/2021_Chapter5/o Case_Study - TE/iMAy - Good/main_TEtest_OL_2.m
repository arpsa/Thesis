clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')

addpath('Plant')
addpath('Model')
addpath('Functions')




%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.- Initialize plant at base case
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.1.- Tunable parameters
    Measurement_Noise = 0; % 0: without noise | 1: with noise
        MNoise.time           = 0;
        MNoise.signals.values = Measurement_Noise;
% 1.2.- Base case initialisation of states & simulation sampling times
    load Mode1xInitial
    Ts_base=0.0005;
    Ts_save=0.01;
% 1.3.- Initial setpoints
    setpoints.time    = 0;
    % mode 1
%     1.- m11_sp      5.- Pr_sp     9.- Tr_sp
%     2.- Vpstr_sp    6.- cG11_sp  10.- v_recycle
%     3.- Vpsep_sp    7.- c_Asp    11.- steam_valve
%     4.- Vpr_sp      8.- c_ACsp   12.- omega_r
%     setpoints.signals.values = [22.89; 50; 50; 65; 2800; 53.83; 100*32.19/(32.19+26.38); 32.19+26.38; 122.9; 1; 1; 100]';
    setpoints.signals.values = [21; 40; 60; 60; 2500; 10; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
        setpoints.signals.values = [22.89; 50; 50; 65; 2800; 53.83; 63.21; 50.97; 122.9; 1; 1; 100]';
prev_setpoints = setpoints;
% 1.4.- Initial valve positions
   u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
%      u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
    for i=1:12
        iChar=int2str(i);
        eval(['xmv',iChar,'_0=u0(',iChar,');']);
    end
% 1.5.- Initial Controlers parameters
    Fp_0   = 100;
    r1_0   = 0.251/Fp_0;
    r2_0   = 3664/Fp_0;
    r3_0   = 4509/Fp_0;
    r4_0   = 9.35/Fp_0;
    r5_0   = 0.337/Fp_0;
    r6_0   = 25.16/Fp_0;
    r7_0   = 22.95/Fp_0;
    Eadj_0 = 0;
    SP17_0 = 80.1;
    
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2.- Lauch simulation
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sim('MultiLoop_mode1')

%% %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % 3.- Extract data
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost);


%% Initialization model with plant values
PBstruct   = ProblemStructure();
Parameters = SetParameters();

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Inputs definition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs variables
m11_sp   = setpoints.signals.values(1);
Vpstr_sp = setpoints.signals.values(2);
Vpsep_sp = setpoints.signals.values(3);
Vpr_sp   = setpoints.signals.values(4);
Pr_sp    = setpoints.signals.values(5);
cG11_sp  = setpoints.signals.values(6);
c_Asp    = setpoints.signals.values(7);
c_ACsp   = setpoints.signals.values(8);
Tr_sp    = setpoints.signals.values(9);
vsteam   = setpoints.signals.values(10);
F6       = results.xmeasstream.F6;

u = zeros(5,1);
u(1)  = m11_sp;
% u(2)  = Vpr_sp;
% u(3)  = Pr_sp;
u(2) = cG11_sp;
u(3)  = c_Asp;
u(4)  = c_ACsp;
u(5)  = Tr_sp;
% u(10) = vsteam;

u_TE = setpoints.signals.values([1 6 7 8 9])';

% x_m = x_m = [c6_B; c6_D; c6_E; c6_F; c6_G; F1; F2; F3];
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
tic
[x_m, x_sep, x_str, x_r, ub_m,lb_m , ub_r,lb_r , ub_sep,lb_sep  , ub_str,lb_str , x_RSS , ub_RSS,lb_RSS , x_TE , ub_TE,lb_TE  ] = InitState(results);



%%
PBstruct   = ProblemStructure();
clc

            Modifiers.type  = 'none'; 
x_sol = lsqnonlin(@(x_TE) SimTE_2SubSystems_New(x_TE, u_TE, Parameters, Modifiers), x_TE, lb_TE, ub_TE, PBstruct.lsqnonlin_options);

[test, y] = SimTE_2SubSystems_New(x_sol, u_TE, Parameters, Modifiers);
max(test)
%%
disp(['F5   Plant: ',num2str(results.xmeasstream.F5,4), '   Model: ', num2str(y(1),4)])
disp(['F6   Plant: ',num2str(results.xmeasstream.F6,4), '   Model: ', num2str(y(2),4)])
disp(['F8   Plant: ',num2str(results.xmeasstream.F8,4), '   Model: ', num2str(y(3),4)])
disp(['F9   Plant: ',num2str(results.xmeasstream.F9,4), '   Model: ', num2str(y(4),4)])
disp(['F11  Plant: ',num2str(results.xmeasstream.F11,4),'   Model: ', num2str(y(5),4)])

disp(' ')
disp(['c5_A Plant: ',num2str(results.xmeascomp.c5_A,4), '   Model: ', num2str(y(6),4)])
disp(['c5_B Plant: ',num2str(results.xmeascomp.c5_B,4), '   Model: ', num2str(y(7),4)])
disp(['c5_C Plant: ',num2str(results.xmeascomp.c5_C,4), '   Model: ', num2str(y(8),4)])
disp(['c5_D Plant: ',num2str(results.xmeascomp.c5_D,4), '   Model: ', num2str(y(9),4)])
disp(['c5_E Plant: ',num2str(results.xmeascomp.c5_E,4), '   Model: ', num2str(y(10),4)])
disp(['c5_F Plant: ',num2str(results.xmeascomp.c5_F,4), '   Model: ', num2str(y(11),4)])
disp(['c5_G Plant: ',num2str(results.xmeascomp.c5_G,4), '   Model: ', num2str(y(12),4)])
disp(['c5_H Plant: ',num2str(results.xmeascomp.c5_H,4), '   Model: ', num2str(y(13),4)])
%  sum(yy(12:19))
disp(' ')
disp(['c6_A Plant: ',num2str(results.xmeascomp.c6_A,4), '   Model: ', num2str(y(14),4)])
disp(['c6_B Plant: ',num2str(results.xmeascomp.c6_B,4), '   Model: ', num2str(y(15),4)])
disp(['c6_C Plant: ',num2str(results.xmeascomp.c6_C,4), '   Model: ', num2str(y(16),4)])
disp(['c6_D Plant: ',num2str(results.xmeascomp.c6_D,4), '   Model: ', num2str(y(17),4)])
disp(['c6_E Plant: ',num2str(results.xmeascomp.c6_E,4), '   Model: ', num2str(y(18),4)])
disp(['c6_F Plant: ',num2str(results.xmeascomp.c6_F,4), '   Model: ', num2str(y(19),4)])
disp(['c6_G Plant: ',num2str(results.xmeascomp.c6_G,4), '   Model: ', num2str(y(20),4)])
disp(['c6_H Plant: ',num2str(results.xmeascomp.c6_H,4), '   Model: ', num2str(y(21),4)])

disp(' ')
disp(['c8_A Plant: ',num2str(results.xmeascomp.c8_A,4), '   Model: ', num2str(y(22),4)])
disp(['c8_B Plant: ',num2str(results.xmeascomp.c8_B,4), '   Model: ', num2str(y(23),4)])
disp(['c8_C Plant: ',num2str(results.xmeascomp.c8_C,4), '   Model: ', num2str(y(24),4)])
disp(['c8_D Plant: ',num2str(results.xmeascomp.c8_D,4), '   Model: ', num2str(y(25),4)])
disp(['c8_E Plant: ',num2str(results.xmeascomp.c8_E,4), '   Model: ', num2str(y(26),4)])
disp(['c8_F Plant: ',num2str(results.xmeascomp.c8_F,4), '   Model: ', num2str(y(27),4)])
disp(['c8_G Plant: ',num2str(results.xmeascomp.c8_G,4), '   Model: ', num2str(y(28),4)])
disp(['c8_H Plant: ',num2str(results.xmeascomp.c8_H,4), '   Model: ', num2str(y(29),4)])

disp(' ')
disp(['c11_A Plant: ',num2str(results.xmeascomp.c11_A,4), '   Model: ', num2str(y(30),4)])
disp(['c11_B Plant: ',num2str(results.xmeascomp.c11_B,4), '   Model: ', num2str(y(31),4)])
disp(['c11_C Plant: ',num2str(results.xmeascomp.c11_C,4), '   Model: ', num2str(y(32),4)])
disp(['c11_D Plant: ',num2str(results.xmeascomp.c11_D,4), '   Model: ', num2str(y(33),4)])
disp(['c11_E Plant: ',num2str(results.xmeascomp.c11_E,4), '   Model: ', num2str(y(34),4)])
disp(['c11_F Plant: ',num2str(results.xmeascomp.c11_F,4), '   Model: ', num2str(y(35),4)])
disp(['c11_G Plant: ',num2str(results.xmeascomp.c11_G,4), '   Model: ', num2str(y(36),4)])
disp(['c11_H Plant: ',num2str(results.xmeascomp.c11_H,4), '   Model: ', num2str(y(37),4)])

% disp(' ')
% disp(['Tr   Plant: ',num2str(results.xmeas.Tr,4),   '   Model: ', num2str(y(40),4)])
% 
% disp(' ')
% disp(['VLr   Plant: ',num2str(results.xmeas.Vlr,4),  '   Model: ', num2str(y(41),4)])
% disp(['VLsep Plant: ',num2str(results.xmeas.Vlsep,4),'   Model: ', num2str(y(42),4)])
% disp(['VLstr Plant: ',num2str(results.xmeas.Vlstr,4),'   Model: ', num2str(y(43),4)]) 
% 
% disp(' ')
% disp(['Pr   Plant: ',num2str(results.xmeas.Pr,4),  '   Model: ', num2str(y(44),4)])
% 
% disp(' ')
% disp(['OPEX  Plant: ',num2str(results.OPEX,4),  '   Model: ', num2str(phi1,4)])
% disp(['PRate Plant: ',num2str(-results.PRate,6), '   Model: ', num2str(-phi2,6)])



disp(' ')
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')
