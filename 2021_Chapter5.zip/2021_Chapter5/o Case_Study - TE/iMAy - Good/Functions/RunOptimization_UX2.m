function [xus_sol, f, eflag, outpt, Last_ceq] = RunOptimization_UX2(xu0s, Parameters, lb_xu, ub_xu, mode, Modifiers, K, uk)
%                                                                                      PBstruct.lsqnonlin_options
Last_x   = [];
Last_f   = [];
Last_c   = [];
Last_ceq = [];

% Aeq = [];
% beq = [];
Aeq = [zeros(1,60) zeros(1,1) 1 zeros(1,5)  zeros(1,60);
       zeros(1,60) zeros(1,2) 1 zeros(1,4)  zeros(1,60)];
beq = [0; 1];

A = [];
b = [];

ubs = ones(1,length(xu0s));
lbs = zeros(1,length(xu0s));

PBstruct = ProblemStructure();

[xus_sol, f, eflag, outpt] = fmincon(@(xus)objfun(xus, Parameters, ub_xu, lb_xu),...
                                xu0s, A, b, Aeq, beq, lbs, ubs, ...
                                @(xus)constr(xus, Parameters, ub_xu, lb_xu),PBstruct.fmincon_options_6);  % 

    function y = objfun(xus, Parameters, ub_xu, lb_xu)
        if ~isequal(xus,Last_x) % Check if computation is necessary
            xu  = (xus).*(ub_xu'-lb_xu') + lb_xu';
            x = xu(1:60); 
            u = xu(61:67); 
            x2 = xu(68:end); 
            [dx, y]= SimTE_2SubSystems(x, u, Parameters, Modifiers);
            [phi1, phi2, g, geq] = uy2phig2(u, y, mode, Modifiers, Parameters);
            [dx2, y2]= SimTE_2SubSystems(x2, K*(u-uk)+uk, Parameters, Modifiers);
            [~, ~, g2, geq2] = uy2phig2(K*(u-uk)+uk, y2, mode, Modifiers, Parameters);
%              Last_ceq = dx;
%             Last_x = xus;
%             Last_f = 0;
%             Last_c = [];
            
            if mode < 4
                Last_f   = phi1; % *100
            elseif mode > 3
                Last_f   = phi2;
            end
%             Last_c   = g;
%             Last_ceq = [dx*10; geq];
%             Last_x = xus;
            Last_c   = [g; g2(1:end)];
%             Last_ceq = [dx*10; dx2*10; geq]; % *10*10
            Last_ceq = [dx*10; dx2*10]; % 
            Last_x = xus;
        end
        % Now give cost functions
        y = Last_f;
    end

    function [c,ceq] = constr(xus, Parameters, ub_xu, lb_xu)
        if ~isequal(xus,Last_x) % Check if computation is necessary
            xu  = (xus).*(ub_xu'-lb_xu') + lb_xu';
            x = xu(1:60); 
            u = xu(61:67); 
            x2 = xu(68:end); 
            [dx, y]= SimTE_2SubSystems(x, u, Parameters, Modifiers);
            [phi1, phi2, g, geq] = uy2phig2(u, y, mode, Modifiers, Parameters);
            [dx2, y2]= SimTE_2SubSystems(x2, K*(u-uk)+uk, Parameters, Modifiers);
            [~, ~, g2, geq2] = uy2phig2(K*(u-uk)+uk, y2, mode, Modifiers, Parameters);
%              Last_ceq = dx;
%             Last_x = xus;
%             Last_f = 0;
%             Last_c = [];
            
            if mode < 4
                Last_f   = phi1 % *100;
            elseif mode > 3
                Last_f   = phi2;
            end
%             Last_c   = g;
%             Last_ceq = [dx*10; geq];
%             Last_x = xus;
            Last_c   = [g; g2(1:end)];
%             Last_ceq = [dx; dx2; geq; geq2];  % *10*10
            Last_ceq = [dx*10; dx2*10];
            Last_x = xus;
        end
        % Now give constraint functions
        c   = Last_c;
        ceq = Last_ceq;
    end

end