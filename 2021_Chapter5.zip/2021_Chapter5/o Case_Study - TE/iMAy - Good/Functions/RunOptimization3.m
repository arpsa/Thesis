function [xxs, f, eflag, outpt, Last_ceq, Last_c] = RunOptimization3(u0s, Parameters, lbs, ubs,lb, ub, opts, mode)
%                                                                                      PBstruct.lsqnonlin_options

global Fp_0 r1_0 r2_0 r3_0 r4_0 r5_0 r6_0 r7_0 Eadj_0 SP17_0      ...
       xmv1_0 xmv2_0 xmv3_0 xmv4_0 xmv5_0 xmv6_0 xmv7_0 xmv8_0    ...
       xmv9_0 xmv10_0 xmv11_0 xmv12_0 xInitial XMV r xFinal XMEAS ...
       XMEASCOMP XMEASSTREAM XMEASRHO setpoints OpCost IDV x Production Quality tout
   
Last_u   = [];
Last_f   = [];
Last_c   = []; % Attention c is not the input of the plant but the NL constraint !!
Last_ceq = [];

temp = 0;

Aeq = [];  
beq = [];

A = [];
b = [];

%%%%%%%%%%%%%%%  
% xs_sol = lsqnonlin(@(xs) SimTE(xs, u, Parameters, ub, lb),x0s,lbs,ubs,opts);

[xxs, f, eflag, outpt] = fmincon(@(us)objfun(us),...
                                u0s, A, b, Aeq, beq, lbs, ubs, ...
                                @(us)constr(us,Parameters, ub, lb),opts);

    function y = objfun(us)
        if ~isequal(us,Last_u) % Check if computation is necessary
            if temp == 0
                stepsize = 0; 
            else
                temp = 1;
                stepsize = us - Last_u; 
            end 
            maxstepsize = max([stepsize]);
            
            if stepsize > 0.1 
                Last_f   = abs(Last_f)*inf;
                Last_c   = abs(Last_c)*inf;
                Last_ceq = abs(Last_ceq)*inf;
            else
                Last_u = us; 
                u = (us).*(ub'-lb') + lb';

                setpoints.signals(1).values = [u; 1; 100]';
                sim('MultiLoop_mode1')

                disp('Sim objf: ok')
                [Fp_0,r1_0,r2_0,r3_0,r4_0,r5_0,r6_0,r7_0,Eadj_0,SP17_0,xmv1_0,xmv2_0,xmv3_0,xmv4_0,xmv5_0,xmv6_0,xmv7_0,xmv8_0,xmv9_0,xmv10_0,xmv11_0,xmv12_0,xInitial] = transition(XMV,r,xFinal);

                results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost);
                [phi1, phi2, g, geq] = uy2phig_plant(results, mode);
                if mode < 4
                    Last_f   = phi1;
                elseif mode > 3
                    Last_f   = phi2;
                end
                Last_c   = g;
                Last_ceq = geq;
            end
        end
        y = Last_f;
    end

    function [c,ceq] = constr(us,  Parameters, ub, lb)
        if ~isequal(us,Last_u) % Check if computation is necessary
            if temp == 0
                stepsize = 0; 
            else
                temp = 1;
                stepsize = us - Last_u; 
            end 
            maxstepsize = max([stepsize]);
            
            if stepsize > 0.1
                Last_f   = abs(Last_f)*inf;
                Last_c   = abs(Last_c)*inf;
                Last_ceq = abs(Last_ceq)*inf;
            else
                Last_u = us; 
                u = (us).*(ub'-lb') + lb';

                setpoints.signals(1).values = [u; 1; 100]';
                sim('MultiLoop_mode1')

                disp('Sim objf: ok')
                [Fp_0,r1_0,r2_0,r3_0,r4_0,r5_0,r6_0,r7_0,Eadj_0,SP17_0,xmv1_0,xmv2_0,xmv3_0,xmv4_0,xmv5_0,xmv6_0,xmv7_0,xmv8_0,xmv9_0,xmv10_0,xmv11_0,xmv12_0,xInitial] = transition(XMV,r,xFinal);

                results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost);
                [phi1, phi2, g, geq] = uy2phig_plant(results, mode);
                if mode < 4
                    Last_f   = phi1;
                elseif mode > 3
                    Last_f   = phi2;
                end
                Last_c   = g;
                Last_ceq = geq;
            end
        end
        % Now compute constraint functions
        c   = Last_c;
        ceq = Last_ceq;
    end

end