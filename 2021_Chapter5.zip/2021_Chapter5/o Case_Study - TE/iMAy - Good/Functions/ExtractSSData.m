function [results] = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost)

xmeas = struct();
    xmeas.Stream1_kscmh = XMEAS(end,1);  % [kscmh] (kilo standard cubic meters per hours in stream 1)
    xmeas.Stream2_m     = XMEAS(end,2);  % [kg/h]
    xmeas.Stream3_m     = XMEAS(end,3);  % [kg/h]
    xmeas.Stream4_kscmh = XMEAS(end,4);  % [kscmh]
    xmeas.Stream8_kscmh = XMEAS(end,5);  % [kscmh]
    xmeas.Stream6_kscmh = XMEAS(end,6);  % [kscmh]
    xmeas.Pr            = XMEAS(end,7);  % [kPa]
    xmeas.Vlr_percent   = XMEAS(end,8);  % [%]
        xmeas.Vlr       = (XMEAS(end,8)*666.7/100+84.5)/35.3145; % [m3]
    xmeas.Tr            = XMEAS(end,9);  % [�C]
    xmeas.Stream9_kscmh = XMEAS(end,10); % [kscmh]
    xmeas.Tsep          = XMEAS(end,11); % [�C]
    xmeas.Vlsep_percent = XMEAS(end,12); % [%]
        xmeas.Vlsep     = (XMEAS(end,12)*290/100+27.5)/35.3145; % [m3]
    xmeas.Psep          = XMEAS(end,13); % [kPa]
    xmeas.Stream10_m3h  = XMEAS(end,14); % [m3/h]
    xmeas.Vlstr_percent = XMEAS(end,15); % [%]
        xmeas.Vlstr     = (XMEAS(end,15)*156.5/100+78.25)/35.3145; % [m3]
    xmeas.Pstr          = XMEAS(end,16); % [kPa]
    xmeas.Stream11_m3h  = XMEAS(end,17); % [m3/h]
    xmeas.Tstr          = XMEAS(end,18); % [�C]
    xmeas.m_steam       = XMEAS(end,19); % [kg/h]
    xmeas.W_comp        = XMEAS(end,20); % [kW]
    xmeas.Twor          = XMEAS(end,21); % [�C]
    xmeas.Twoc          = XMEAS(end,22); % [�C]
    
    xmeas.c6_A  = XMEAS(end,23); % [kmol A / kmol *100]
    xmeas.c6_B  = XMEAS(end,24); % [kmol B / kmol *100]
    xmeas.c6_C  = XMEAS(end,25); % [kmol C / kmol *100]
    xmeas.c6_D  = XMEAS(end,26); % [kmol D / kmol *100]
    xmeas.c6_E  = XMEAS(end,27); % [kmol E / kmol *100]
    xmeas.c6_F  = XMEAS(end,28); % [kmol F / kmol *100]
    
    xmeas.c9_A  = XMEAS(end,29); % [kmol A / kmol *100]
    xmeas.c9_B  = XMEAS(end,30); % [kmol B / kmol *100]
    xmeas.c9_C  = XMEAS(end,31); % [kmol C / kmol *100]
    xmeas.c9_D  = XMEAS(end,32); % [kmol D / kmol *100]
    xmeas.c9_E  = XMEAS(end,33); % [kmol E / kmol *100]
    xmeas.c9_F  = XMEAS(end,34); % [kmol F / kmol *100]
    xmeas.c9_G  = XMEAS(end,35); % [kmol G / kmol *100]
    xmeas.c9_H  = XMEAS(end,36); % [kmol H / kmol *100]

    xmeas.c11_D = XMEAS(end,37); % [kmol D / kmol *100]
    xmeas.c11_E = XMEAS(end,38); % [kmol E / kmol *100]
    xmeas.c11_F = XMEAS(end,39); % [kmol F / kmol *100]
    xmeas.c11_G = XMEAS(end,40); % [kmol G / kmol *100]
    xmeas.c11_H = XMEAS(end,41); % [kmol H / kmol *100]

xmeascomp = struct();
    xmeascomp.c2_A = XMEASCOMP(end,1);  % [kmol A / kmol]
    xmeascomp.c2_B = XMEASCOMP(end,2);  % [kmol B / kmol]
    xmeascomp.c2_C = XMEASCOMP(end,3);  % [kmol C / kmol]
    xmeascomp.c2_D = XMEASCOMP(end,4);  % [kmol D / kmol]
    xmeascomp.c2_E = XMEASCOMP(end,5);  % [kmol E / kmol]
    xmeascomp.c2_F = XMEASCOMP(end,6);  % [kmol F / kmol]
    xmeascomp.c2_G = XMEASCOMP(end,7);  % [kmol G / kmol]
    xmeascomp.c2_H = XMEASCOMP(end,8);  % [kmol H / kmol]
    
    xmeascomp.c3_A = XMEASCOMP(end,9);  % [kmol A / kmol]
    xmeascomp.c3_B = XMEASCOMP(end,10); % [kmol B / kmol]
    xmeascomp.c3_C = XMEASCOMP(end,11); % [kmol C / kmol]
    xmeascomp.c3_D = XMEASCOMP(end,12); % [kmol D / kmol]
    xmeascomp.c3_E = XMEASCOMP(end,13); % [kmol E / kmol]
    xmeascomp.c3_F = XMEASCOMP(end,14); % [kmol F / kmol]
    xmeascomp.c3_G = XMEASCOMP(end,15); % [kmol G / kmol]
    xmeascomp.c3_H = XMEASCOMP(end,16); % [kmol H / kmol]
    
    xmeascomp.c1_A = XMEASCOMP(end,17); % [kmol A / kmol]
    xmeascomp.c1_B = XMEASCOMP(end,18); % [kmol B / kmol]
    xmeascomp.c1_C = XMEASCOMP(end,19); % [kmol C / kmol]
    xmeascomp.c1_D = XMEASCOMP(end,20); % [kmol D / kmol]
    xmeascomp.c1_E = XMEASCOMP(end,21); % [kmol E / kmol]
    xmeascomp.c1_F = XMEASCOMP(end,22); % [kmol F / kmol]
    xmeascomp.c1_G = XMEASCOMP(end,23); % [kmol G / kmol]
    xmeascomp.c1_H = XMEASCOMP(end,24); % [kmol H / kmol]
    
    xmeascomp.c4_A = XMEASCOMP(end,25); % [kmol A / kmol]
    xmeascomp.c4_B = XMEASCOMP(end,26); % [kmol B / kmol]
    xmeascomp.c4_C = XMEASCOMP(end,27); % [kmol C / kmol]
    xmeascomp.c4_D = XMEASCOMP(end,28); % [kmol D / kmol]
    xmeascomp.c4_E = XMEASCOMP(end,29); % [kmol E / kmol]
    xmeascomp.c4_F = XMEASCOMP(end,30); % [kmol F / kmol]
    xmeascomp.c4_G = XMEASCOMP(end,31); % [kmol G / kmol]
    xmeascomp.c4_H = XMEASCOMP(end,32); % [kmol H / kmol]
    
    xmeascomp.c5_A = XMEASCOMP(end,33); % [kmol A / kmol]
    xmeascomp.c5_B = XMEASCOMP(end,34); % [kmol B / kmol]
    xmeascomp.c5_C = XMEASCOMP(end,35); % [kmol C / kmol]
    xmeascomp.c5_D = XMEASCOMP(end,36); % [kmol D / kmol]
    xmeascomp.c5_E = XMEASCOMP(end,37); % [kmol E / kmol]
    xmeascomp.c5_F = XMEASCOMP(end,38); % [kmol F / kmol]
    xmeascomp.c5_G = XMEASCOMP(end,39); % [kmol G / kmol]
    xmeascomp.c5_H = XMEASCOMP(end,40); % [kmol H / kmol]
    
    xmeascomp.c6_A = XMEASCOMP(end,41); % [kmol A / kmol]
    xmeascomp.c6_B = XMEASCOMP(end,42); % [kmol B / kmol]
    xmeascomp.c6_C = XMEASCOMP(end,43); % [kmol C / kmol]
    xmeascomp.c6_D = XMEASCOMP(end,44); % [kmol D / kmol]
    xmeascomp.c6_E = XMEASCOMP(end,45); % [kmol E / kmol]
    xmeascomp.c6_F = XMEASCOMP(end,46); % [kmol F / kmol]
    xmeascomp.c6_G = XMEASCOMP(end,47); % [kmol G / kmol]
    xmeascomp.c6_H = XMEASCOMP(end,48); % [kmol H / kmol]
    
    xmeascomp.c7_A = XMEASCOMP(end,49); % [kmol A / kmol]
    xmeascomp.c7_B = XMEASCOMP(end,50); % [kmol B / kmol]
    xmeascomp.c7_C = XMEASCOMP(end,51); % [kmol C / kmol]
    xmeascomp.c7_D = XMEASCOMP(end,52); % [kmol D / kmol]
    xmeascomp.c7_E = XMEASCOMP(end,53); % [kmol E / kmol]
    xmeascomp.c7_F = XMEASCOMP(end,54); % [kmol F / kmol]
    xmeascomp.c7_G = XMEASCOMP(end,55); % [kmol G / kmol]
    xmeascomp.c7_H = XMEASCOMP(end,56); % [kmol H / kmol]
    
    xmeascomp.c8_A = XMEASCOMP(end,57); % [kmol A / kmol]
    xmeascomp.c8_B = XMEASCOMP(end,58); % [kmol B / kmol]
    xmeascomp.c8_C = XMEASCOMP(end,59); % [kmol C / kmol]
    xmeascomp.c8_D = XMEASCOMP(end,60); % [kmol D / kmol]
    xmeascomp.c8_E = XMEASCOMP(end,61); % [kmol E / kmol]
    xmeascomp.c8_F = XMEASCOMP(end,62); % [kmol F / kmol]
    xmeascomp.c8_G = XMEASCOMP(end,63); % [kmol G / kmol]
    xmeascomp.c8_H = XMEASCOMP(end,64); % [kmol H / kmol]
    
    xmeascomp.c9_A = XMEASCOMP(end,65); % [kmol A / kmol]
    xmeascomp.c9_B = XMEASCOMP(end,66); % [kmol B / kmol]
    xmeascomp.c9_C = XMEASCOMP(end,67); % [kmol C / kmol]
    xmeascomp.c9_D = XMEASCOMP(end,68); % [kmol D / kmol]
    xmeascomp.c9_E = XMEASCOMP(end,69); % [kmol E / kmol]
    xmeascomp.c9_F = XMEASCOMP(end,70); % [kmol F / kmol]
    xmeascomp.c9_G = XMEASCOMP(end,71); % [kmol G / kmol]
    xmeascomp.c9_H = XMEASCOMP(end,72); % [kmol H / kmol]
    
    xmeascomp.c10_A = XMEASCOMP(end,73); % [kmol A / kmol]
    xmeascomp.c10_B = XMEASCOMP(end,74); % [kmol B / kmol]
    xmeascomp.c10_C = XMEASCOMP(end,75); % [kmol C / kmol]
    xmeascomp.c10_D = XMEASCOMP(end,76); % [kmol D / kmol]
    xmeascomp.c10_E = XMEASCOMP(end,77); % [kmol E / kmol]
    xmeascomp.c10_F = XMEASCOMP(end,78); % [kmol F / kmol]
    xmeascomp.c10_G = XMEASCOMP(end,79); % [kmol G / kmol]
    xmeascomp.c10_H = XMEASCOMP(end,80); % [kmol H / kmol]
    
    xmeascomp.c11_A = XMEASCOMP(end,89); % [kmol A / kmol]
    xmeascomp.c11_B = XMEASCOMP(end,90); % [kmol B / kmol]
    xmeascomp.c11_C = XMEASCOMP(end,91); % [kmol C / kmol]
    xmeascomp.c11_D = XMEASCOMP(end,92); % [kmol D / kmol]
    xmeascomp.c11_E = XMEASCOMP(end,93); % [kmol E / kmol]
    xmeascomp.c11_F = XMEASCOMP(end,94); % [kmol F / kmol]
    xmeascomp.c11_G = XMEASCOMP(end,95); % [kmol G / kmol]
    xmeascomp.c11_H = XMEASCOMP(end,96); % [kmol H / kmol]


xmeasstream = struct();
    xmeasstream.F1  = XMEASSTREAM(end,1);  % [kmol/h]
    xmeasstream.F2  = XMEASSTREAM(end,2);  % [kmol/h]
    xmeasstream.F3  = XMEASSTREAM(end,3);  % [kmol/h]
    xmeasstream.F4  = XMEASSTREAM(end,4);  % [kmol/h]
    xmeasstream.F5  = XMEASSTREAM(end,5);  % [kmol/h]
    xmeasstream.F6  = XMEASSTREAM(end,6);  % [kmol/h]
    xmeasstream.F7  = XMEASSTREAM(end,7);  % [kmol/h]
    xmeasstream.F8  = XMEASSTREAM(end,8);  % [kmol/h]
    xmeasstream.F9  = XMEASSTREAM(end,9);  % [kmol/h]
    xmeasstream.F10 = XMEASSTREAM(end,10); % [kmol/h]
    xmeasstream.F11 = XMEASSTREAM(end,11); % [kmol/h]

xmv = struct();
    xmv.v2     = XMV(end,1);  % [%]
    xmv.v3     = XMV(end,2);  % [%]
    xmv.v1     = XMV(end,3);  % [%]
    xmv.v4     = XMV(end,4);  % [%]
    xmv.v9     = XMV(end,6);  % [%]
    xmv.v10    = XMV(end,7);  % [%]
    xmv.v11    = XMV(end,8);  % [%]
    xmv.vsteam = XMV(end,9);  % [%]
    xmv.vwr    = XMV(end,10); % [%]
    xmv.vwc    = XMV(end,11); % [%]
    xmv.omegar = XMV(end,12); % [%]
	xmv.vcompressor_recycle = XMV(end,5); % we do not care about this value in this study
   
xmeasrho = struct();    
    xmeasrho.rho_9  = XMEASRHO(end,1); % [kg/kscm]
    xmeasrho.rho_11 = XMEASRHO(end,2); % [kg/m3]

u  = struct();    
    u.m11_sp   = setpoints.signals.values(1);
    u.Vpstr_sp = setpoints.signals.values(2);
    u.Vpsep_sp = setpoints.signals.values(3);
    u.Vpr_sp   = setpoints.signals.values(4);
    u.Pr_sp    = setpoints.signals.values(5);
    u.c_G11_sp = setpoints.signals.values(6);
    u.c_Asp    = setpoints.signals.values(7);
    u.c_ACsp   = setpoints.signals.values(8);
    u.Tr_sp    = setpoints.signals.values(9);
    u.vcomp    = setpoints.signals.values(10); % don't care about it
    u.vsteam   = setpoints.signals.values(11);
    u.omegar   = setpoints.signals.values(12);
    
OPEX  = OpCost(end,1);
PRate = xmeasstream.F11*(62*xmeascomp.c11_G + 76*xmeascomp.c11_H); 
% + 48*xmeascomp.c11_F+ ...
%         46*xmeascomp.c11_E + 32*xmeascomp.c11_D + 28*xmeascomp.c11_C + 25.4*xmeascomp.c11_B + ...
%          2*xmeascomp.c11_A );

results = struct();
    results.xmeas       = xmeas;
    results.xmeascomp   = xmeascomp;
    results.xmeasstream = xmeasstream;
    results.xmeasrho    = xmeasrho;
    results.xmv         = xmv;
    results.u           = u;
    results.OPEX        = OPEX;
    results.PRate       = PRate;






