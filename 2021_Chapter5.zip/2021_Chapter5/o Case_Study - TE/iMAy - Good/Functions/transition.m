% function [Fp_0,r1_0,r2_0,r3_0,r4_0,r5_0,r6_0,r7_0,Eadj_0,SP17_0,xmv1_0,xmv2_0,xmv3_0,xmv4_0,xmv5_0,xmv6_0,xmv7_0,xmv8_0,xmv9_0,xmv10_0,xmv11_0,xmv12_0,xInitial] = transition(XMV,r,xFinal)
function [] = transition()

global Fp_0 r1_0 r2_0 r3_0 r4_0 r5_0 r6_0 r7_0 Eadj_0 SP17_0      ...
       xmv1_0 xmv2_0 xmv3_0 xmv4_0 xmv5_0 xmv6_0 xmv7_0 xmv8_0    ...
       xmv9_0 xmv10_0 xmv11_0 xmv12_0 xInitial XMV r xFinal XMEAS ...
       XMEASCOMP XMEASSTREAM XMEASRHO setpoints OpCost IDV x      ...
       Production Quality tout prev_setpoints
   
u0=XMV(end,:);
for i=1:12
    iChar=int2str(i);
    eval(['xmv',iChar,'_0=u0(',iChar,');']);
end

Fp_0   = r(end,1);
r1_0   = r(end,2);
r2_0   = r(end,3);
r3_0   = r(end,4);
r4_0   = r(end,5);
r5_0   = r(end,6);
r6_0   = r(end,7);
r7_0   = r(end,8);
Eadj_0 = r(end,9);
SP17_0 = r(end,10);

xInitial = xFinal;
