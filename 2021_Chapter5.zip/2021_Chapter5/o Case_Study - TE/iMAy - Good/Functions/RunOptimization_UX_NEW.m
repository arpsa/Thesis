function [xus_sol, f, eflag, outpt, lambda, dx] = RunOptimization_UX_NEW(xu0s, Parameters, lb_xu, ub_xu, mode, Modifiers, K, uk, Derivatives_P, lb_TE, ub_TE)
%                                                                                      PBstruct.lsqnonlin_options
Last_x   = [];
Last_f   = [];
Last_c   = [];
Last_ceq = [];

Aeq = [];
beq = [];

A = [];
b = [];

ubs = ones(1,length(xu0s));
lbs = zeros(1,length(xu0s));

PBstruct = ProblemStructure();

[xus_sol, f, eflag, outpt,lambda] = fmincon(@(xus)objfun(xus, Parameters, ub_xu, lb_xu),...
                                xu0s, A, b, Aeq, beq, lbs, ubs, ...
                                @(xus)constr(xus, Parameters, ub_xu, lb_xu),PBstruct.fmincon_options_5 );  % 

    function y = objfun(xus, Parameters, ub_xu, lb_xu)
        if ~isequal(xus,Last_x) % Check if computation is necessary
            xu  = (xus).*(ub_xu'-lb_xu') + lb_xu';
            xs = xus(1:45); 
            x  = xu(1:45); 
            u  = xu(46:50); 
            
            [dx, y_m,~,~,~,~,u_RSS,~,y] = SimTE_2SubSystems_New(xs, u, Parameters, Modifiers, Derivatives_P, lb_TE, ub_TE);
            if strcmp(Modifiers.type,'iMA1') || strcmp(Modifiers.type,'iMA2')
                [phi1, phi2, g, geq] = uy2phig2(u, y, mode, Modifiers, Parameters,u_RSS);
            else
                [phi1, phi2, g, geq] = uy2phig2(u, y_m, mode, Modifiers, Parameters,u_RSS);
            end 
            
            if mode < 4
                Last_f   = phi1; 
            elseif mode > 3
                Last_f   = phi2;
            end
            Last_c   = [g; -y];%(2)
%             Last_ceq = [dx*1000; geq];
            Last_ceq = [dx*10; geq];
%             Last_ceq = [dx; geq*100];
            Last_x   = xus;
        end
        y = Last_f;
    end

    function [c,ceq] = constr(xus, Parameters, ub_xu, lb_xu)
        if ~isequal(xus,Last_x) % Check if computation is necessary
            xu  = (xus).*(ub_xu'-lb_xu') + lb_xu';
            xs = xus(1:45); 
            x  = xu(1:45); 
            u  = xu(46:50); 
            
            [dx, y_m,~,~,~,~,u_RSS,~,y] = SimTE_2SubSystems_New(xs, u, Parameters, Modifiers, Derivatives_P, lb_TE, ub_TE);
            if strcmp(Modifiers.type,'iMA1') || strcmp(Modifiers.type,'iMA2')
                [phi1, phi2, g, geq] = uy2phig2(u, y, mode, Modifiers, Parameters,u_RSS);
            else
                [phi1, phi2, g, geq] = uy2phig2(u, y_m, mode, Modifiers, Parameters,u_RSS);
            end 
            
            if mode < 4
                Last_f   = phi1; 
            elseif mode > 3
                Last_f   = phi2;
            end
            Last_c   = [g; -y];%(2)
%             Last_ceq = [dx*1000; geq];
            Last_ceq = [dx*10; geq];
%             Last_ceq = [dx; geq*100];
            Last_x   = xus;
        end
        c   = Last_c;
        ceq = Last_ceq;
    end

end