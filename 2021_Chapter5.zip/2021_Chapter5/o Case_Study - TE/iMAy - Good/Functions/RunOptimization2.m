function [xxs, f, eflag, outpt, Last_ceq, Last_c] = RunOptimization2(xu0s, Parameters, lbs, ubs,lb, ub, opts, mode)
%                                                                                      PBstruct.lsqnonlin_options
Last_xu  = [];
Last_f   = [];
Last_c   = []; % Attention c is not the input of the plant but the NL constraint !!
Last_ceq = [];

Aeq = [];  
beq = [];

A = [];
b = [];

%%%%%%%%%%%%%%%  
% xs_sol = lsqnonlin(@(xs) SimTE(xs, u, Parameters, ub, lb),x0s,lbs,ubs,opts);

[xxs, f, eflag, outpt] = fmincon(@(xus)objfun(xus),...
                                xu0s, A, b, Aeq, beq, lbs, ubs, ...
                                @(xus)constr(xus,Parameters, ub, lb),opts);

    function y = objfun(xus)
        if ~isequal(xus,Last_xu) % Check if computation is necessary
            
            xu = (xus).*(ub'-lb') + lb';
            x = xu(1:48);
            u = xu(49:end);
            
            [dx, y] = SimTE(x, u, Parameters);
            [phi1, phi2, g, geq] = uy2phig(u,y, mode);
            
            Last_xu  = xus;
            if mode < 4
                Last_f   = phi1;
            elseif mode > 3
                Last_f   = phi2;
            end
%              Last_f   =0;
            Last_c   = g;
            Last_ceq = [dx; geq];
%             geq
        end
        y = Last_f;
    end

    function [c,ceq] = constr(xus,  Parameters, ub, lb)
        if ~isequal(xus,Last_xu) % Check if computation is necessary
            
            xu = (xus).*(ub'-lb') + lb';
            x = xu(1:48);
            u = xu(49:end);
            [dx, y] = SimTE(x, u, Parameters);
            [phi1, phi2, g, geq] = uy2phig(u,y, mode);
            
            Last_xu  = xus;
            if mode < 4
                Last_f   = phi1;
            elseif mode > 3
                Last_f   = phi2;
            end
%              Last_f   =0;
            Last_c   = g;
            Last_ceq = [dx; geq];
        end
        % Now compute constraint functions
        c   = Last_c;
        ceq = Last_ceq;
    end

end