function [xxs, f, eflag, outpt, dx] = SolveMCSSC_OL(x0s, u, Parameters, lb, ub, opts)

%                                                                                      PBstruct.lsqnonlin_options
Last_x   = [];
Last_f   = [];
Last_c   = []; % Attention c is not the input of the plant but the NL constraint !!
Last_ceq = [];

Aeq = [];  
beq = [];

A = [];
b = [];

ubs =  ones(1,length(x0s));
lbs = zeros(1,length(x0s));

%%%%%%%%%%%%%%%  
% xs_sol = lsqnonlin(@(xs) SimTE(xs, u, Parameters, ub, lb),x0s,lbs,ubs,opts);

[xxs, f, eflag, outpt] = fmincon(@(xs)objfun(xs),...
                                x0s, A, b, Aeq, beq, lbs, ubs, ...
                                @(xs)constr(xs, u, Parameters, ub, lb),opts);

    function y = objfun(xs)
        if ~isequal(xs,Last_x) % Check if computation is necessary
            x  = (xs).*(ub'-lb') + lb';
            dx = MCSSC_OL(x, u, Parameters);
            Last_ceq = dx;
            Last_x = xs;
            Last_f = 0;
            Last_c = [];
            
        end
        y = Last_f;
    end

    function [c,ceq] = constr(xs, u, Parameters, ub, lb)
        if ~isequal(xs,Last_x) % Check if computation is necessary
            x  = (xs).*(ub'-lb') + lb';
            dx = MCSSC_OL(x, u, Parameters);
            Last_ceq = dx;
            Last_x = xs;
            Last_f = 0;
            Last_c = [];
        end
        % Now compute constraint functions
        c   = Last_c;
        ceq = Last_ceq;
    end

end