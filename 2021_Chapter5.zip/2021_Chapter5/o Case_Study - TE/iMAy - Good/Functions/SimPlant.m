function [y, phi1, phi2, g, geq, yy, uuk, yyk] = SimPlant(u, mode)

global Fp_0 r1_0 r2_0 r3_0 r4_0 r5_0 r6_0 r7_0 Eadj_0 SP17_0      ...
       xmv1_0 xmv2_0 xmv3_0 xmv4_0 xmv5_0 xmv6_0 xmv7_0 xmv8_0    ...
       xmv9_0 xmv10_0 xmv11_0 xmv12_0 xInitial XMV r xFinal XMEAS ...
       XMEASCOMP XMEASSTREAM XMEASRHO setpoints OpCost IDV x      ...
       Production Quality tout prev_setpoints
 

setpoints.time    = 0;
prev_setpoints = setpoints;
setpoints.signals(1).values = [u(1), 50, 50, 65, 2800 u(2:5)', 1, 1, 100];
sim('MultiLoop_mode1');
results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost);
[phi1, phi2, g, geq, y, yy] = uy2phig_plant(results, mode);
[uuk, yyk] = IOsubsystems_p(u, y);
% [Fp_0,r1_0,r2_0,r3_0,r4_0,r5_0,r6_0,r7_0,Eadj_0,SP17_0,xmv1_0,xmv2_0,xmv3_0,xmv4_0,xmv5_0,xmv6_0,xmv7_0,xmv8_0,xmv9_0,xmv10_0,xmv11_0,xmv12_0,xInitial] = transition(XMV,r,xFinal);
transition();




