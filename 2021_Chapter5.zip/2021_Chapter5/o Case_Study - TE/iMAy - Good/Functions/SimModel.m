function [yk, phi1k, phi2k, gk, geqk, eflag, dx, x_sol] = SimModel(uk, x_TEs, lb_TE, ub_TE, Modifiers, Parameters, mode, Derivatives_P)

PBstruct   = ProblemStructure();

[x_sol,~,~,eflag]        = lsqnonlin(@(x_TE) SimTE_2SubSystems_New(x_TE, uk, Parameters, Modifiers, Derivatives_P, lb_TE, ub_TE), x_TEs, zeros(size(lb_TE)), ones(size(ub_TE)), PBstruct.lsqnonlin_options_2);
[dx, yk]                 = SimTE_2SubSystems_New(x_sol, uk, Parameters, Modifiers, Derivatives_P, lb_TE, ub_TE);
[phi1k, phi2k, gk, geqk] = uy2phig2(uk,yk, mode, Modifiers,Parameters);
      
