function [phi1, phi2, g, geq, y, yy] = uy2phig_plant(results, mode)

y = zeros(56,1);
y(1)  = results.xmeasstream.F5;
y(2)  = results.xmeasstream.F6;
y(3)  = results.xmeasstream.F8;
y(4)  = results.xmeasstream.F9;
y(5)  = results.xmeasstream.F11;
y(6)  = results.xmeascomp.c5_A;
y(7)  = results.xmeascomp.c5_B;
y(8)  = results.xmeascomp.c5_C;
y(9)  = results.xmeascomp.c5_D; 
y(10) = results.xmeascomp.c5_E;
y(11) = results.xmeascomp.c5_F;
y(12) = results.xmeascomp.c5_G;
y(13) = results.xmeascomp.c5_H;
y(14) = results.xmeascomp.c6_A;
y(15) = results.xmeascomp.c6_B;
y(16) = results.xmeascomp.c6_C;
y(17) = results.xmeascomp.c6_D;
y(18) = results.xmeascomp.c6_E;
y(19) = results.xmeascomp.c6_F;
y(20) = results.xmeascomp.c6_G;
y(21) = results.xmeascomp.c6_H;
y(22) = results.xmeascomp.c8_A;
y(23) = results.xmeascomp.c8_B;
y(24) = results.xmeascomp.c8_C;
y(25) = results.xmeascomp.c8_D;
y(26) = results.xmeascomp.c8_E;
y(27) = results.xmeascomp.c8_F;
y(28) = results.xmeascomp.c8_G;
y(29) = results.xmeascomp.c8_H;
y(30) = results.xmeascomp.c11_A*0;
y(31) = results.xmeascomp.c11_B*0;
y(32) = results.xmeascomp.c11_C*0;
y(33) = results.xmeascomp.c11_D;
y(34) = results.xmeascomp.c11_E;
y(35) = results.xmeascomp.c11_F;
y(36) = results.xmeascomp.c11_G;
y(37) = results.xmeascomp.c11_H;
y(38) = results.xmeas.W_comp;
y(39) = results.xmeas.m_steam;
y(40) = results.xmeas.Tr;
y(41) = results.xmeas.Vlr;
y(42) = results.xmeas.Vlsep;
y(43) = results.xmeas.Vlstr;
y(44) = results.xmeas.Pr;
y(45) = results.xmeas.Psep;
y(46) = results.xmeas.Tstr;
y(47) = results.xmeas.Stream11_m3h;
y(48) = results.xmeasrho.rho_11;
y(49) = (results.xmeas.Vlr* 35.3145-84.5)*(100/666.7);
y(50) = (results.xmeas.Vlsep* 35.3145-27.5)*(100/290);
y(51) = (results.xmeas.Vlstr* 35.3145-78.25)*(100/156.5);
y(52) = results.xmeasrho.rho_9;
y(53) = results.xmeas.Stream9_kscmh;
y(54) = results.xmeas.Tsep;
y(55) = results.xmv.v9;
y(56) = results.xmeas.Pstr;
y(57) = results.xmeasstream.F1;
y(58) = results.xmeasstream.F2;
y(59) = results.xmeasstream.F3;

MA = 2;
MB = 25.4;
MC = 28;
MD = 32;
ME = 46;
MF = 48;
MG = 62;
MH = 76;

phi1 = results.OPEX;
M9  = y(22)*MA + y(23)*MB + y(24)*MC + y(25)*MD + y(26)*ME + y(27)*MF + y(28)*MG + y(29)*MH; 
M11 = y(30)*MA + y(31)*MB + y(32)*MC + y(33)*MD + y(34)*ME + y(35)*MF + y(36)*MG + y(37)*MH; 
% 
% phi1
% M9

C_comp  = y(38)*0.0536;
C_steam = y(39)*0.0318;
C_purge = y(53)*y(52)/M9*(2.206*y(22) + 6.177*y(24) + 22.06*y(25) + 14.56*y(26) +  17.89*y(27) + 30.44*y(28) + 22.94*y(29));
C_prod  = y(47)*y(48)/M11*(22.06*y(33) + 14.56*y(34) +  17.89*y(35));

phi1 = C_comp + C_steam + C_purge + C_prod;

phi2 = -y(47)*y(48)/M11*(y(36)*62 + y(37)*76);


g = [y(44)-2895;
     y(40)-150;
     y(41)-21.3; 
     11.8-y(41); 
     y(42)-9; 
     3.3-y(42);
     y(43)-6.6; 
     3.35-y(43)];
 
if mode == 1 || mode == 4
    geq = y(36)*62/(y(37)*76+0.000001) - 50/50;
    if mode == 1
        geq = [geq; (y(47)*y(48)/M11*(y(36)*62 + y(37)*76)-14076)*1e-5];
%         geq = [geq; y(47)*y(48)/M11*(y(36)*62 + y(37)*76)-14076];
    end
elseif mode == 2 || mode == 5
    geq = y(36)*62/(y(37)*76) - 10/90;
    if mode == 2
        geq = [geq; (y(47)*y(48)/M11*(y(36)*62 + y(37)*76)-14076)*1e-5];
    end
else
    geq = y(36)*62/(y(37)*76) - 90/10;
    if mode == 3
        geq = [geq; y(47)*y(48)/M11*(y(36)*62 + y(37)*76)-11111];
    end
end

% y = [F6_m; F7_m; F8_m; F9_m; F11_m;...
%      c6_m; c7_m; c8_m; c11_m; ...
%      Wcomp_m;  msteam_m; Tr_m; VLr_m; VLsep_m; VLstr_m; ...
%      Pr_m];




yy = zeros(61,1);
yy(1)  = results.xmeasstream.F1;
yy(2)  = results.xmeasstream.F2;
yy(3)  = results.xmeasstream.F3;
yy(4)  = results.xmeasstream.F4;
yy(5)  = results.xmeasstream.F5;
yy(6)  = results.xmeasstream.F6;
yy(7)  = results.xmeasstream.F7;
yy(8)  = results.xmeasstream.F8;
yy(9)  = results.xmeasstream.F9;
yy(10) = results.xmeasstream.F10;
yy(11) = results.xmeasstream.F11;
yy(12) = results.xmeascomp.c5_A;
yy(13) = results.xmeascomp.c5_B;
yy(14) = results.xmeascomp.c5_C;
yy(15) = results.xmeascomp.c5_D;
yy(16) = results.xmeascomp.c5_E;
yy(17) = results.xmeascomp.c5_F;
yy(18) = results.xmeascomp.c5_G;
yy(19) = results.xmeascomp.c5_H;
yy(20) = results.xmeascomp.c6_A;
yy(21) = results.xmeascomp.c6_B;
yy(22) = results.xmeascomp.c6_C;
yy(23) = results.xmeascomp.c6_D;
yy(24) = results.xmeascomp.c6_E;
yy(25) = results.xmeascomp.c6_F;
yy(26) = results.xmeascomp.c6_G;
yy(27) = results.xmeascomp.c6_H;
yy(28) = results.xmeascomp.c7_A;
yy(29) = results.xmeascomp.c7_B;
yy(30) = results.xmeascomp.c7_C;
yy(31) = results.xmeascomp.c7_D;
yy(32) = results.xmeascomp.c7_E;
yy(33) = results.xmeascomp.c7_F;
yy(34) = results.xmeascomp.c7_G;
yy(35) = results.xmeascomp.c7_H;
yy(36) = results.xmeascomp.c8_A;
yy(37) = results.xmeascomp.c8_B;
yy(38) = results.xmeascomp.c8_C;
yy(39) = results.xmeascomp.c8_D;
yy(40) = results.xmeascomp.c8_E;
yy(41) = results.xmeascomp.c8_F;
yy(42) = results.xmeascomp.c8_G;
yy(43) = results.xmeascomp.c8_H;
yy(44) = results.xmeascomp.c10_A;
yy(45) = results.xmeascomp.c10_B;
yy(46) = results.xmeascomp.c10_C;
yy(47) = results.xmeascomp.c10_D;
yy(48) = results.xmeascomp.c10_E;
yy(49) = results.xmeascomp.c10_F;
yy(50) = results.xmeascomp.c10_G;
yy(51) = results.xmeascomp.c10_H;
yy(52) = results.xmeascomp.c11_A;
yy(53) = results.xmeascomp.c11_B;
yy(54) = results.xmeascomp.c11_C;
yy(55) = results.xmeascomp.c11_D;
yy(56) = results.xmeascomp.c11_E;
yy(57) = results.xmeascomp.c11_F;
yy(58) = results.xmeascomp.c11_G;
yy(59) = results.xmeascomp.c11_H;
yy(60) = results.xmeas.Pr ;
yy(61) = results.xmeas.Pstr ;

























