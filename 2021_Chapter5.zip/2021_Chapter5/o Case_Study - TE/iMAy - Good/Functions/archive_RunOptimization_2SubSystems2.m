function [xxs, f, eflag, outpt] = RunOptimization_2SubSystems2(x0s, u, Parameters, lb, ub, opts)
%                                                                                      PBstruct.lsqnonlin_options
Last_x   = [];
Last_f   = [];
Last_c   = [];
Last_ceq = [];

Aeq = [];  
beq = [];

A = [];
b = [];

ubs = ones(1,length(x0s));
lbs = zeros(1,length(x0s));

[xxs, f, eflag, outpt] = fmincon(@(xs)objfun(xs),...
                                x0s, A, b, Aeq, beq, lbs, ubs, ...
                                @(xs)constr(xs, u, Parameters, ub, lb),opts);

    function y = objfun(xs)
        if ~isequal(xs,Last_x) % Check if computation is necessary
            x  = (xs).*(ub'-lb') + lb';
            dx = SimTE_2SubSystems2(x, u, Parameters);
            Last_ceq = dx;
            Last_x = xs;
            Last_f = 0;
            Last_c = [];
        end
        % Now give cost functions
        y = Last_f;
    end

    function [c,ceq] = constr(xs, u, Parameters, ub, lb)
        if ~isequal(xs,Last_x) % Check if computation is necessary
            x  = (xs).*(ub'-lb') + lb';
            dx = SimTE_2SubSystems2(x, u, Parameters);
            Last_ceq = dx;
            Last_x = xs;
            Last_f = 0;
            Last_c = [];
        end
        % Now give constraint functions
        c   = Last_c;
        ceq = Last_ceq;
    end

end