function derivatives = derivatives_P(uk_s, uk, delta_P, ub_u, lb_u, mode, Method)

global Fp_0 r1_0 r2_0 r3_0 r4_0 r5_0 r6_0 r7_0 Eadj_0 SP17_0      ...
       xmv1_0 xmv2_0 xmv3_0 xmv4_0 xmv5_0 xmv6_0 xmv7_0 xmv8_0    ...
       xmv9_0 xmv10_0 xmv11_0 xmv12_0 xInitial XMV r xFinal XMEAS ...
       XMEASCOMP XMEASSTREAM XMEASRHO setpoints OpCost IDV x      ...
       Production Quality tout prev_setpoints
 
   
%% At the point
[yk, phi1k, phi2k, gk, geqk ~, uuk, yyk] = SimPlant(uk, mode);

prev_setpoints = setpoints;
derivatives.yk   = yk;
derivatives.uk   = uk;
derivatives.uuk_1 = uuk{1};
derivatives.uuk_2 = uuk{2};
derivatives.uuk_3 = uuk{3};
derivatives.yyk_1 = yyk{1};
derivatives.yyk_2 = yyk{2};
derivatives.yyk_3 = yyk{3};

derivatives.phi1k = phi1k;
derivatives.phi2k = phi2k;
derivatives.gk    = gk;
derivatives.geqk  = geqk;


%%
if Method < 10
nu = length(uk);

for i = 1:nu
    uk_p = (ub_u' - lb_u').*(uk_s+[zeros(i-1,1); delta_P(i) ; zeros(nu-i,1)]) + lb_u';
       [yk_p(:,i), phi1k_p(i), phi2k_p(i), gk_p(:,i), geqk_p(:,i), ~, uuk_p_temp, yyk_p_temp] = SimPlant(uk_p, mode);

prev_setpoints = setpoints;

    uuk_p1(:,i) = uuk_p_temp{1};
    uuk_p2(:,i) = uuk_p_temp{2};
    uuk_p3(:,i) = uuk_p_temp{3};
    
    derivatives.uuk_1d{i} = uuk_p1(:,i);
    derivatives.uuk_2d{i} = uuk_p2(:,i);
    derivatives.uuk_3d{i} = uuk_p3(:,i);
    derivatives.uk_p{i}   = uk_p ;

    yyk_p1(:,i) = yyk_p_temp{1};
    yyk_p2(:,i) = yyk_p_temp{2};
    yyk_p3(:,i) = yyk_p_temp{3};
    
    % Forward finit difference
    derivatives.dyk_du(:,i)    = (yk_p(:,i)-yk)       /(norm(uk_p-uk));
    derivatives.dphi1k_du(i,1) = (phi1k_p(i)-phi1k)   /(norm(uk_p-uk));
    derivatives.dphi2k_du(i,1) = (phi2k_p(i)-phi2k)   /(norm(uk_p-uk));
    derivatives.dgk_du(:,i)    = (gk_p(:,i)-gk)       /(norm(uk_p-uk));
    derivatives.dgeqk_du(:,i)  = (geqk_p(:,i)-geqk)   /(norm(uk_p-uk));
    derivatives.duuk_1_du(:,i) = (uuk_p1(:,i)-uuk{1}) /(norm(uk_p-uk));
    derivatives.duuk_2_du(:,i) = (uuk_p2(:,i)-uuk{2}) /(norm(uk_p-uk));
    derivatives.duuk_3_du(:,i) = (uuk_p3(:,i)-uuk{3}) /(norm(uk_p-uk));
    derivatives.dyyk_1_du(:,i) = (yyk_p1(:,i)-yyk{1}) /(norm(uk_p-uk));
    derivatives.dyyk_2_du(:,i) = (yyk_p2(:,i)-yyk{2}) /(norm(uk_p-uk));
    derivatives.dyyk_3_du(:,i) = (yyk_p3(:,i)-yyk{3}) /(norm(uk_p-uk));
    
    Dyyk_1(:,i) = yyk_p1(:,i)-yyk{1};
    Dyyk_2(:,i) = yyk_p2(:,i)-yyk{2};    
    Dyyk_3(:,i) = yyk_p3(:,i)-yyk{3};
    
    Dphi1(:,i) = phi1k_p(i)  - phi1k;
    Dphi2(:,i) = phi2k_p(i)  - phi2k;
    Dgp(:,i)   = gk_p(:,i)   - gk;
    Dgeqp(:,i) = geqk_p(:,i) - geqk;
end

derivatives.dyyk_3_duu3 = derivatives.dyyk_3_du; 
    
%% compute the "local derivatives"
W1             = uuk_p1-kron(ones(1,nu),uuk{1});
pinvW1         = pinv(W1);
W1_x_invW1     = W1*pinvW1;
pinvW1_x_invW1 = pinv(W1_x_invW1);
    derivatives.pinvW1         = pinvW1; 
    derivatives.pinvW1_x_invW1 = pinvW1_x_invW1;
    derivatives.dyyk_1_duu1      = Dyyk_1  *pinvW1*pinvW1_x_invW1;

W2             = uuk_p2-kron(ones(1,nu),uuk{2});
pinvW2         = pinv(W2);
W2_x_invW2     = W2*pinvW2;
pinvW2_x_invW2 = pinv(W2_x_invW2);
    derivatives.pinvW2         = pinvW2;
    derivatives.pinvW2_x_invW2 = pinvW2_x_invW2;
    derivatives.dyyk_2_duu2      = Dyyk_2  *pinvW2*pinvW2_x_invW2;
    derivatives.dphi1k_duu2      = Dphi1   *pinvW2*pinvW2_x_invW2;
    derivatives.dphi2k_duu2      = Dphi2   *pinvW2*pinvW2_x_invW2;
    derivatives.dgk_duu2         = Dgp     *pinvW2*pinvW2_x_invW2;
    derivatives.dgeqk_duu2       = Dgeqp   *pinvW2*pinvW2_x_invW2;

W3             = uuk_p3-kron(ones(1,nu),uuk{3});
pinvW3         = pinv(W3);
W3_x_invW3     = W3*pinvW3;
pinvW3_x_invW3 = pinv(W3_x_invW3);
    derivatives.pinvW3         = pinvW3;
    derivatives.pinvW3_x_invW3 = pinvW3_x_invW3;
    derivatives.dyyk_3_duu3    = Dyyk_3  *pinvW3*pinvW3_x_invW3;
end
end







