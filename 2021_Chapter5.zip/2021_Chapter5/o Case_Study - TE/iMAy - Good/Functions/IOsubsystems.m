function [uuk, yyk] = IOsubsystems(u, y)

c_A   = 100*y(14)/(y(14)+y(16));
c_AC  = 100*(y(14)+y(16));
                         % [�C]
F1 = y(57); 
F2 = y(58);
F3 = y(59);
F6 = y(2);
F8 = y(3);

c1 = [0.9999; 0.0001; 0; 0; 0; 0; 0; 0];
c2 = [0; 0.0001; 0; 0.9999; 0; 0; 0; 0];
c3 = [0; 0; 0; 0; 0.9999; 0.0001; 0; 0];
c6 = y(14:21);
c8 = y(22:29);

F5 = F6 - F1-F2-F3-F8;
c5 = (F6*c6 - F1*c1 - F2*c2 - F3*c3 - F8*c8)/F5;



%% Controllers
%         m11_sp; cG11_sp; c_Asp; c_ACsp; Tr_sp    
uuk{1} = [u(1);   u(2);    u(3);  u(4);   u(5)]; 
%% RSS
%         m11    Vpstr; Vpsep; Vpr;   Pr;    Tr;    msteam; Tstr;  F9;       
uuk{2} = [y(47); y(51); y(50); y(49); y(44); y(40); y(39);  y(46); y(4); ...
...       F8;   Pm;    c6_A   c6_B   c6_C   c6_D   c6_E   c6_F   c6_G   c6_H      
          y(3); y(56); y(14); y(15); y(16); y(17); y(18); y(19); y(20); y(21); ...
...       Tsep] 
          y(54)];
%% Mixer
%         c_A; c_AC; F5;   F6;   Pr;    T8;    Tstr;   
uuk{3} = [c_A; c_AC; y(1); y(2); y(44); y(46); y(46); ...
...       c5_A  c5_B  c5_C  c5_D  c5_E   c5_F   c5_G   c5_H
          y(6); y(7); y(8); y(9); y(10); y(11); y(12); y(13); ...
...       c8_A   c8_B   c8_C   c8_D   c8_E   c8_F   c8_G   c8_H   c6_E
          y(22); y(23); y(24); y(25); y(26); y(27); y(28); y(29); y(18)];

% %         c_A; c_AC; F5;   F6;   Pr;    T8;    Tstr;   
% uuk{3} = [c_A; c_AC; F5; y(2); y(44); y(54); y(46); ...
% ...       c5_A  c5_B  c5_C  c5_D  c5_E   c5_F   c5_G   c5_H
%           c5(1); c5(2); c5(3); c5(4); c5(5); c5(6); c5(7); c5(8); ...
% ...       c8_A   c8_B   c8_C   c8_D   c8_E   c8_F   c8_G   c8_H 
%           y(22); y(23); y(24); y(25); y(26); y(27); y(28); y(29)]; 

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Controllers
%         m11;   Vpstr; Vpsep; Vpr;   Pr;    cG11;      c_A; c_AC; Tr;    msteam;  Tstr    F9   c6E    F6   Pm   ]   
yyk{1} = [y(47); y(51); y(50); y(49); y(44); y(36)*100; c_A; c_AC; y(40); y(39);   y(46); y(4); y(18);y(2); y(56)];   
%% RSS
%         F5;   F6;   F11;  T8;    Tsep;  Psep;  VLsep; VLstr; Vliqr;   rho11; rho9;   scm9     Wcomp          
yyk{2} = [y(1); y(2); y(5); y(46); y(54); y(45); y(42);  y(43);  y(41);  y(48); y(52); y(53); y(38); ...
...       c5_A  c5_B  c5_C  c5_D  c5_E   c5_F   c5_G   c5_H
          y(6); y(7); y(8); y(9); y(10); y(11); y(12); y(13); ...
...       c8_A   c8_B   c8_C   c8_D   c8_E   c8_F   c8_G   c8_H 
          y(22); y(23); y(24); y(25); y(26); y(27); y(28); y(29); ...
...       c11_A  c11_B  c11_C  c11_D  c11_E  c11_F  c11_G  c11_H 
          y(30); y(31); y(32); y(33); y(34); y(35); y(36); y(37)];

% %         F5;   F6;   F11;  T8;    Tsep;  Psep;  VLsep; VLstr; Vliqr; rho11; rho9;  v9     Wcomp          
% yyk{2} = [F5; y(2); y(5); y(46); y(54); y(45); y(42);  y(43);  y(41);  y(48); y(52); y(55); y(38); ...
% ...       c5_A  c5_B  c5_C  c5_D  c5_E   c5_F   c5_G   c5_H
%           c5(1); c5(2); c5(3); c5(4); c5(5); c5(6); c5(7); c5(8); ...
% ...       c8_A   c8_B   c8_C   c8_D   c8_E   c8_F   c8_G   c8_H 
%           y(22); y(23); y(24); y(25); y(26); y(27); y(28); y(29); ...
% ...       c11_A  c11_B  c11_C  c11_D  c11_E  c11_F  c11_G  c11_H 
%           y(30); y(31); y(32); y(33); y(34); y(35); y(36); y(37)]; 
%% Mixer
%         F8;   Tm;    Pm;   
yyk{3} = [y(3); y(46); y(56); ...
...       c6_A   c6_B   c6_C   c6_D   c6_E   c6_F   c6_G   c6_H
          y(14); y(15); y(16); y(17); y(18); y(19); y(20); y(21)]; 
end






