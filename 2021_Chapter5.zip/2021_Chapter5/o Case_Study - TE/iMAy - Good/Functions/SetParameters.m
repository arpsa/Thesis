function Parameter = SetParameters()

Parameter = struct();

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Inflows
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Parameter.Stream1.c = [0.9999; 0.0001; 0; 0; 0; 0; 0; 0];   % [molar fraction]
Parameter.Stream1.T = 45;                             % [�C]

Parameter.Stream2.c = [0; 0.0001; 0; 0.9999; 0; 0; 0; 0];   % [molar fraction]
Parameter.Stream2.T = 45;                             % [�C]

Parameter.Stream3.c = [0; 0; 0; 0; 0.9999; 0.0001; 0; 0];   % [molar fraction]
Parameter.Stream3.T = 45;                             % [�C]

Parameter.Stream4.c = [0.485; 0.005; 0.51; 0; 0; 0; 0; 0];  % [molar fraction]
Parameter.Stream4.T = 45;                             % [�C]


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  2.- Components physical properties
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Parameter.A.M    = 2;     % [kg/kmol]
Parameter.A.rho  = 0;     % [kg/m3]
Parameter.A.Cpl  = 0;     % [kJ/(kg �C)]
Parameter.A.Cpv  = 14.6;  % [kJ/(kg �C)]
Parameter.A.Hvap = 0;     % [kJ/kg]

Parameter.B.M    = 25.4;  % [kg/kmol]
Parameter.B.rho  = 0;     % [kg/m3]
Parameter.B.Cpl  = 0;     % [kJ/(kg �C)]
Parameter.B.Cpv  = 2.04;  % [kJ/(kg �C)]
Parameter.B.Hvap = 0;     % [kJ/kg]

Parameter.C.M    = 28;    % [kg/kmol]
Parameter.C.rho  = 0;     % [kg/m3]
Parameter.C.Cpl  = 0;     % [kJ/(kg �C)]
Parameter.C.Cpv  = 1.05;  % [kJ/(kg �C)]
Parameter.C.Hvap = 0;     % [kJ/kg]

Parameter.D.M    = 32;    % [kg/kmol]
Parameter.D.rho  = 299;   % [kg/m3]
Parameter.D.Cpl  = 7.66;  % [kJ/(kg �C)]
Parameter.D.Cpv  = 1.85;  % [kJ/(kg �C)]
Parameter.D.Hvap = 202;   % [kJ/kg]

Parameter.E.M    = 46;    % [kg/kmol]
Parameter.E.rho  = 365;   % [kg/m3]
Parameter.E.Cpl  = 4.17;  % [kJ/(kg �C)]
Parameter.E.Cpv  = 1.87;  % [kJ/(kg �C)]
Parameter.E.Hvap = 372;   % [kJ/kg]

Parameter.F.M    = 48;    % [kg/kmol]
Parameter.F.rho  = 328;   % [kg/m3]
Parameter.F.Cpl  = 4.45;  % [kJ/(kg �C)]
Parameter.F.Cpv  = 2.02;  % [kJ/(kg �C)]
Parameter.F.Hvap = 372;   % [kJ/kg]

Parameter.G.M    = 62;    % [kg/kmol]
Parameter.G.rho  = 612;   % [kg/m3]
Parameter.G.Cpl  = 2.55;  % [kJ/(kg �C)]
Parameter.G.Cpv  = 0.712; % [kJ/(kg �C)]
Parameter.G.Hvap = 523;   % [kJ/kg]

Parameter.H.M    = 76;    % [kg/kmol]
Parameter.H.rho  = 617;   % [kg/m3]
Parameter.H.Cpl  = 2.45;  % [kJ/(kg �C)]
Parameter.H.Cpv  = 0.628; % [kJ/(kg �C)]
Parameter.H.Hvap = 486;   % [kJ/kg]

Parameter.D.A = 20.81;    % [-]
Parameter.D.B = -1444;    % [-]
Parameter.D.c = 259;      % [-]

Parameter.E.A = 21.24;    % [-]
Parameter.E.B = -2114;    % [-]
Parameter.E.C = 266;      % [-]

Parameter.F.A = 21.24;    % [-]
Parameter.F.B = -2114;    % [-]
Parameter.F.C = 266;      % [-]

Parameter.G.A = 21.32;    % [-]
Parameter.G.B = -2748;    % [-]
Parameter.G.C = 233;      % [-]

Parameter.H.A = 22.1;     % [-]
Parameter.H.B = -3318;    % [-]
Parameter.H.C = 250;      % [-]


 
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  3.- Reactions
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Parameter.a1  = 1.08;  % [-]
Parameter.a2  = 0.311; % [-]
Parameter.a3  = 0.874; % [-]
Parameter.a4  = 1.15;  % [-]
Parameter.a5  = 0.37;  % [-]
Parameter.a6  = 1;     % [-]
Parameter.a7  = 1;     % [-]
Parameter.a8  = 1;     % [-]
Parameter.a9  = 1;     % [-]
Parameter.a10 = 1;     % [-]

% % Test
Parameter.k1 = 44.06; % [??]
Parameter.k2 = 10.27; % [??]
Parameter.k3 = 59.5;  % [??]
Parameter.E1 = 42600; % [??]
Parameter.E2 = 19400; % [??]
Parameter.E3 = 59400; % [??]

% 
% % % Test
% Parameter.k1 = 44.06; % [??]
% Parameter.k2 = 10.27; % [??]
% Parameter.k3 = 59.5;  % [??]
% Parameter.E1 = 42650; % [??]
% Parameter.E2 = 19400; % [??]
% Parameter.E3 = 59450; % [??]
% 
% % Test2Parameter.a1  = 1.08;  % [-]
% Parameter.a2  = 0.3; % [-]
% Parameter.a3  = 0.9; % [-]
% Parameter.a4  = 1.2;  % [-]
% Parameter.a5  = 0.4;  % [-]
% Parameter.a6  = 1;     % [-]
% Parameter.a7  = 1;     % [-]
% Parameter.a8  = 1;     % [-]
% Parameter.a9  = 1;     % [-]
% Parameter.a10 = 1;     % [-]
% Parameter.k1 = 44.06; % [??]
% Parameter.k2 = 10.27; % [??]
% Parameter.k3 = 59.5;  % [??]
% Parameter.E1 = 42700; % [??]
% Parameter.E2 = 19410; % [??]
% Parameter.E3 = 59390; % [??]



% 
% Parameter.a1  = 1.077;  % [-]
% Parameter.a2  = 0.442; % [-]
% Parameter.a3  = 1; % [-]
% Parameter.a4  = 1.016;  % [-]
% Parameter.a5  = 0.478;  % [-]
% Parameter.a6  = 1;     % [-]
% Parameter.a7  = 0.995;     % [-]
% Parameter.a8  = 1;     % [-]
% Parameter.a9  = 0.997;     % [-]
% Parameter.a10 = 1;     % [-]
% 
% Parameter.k1 = 31.681; % [??]
% Parameter.k2 = 3.322; % [??]
% Parameter.k3 = 53.814;  % [??]
% Parameter.k4 = 53.333; % [??]
% 
% Parameter.E1 = 40000; % [??]
% Parameter.E2 = 20000; % [??]
% Parameter.E3 = 60000; % [??]
% Parameter.E4 = 60000; % [??]

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 3.- Valves coefficients
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Parameter.v6  =   3e3;  % [kmol/(h.MPa^(1/2))]
Parameter.v7  = 5.5e3;  % [kmol/(h.MPa^(1/2))]
Parameter.pv9 = 0.2369; % [kmol/(h.MPa^(1/2))]


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 4.- Environement
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Parameter.Pout = 0.1013; % [MPa]

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 5.- Universal Constant
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Parameter.R = 8314.4598; % [m3.kPa/(K.kmol)]
 
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 6.- Stripper constantes
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Parameter.cQstr = 2300; % [kJ/kg]

end