function [xus_sol2, f, eflag, outpt, lambda,dx] = RunOptimization_UX_combo(xu0s, Parameters, lb_xu, ub_xu, mode, Modifiers, K, uk)

%     [xus_sol] = RunOptimization_UX(xu0s, Parameters, lb_xu, ub_xu, mode, Modifiers, K, uk);
%     [xus_sol2, f, eflag, outpt, Last_ceq] = RunOptimization_UX2(xus_sol, Parameters, lb_xu, ub_xu, mode, Modifiers, K, uk);
    [xus_sol2, f, eflag, outpt, lambda, dx] = RunOptimization_UX(xu0s, Parameters, lb_xu, ub_xu, mode, Modifiers, K, uk);
% %     [xus_sol2, f, eflag, outpt, Last_ceq] = RunOptimization_UX2(xus_sol, Parameters, lb_xu, ub_xu, mode, Modifiers, K, uk);

end