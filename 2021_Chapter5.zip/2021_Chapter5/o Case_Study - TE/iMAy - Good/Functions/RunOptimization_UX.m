function [xus_sol, f, eflag, outpt, lambda, dx] = RunOptimization_UX(xu0s, Parameters, lb_xu, ub_xu, mode, Modifiers, K, uk)
%                                                                                      PBstruct.lsqnonlin_options
Last_x   = [];
Last_f   = [];
Last_c   = [];
Last_ceq = [];

% Aeq = [zeros(1,60) zeros(1,1) 1 zeros(1,5);
%        zeros(1,60) zeros(1,2) 1 zeros(1,4);
%        zeros(1,60) zeros(1,6) 1 ];
% beq = [0; 1; 0];%


% Aeq = [zeros(1,60) zeros(1,1) 1 zeros(1,5);
%        zeros(1,60) zeros(1,2) 1 zeros(1,4)];
% beq = [0; 1];%

Aeq = [];
beq = [];%


A = [];
b = [];

ubs = ones(1,length(xu0s));
lbs = zeros(1,length(xu0s));

PBstruct = ProblemStructure();

[xus_sol, f, eflag, outpt,lambda] = fmincon(@(xus)objfun(xus, Parameters, ub_xu, lb_xu),...
                                xu0s, A, b, Aeq, beq, lbs, ubs, ...
                                @(xus)constr(xus, Parameters, ub_xu, lb_xu),PBstruct.fmincon_options_5);  % 

    function y = objfun(xus, Parameters, ub_xu, lb_xu)
        if ~isequal(xus,Last_x) % Check if computation is necessary
            xu  = (xus).*(ub_xu'-lb_xu') + lb_xu';
            x  = xu(1:60); 
            u  = xu(61:65); 
%             x2 = xu(66:end);
            
            [dx, y, yy]= SimTE_2SubSystems(x, u, Parameters, Modifiers);
            [phi1, phi2, g, geq] = uy2phig2(u, y, mode, Modifiers, Parameters);
            
%             [dx_2, y_2]= SimTE_2SubSystems(x2, K*(u-uk)+uk, Parameters, Modifiers);
%             [~, ~, g_2, geq_2] = uy2phig2(K*(u-uk)+uk, y_2, mode, Modifiers, Parameters);

%             Modifiers2 = Modifiers;
%             Modifiers2.type = 'none';
%             [dx_2, y_2]= SimTE_2SubSystems(x2, u, Parameters, Modifiers2);
% %             [~, ~, g_2, geq_2] = uy2phig2(u, y_2, mode, Modifiers, Parameters);
%             
%                 steplim = zeros(5,1);
%                steplim(1)= abs(uk(1)-u(1)) - 5;  % m11 
%                steplim(2)= abs(uk(2)-u(2)) - 5;  % %G  
%                steplim(3)= abs(uk(3)-u(3)) - 5;  % C_A 
%                steplim(4)= abs(uk(4)-u(4)) - 5;  % C_AC 
%                steplim(5)= abs(uk(5)-u(5)) - 2;  % Tr
               
            if mode < 4
                Last_f   = phi1; 
            elseif mode > 3
                Last_f   = phi2;
            end
%             Last_c   = [g; -y; g_2; -y_2; geq(1); -geq(2)];
%             Last_ceq = [dx; dx_2];
%             Last_c   = [g; -y];
%             Last_ceq = [dx; dx_2; geq(1); -geq(2)];
%             Last_c   = [g; -y; (1); -geq(2)];
            Last_c   = [g; -y; -yy'];
            Last_ceq = [dx; geq];
            Last_x   = xus;
        end
        % Now give cost functions
        y = Last_f;
    end

    function [c,ceq] = constr(xus, Parameters, ub_xu, lb_xu)
        if ~isequal(xus,Last_x) % Check if computation is necessary
            xu  = (xus).*(ub_xu'-lb_xu') + lb_xu';
            x  = xu(1:60); 
            u  = xu(61:65); 
%             x2 = xu(66:end);
            
            [dx, y, yy]= SimTE_2SubSystems(x, u, Parameters, Modifiers);
            [phi1, phi2, g, geq] = uy2phig2(u, y, mode, Modifiers, Parameters);
            
%             [dx_2, y_2]= SimTE_2SubSystems(x2, K*(u-uk)+uk, Parameters, Modifiers);
%             [~, ~, g_2, geq_2] = uy2phig2(K*(u-uk)+uk, y_2, mode, Modifiers, Parameters);
% 
%             Modifiers2 = Modifiers;
%             Modifiers2.type = 'none';
%             [dx_2, y_2]= SimTE_2SubSystems(x2, u, Parameters, Modifiers2);
% %             [~, ~, g_2, geq_2] = uy2phig2(u, y_2, mode, Modifiers, Parameters);
            

%       m11 %G C_A C_AC  Tr

%                 steplim = zeros(5,1);
%                steplim(1)= abs(uk(1)-u(1)) - 5;  % m11 
%                steplim(2)= abs(uk(2)-u(2)) - 5;  % %G  
%                steplim(3)= abs(uk(3)-u(3)) - 5;  % C_A 
%                steplim(4)= abs(uk(4)-u(4)) - 5;  % C_AC 
%                steplim(5)= abs(uk(5)-u(5)) - 2;  % Tr
                
            if mode < 4
                Last_f   = phi1; 
            elseif mode > 3
                Last_f   = phi2;
            end
%             Last_c   = [g; -y; g_2; -y_2; geq(1); -geq(2)];
%             Last_ceq = [dx; dx_2];
%             Last_c   = [g; -y];
%             Last_ceq = [dx; dx_2; geq(1); -geq(2)];
            Last_c   = [g; -y; -yy'];
            Last_ceq = [dx; geq];
            Last_x   = xus;
        end
        % Now give constraint functions
        c   = Last_c;
        ceq = Last_ceq;
    end

end