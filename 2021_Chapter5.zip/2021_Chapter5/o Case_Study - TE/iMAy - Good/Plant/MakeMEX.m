% setenv('MW_MINGW64_LOC','C:\Users\arisp_3vn8lw9\mingw64')
% mex Copy_of_temexd_mod.c
mex temexd_mod.c