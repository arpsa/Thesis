clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')

addpath('Plant')
addpath('Model')
addpath('Functions')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.- Initialize plant at base case
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.1.- Tunable parameters
    Measurement_Noise = 0; % 0: without noise | 1: with noise
        MNoise.time           = 0;
        MNoise.signals.values = Measurement_Noise;
% 1.2.- Base case initialisation of states & simulation sampling times
    load Mode1xInitial
    Ts_base=0.0005;
    Ts_save=0.01;
% 1.3.- Initial setpoints
    setpoints.time    = 0;
    setpoints.signals.values = [21; 50; 50; 50; 2800; 53.8; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';
    prev_setpoints = setpoints;
% 1.4.- Initial valve positions
    u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
    for i=1:12
        iChar=int2str(i);
        eval(['xmv',iChar,'_0=u0(',iChar,');']);
    end
% 1.5.- Initial Controlers parameters
    Fp_0   = 100;
    r1_0   = 0.251/Fp_0;
    r2_0   = 3664/Fp_0;
    r3_0   = 4509/Fp_0;
    r4_0   = 9.35/Fp_0;
    r5_0   = 0.337/Fp_0;
    r6_0   = 25.16/Fp_0;
    r7_0   = 22.95/Fp_0;
    Eadj_0 = 0;
    SP17_0 = 80.1;
    
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2.- Lauch simulation
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sim('MultiLoop_mode1')

% %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % 3.- Extract data
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[results] = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost)


%% Initialization model with plant values
Parameters = SetParameters();

% u_str = [Vpstr_sp; m11_sp; msteam_sp; Tsep; Tstr; c10]; 
% x_str = [F4; F5; F10; F11];
% y_str = [F4; F5; F10; F11; Tstr; rho_11; m11; msteam; Vliq_str; c5; c11];


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Inputs definition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs variables
F10       = results.xmeasstream.F10;
c11_G_sp  = setpoints.signals.values(6);
Tstr_sp   = results.xmeas.Tstr;
Vpstr_sp  = setpoints.signals.values(2);
m11_sp    = setpoints.signals.values(1);
msteam_sp = results.xmeas.m_steam;  % Should be valve position
Tsep      = results.xmeas.Tsep ;
c10       = [results.xmeascomp.c10_A; results.xmeascomp.c10_B; results.xmeascomp.c10_C; ...
            results.xmeascomp.c10_D; results.xmeascomp.c10_E; results.xmeascomp.c10_F; ...
            results.xmeascomp.c10_G; results.xmeascomp.c10_H]; 
Tstr      = results.xmeas.Tstr;

u_str = zeros(13,1);
u_str(1)     = Vpstr_sp;
u_str(2)     = m11_sp;
u_str(3)     = msteam_sp;
u_str(4)     = Tsep;
u_str(5)     = Tstr;
u_str(6:6+7) = c10;

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
% x_str = [F4; F5; F10; F11];
x0 = [results.xmeasstream.F4; results.xmeasstream.F5; results.xmeasstream.F10; results.xmeasstream.F11]*0.5; 
PBstruct   = ProblemStructure();

ub = [1000 1000 1000 1000];
lb = [ 100  100  100  100];
x_sol = lsqnonlin(@(x_str) Stripper(x_str, u_str, Parameters),x0,lb,ub,PBstruct.lsqnonlin_options);
[test, y_str] = Stripper(x_sol, u_str, Parameters);
test
%%
% y_str = [F4; F5; F10; F11; Tstr; rho11; m11; msteam; Vliq_str; c5; c11];
disp(['F4     Plant: ',num2str(results.xmeasstream.F4,4)  ,'   Model: ', num2str(y_str(1),4)])
disp(['F5     Plant: ',num2str(results.xmeasstream.F5,4)  ,'   Model: ', num2str(y_str(2),4)])
disp(['F10    Plant: ',num2str(results.xmeasstream.F10,4) ,'   Model: ', num2str(y_str(3),4)])
disp(['F11    Plant: ',num2str(results.xmeasstream.F11,4) ,'   Model: ', num2str(y_str(4),4)])
disp(['Tstr   Plant: ',num2str(results.xmeas.Tstr ,4)     ,'   Model: ', num2str(y_str(5),4)])
disp(['rho11  Plant: ',num2str(results.xmeasrho.rho_11,4) ,'   Model: ', num2str(y_str(6),4)])
disp(['m11    Plant: ',num2str(results.xmeas.Stream11_m3h),'   Model: ', num2str(y_str(7),4)])
disp(['Vliq_str  Plant: ',num2str(results.xmeas.Vlstr,4)  ,'   Model: ', num2str(y_str(8),4)])
disp(' ')

disp(['c5_A   Plant: ',num2str(results.xmeascomp.c5_A,4)  ,'   Model: ', num2str(y_str(9),4)])
disp(['c5_B   Plant: ',num2str(results.xmeascomp.c5_B,4)  ,'   Model: ', num2str(y_str(10),4)])
disp(['c5_C   Plant: ',num2str(results.xmeascomp.c5_C,4)  ,'   Model: ', num2str(y_str(11),4)])
disp(['c5_D   Plant: ',num2str(results.xmeascomp.c5_D,4)  ,'   Model: ', num2str(y_str(12),4)])
disp(['c5_E   Plant: ',num2str(results.xmeascomp.c5_E,4)  ,'   Model: ', num2str(y_str(13),4)])
disp(['c5_F   Plant: ',num2str(results.xmeascomp.c5_F,4)  ,'   Model: ', num2str(y_str(14),4)])
disp(['c5_G   Plant: ',num2str(results.xmeascomp.c5_G,4)  ,'   Model: ', num2str(y_str(15),4)])
disp(['c5_H   Plant: ',num2str(results.xmeascomp.c5_H,4)  ,'   Model: ', num2str(y_str(16),4)])
sum(y_str(10:17))
disp(' ')

disp(['c11_A   Plant: ',num2str(results.xmeascomp.c11_A,4)  ,'   Model: ', num2str(y_str(17),4)])
disp(['c11_B   Plant: ',num2str(results.xmeascomp.c11_B,4)  ,'   Model: ', num2str(y_str(18),4)])
disp(['c11_C   Plant: ',num2str(results.xmeascomp.c11_C,4)  ,'   Model: ', num2str(y_str(19),4)])
disp(['c11_D   Plant: ',num2str(results.xmeascomp.c11_D,4)  ,'   Model: ', num2str(y_str(20),4)])
disp(['c11_E   Plant: ',num2str(results.xmeascomp.c11_E,4)  ,'   Model: ', num2str(y_str(21),4)])
disp(['c11_F   Plant: ',num2str(results.xmeascomp.c11_F,4)  ,'   Model: ', num2str(y_str(22),4)])
disp(['c11_G   Plant: ',num2str(results.xmeascomp.c11_G,4)  ,'   Model: ', num2str(y_str(23),4)])
disp(['c11_H   Plant: ',num2str(results.xmeascomp.c11_H,4)  ,'   Model: ', num2str(y_str(24),4)])

disp(' ')
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')