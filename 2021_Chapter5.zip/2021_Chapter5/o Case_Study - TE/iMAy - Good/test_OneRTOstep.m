clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')

addpath('Plant')
addpath('Model')
addpath('Functions')
global Fp_0 r1_0 r2_0 r3_0 r4_0 r5_0 r6_0 r7_0 Eadj_0 SP17_0      ...
       xmv1_0 xmv2_0 xmv3_0 xmv4_0 xmv5_0 xmv6_0 xmv7_0 xmv8_0    ...
       xmv9_0 xmv10_0 xmv11_0 xmv12_0 xInitial XMV r xFinal XMEAS ...
       XMEASCOMP XMEASSTREAM XMEASRHO setpoints OpCost IDV x      ...
       prev_setpoints Production Quality tout

   
Parameters = SetParameters();
   
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.- Initialize plant at base case
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.1.- Tunable parameters
    Measurement_Noise = 0; % 0: without noise | 1: with noise
        MNoise.time           = 0;
        MNoise.signals.values = Measurement_Noise;
% 1.2.- Base case initialisation of states & simulation sampling times
    load Mode1xInitial
    Ts_base=0.0005;
    Ts_save=0.01;
% 1.3.- Initial setpoints
    setpoints.time    = 0;
    setpoints.signals.values = [21; 40; 60; 60; 2500; 10; 100*32.2/(32.2+18.8); 32.2+18.8; 125; 1; 1; 100]';

    prev_setpoints = setpoints;
    % 1.4.- Initial valve positions
    u0=[63.053, 53.98, 24.644, 61.302, 22.21, 40.064, 38.10, 46.534, 47.446, 41.106, 18.114, 50];
    for i=1:12
        iChar=int2str(i);
        eval(['xmv',iChar,'_0=u0(',iChar,');']);
    end
% 1.5.- Initial Controlers parameters
    Fp_0   = 100;
    r1_0   = 0.251/Fp_0;
    r2_0   = 3664/Fp_0;
    r3_0   = 4509/Fp_0;
    r4_0   = 9.35/Fp_0;
    r5_0   = 0.337/Fp_0;
    r6_0   = 25.16/Fp_0;
    r7_0   = 22.95/Fp_0;
    Eadj_0 = 0;
    SP17_0 = 80.1;
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2.- Lauch simulation
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 u0   = setpoints.signals.values([1 4 5 6 7 8 9])';
    mode = 1;
    [yk, phi1k, phi2k, gk, geqk] = SimPlant(u0, mode);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % 3.- Extract data
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
results = ExtractSSData(XMEAS, XMEASCOMP, XMEASSTREAM, XMEASRHO, XMV, setpoints, OpCost);

uk = setpoints.signals.values([1 4 5 6 7 8 9])';
%       m11 VLr Pr   %G C_A C_AC  Tr
ub_u = [40  80  2800 60 70  100   140];
lb_u = [21  65  1000 20 30   30   110]; % min for VLstr, VLsep, and vsteam chosen such that they are equal to their equality constraint.
uk_s = (uk - lb_u')./(ub_u' - lb_u') ;

delta_M =[1e-4 1e-5 1e-4 1e-5 1e-5 0.9e-4 1e-5];
delta_P =[1e-5 1e-5 1e-4 1e-5 1e-5 0.9e-4 1e-5];

mode = 1;


Modifiers = struct();
    Modifiers.type = 'none';
    Modifiers.type_for_derivative = 'none';

    
%% here start algorithm {{{{{{{{{{{{{{{{{{{{{{{{{{
 
Method = 2;   
    
    
disp('Derivatives_P: Started')
Derivatives_P = derivatives_P(uk_s, uk, delta_P, ub_u, lb_u, mode, Method);
disp('Derivatives_P: Finished')
    %% Rewrite properly what is below:
    x_m   = [results.xmeascomp.c6_B; results.xmeascomp.c6_D; results.xmeascomp.c6_E; results.xmeascomp.c6_F; results.xmeascomp.c6_G; results.xmeasstream.F1; results.xmeasstream.F2; results.xmeasstream.F3; results.xmeasstream.F8]*1; 
    x_sep = [ results.xmeascomp.c8_A; results.xmeascomp.c8_B;results.xmeascomp.c8_C; results.xmeascomp.c8_D; results.xmeascomp.c8_E; results.xmeascomp.c8_F; results.xmeascomp.c8_G; ...
              results.xmeas.Psep   ; results.xmeasstream.F9; results.xmeas.Tsep ]; 
    x_str = [results.xmeasstream.F4; results.xmeasstream.F5; results.xmeasstream.F10; results.xmeasstream.F11]; 
    ub_m   = [0.999 0.999 0.999 0.999 0.999 3000 3000 3000 3000];
    lb_m   = [0     0     0     0     0        0    0    0    0];
    ub_sep = [0.9 0.9 0.9 0.9 0.9 0.9 0.9 5000 50 150];
    lb_sep = [0   0   0   0   0   0   0      1  0  60];
    ub_str = [3000  3000  3000  3000];
    lb_str = [   1     1     1     1];
    x0_MCSSC = [results.xmeascomp.c5_A; results.xmeascomp.c5_B; results.xmeascomp.c5_C; ...
          results.xmeascomp.c5_D; results.xmeascomp.c5_E; results.xmeascomp.c5_F; ...
          results.xmeascomp.c5_G;  ...
          results.xmeasstream.F5;  results.xmeasstream.F10; results.xmeas.Tstr; ...
          x_m; x_sep; x_str];
    ub_x = [0.999 0.999 0.999 0.999 0.999 0.999 0.999 3000 3000 200];
    lb_x = [0     0     0     0     0     0     0        1    1  20];
    ub_MCSSC = [ub_x ub_m ub_sep ub_str];
    lb_MCSSC = [lb_x lb_m lb_sep lb_str];
    x0_r = [results.xmeascomp.c7_A; results.xmeascomp.c7_B; results.xmeascomp.c7_C; results.xmeascomp.c7_D; results.xmeascomp.c7_E; results.xmeascomp.c7_F; results.xmeascomp.c7_G; results.xmeasstream.F6]; 
    ub_r = [0.999 0.999 0.999 0.999 0.999 0.999 0.999 5000];
    lb_r = [0     0     0     0     0     0     0        0];
    x0_x2 = [results.xmeasstream.F7; results.xmeasstream.F8; results.xmeasstream.F9; ...
             results.xmeascomp.c6_A; results.xmeascomp.c6_B; results.xmeascomp.c6_C ; ...
             results.xmeascomp.c6_D; results.xmeascomp.c6_E; results.xmeascomp.c6_F ; ...
             results.xmeascomp.c6_G; results.xmeascomp.c6_H; ...
             results.xmeascomp.c8_A; results.xmeascomp.c8_B; results.xmeascomp.c8_C ; ...
             results.xmeascomp.c8_D; results.xmeascomp.c8_E; results.xmeascomp.c8_F ; ...
             results.xmeascomp.c8_G; results.xmeascomp.c8_H]; 
    ub_x2 = [3000 3000 100 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999 0.999];
    lb_x2 = [   1    1   0 0     0     0     0     0     0     0     0     0     0     0     0     0     0     0     0    ];
x0 = [x0_MCSSC; x0_r; x0_x2];
ub = [ub_MCSSC ub_r ub_x2]; %
lb = [lb_MCSSC lb_r lb_x2]; %

x0s = (x0 - lb')./(ub' - lb');
x0s = x0s;
x0s_x = (x0_MCSSC - lb_MCSSC')./(ub_MCSSC' - lb_MCSSC');
x0s_x = x0s_x;
lb_x  = lb_MCSSC;
ub_x  = ub_MCSSC;
%% ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
[yk, phi1k, phi2k, gk, geqk, ~, xs_sol, eflag, dx] = SimModel(uk, x0s*0.8, lb, ub, Modifiers, Parameters);

x_sol = xs_sol.*(ub' - lb') + lb';
% 
[dx, y, yy] = SimTE_2SubSystems(x_sol, uk, Parameters, Modifiers);
% [phi1, phi2, g, geq] = uy2phig2(uk,y, 1, Modifiers,Parameters)
%%
% 270s
% clc
tic
% %         ok   ok   ok   ok   ok   ok   ok   ok     ok   ok
% delta_M =[1e-4 1e-4 1e-4 1e-5 1e-4 1e-5 1e-5 0.9e-4 1e-5 1e-4];

if Method == 1
    Modifiers.type_for_derivative = 'MA'; 
elseif Method == 2
    Modifiers.type_for_derivative = 'MAy'; 
elseif Method == 3
    Modifiers.type_for_derivative = 'iMAy1'; 
elseif Method == 4
    Modifiers.type_for_derivative = 'iMAy2'; 
end
disp('Derivatives_M: Started')
Modifiers.type = 'none';
Derivatives_M = derivatives_M(uk_s, uk, delta_M, Parameters, ub_u, lb_u, x0s, lb, ub, Modifiers, Derivatives_P, x0s_x, lb_x, ub_x);
disp('Derivatives_M: Finished')
toc
% Simulate the modified model et compare it to the plant 
if Method == 1
    Modifiers.type = 'MA'; 
    Modifiers.uk            =  Derivatives_P.uk;
    Modifiers.epsilon_phi1k = (Derivatives_P.phi1k     - Derivatives_M.phi1k     );
    Modifiers.lambda_phi1k  = (Derivatives_P.dphi1k_du - Derivatives_M.dphi1k_du );
    Modifiers.epsilon_phi2k = (Derivatives_P.phi2k     - Derivatives_M.phi2k     );
    Modifiers.lambda_phi2k  = (Derivatives_P.dphi2k_du - Derivatives_M.dphi2k_du );
    Modifiers.epsilon_gk    = (Derivatives_P.gk        - Derivatives_M.gk        );
    Modifiers.lambda_gk     = (Derivatives_P.dgk_du    - Derivatives_M.dgk_du    ); 
    Modifiers.epsilon_geqk  = (Derivatives_P.geqk      - Derivatives_M.geqk      );
    Modifiers.lambda_geqk   = (Derivatives_P.dgeqk_du  - Derivatives_M.dgeqk_du  ); 

elseif Method == 2
    Modifiers.type = 'MAy'; 
    Modifiers.uk         =  Derivatives_P.uk;
    Modifiers.epsilon_yk = (Derivatives_P.yk     - Derivatives_M.yk    );
    Modifiers.lambda_yk  = (Derivatives_P.dyk_du - Derivatives_M.dyk_du);

elseif Method == 3
    Modifiers.type = 'iMAy1'; 
    Modifiers.uk            =  Derivatives_P.uk;
    Modifiers.epsilon_iMAy1_yyk_1 = (Derivatives_P.yyk_1     - Derivatives_M.yyk_1_corr   );
    Modifiers.epsilon_iMAy1_yyk_2 = (Derivatives_P.yyk_2     - Derivatives_M.yyk_2_corr   );
    Modifiers.epsilon_iMAy1_yyk_3 = (Derivatives_P.yyk_3     - Derivatives_M.yyk_3_corr   );
    Modifiers.lambda_iMAy1_yyk_1  = (Derivatives_P.dyyk_1_du - Derivatives_M.dyyk_1_du_corr);
    Modifiers.lambda_iMAy1_yyk_2  = (Derivatives_P.dyyk_2_du - Derivatives_M.dyyk_2_du_corr);
    Modifiers.lambda_iMAy1_yyk_3  = (Derivatives_P.dyyk_3_du - Derivatives_M.dyyk_3_du_corr);
    
elseif Method == 4
    Modifiers.type = 'iMAy2'; 
    Modifiers.uuk_1         =  Derivatives_P.uuk_1;
    Modifiers.uuk_2         =  Derivatives_P.uuk_2;
    Modifiers.uuk_3         =  Derivatives_P.uuk_3;
    Modifiers.epsilon_iMAy2_yyk_1 = (Derivatives_P.yyk_1       - Derivatives_M.yyk_1_corr );
    Modifiers.epsilon_iMAy2_yyk_2 = (Derivatives_P.yyk_2       - Derivatives_M.yyk_2_corr );
    Modifiers.epsilon_iMAy2_yyk_3 = (Derivatives_P.yyk_3       - Derivatives_M.yyk_3_corr );
    Modifiers.lambda_iMAy2_yyk_1  = (Derivatives_P.dyyk_1_duu1 - Derivatives_M.dyyk_1_duu1);
    Modifiers.lambda_iMAy2_yyk_2  = (Derivatives_P.dyyk_2_duu2 - Derivatives_M.dyyk_2_duu2);
    Modifiers.lambda_iMAy2_yyk_3  = (Derivatives_P.dyyk_3_duu3 - Derivatives_M.dyyk_3_duu3);
end

% Post traitement desmodifiers
%       Finally not really necessary (but could be!)
%
%
disp('Derivatives_M2: Started')
Modifiers.type_for_derivative = 'none'; 
Derivatives_M2 = derivatives_M(uk_s, uk, delta_M, Parameters, ub_u, lb_u, x0s, lb, ub, Modifiers, Derivatives_P, x0s_x, lb_x, ub_x);
disp('Derivatives_M2: Finished')

%
TEST = round(1e10*(Derivatives_P.yk - Derivatives_M2.yk))/ 1e10; 
% Derivatives_P.dyyk_1_du-Derivatives_M2.dyyk_1_du
Derivatives_P.phi2k-Derivatives_M2.phi2k
toc
% 

disp('-------------- E N D --------------')


