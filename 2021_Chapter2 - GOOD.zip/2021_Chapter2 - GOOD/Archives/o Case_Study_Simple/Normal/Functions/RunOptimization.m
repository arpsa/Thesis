function [u, eflag, outpt] = RunOptimization(u0, uk, lambda, opts)

Last_u   = [];
Last_f   = [];
Last_c   = []; % Attention c is not the input of the plant but the NL constraint !!
Last_ceq = [];

%%%%%%%%%%%%%%%  

lb = -5;
ub = 5;

Aeq = [];  
beq = [];

A = [];
b = [];

%%%%%%%%%%%%%%%  

[u, eflag, outpt] = fmincon(@(u)objfun(u, uk,lambda),...
                                u0, A, b, Aeq, beq, lb, ub, ...
                                @(u)constr(u,uk, lambda),opts);

    function y = objfun(u, uk,lambda)
        if ~isequal(u,Last_u) % Check if computation is necessary
            phi_m = model(u) + lambda*(u-uk);
            Last_u   = u;
            Last_f   = phi_m;
            Last_c   = [];
            Last_ceq = [];
        end
        y = Last_f;
    end

    function [c,ceq] = constr(u, uk,lambda)
        if ~isequal(u,Last_u) % Check if computation is necessary
            phi_m = model(u) + lambda*(u-uk);
            Last_u   = u;
            Last_f   = phi_m;
            Last_c   = [];
            Last_ceq = [];
        end
        c   = Last_c;
        ceq = Last_ceq;
    end

end