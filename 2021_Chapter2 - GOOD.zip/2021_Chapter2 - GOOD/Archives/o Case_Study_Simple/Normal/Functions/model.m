function [phi, Dphi] = model(u)
    phi  = u^2/4;
    Dphi = u/2  ;
end