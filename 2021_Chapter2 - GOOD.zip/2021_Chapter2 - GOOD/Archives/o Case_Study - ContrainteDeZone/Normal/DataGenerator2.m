clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

% format shortEng

%% Code architecture initialization & Output files 
addpath('Functions')

Noise = 0 ;  % 0:No, 1:Yes
Results_file_name = 'Results_DataGenerator2';

%% Tuning paramters


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  0.- Initialization of the algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 0.1.- Parameter defined by the user
u_max  =  5;
u_min  = -5;
NBiter = 1000;
K = 1;
use_methode = 0; % [0]: fixer K, 
                 % [1]: Choix de K pour garantir Niveau 2, 
                 % [2]: Choix optimal de K.                

manageconvergence = 0; % [0]: Yes, [1]: No

% 0.2.- Simulations parameters
PBstruct = ProblemStructure();        % options for solver | nb iterations
    fmincon_options = PBstruct.fmincon_options;
    fsolve_options  = PBstruct.fsolve_options;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Save Results
Results  = struct();
struct_Y = struct();

u(1) = 0; % opt 0
u0   = 0;
ukp1_opt(1) = 0;
KK(1) = K;

iter = 0; % just to see if there is progress >>>>
vK = [0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5];
for i = 1:length(vK)

disp(num2str(iter/length(vK))); % just to see if there is progress <<<<
iter = iter+1;
% ************************************************************************
K =  vK(i);        
for k = 1:NBiter
    %% 1.- Do experiment
    uk = u(k); 
    [phi_k, Dphi_k] = model(uk);
    [phi_pk, Dphi_pk] = plant(uk);
    %% 2.- Compute modifiers
    lambda = Dphi_pk - Dphi_k;
    %% 3.- Compute next point
    ukp1_opt(k+1) = RunOptimization(u0, uk, lambda, fmincon_options);
    %% 4.- Apply filter
    if use_methode == 0 || k == 1
    %%%%%%% ******** Methode 0 ******** %%%%%%%
        u(k+1) = uk + K*(ukp1_opt(k+1) - uk);
        KKopt(k) = K;
    elseif use_methode == 1
    %%%%%%% ******** Methode 1.2 ******** %%%%%%%
        flag = 0;
        KK(k) = 1;
        if (u(k)-u(k-1) < 0.0001) && (ukp1_opt(k+1)-ukp1_opt(k) < 0.0001) && (manageconvergence == 1)
            KK(k)    = KK(k-1);
            KKopt(k) = KKopt(k-1);
        else
            while flag == 0 
                test = abs(1 - KK(k)*(1-  (ukp1_opt(k+1)-ukp1_opt(k))/(u(k)-u(k-1)) ));
                if test <1 
                    flag = 1;
                    KKopt(k) = KK(k);
                    KK(k)    = KK(k)-0.1;
                else
                    KK(k) = KK(k)-0.0001;
                end
            end
        end
        u(k+1) = uk + KK(k)*(ukp1_opt(k+1) - uk);
    else
    %%%%%%% ******** Methode 2.2 ******** %%%%%%%
        test = 100000000;
        if (u(k)-u(k-1) < 0.0001) && (ukp1_opt(k+1)-ukp1_opt(k) < 0.0001) && (manageconvergence == 1)
            KK(k)    = KK(k-1);
            KKopt(k) = KK(k);
        else
            KK(k)= RunOptimizationK( ukp1_opt(k+1), ...
                              ukp1_opt(k),   ...
                              u(k),u(k-1), fmincon_options);
            KKopt(k) = KK(k);
        end
        u(k+1) = uk + KK(k)*(ukp1_opt(k+1) - uk);
    end
end

%% SAVE DATA FOR FIGuRES
Results.U_SAVE{i} = u;
Results.K_SAVE{i} = K;
Results.NBiter{i} = NBiter;

% ************************************************************************
end

save(Results_file_name, 'Results')

%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')