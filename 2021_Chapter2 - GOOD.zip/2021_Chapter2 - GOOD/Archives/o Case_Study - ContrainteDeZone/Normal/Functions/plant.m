function [phi_p, Dphi_p] = plant(u)
    phi_p  = (u-1)^2;
    Dphi_p = 2*(u-1);
end