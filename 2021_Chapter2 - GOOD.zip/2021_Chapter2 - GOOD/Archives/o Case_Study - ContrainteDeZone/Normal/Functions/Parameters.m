function ThetaUncertain = Parameters(test, B)
% test == 1 => good parameters
%      ~= 1 =>  mismatch

ThetaUncertain = struct();

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% WO reactor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 5 reactions
%
% A +  B -> C      (1)
% C +  B -> P + E  (2)
% P +  C -> G      (3)
%
if strcmp(test,'Plant') == 1
  
%     Plant
ThetaUncertain.A1 = 5.97*1e9;   % [1/h]
ThetaUncertain.B1 = 6666.67; % [�K]
ThetaUncertain.A2 = 2.59*1e12;  % [1/h]
ThetaUncertain.B2 = 8333.33; % [�K]
ThetaUncertain.A3 = 9.63*1e15;  % [1/h]
ThetaUncertain.B3 = 11111.11; % [�K]

ThetaUncertain.A4 = 0;  % [1/h]
ThetaUncertain.B4 = 1; % [�K]
ThetaUncertain.A5 = 0;  % [1/h]                                                                 
ThetaUncertain.B5 = 1; % [�K]

else

% % Model

% Parametric 
%
ThetaUncertain.B1 = B(1); % [�K]
    if  B(1) == 0
        ThetaUncertain.A1 = 0;   % [1/h]
    else
        ThetaUncertain.A1 =  5.97*1e9;   % [1/h]
    end
ThetaUncertain.B2 = B(2); % [�K]
    if  B(2) == 0
        ThetaUncertain.A2 = 0;   % [1/h]
    else
        ThetaUncertain.A2 = 2.59*1e12;   % [1/h]
    end
ThetaUncertain.B3 = B(3); % [�K]
    if  B(2) == 0
        ThetaUncertain.A3 = 0;   % [1/h]
    else
        ThetaUncertain.A3 = 9.63*1e15;   % [1/h]
    end

    
    %% 8077.6 12438.5

ThetaUncertain.B4 = B(4); % [�K]
    if  B(4) == 0
        ThetaUncertain.A4 = 0;   % [1/h]
    else
        
%         ThetaUncertain.A4 =  2.189e+008*3600;   % [1/h]   2.189231810604804e+008*3600; 
        ThetaUncertain.A4 =  2.189231810604804e+008*3600; 
        
    end
ThetaUncertain.B5 = B(5); % [�K]
    if  B(4) == 0
        ThetaUncertain.A5 = 0;   % [1/h]
    else
%         ThetaUncertain.A5 =  4.309e+013*3600;    % [1/h] 4.309773370943014e+013*3600; 
        ThetaUncertain.A5 =  4.309773370943014e+013*3600; 
    end
    
% ThetaUncertain.B4 = B(4); % [�K]
%     if  B(4) == 0
%         ThetaUncertain.A4 = 0;   % [1/h]
%     else
%         ThetaUncertain.A4 = 1.0728*1e8*3600;   % [1/h]
%     end
% ThetaUncertain.B5 = B(5); % [�K]
%     if  B(4) == 0
%         ThetaUncertain.A5 = 0;   % [1/h]
%     else
%         ThetaUncertain.A5 = 1.4155*1e13*3600;   % [1/h]
%     end

end

ThetaUncertain.FA = 6579; % [kg/h]

end