function [phi, Dphi] = model(u)
    phi  = u^2/4;
    Dphi = u/2  ;
%     phi  = 1/20*u^2;
%     Dphi = 2/20*u;
end