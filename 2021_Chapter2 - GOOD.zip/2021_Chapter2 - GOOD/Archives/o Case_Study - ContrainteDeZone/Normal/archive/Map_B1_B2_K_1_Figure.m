clc
% close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

%% Name of the fil3   MA_Vs_MAY_K_map_precise
Results_file_name = 'test_map';
load(Results_file_name)


% lim = 20;

phi_opt = Results.phi_opt(1,1,1,1);
g_opt   = Results.g_opt(1,1,1,1);
NBiter  = Results.k;

u1_optimum = Results.u1_opt(1);
u2_optimum = Results.u2_opt(1);
    

for ii = 1: length(Results.B1(1,:,1))
    for jj = 1:length(Results.B2(1,1,:))
        for Method= [1 2 5]
            Results.NbStepsUponConv{Method}(ii,jj) = NBiter+1;
            for l = 1:NBiter
                 if abs((Results.uk1(Method,ii,jj,NBiter-l+1)-u1_optimum))/(u1_optimum)<= 0.1/100 && ...
                    abs((Results.uk2(Method,ii,jj,NBiter-l+1)-u2_optimum))/(u1_optimum)<= 0.1/100
                    Results.NbStepsUponConv{Method}(ii,jj) = Results.NbStepsUponConv{Method}(ii,jj) - 1;
                else
                   break
                end 
            end 
        end
    end
end

%%  %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%
figure
%%%%%%%%%%%%%%
subplot(1,3,1)
colormap(hot)
[C,h] = contourf(reshape(Results.B1(1,:,:),[],size(Results.B1(1,:,:),2),1)', reshape(Results.B2(1,:,:),[],size(Results.B2(1,:,:),2),1)', Results.NbStepsUponConv{1}(:,:)', 'edgecolor','none');
subplot(1,3,2)
colormap(hot)
[C,h] = contourf(reshape(Results.B1(2,:,:),[],size(Results.B1(2,:,:),2),1)', reshape(Results.B2(2,:,:),[],size(Results.B2(2,:,:),2),1)', Results.NbStepsUponConv{2}(:,:)', 'edgecolor','none');
subplot(1,3,3)
colormap(hot)
[C,h] = contourf(reshape(Results.B1(5,:,:),[],size(Results.B1(5,:,:),2),1)', reshape(Results.B2(5,:,:),[],size(Results.B2(3,:,:),2),1)', Results.NbStepsUponConv{5}(:,:)', 'edgecolor','none');









   
