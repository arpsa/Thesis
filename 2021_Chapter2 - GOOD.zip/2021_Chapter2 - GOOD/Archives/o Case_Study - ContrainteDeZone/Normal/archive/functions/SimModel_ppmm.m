function [y, phi, g, uu, yy] = SimModel_ppmm(u, y0, Modifiers, Parameters, fsolve_options)

y_temp2 = fsolve(@(y_temp) System2_ppmm(0, y_temp, u, Parameters, Modifiers), y0, fsolve_options);
[~, y, g, phi, uu, yy] = System2_ppmm(0, y_temp2, u, Parameters, Modifiers);

end