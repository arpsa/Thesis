function  [phi, g] = uy2phig(u,y,Parameters)

F_A = u(1);
F_B = u(2);
T_R = u(3);

A_R = y(1); 
B_R = y(2);
C_R = y(3); 
E_R = y(4); 
G_R = y(5); 
P_R = y(6);

% if Parameters.k <= 40
%     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*F_A - 114.34*F_B); 
% elseif Parameters.k > 40 && Parameters.k <= 80
%     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*2*F_A - 114.34/2*F_B); 
% else
%     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23/2*F_A - 114.34*2*F_B); 
% end

% if Parameters.k < 21 
% %     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*1.1*F_A - 114.34*1.1*F_B); % mode 1
% % if Parameters.k < 21 
% %     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*0.85*F_A - 114.34*F_B); % mode 2
% % elseif Parameters.k >=11 && Parameters.k < 21
%     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*1*F_A - 114.34*1*F_B); % mode 2
% elseif Parameters.k >=21 && Parameters.k < 41 
%     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*F_A - 114.34*0.9*F_B);  % mode 3
% elseif Parameters.k >=41 && Parameters.k < 61
%     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*1.1*F_A - 114.34*1.1*F_B); % mode 1
% elseif Parameters.k >=61 %&& Parameters.k < 81
%     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*0.85*F_A - 114.34*F_B); % mode 2
% % else
% %     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*1.1*F_A - 114.34*1.1*F_B); % mode 1
% end
% if Parameters.k < 21 
if Parameters.k < 8 
%     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*1.1*F_A - 114.34*1.1*F_B); % mode 1
% if Parameters.k < 21 
%     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*0.85*F_A - 114.34*F_B); % mode 2
% elseif Parameters.k >=11 && Parameters.k < 21
    phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*1*F_A - 114.34*1*F_B); % mode 2
elseif Parameters.k >= 8 && Parameters.k < 14 
    phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*0.9*F_A - 114.34*0.9*F_B);  % mode 3
elseif Parameters.k >=14 %&& Parameters.k < 61
    phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*1*F_A - 114.34*1.1*F_B); % mode 1
    phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*1.02*F_A - 114.34*1.*F_B); % mode 1
% elseif Parameters.k >=61 %&& Parameters.k < 81
%     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*F_A - 114.34*F_B); % mode 2
% % else
% %     phi = -(1143.38*P_R*(F_A+F_B) + 25.92*E_R*(F_A+F_B) - 76.23*1.1*F_A - 114.34*1.1*F_B); % mode 1
end

g = G_R-0.08; 

end