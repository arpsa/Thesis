function  y = x2y(x)

% u = [F_A; T_R];
%
% x = [A_R; B_R; C_R; E_R; G_R; P_R]
%
% y = [X_E; X_P]

E_R = x(4);
P_R = x(6);
G_R = x(5);

X_E = E_R;
X_P = P_R;
X_G = G_R;

y = [X_E; X_P; X_G];

end