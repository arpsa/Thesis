function [y, phi, g, uu, yy] = SimPlant(u, y0_p, Modifiers, Parameters, fsolve_options)

y = fsolve(@(y_temp) System2(0, y_temp, u, Parameters, Modifiers), y0_p, fsolve_options);
[~, y, g, phi, uu, yy] = System2(0, y, u, Parameters, Modifiers);


end