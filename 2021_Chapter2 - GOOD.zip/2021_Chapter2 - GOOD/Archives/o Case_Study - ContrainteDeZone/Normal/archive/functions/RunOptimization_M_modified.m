function [uy_opt, f, eflag, outpt] = RunOptimization_M_modified(uy_s_O,  Parameters, inv_A_us, b_u, Modifiers, opts)


%% 
lb = [0; 0; zeros(9,1)];
ub = [1; 1; ones(9,1)];
  
A = [];
b = [];

% Aeq = [0 0 1 1 1 1 1 1 0 0 0 0];
% beq = 1;

Aeq = [];  
beq = [];


Last_uy  = [];
Last_f   = [];
Last_c   = []; 
Last_ceq = [];

%%%%%%%%%%%%%%%  

[uy_opt, f, eflag, outpt] = fmincon(@(uy)objfun(uy),...
                                uy_s_O, A, b, Aeq, beq, lb, ub, ...
                                @(uy)constr(uy),opts);

    function obj = objfun(uy)
        if ~isequal(uy,Last_uy) % Check if computation is necessary
            u_s = uy(1:2);
            u = inv_A_us*u_s+b_u;
            yy = uy(3:end);
            
            [dy, ~, g, phi] = System2(0, yy, u, Parameters, Modifiers);
            
            Last_uy  = uy;
            
            Last_f   = phi;
%             Last_ceq = [dy; g];
            Last_ceq = dy;
            Last_c   = [];
        end
        % Now compute objective function
        obj = Last_f;
    end

    function [c,ceq] = constr(uy)
        if ~isequal(uy,Last_uy) % Check if computation is necessary
            u_s = uy(1:2);
            u = inv_A_us*u_s+b_u;
            yy = uy(3:end);
            
            [dy, ~, g, phi] = System2(0, yy, u, Parameters, Modifiers);
            
            Last_uy  = uy;
            
            Last_f   = phi;
%             Last_ceq = [dy; g];
            Last_ceq = dy;
            Last_c   = [];
        end
        % Now compute constraint functions
        c   = Last_c;
        ceq = Last_ceq;
    end

end
