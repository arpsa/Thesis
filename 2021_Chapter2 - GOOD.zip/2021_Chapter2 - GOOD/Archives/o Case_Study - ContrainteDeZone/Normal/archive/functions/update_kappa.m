function e = update_kappa(kappa, u_opt, nu, Delta_u, delta_M, delta_m, Parameters, y0, Modifiers, A_us, b_u, fsolve_options, uk)

uu_1 = u_opt + [Delta_u(1);0;0];    
uu_2 = u_opt + [0;Delta_u(2);0];
uu_3 = u_opt + [0;0;Delta_u(3)];

uu_0_K =  
uu_1_K
uu_2_K
uu_3_K


uu_s_0 = A_us*(u_opt-b_u); 
uu_s_1 = A_us*(kappa*uu_1+(1-kappa)*u_opt-b_u);
uu_s_2 = A_us*(kappa*uu_2+(1-kappa)*u_opt-b_u);
uu_s_3 = A_us*(kappa*uu_3+(1-kappa)*u_opt-b_u);
       
%% G1
d_0 = derivatives_M_spmm(uu_s_0, u_opt, delta_M, delta_m, Parameters, A_us, b_u, y0, Modifiers, fsolve_options);
dphi_du_0 = d_0.dphik_du;    
dg_du_0   = d_0.dgk_du;    
            
d_1 = derivatives_M_spmm(uu_s_1, uu_1, delta_M, delta_m, Parameters, A_us, b_u, y0, Modifiers, fsolve_options);
dphi_du_1 = d_1.dphik_du;    
dgg_du_1   = d_1.dgk_du;    

d_2 = derivatives_M_spmm(uu_s_2, uu_2, delta_M, delta_m, Parameters, A_us, b_u, y0, Modifiers, fsolve_options);
dphi_du_2 = d_2.dphik_du;    
dgg_du_2   = d_2.dgk_du;  

d_3 = derivatives_M_spmm(uu_s_3, uu_3, delta_M, delta_m, Parameters, A_us, b_u, y0, Modifiers, fsolve_options);
dphi_du_3 = d_3.dphik_du;    
dgg_du_3   = d_3.dgk_du;  

Hg1   = [(uu_1-u_opt)'; (uu_2-u_opt)'; (uu_3-u_opt)']\[(dgg_du_1-dg_du_0) ; (dgg_du_2-dg_du_0) ; (dgg_du_3-dg_du_0)];
  
%% G2

d_0 = derivatives_M_spmm(uu_s_0, u_opt, delta_M, delta_m, Parameters, A_us, b_u, y0, Modifiers, fsolve_options);
dphi_du_0 = d_0.dphik_du;    
dg_du_0   = d_0.dgk_du;    
            
d_1 = derivatives_M_spmm(uu_s_1, uu_1, delta_M, delta_m, Parameters, A_us, b_u, y0, Modifiers, fsolve_options);
dphi_du_1 = d_1.dphik_du;    
dgg_du_1   = d_1.dgk_du;    

d_2 = derivatives_M_spmm(uu_s_2, uu_2, delta_M, delta_m, Parameters, A_us, b_u, y0, Modifiers, fsolve_options);
dphi_du_2 = d_2.dphik_du;    
dgg_du_2   = d_2.dgk_du;  

d_3 = derivatives_M_spmm(uu_s_3, uu_3, delta_M, delta_m, Parameters, A_us, b_u, y0, Modifiers, fsolve_options);
dphi_du_3 = d_3.dphik_du;    
dgg_du_3   = d_3.dgk_du;  

Hg1   = [(uu_1-u_opt)'; (uu_2-u_opt)'; (uu_3-u_opt)']\[(dgg_du_1-dg_du_0) ; (dgg_du_2-dg_du_0) ; (dgg_du_3-dg_du_0)];
  


%%

Hphi = [(uu_1-u_opt)'; (uu_2-u_opt)'; (uu_3-u_opt)']\[(dphi_du_1-dphi_du_0)' ; (dphi_du_2-dphi_du_0)'; (dphi_du_3-dphi_du_0)'];

% size([(uu_1-u_opt)'; (uu_2-u_opt)'; (uu_3-u_opt)'])
% size([(dgg_du_1-dg_du_0)' ; (dgg_du_2-dg_du_0)' ; (dgg_du_3-dg_du_0)'])
        
size(Hphi) 
size(Hg) 


N  = null(dg_du_0');            
HL = Hphi+ nu*Hg;
e  = eig(N'*HL*N);

end