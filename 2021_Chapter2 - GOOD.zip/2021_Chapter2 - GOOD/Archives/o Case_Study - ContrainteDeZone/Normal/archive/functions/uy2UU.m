function  UU = uy2UU(u,y)

% Model             % Plant
UU{1} = [u;y(2)];   % uu{1} = [u;y(2)];
UU{2} = u;          % uu{2} = y(1);
 

end