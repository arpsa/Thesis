function [y, phi, g, uu, yy] = SimModel(u, y0, Modifiers, Parameters, fsolve_options)

y = fsolve(@(y_temp) System2(0, y_temp, u, Parameters, Modifiers), y0, fsolve_options);
[~, y, g, phi, uu, yy] = System2(0, y, u, Parameters, Modifiers);

end