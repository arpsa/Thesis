function [uy_opt, f, eflag, outpt,lambda] = RunOptimization_M_modified_spmm_2(uy_s_O,  Parameters, inv_A_us, b_u, Modifiers, opts, Ku, UseMethode, uk_test)


%% 
ub = [1; 1; 1; ones(8*2,1)];
lb = [0; 0; 0; zeros(8*2,1)];

A = [];
b = [];

% 3600*3.887
% Aeq = [1 zeros(1,18)];  
% beq = [3600*3.887];

Aeq = [];  
beq = [];


Last_uy  = [];
Last_f   = [];
Last_c   = []; 
Last_ceq = [];

%%%%%%%%%%%%%%%  

[uy_opt, f, eflag, outpt, lambda] = fmincon(@(uy)objfun(uy),...
                                uy_s_O, A, b, Aeq, beq, lb, ub, ...
                                @(uy)constr(uy),opts);

    function obj = objfun(uy)
        if ~isequal(uy,Last_uy) % Check if computation is necessary
            u_s = uy(1:3);
            
            % Target point 
            u = inv_A_us*u_s+b_u;
            yy = uy(4:4+8-1);
            
            % Filtered point
%             uk = Modifiers.uk;
            yy2 = uy(4+8:4+8+8-1);
            u2 = Ku*u + (1-Ku)*uk_test;
            
            [dy, ~, g, phi] = System2_spmm(0, yy, u, Parameters, Modifiers);
            [dy2, ~, g2, ~] = System2_spmm(0, yy2, u2, Parameters, Modifiers);
            
            Last_uy  = uy;
            
            Last_f   = phi;
            Last_ceq = [dy;dy2];
            if  UseMethode == 1
                Last_c   = [g;g2];
            else
                Last_c   = g; 
            end
        end
        % Now compute objective function
        obj = Last_f;
    end

    function [c,ceq] = constr(uy)
        if ~isequal(uy,Last_uy) % Check if computation is necessary
            u_s = uy(1:3);
            
            % Target point 
            u = inv_A_us*u_s+b_u;
            yy = uy(4:4+8-1);
            
            % Filtered point
%             uk = Modifiers.uk;
            yy2 = uy(4+8:4+8+8-1);
            u2 = Ku*u + (1-Ku)*uk_test;
            
            [dy, ~, g, phi] = System2_spmm(0, yy, u, Parameters, Modifiers);
            [dy2, ~, g2, ~] = System2_spmm(0, yy2, u2, Parameters, Modifiers);
            
            Last_uy  = uy;
            
            Last_f   = phi;
            Last_ceq = [dy;dy2];
            if  UseMethode == 1
                Last_c   = [g;g2];
            else
                Last_c   = g; 
            end
        end
        % Now compute constraint functions
        c   = Last_c;
        ceq = Last_ceq;
    end

end
