clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

% Elapsed time is 28938.734843 seconds.

%% Code architecture initialization & Output files 
addpath('Functions')
addpath('Plant')

Noise = 0 ;  % 0:No, 1:Yes
Results_file_name = 'test_B1B2B3_map';

%% Tuning paramters

Ku = 1; % Filter on inputs
% B  = [0; 0; 0; 8077; 12438];
% B  = [0; 0; 0; 8277; 12238];
% B  = [11000; 8333.33; 11111.11; 0; 0];

Bp = [0; 0; 0; 0; 0];
    Theta_P = Parameters('Plant',    Bp);   % 'Plant' or 'Mismatch'
%     Theta_M = Parameters('Mismatch', B);    % 'Plant' or 'Mismatch'
NBiter  = 30;           % Simulation iterations number

% uk{1}   = [17890; 357.5];  % [F_B;T] Starting point
% uk{1}   = [12635; 335];  % [F_B;T] Starting point
uk{1}   = [17800; 355];  % [F_B;T] Starting point
delta_M = [1e-6, 1e-5]; % [u1; u2] Step finit difference
    nuA = 4; nuB = 5; nuC = 5; nuE = 5; nuG = 6; nuP = 5;
    d = 1e-5;
    delta_m{1} = ones(nuA,1)*d;
    delta_m{2} = ones(nuB,1)*d;
    delta_m{3} = ones(nuC,1)*d;
    delta_m{4} = ones(nuE,1)*d;
    delta_m{5} = ones(nuG,1)*d;
    delta_m{6} = ones(nuP,1)*d;
delta_P = [1e-6, 1e-5];

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  0.- Initialization of the algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 0.1.- Parameter defined by the user
u_max  = [21600; 378];
u_min  = [10800; 323];

% 0.2.- Simulations parameters
PBstruct = ProblemStructure();        % options for solver | nb iterations
fsolve_options    = PBstruct.fsolve_options;
fmincon_options   = PBstruct.fmincon_options;

% 0.3.- Scaling
inv_A_us = diag(u_max-u_min);
A_us = inv(diag(u_max-u_min));
b_u  = u_min;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Save Results
Results  = struct();
struct_Y = struct();

% y0   = [0.122; 0.383; 0.025; 0.346; 0.085; 0.039; 0.121; 0.383; 0.025; 0.039] ; 
% y0_p = [0.122; 0.383; 0.025;        0.085; 0.039; 0.121; 0.383; 0.025; 0.039] ; 

y0_p = [98.2090e-003; 426.1109e-003; 18.9052e-003; 80.0000e-003; 107.8139e-003; 98.2090e-003; 426.1109e-003; 18.9052e-003; 107.8139e-003];
u0_p = [17.8904e+003; 357.4296e+000];


Modifiers = struct();
    Modifiers.type = 'none';

iter = 0;

nnn  = 20;
nnn3 = 5;
B1 = 6000:(6900-6000)/(nnn-1):6900;       % 6666.66
B2 = 8000:(8800-8000)/(nnn-1):8800;       % 8333.33
B3 = 11000:(12000-11000)/(nnn3-1):12000;  % 11111.11
B1 = sort([B1,6666.66]);
B2 = sort([B2,8333.33]);
B3 = sort([B3,11111.11]);


for ii = 1:length(B1)
    for jj = 1:length(B2)
        for kk = 1:length(B3)
            B  = [ B1(ii); B2(jj); B3(kk); 0; 0];
            Theta_M = Parameters('Mismatch', B );   % 'Plant' or 'Mismatch'
    
    
for Method = [1 2 5 6]
    eflag = 0;
    for k = 1:NBiter
        
        % 1.0.- Current state & gradients of the plant
        uk_s{k}  = A_us *(uk{k}-b_u);
        Modifiers.type = 'none';
        Plant_derivatives = derivatives_P_ppmm(uk_s{k}, uk{k}, delta_P,          Theta_P,  A_us, b_u, y0_p, Modifiers, fsolve_options);
            Modifiers.uk  = uk{k};
            Modifiers.uAk = Plant_derivatives.uuk_A;
            Modifiers.uBk = Plant_derivatives.uuk_B;
            Modifiers.uCk = Plant_derivatives.uuk_C;
            Modifiers.uEk = Plant_derivatives.uuk_E;
            Modifiers.uGk = Plant_derivatives.uuk_G;
            Modifiers.uPk = Plant_derivatives.uuk_P;
            phipk{k} = Plant_derivatives.phik;
            gpk{k}   = Plant_derivatives.gk;
            ypk{k}   = Plant_derivatives.yk;
        Model_derivatives = derivatives_M_ppmm(uk_s{k}, uk{k}, delta_M, delta_m, Theta_M,  A_us, b_u, y0_p, Modifiers, fsolve_options, Plant_derivatives.uuk);
   
        if Method == 1
            Modifiers.type = 'MA'; 
            Modifiers.epsilon_phi_k = Plant_derivatives.phik     - Model_derivatives.phik;
            Modifiers.lambda_phi_k  = Plant_derivatives.dphik_du - Model_derivatives.dphik_du;
            Modifiers.epsilon_g_k   = Plant_derivatives.gk       - Model_derivatives.gk;
            Modifiers.lambda_g_k    = Plant_derivatives.dgk_du   - Model_derivatives.dgk_du; 
            
        elseif Method == 2
            Modifiers.type = 'MAy'; 
            Modifiers.epsilon_y_k = Plant_derivatives.yk     - Model_derivatives.yk;
            Modifiers.lambda_y_k  = Plant_derivatives.dyk_du - Model_derivatives.dyk_du;
            
        elseif Method == 5
            Modifiers.type = 'iMAy1';
            % Reaction A
            Modifiers.epsilon_iMAy1_yA = Plant_derivatives.yyk_A     - Model_derivatives.yk_A;
            Modifiers.lambda_iMAy1_yA  = Plant_derivatives.dyyk_A_du - Model_derivatives.dyk_A_duA * Plant_derivatives.duuk_A_du;
            % Reaction B
            Modifiers.epsilon_iMAy1_yB = Plant_derivatives.yyk_B     - Model_derivatives.yk_B;
            Modifiers.lambda_iMAy1_yB  = Plant_derivatives.dyyk_B_du - Model_derivatives.dyk_B_duB * Plant_derivatives.duuk_B_du;
            % Reaction C
            Modifiers.epsilon_iMAy1_yC = Plant_derivatives.yyk_C     - Model_derivatives.yk_C;
            Modifiers.lambda_iMAy1_yC  = Plant_derivatives.dyyk_C_du - Model_derivatives.dyk_C_duC * Plant_derivatives.duuk_C_du;
            % Reaction E
            Modifiers.epsilon_iMAy1_yE = Plant_derivatives.yyk_E     - Model_derivatives.yk_E;                          % <<<<<<<<<<<<<<<<<<<<<<<< PB
            Modifiers.lambda_iMAy1_yE  = Plant_derivatives.dyyk_E_du - Model_derivatives.dyk_E_duE * Plant_derivatives.duuk_E_du;
            % Reaction G
            Modifiers.epsilon_iMAy1_yG = Plant_derivatives.yyk_G     - Model_derivatives.yk_G;
            Modifiers.lambda_iMAy1_yG  = Plant_derivatives.dyyk_G_du - Model_derivatives.dyk_G_duG * Plant_derivatives.duuk_G_du;
            % Reaction P
            Modifiers.epsilon_iMAy1_yP = Plant_derivatives.yyk_P     - Model_derivatives.yk_P;
            Modifiers.lambda_iMAy1_yP  = Plant_derivatives.dyyk_P_du - Model_derivatives.dyk_P_duP * Plant_derivatives.duuk_P_du;
            % ------
         
       elseif Method == 6
            Modifiers.type = 'iMAy2';  
            % Reaction A       round( Plant_derivatives.WA_x_invWA,1)
            Modifiers.epsilon_iMAy2_yA = Plant_derivatives.yyk_A   - Model_derivatives.yk_A;
            Modifiers.lambda_iMAy2_yA  = Plant_derivatives.dyA_duA - Model_derivatives.dyk_A_duA *Plant_derivatives.WA_x_invWA;
            % Reaction B
            Modifiers.epsilon_iMAy2_yB = Plant_derivatives.yyk_B   - Model_derivatives.yk_B;
            Modifiers.lambda_iMAy2_yB  = Plant_derivatives.dyB_duB - Model_derivatives.dyk_B_duB * Plant_derivatives.WB_x_invWB;
            % Reaction C
            Modifiers.epsilon_iMAy2_yC = Plant_derivatives.yyk_C   - Model_derivatives.yk_C;
            Modifiers.lambda_iMAy2_yC  = Plant_derivatives.dyC_duC - Model_derivatives.dyk_C_duC * Plant_derivatives.WC_x_invWC;
            % Reaction E
            Modifiers.epsilon_iMAy2_yE = Plant_derivatives.yyk_E   - Model_derivatives.yk_E;
            Modifiers.lambda_iMAy2_yE  = Plant_derivatives.dyE_duE - Model_derivatives.dyk_E_duE * Plant_derivatives.WE_x_invWE; 
            % Reaction G
            Modifiers.epsilon_iMAy2_yG = Plant_derivatives.yyk_G   - Model_derivatives.yk_G;
            Modifiers.lambda_iMAy2_yG  = Plant_derivatives.dyG_duG - Model_derivatives.dyk_G_duG * Plant_derivatives.WG_x_invWG; 
            % Reaction P
            Modifiers.epsilon_iMAy2_yP = Plant_derivatives.yyk_P   - Model_derivatives.yk_P;
            Modifiers.lambda_iMAy2_yP  = Plant_derivatives.dyP_duP - Model_derivatives.dyk_P_duP * Plant_derivatives.WP_x_invWP; 
            % ------
        end   
        
        Results.Modifiers{k} = Modifiers;
        
        uy_s_O = [u0_p; y0_p];
        
        if  eflag ~= -2
            [uy_s_opt, ~, eflag]  = RunOptimization_M_modified_ppmm(uy_s_O, Theta_M, inv_A_us, b_u, Modifiers, fmincon_options);
        end

        u_opt   = inv_A_us*uy_s_opt(1:2) + b_u;
%         y0_p = uy_s_opt(3:end);
        uk{k+1} = Ku*u_opt + (1-Ku)*uk{k};
        iter = iter + 1
    end

    %% Optimal point
    y0 = [0.222; 0.183; 0.225; 0.085; 0.139; 0.121; 0.383; 0.025; 0.039] ; 

    uy_0_s = [A_us*(uk{k+1}-b_u);  y0_p];

    Modifiers.type = 'none';
    uyp_s_opt = RunOptimization_P(uy_0_s, Theta_P, inv_A_us, b_u, Modifiers, fmincon_options);

    u_s_opt = uyp_s_opt(1:2);
    up_opt = inv_A_us*u_s_opt+b_u;
    
    yyp_opt = fsolve(@(y_temp) System2(0, y_temp, up_opt, Theta_P, Modifiers), y0, fsolve_options);
    [~, yp_opt, gp_opt, phip_opt, ~, ~] = System2(0, yyp_opt, up_opt, Theta_P, Modifiers);

    %% Results
    for i = 1:k
        % Define what to save !!
        Results.uk1(Method,ii,jj,kk,i)  = uk{i}(1);
        Results.uk2(Method,ii,jj,kk,i)  = uk{i}(2);

        Results.phipk(Method,ii,jj,kk,i) = phipk{i};
        Results.gpk(Method,ii,jj,kk,i)   = gpk{i};

        Results.ypk1(Method,ii,jj,kk,i) = ypk{i}(1);
        Results.ypk2(Method,ii,jj,kk,i) = ypk{i}(2);
        Results.ypk3(Method,ii,jj,kk,i) = ypk{i}(3);
        Results.ypk4(Method,ii,jj,kk,i) = ypk{i}(4);
        Results.ypk5(Method,ii,jj,kk,i) = ypk{i}(5);
        Results.ypk6(Method,ii,jj,kk,i) = ypk{i}(6);

        % Opt Point
        Results.u1_opt(Method,ii,jj,kk,i) = up_opt(1);
        Results.u2_opt(Method,ii,jj,kk,i) = up_opt(2);

        Results.phi_opt(Method,ii,jj,kk,i) = phip_opt;
        Results.g_opt(Method,ii,jj,kk,i)   = gp_opt;
        
        Results.y1_opt(Method,ii,jj,kk,i) = yp_opt(1);
        Results.y2_opt(Method,ii,jj,kk,i) = yp_opt(2);
        Results.y3_opt(Method,ii,jj,kk,i) = yp_opt(3);
        Results.y4_opt(Method,ii,jj,kk,i) = yp_opt(4);
        Results.y5_opt(Method,ii,jj,kk,i) = yp_opt(5);
        Results.y6_opt(Method,ii,jj,kk,i) = yp_opt(6);
    end     
    Results.B1(Method,ii,jj,kk) = B1(ii);
    Results.B2(Method,ii,jj,kk) = B2(jj);
    Results.B3(Method,ii,jj,kk) = B3(kk);
end
        end
    end
end

Results.k  = NBiter;
%%
save(Results_file_name, 'Results')

%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')