clc
% close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

% format shortEng

%% Code architecture initialization & Output files 
addpath('Functions')
addpath('Plant')

Noise = 0 ;  % 0:No, 1:Yes
Results_file_name = 'test';

%% Tuning paramters

Ku      = 0.5; % Filter on inputs
NBiter  = 1;           % Simulation iterations number
pm_mismatch = 'struct';   % struct                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            param

UseMethode = 1; 

if strcmp(pm_mismatch,'param') == 1
B  = [6666.67; 8333; 11111.11; 0;0]; % no plant-model mismatch
else
    B  = [0; 0; 0; 8077.6; 12438.5]; % realistic structural pm-mismatch
end
Bp = [0; 0; 0; 0; 0];
    Theta_P = Parameters('Plant',    Bp);   % 'Plant' or 'Mismatch'
    Theta_M = Parameters('Mismatch', B);    % 'Plant' or 'Mismatch'

% uk{1}   = [12960; 36000; 358.15];  % [F_B;T] Starting point
% uk{1}   = [16200; 21600; 353.1500];  % [F_B;T] Starting point
uk{1} = [ 1.3890e+004; 3.3491e+004; 364.2712];

delta_M = [1e-7,1e-7, 1e-6]; % [u1; u2] Step finit difference
    nuA = 6; nuB = 6; nuC = 6; nuE = 6; nuG = 7; nuP = 6;
    d = 1e-6;
    delta_m{1} = ones(nuA,1)*d;
    delta_m{2} = ones(nuB,1)*d;
    delta_m{3} = ones(nuC,1)*d;
    delta_m{4} = ones(nuE,1)*d;
    delta_m{5} = ones(nuG,1)*d;
    delta_m{6} = ones(nuP,1)*d;
delta_P = [1e-6, 1e-6, 1e-4];
Delta_u = [10; 10; 1];


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  0.- Initialization of the algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 0.1.- Parameter defined by the user
u_max  = [4.5*3600; 11*3600; 105+273.15];
u_min  = [3*3600;   6*3600; 80+273.15];

% 0.2.- Simulations parameters
PBstruct = ProblemStructure();        % options for solver | nb iterations
fsolve_options    = PBstruct.fsolve_options;
fmincon_options   = PBstruct.fmincon_options;

% 0.3.- Scaling
inv_A_us = diag(u_max-u_min);
A_us = inv(diag(u_max-u_min));
b_u  = u_min;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Save Results
Results  = struct();
struct_Y = struct();

y0_p = [0.1302; 0.4188; 0.0224; 0.0800;  0.0984];
% y0_p = [0.4; 0.3; 0.01; 0.0800;  0.1];
u0_p = [ 1.3890e+004; 3.3491e+004; 364.2712]; % opt


y0_pstruc = [y0_p; y0_p([1,2,5])]; %  % remove C from the initialization
y0_param  = [y0_p; y0_p([1,2,3,5])];  % remove C from the initialization

y0_pstruc_opt = [y0_pstruc; y0_pstruc];
y0_param_opt  = [y0_param; y0_param];

Modifiers = struct();
    Modifiers.type = 'none';

iter = 0;
for Method = 1 % [1 2]
    for k = 1:NBiter
        % 1.0.- Current state & gradients of the plant
        uk_s{k}  = A_us *(uk{k}-b_u);

          if strcmp(pm_mismatch,'param') == 1 
              
            Modifiers.type = 'none';
            Plant_derivatives = derivatives_P_ppmm(uk_s{k}, uk{k}, delta_P,          Theta_P,  A_us, b_u, y0_param, Modifiers, fsolve_options);
            Modifiers.uk  = uk{k};
            
            phipk{k} = Plant_derivatives.phik;
            gpk{k}   = Plant_derivatives.gk;
            ypk{k}   = Plant_derivatives.yk;
              
            Modifiers.uAk = Plant_derivatives.uuk_A;
            Modifiers.uBk = Plant_derivatives.uuk_B;
            Modifiers.uCk = Plant_derivatives.uuk_C;
            Modifiers.uEk = Plant_derivatives.uuk_E;
            Modifiers.uGk = Plant_derivatives.uuk_G;
            Modifiers.uPk = Plant_derivatives.uuk_P;

            Model_derivatives = derivatives_M_ppmm(uk_s{k}, uk{k}, delta_M, delta_m, Theta_M,  A_us, b_u, y0_param, Modifiers, fsolve_options);
          
          else
              
            Modifiers.type = 'none';
            Plant_derivatives = derivatives_P_spmm(uk_s{k}, uk{k}, delta_P,          Theta_P,  A_us, b_u, y0_param, Modifiers, fsolve_options);
            Modifiers.uk  = uk{k};
            
            phipk{k} = Plant_derivatives.phik;
            gpk{k}   = Plant_derivatives.gk;
            ypk{k}   = Plant_derivatives.yk;
            
            Modifiers.uAk = Plant_derivatives.uuk_A;
            Modifiers.uBk = Plant_derivatives.uuk_B;
            Modifiers.uCk = Plant_derivatives.uuk_C;
            Modifiers.uEk = Plant_derivatives.uuk_E;
            Modifiers.uGk = Plant_derivatives.uuk_G;
            Modifiers.uPk = Plant_derivatives.uuk_P;
%               
%             Modifiers.uAk = [uk{k}; ypk{k}([2,6])]; % 
%             Modifiers.uBk = [uk{k}; ypk{k}([1,6])]; % 
%             Modifiers.uCk = []; % 
%             Modifiers.uEk = [uk{k}; ypk{k}([1,2])]; % 
%             Modifiers.uGk = [uk{k}; ypk{k}([1,2,6])]; % 
%             Modifiers.uPk = [uk{k}; ypk{k}([1,2])]; %  

            Model_derivatives = derivatives_M_spmm(uk_s{k}, uk{k}, delta_M, delta_m, Theta_M,  A_us, b_u, y0_pstruc, Modifiers, fsolve_options);
          
          end
        
          if Method == 1
            Modifiers.type = 'MA'; 
            Modifiers.epsilon_phi_k = (Plant_derivatives.phik     - Model_derivatives.phik);
            Modifiers.lambda_phi_k  = (Plant_derivatives.dphik_du - Model_derivatives.dphik_du);
            Modifiers.epsilon_g_k   = (Plant_derivatives.gk       - Model_derivatives.gk);
            Modifiers.lambda_g_k    = (Plant_derivatives.dgk_du   - Model_derivatives.dgk_du); 
            
        elseif Method == 2
            Modifiers.type = 'MAy'; 
            Modifiers.epsilon_y_k = Plant_derivatives.yk     - Model_derivatives.yk;
            Modifiers.lambda_y_k  = (Plant_derivatives.dyk_du - Model_derivatives.dyk_du);
            
          elseif Method == 5
            Modifiers.type = 'iMAy1';
            % Reaction A
            Modifiers.epsilon_iMAy1_yA = (Plant_derivatives.yyk_A      - Model_derivatives.yk_A);
            Modifiers.lambda_iMAy1_yA  = (Plant_derivatives.dyyk_A_du - Model_derivatives.dyk_A_duA * Plant_derivatives.duuk_A_du);
            % Reaction B
            Modifiers.epsilon_iMAy1_yB = (Plant_derivatives.yyk_B      - Model_derivatives.yk_B);
            Modifiers.lambda_iMAy1_yB  = (Plant_derivatives.dyyk_B_du - Model_derivatives.dyk_B_duB * Plant_derivatives.duuk_B_du);
            if strcmp(pm_mismatch,'param') == 1 
                % Reaction C
                Modifiers.epsilon_iMAy1_yC = (Plant_derivatives.yyk_C      - Model_derivatives.yk_C);
                Modifiers.lambda_iMAy1_yC  = (Plant_derivatives.dyyk_C_du - Model_derivatives.dyk_C_duC * Plant_derivatives.duuk_C_du);
            end
            % Reaction E
            Modifiers.epsilon_iMAy1_yE = (Plant_derivatives.yyk_E     - Model_derivatives.yk_E);
            Modifiers.lambda_iMAy1_yE  = (Plant_derivatives.dyyk_E_du - Model_derivatives.dyk_E_duE * Plant_derivatives.duuk_E_du);
            % Reaction G
            Modifiers.epsilon_iMAy1_yG = (Plant_derivatives.yyk_G      - Model_derivatives.yk_G);
            Modifiers.lambda_iMAy1_yG  = (Plant_derivatives.dyyk_G_du - Model_derivatives.dyk_G_duG * Plant_derivatives.duuk_G_du);
            % Reaction P
            Modifiers.epsilon_iMAy1_yP = (Plant_derivatives.yyk_P      - Model_derivatives.yk_P);
            Modifiers.lambda_iMAy1_yP  = (Plant_derivatives.dyyk_P_du -  Model_derivatives.dyk_P_duP * Plant_derivatives.duuk_P_du);
            % ------
            
            % Plant_derivatives.yyk_A+Plant_derivatives.yyk_B +Plant_derivatives.yyk_E +Plant_derivatives.yyk_G +Plant_derivatives.yyk_P 
            % Model_derivatives.yk_A+Model_derivatives.yk_B+Model_derivatives.yk_E+Model_derivatives.yk_G+Model_derivatives.yk_P
            % sum(y_p)
            % sum(y)
            
%             % test code
%             [y, phi, g, uu, yy] = SimModel_spmm(uk{k}, y0_pstruc, Modifiers, Theta_M, fsolve_options);
%             Modifiers.type = 'none';
%             [y_p, phi_p, g_p, uu_p, yy_p] = SimModel_ppmm(uk{k}, y0_p, Modifiers, Theta_P, fsolve_options);
%             ansss = y - y_p
%             ansss = phi - phi_p
%             
%             Modifiers.type = 'iMAy1';
%             % ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
%             
            
            
            
         
        elseif Method == 6
            Modifiers.type = 'iMAy2';  
            % Reaction A       round( Plant_derivatives.WA_x_invWA,1)
            Modifiers.epsilon_iMAy2_yA = (Plant_derivatives.yyk_A   - Model_derivatives.yk_A);
            Modifiers.lambda_iMAy2_yA  = (Plant_derivatives.dyA_duA - Model_derivatives.dyk_A_duA *Plant_derivatives.WA_x_invWA);
            % Reaction B
            Modifiers.epsilon_iMAy2_yB = (Plant_derivatives.yyk_B   - Model_derivatives.yk_B);
            Modifiers.lambda_iMAy2_yB  = (Plant_derivatives.dyB_duB - Model_derivatives.dyk_B_duB * Plant_derivatives.WB_x_invWB);
            if strcmp(pm_mismatch,'param') == 1 
                % Reaction C
                Modifiers.epsilon_iMAy2_yC = (Plant_derivatives.yyk_C   - Model_derivatives.yk_C);
                Modifiers.lambda_iMAy2_yC  = (Plant_derivatives.dyC_duC - Model_derivatives.dyk_C_duC * Plant_derivatives.WC_x_invWC);
            end
            % Reaction E
            Modifiers.epsilon_iMAy2_yE = (Plant_derivatives.yyk_E   - Model_derivatives.yk_E);
            Modifiers.lambda_iMAy2_yE  = (Plant_derivatives.dyE_duE - Model_derivatives.dyk_E_duE * Plant_derivatives.WE_x_invWE); 
            % Reaction G
            Modifiers.epsilon_iMAy2_yG = (Plant_derivatives.yyk_G   - Model_derivatives.yk_G);
            Modifiers.lambda_iMAy2_yG  = (Plant_derivatives.dyG_duG - Model_derivatives.dyk_G_duG * Plant_derivatives.WG_x_invWG); 
            % Reaction P
            Modifiers.epsilon_iMAy2_yP = (Plant_derivatives.yyk_P   - Model_derivatives.yk_P);
            Modifiers.lambda_iMAy2_yP  = (Plant_derivatives.dyP_duP - Model_derivatives.dyk_P_duP * Plant_derivatives.WP_x_invWP); 
            % ------
          end   
        
%         % ---------
      
        Results.Modifiers{Method}{k} = Modifiers;
        
        
        
        kappa = 0.1:0.05:1;
        
        for ka = 1:length(kappa)
            
            uy_s_O = [u0_p; y0_pstruc_opt];
            [uy_s_opt, ~, ~, ~,lambda] = RunOptimization_M_modified_spmm(uy_s_O, Theta_M, inv_A_us, b_u, Modifiers, fmincon_options, kappa(ka), UseMethode);
            
            nu    = lambda.ineqnonlin;
            u_opt = inv_A_us*uy_s_opt(1:3) + b_u;
            u_opt1(ka) = u_opt(1);
            u_opt2(ka) = u_opt(2);
            u_opt3(ka) = u_opt(3);
            
            e     = evaluate_adequacy_of_the_target(kappa(ka), u_opt, nu, Delta_u, delta_M, delta_m, Theta_M, y0_param, Modifiers, A_us, b_u, fsolve_options, uk{k});
            
            ee(ka) = min(e);
        end
        
    end

    %% Optimal point
%     y0 = [0.222; 0.183; 0.225; 0.085; 0.139; 0.121; 0.383; 0.025; 0.039] ; 

    uy_0_s = [A_us*(uk{k}-b_u);  y0_param];

    Modifiers.type = 'none';
    uyp_s_opt = RunOptimization_P(uy_0_s, Theta_P, inv_A_us, b_u, Modifiers, fmincon_options);

    u_s_opt = uyp_s_opt(1:3);
    up_opt = inv_A_us*u_s_opt+b_u;
    yyp_opt = fsolve(@(y_temp) System2_ppmm(0, y_temp, up_opt, Theta_P, Modifiers), y0_param, fsolve_options);
    [~, yp_opt, gp_opt, phip_opt, ~, ~] = System2_ppmm(0, yyp_opt, up_opt, Theta_P, Modifiers);

    %% Results
    
end
Results.k = k;
Results.B = B;
%%
uk{1}   = [12960; 36000; 358.15];  % [F_B;T] Starting point
%%
figure
plot(kappa,u_opt1,'b')
hold on
plot(kappa,up_opt(1)*ones(size(kappa)),'g')
plot(0,12960)
%%
figure
plot(kappa,u_opt2,'b')
hold on
plot(kappa,up_opt(2)*ones(size(kappa)),'g')
plot(0,36000)
%%
figure
plot(kappa,u_opt3,'b')
hold on
plot(kappa,up_opt(3)*ones(size(kappa)),'g')
plot(0,358.15)

%%
figure
plot(kappa,ee,'b')



%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')