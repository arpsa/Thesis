clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

%% 

Method = 5;

addpath('Plant')
addpath('Functions')

load('test.mat')
B = Results.B
% B  = [0; 0; 0; 8377; 12438];


Bp = [0; 0; 0; 0; 0];
    Theta_P = Parameters('Plant',    Bp);   % 'Plant' or 'Mismatch'
    Theta_M = Parameters('Mismatch', B);    % 'Plant' or 'Mismatch'
    
PBstruct = ProblemStructure();        % options for solver

fsolve_options    = PBstruct.fsolve_options;

N = 20;
% normal
F_B = 10800:(21600-10800)/(N-1):21600;
T_R = 323:(378-323)/(N-1):378;
%% contrain zoom
% F_B = 17000:(21600-17000)/(N-1):21600;
% T_R = 350:(360-355)/(N-1):365;
%% libre zoom
% F_B = 16800:(21600-16800)/(N-1):21600;
% T_R = 360:(370-360)/(N-1):370;
%% at optimum       1.7895e+04       357.4322
F_B = 17800:(18000-17800)/(N-1):18000;
T_R = 355:(359-355)/(N-1):359;




y0_p= [0.122; 0.383-0.1970; 0.0; 0.085; 0.039; 0.121; 0.383; 0.025; 0.039] ; 
y0_pstruc = [y0_p(1:2); 0; y0_p(4:7); y0_p(9)]; % remove C from the initialization


Modifiers = struct();
    Modifiers.type = 'none';

NB_iter = length(F_B)*length(T_R);
iter = 0;
h = waitbar(0,'Please wait...');
for i=1:length(F_B)
    for j=1:length(T_R)
        u = [F_B(i); T_R(j)];
        [y, phi, g] = SimModel_ppmm(u, y0_p, Modifiers, Theta_P, fsolve_options);
        
        SAVE_u1(i,j)    = u(1);
        SAVE_u2(i,j)    = u(2);
        SAVE_phi_p(i,j) = phi;
        SAVE_g_p(i,j,:) = g;
        
        SAVE_y1_p(i,j,:) = y(1);
        SAVE_y2_p(i,j,:) = y(2);
        SAVE_y3_p(i,j,:) = y(3);
        SAVE_y4_p(i,j,:) = y(4);
        SAVE_y5_p(i,j,:) = y(5);
        SAVE_y6_p(i,j,:) = y(6);
        
        iter = iter + 1;
        waitbar(iter/NB_iter)
    end
end
close(h) 

%% 
figure 
subplot(1,2,1)
hold on
   
    [CC,hh] = contour(T_R, F_B./1000, SAVE_y4_p, 'k', 'LineWidth', 1);
    
    clabel(CC,hh,'LabelSpacing',300);           
    hXLabel = xlabel('$T_R$ [K]');
    hYLabel = ylabel('$F_B$ [t/h]');    
set(gca,'FontSize', 11,'FontName','Helvetica');
set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
set(gcf, 'PaperUnits', 'centimeters');
x_width=14 ;y_width=8;   
set(gcf, 'PaperPosition', [0 0 x_width y_width]);
print('-painters','-depsc','Map_y4_plant')

subplot(1,2,2)
hold on
   
    [CC,hh] = contour(T_R, F_B./1000, SAVE_y6_p, 'k', 'LineWidth', 1);
    
    clabel(CC,hh,'LabelSpacing',300);           
    hXLabel = xlabel('$T_R$ [K]');
    hYLabel = ylabel('$F_B$ [t/h]');    
set(gca,'FontSize', 11,'FontName','Helvetica');
set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
set(gcf, 'PaperUnits', 'centimeters');
x_width=14 ;y_width=8;   
set(gcf, 'PaperPosition', [0 0 x_width y_width]);
print('-painters','-depsc','Map_y6_plant')

%%

iter = 0;
h = waitbar(0,'Please wait...');
for i=1:length(F_B)
    for j=1:length(T_R)
        u = [F_B(i); T_R(j)];
        [y, phi, g] = SimModel_spmm(u, y0_pstruc, Modifiers, Theta_M, fsolve_options);
        
        SAVE_u1(i,j)  = u(1);
        SAVE_u2(i,j)  = u(2);
        SAVE_phi_m(i,j) = phi;
        SAVE_g_m(i,j,:) = g;
        
        SAVE_y1_m(i,j,:) = y(1);
        SAVE_y2_m(i,j,:) = y(2);
        SAVE_y3_m(i,j,:) = y(3);
        SAVE_y4_m(i,j,:) = y(4);
        SAVE_y5_m(i,j,:) = y(5);
        SAVE_y6_m(i,j,:) = y(6);
 
        
        iter = iter + 1;
        waitbar(iter/NB_iter)
    end
end
close(h) 

%% 
figure 
subplot(2,2,1)
hold on
    [CC,hh] = contour(T_R, F_B./1000, SAVE_y4_m,'k','LineWidth',1);
    clabel(CC,hh,'LabelSpacing',300);            
    hXLabel = xlabel('$T_R$ [K]');
    hYLabel = ylabel('$F_B$ [t/h]');    
set(gca,'FontSize', 11,'FontName','Helvetica');
set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
set(gcf, 'PaperUnits', 'centimeters');
x_width=14 ;y_width=8;   
set(gcf, 'PaperPosition', [0 0 x_width y_width]);
print('-painters','-depsc','Map_y4_model')

subplot(2,2,2)
hold on
    [CC,hh] = contour(T_R, F_B./1000, SAVE_y6_m,'k','LineWidth',1);
    clabel(CC,hh,'LabelSpacing',300);            
    hXLabel = xlabel('$T_R$ [K]');
    hYLabel = ylabel('$F_B$ [t/h]');    
set(gca,'FontSize', 11,'FontName','Helvetica');
set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
set(gcf, 'PaperUnits', 'centimeters');
x_width=14 ;y_width=8;   
set(gcf, 'PaperPosition', [0 0 x_width y_width]);
print('-painters','-depsc','Map_y6_model')
    subplot(2,2,3)
    hold on
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y4_m-SAVE_y4_p,'k','LineWidth',1);
%          plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8); 
        clabel(CC,hh,'LabelSpacing',300);            
        hXLabel = xlabel('$T_R$ [K]');
        hYLabel = ylabel('$F_B$ [t/h]');    
    set(gca,'FontSize', 11,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
    set(gcf, 'PaperUnits', 'centimeters');
    x_width=14 ;y_width=8;   
    set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['Map_y4_correction_ITER',num2str(k)])

    subplot(2,2,4)
    hold on
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y6_m-SAVE_y6_p,'k','LineWidth',1);
%          plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
        clabel(CC,hh,'LabelSpacing',300);            
        hXLabel = xlabel('$T_R$ [K]');
        hYLabel = ylabel('$F_B$ [t/h]');    
    set(gca,'FontSize', 11,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
    set(gcf, 'PaperUnits', 'centimeters');
    x_width=14 ;y_width=8;   
    set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['Map_y6_correction_ITER',num2str(k)])

%% 

%% 
for k = 1:1
    Modifiers = struct();
    Modifiers = Results.Modifiers{Method}{k};
    
    NB_iter = length(F_B)*length(T_R);
    iter = 0;
    h = waitbar(0,'Please wait...');
    for i=1:length(F_B)
        for j=1:length(T_R)
            u = [F_B(i); T_R(j)];
            
            [y, phi, g] = SimModel_spmm(u, y0_pstruc, Modifiers, Theta_M, fsolve_options);
        
            SAVE_u1(i,j)  = u(1);
            SAVE_u2(i,j)  = u(2);
            SAVE_phi(i,j) = phi;
            SAVE_g(i,j)   = g;
            
            SAVE_y1(i,j,:) = y(1);
            SAVE_y2(i,j,:) = y(2);
            SAVE_y3(i,j,:) = y(3);
            SAVE_y4(i,j,:) = y(4);
            SAVE_y5(i,j,:) = y(5);
            SAVE_y6(i,j,:) = y(6);

            iter = iter + 1;
            waitbar(iter/NB_iter)
        end
    end
    [px,py] = gradient(SAVE_phi);
    close(h) 
    
    %%
%     figure 
%     subplot(2,2,1)
%     hold on
%         [CC,hh] = contour(T_R, F_B./1000, SAVE_y4,[0.25:0.005:0.3],'k','LineWidth',1);
%         [CC,hh] = contour(T_R, F_B./1000, SAVE_y4_p,[0.25:0.005:0.3],'--k','LineWidth',1);
%         [CC,hh] = contour(T_R, F_B./1000, SAVE_y4_m,[0.25:0.005:0.3],':k','LineWidth',1);
%          plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
% %          
%         clabel(CC,hh,'LabelSpacing',300);            
%         hXLabel = xlabel('$T_R$ [K]');
%         hYLabel = ylabel('$F_B$ [t/h]');    
%     set(gca,'FontSize', 11,'FontName','Helvetica');
%     set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=14 ;y_width=8;   
%     set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['Map_y4_ITER',num2str(k)])
% 
%     subplot(2,2,2)
%     hold on
%         [CC,hh] = contour(T_R, F_B./1000, SAVE_y6,[0.105:0.00025:0.11],'k','LineWidth',1);
%         [CC,hh] = contour(T_R, F_B./1000, SAVE_y6_p,[0.105:0.00025:0.11],'--k','LineWidth',1);
%         [CC,hh] = contour(T_R, F_B./1000, SAVE_y6_m,[0.105:0.00025:0.11],':k','LineWidth',1);
%          plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
%         clabel(CC,hh,'LabelSpacing',300);            
%         hXLabel = xlabel('$T_R$ [K]');
%         hYLabel = ylabel('$F_B$ [t/h]');    
%     set(gca,'FontSize', 11,'FontName','Helvetica');
%     set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=14 ;y_width=8;   
%     set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['Map_y6_ITER',num2str(k)])
%     
%     subplot(2,2,3)
%     hold on
%         [CC,hh] = contour(T_R, F_B./1000, SAVE_y4-SAVE_y4_p,'k','LineWidth',1);
%          plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8); 
%         clabel(CC,hh,'LabelSpacing',300);            
%         hXLabel = xlabel('$T_R$ [K]');
%         hYLabel = ylabel('$F_B$ [t/h]');    
%     set(gca,'FontSize', 11,'FontName','Helvetica');
%     set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=14 ;y_width=8;   
%     set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['Map_y4_correction_ITER',num2str(k)])
% 
%     subplot(2,2,4)
%     hold on
%         [CC,hh] = contour(T_R, F_B./1000, SAVE_y6-SAVE_y6_p,'k','LineWidth',1);
%          plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
%         clabel(CC,hh,'LabelSpacing',300);            
%         hXLabel = xlabel('$T_R$ [K]');
%         hYLabel = ylabel('$F_B$ [t/h]');    
%     set(gca,'FontSize', 11,'FontName','Helvetica');
%     set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=14 ;y_width=8;   
%     set(gcf, 'PaperPosition', [0 0 x_width y_width]);
%     print('-painters','-depsc',['Map_y6_correction_ITER',num2str(k)])
%     
    %
    
    figure 
    subplot(2,4,1)
    hold on
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y1,'k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y1_p,'--k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y1_m,':k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y1-SAVE_y1_m,'--b','LineWidth',1);
        plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
            clabel(CC,hh,'LabelSpacing',300);            
            hXLabel = xlabel('$T_R$ [K]');
            hYLabel = ylabel('$F_B$ [t/h]');    
    set(gca,'FontSize', 11,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');

    subplot(2,4,2) 
    hold on
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y2,'k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y2_p,'--k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y2_m,':k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y2-SAVE_y2_m,'--b','LineWidth',1);
        plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
            clabel(CC,hh,'LabelSpacing',300);            
            hXLabel = xlabel('$T_R$ [K]');
            hYLabel = ylabel('$F_B$ [t/h]');    
    set(gca,'FontSize', 11,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');

    subplot(2,4,3)
    hold on
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y3,'k','LineWidth',1);
%         [CC,hh] = contour(T_R, F_B./1000, SAVE_y3_p,'--k','LineWidth',1);
%         [CC,hh] = contour(T_R, F_B./1000, SAVE_y3_m,':k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y3-SAVE_y3_m,':k','LineWidth',1);
        plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
            clabel(CC,hh,'LabelSpacing',300);            
            hXLabel = xlabel('$T_R$ [K]');
            hYLabel = ylabel('$F_B$ [t/h]');    
    set(gca,'FontSize', 11,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');

    subplot(2,4,5)
    hold on
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y4  ,'k'  ,'LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y4_p,'--k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y4_m,':k' ,'LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y4-SAVE_y4_m,'--b','LineWidth',1);
        plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
            clabel(CC,hh,'LabelSpacing',300);            
            hXLabel = xlabel('$T_R$ [K]');
            hYLabel = ylabel('$F_B$ [t/h]');    
    set(gca,'FontSize', 11,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');

    subplot(2,4,6)
    hold on
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y5  ,'k'  ,'LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y5_p,'--k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y5_m,':k' ,'LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y5-SAVE_y5_m,'--b','LineWidth',1);
        plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
            clabel(CC,hh,'LabelSpacing',300);            
            hXLabel = xlabel('$T_R$ [K]');
            hYLabel = ylabel('$F_B$ [t/h]');    
    set(gca,'FontSize', 11,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');

    subplot(2,4,7)
    hold on
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y6,  'k'  ,'LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y6_p,'--k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y6_m,':k' ,'LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_y6-SAVE_y6_m,'--b','LineWidth',1);
        plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
            clabel(CC,hh,'LabelSpacing',300);            
            hXLabel = xlabel('$T_R$ [K]');
            hYLabel = ylabel('$F_B$ [t/h]');    
    set(gca,'FontSize', 11,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
    
    set(gcf, 'PaperUnits', 'centimeters');
    x_width=14 ;y_width=8;   
    set(gcf, 'PaperPosition', [0 0 x_width y_width]);
    print('-painters','-depsc',['Map_y_ITER',num2str(k)])

    
    subplot(2,4,[4,8])
    hold on
%     [CC1,hh1] = contourf(T_R, F_B./1000,SAVE_g,[-1000 1 0]);
%         T = [255, 150, 150        %// red
%              255, 150, 150        %// red
%              255, 255, 255        %// green
%              255, 255, 255]./255; %// green  
%         x = [10000
%              0.0001
%              0
%              -1000];
%         map = interp1(x/255,T,linspace(0,1,255));
%         colormap(map);
        [CC1,hh1] = contour(T_R, F_B./1000, SAVE_g,[0 0],'r','LineWidth',2);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_phi,'k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_phi_p,'--k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_phi_m,':k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1000, SAVE_phi-SAVE_phi_m,'--b','LineWidth',1);
        
        quiver(T_R,F_B./1000,px,py)
        plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','b','MarkerFaceColor','k','MarkerSize',8);
            clabel(CC,hh,'LabelSpacing',300);            
            hXLabel = xlabel('$T_R$ [K]');
            hYLabel = ylabel('$F_B$ [t/h]');    
    set(gca,'FontSize', 11,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
    
%     
end    







%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')