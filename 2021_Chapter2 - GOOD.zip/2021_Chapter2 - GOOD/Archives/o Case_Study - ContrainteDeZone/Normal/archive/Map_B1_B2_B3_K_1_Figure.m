clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

%% Name of the fil3   MA_Vs_MAY_K_map_precise
Results_file_name = 'test_B1B2B3_map';
load(Results_file_name)
%%
lim = 20;

phi_opt = Results.phi_opt(5,1,1,1);
g_opt   = Results.g_opt(5,1,1,1);
NBiter  = Results.k;

u1_optimum = Results.u1_opt(5,1,1,1,1);
u2_optimum = Results.u2_opt(5,1,1,1,1);
    

for ii = 1: length(Results.B1(1,:,1,1))
    for jj = 1:length(Results.B2(1,1,:,1))
        for kk = 1:length(Results.B3(1,1,1,:))
            for Method= 5 %[1 2 5]
                Results.NbStepsUponConv{Method}(ii,jj,kk) = NBiter+1;
                for l = 1:NBiter
%                      if abs((Results.uk1(Method,ii,jj,kk,NBiter-l+1)-u1_optimum))/(u1_optimum)<= 1/100 && ...
%                         abs((Results.uk2(Method,ii,jj,kk,NBiter-l+1)-u2_optimum))/(u1_optimum)<= 1/100
                    if abs((Results.phipk(Method,ii,jj,kk,NBiter-l+1)-phi_opt)/(phi_opt))<= 0.1/100  && ...
                        Results.gpk(Method,ii,jj,kk,NBiter-l+1) <= 0.01
                        Results.NbStepsUponConv{Method}(ii,jj,kk) = Results.NbStepsUponConv{Method}(ii,jj,kk) - 1;
                    else
                       break
                    end 
                end 
            end
        end
    end
end

%%  %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%
figure
B3 = 1;
Results.B3(5,1,3,B3)
%%%%%%%%%%%%%%
% subplot(1,3,1)
% colormap(hot)
% [C,h] = contourf(reshape(Results.B1(1,:,:,B3),[],size(Results.B1(1,:,:,B3),2),1)', reshape(Results.B2(1,:,:,B3),[],size(Results.B2(1,:,:,B3),2),1)', Results.NbStepsUponConv{1}(:,:,B3)', 'edgecolor','none');
% subplot(1,3,2)
% colormap(hot)
% [C,h] = contourf(reshape(Results.B1(2,:,:,B3),[],size(Results.B1(2,:,:,B3),2),1)', reshape(Results.B2(2,:,:,B3),[],size(Results.B2(2,:,:,B3),2),1)', Results.NbStepsUponConv{2}(:,:,B3)', 'edgecolor','none');
% subplot(1,3,3)
colormap(hot)
[C,h] = contourf(reshape(Results.B1(5,:,:,B3),[],size(Results.B1(5,:,:,B3),2),1)', reshape(Results.B2(5,:,:,B3),[],size(Results.B2(3,:,:,B3),2),1)', Results.NbStepsUponConv{5}(:,:,B3)', 'edgecolor','none');









   
