clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

%% 

Method = 5;

addpath('Plant')
addpath('Functions')

load('test.mat')
B = Results.B;
% B  = [0; 0; 0; 8377; 12438];

Bp = [0; 0; 0; 0; 0];
    Theta_P = Parameters('Plant',    Bp);   % 'Plant' or 'Mismatch'
%     Theta_P = Parameters('Mismatch', Bp);   % 'Plant' or 'Mismatch'
B  = [0; 0; 0; 8077.6; 12438.5];
    Theta_M = Parameters('Mismatch', B);    % 'Plant' or 'Mismatch'
    
% Theta_P  = Parameters('Plant', 0);    % 'Plant' or 'Mismatch'
PBstruct = ProblemStructure();        % options for solver

fsolve_options    = PBstruct.fsolve_options;

N = 40;

% F_B = 16800:(19600-16800)/(N-1):19600;
% T_R = 354:(361-354)/(N-1):361;

% F_B = 15000:(18500-15000)/(N-1):18000;
% T_R = 350:(370-350)/(N-1):370;

F_B = 10800:(21600-10800)/(N-1):21600;
T_R = 323:(378-323)/(N-1):378;

y0_p = [0.122; 0.383-0.1970; 0.0; 0.085; 0.039; 0.121; 0.383; 0.025; 0.039] ; 

Modifiers = struct();
    Modifiers.type = 'none';

NB_iter = length(F_B)*length(T_R);
iter = 0;
h = waitbar(0,'Please wait...');
for i=1:length(F_B)
    for j=1:length(T_R)
        u = [F_B(i); T_R(j)];
        [y, phi, g] = SimPlant(u, y0_p, Modifiers, Theta_P, fsolve_options);
        
        SAVE_u1(i,j)    = u(1);
        SAVE_u2(i,j)    = u(2);
        SAVE_phi_p(i,j) = phi;
        SAVE_g_p(i,j,:) = g;
        
        iter = iter + 1;
        waitbar(iter/NB_iter)
    end
end
close(h) 

%% 
figure 
hold on
contourf(T_R, F_B./1000,SAVE_g_p,[-1000 1 0]);
    T = [255, 150, 150        %// red
         255, 150, 150        %// red
         255, 255, 255        %// green
         255, 255, 255]./255; %// green  
    x = [10000
         0.01
         0
         -1000];
    map = interp1(x/255,T,linspace(0,1,255));
    colormap(map);
    [CC,hh] = contour(T_R, F_B./1000, -SAVE_phi_p/1e5,[6:0.1:7],'k','LineWidth',1);
    [CC,hh] = contour(T_R, F_B./1000, -SAVE_phi_p/1e5,'k','LineWidth',1);
    clabel(CC,hh,'LabelSpacing',300); 
    % plot(u_opt(2), u_opt(1)/1000,'ob', 'MarkerEdgeColor','k',...
    %                 'MarkerFaceColor',[0, 0.6, 0],...
    %                 'MarkerSize',8);           
    % plot(370, 3020/1000, 'ob', 'MarkerEdgeColor','k',...
    %                 'MarkerFaceColor','k',...
    %                 'MarkerSize',8);            
    hXLabel = xlabel('$T_R$ [K]');
    hYLabel = ylabel('$F_B$ [t/h]');    
set(gca,'FontSize', 11,'FontName','Helvetica');
set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
set(gcf, 'PaperUnits', 'centimeters');
x_width=14 ;y_width=8;   
set(gcf, 'PaperPosition', [0 0 x_width y_width]);
print('-painters','-depsc','Map_TR_FA_plant')

%%


    delta_M = [1e-6, 1e-5]; % [u1; u2] Step finit difference
        nuA = 4; nuB = 5; nuC = 5; nuE = 5; nuG = 6; nuP = 5;
        d = 1e-4;
        delta_m{1} = ones(nuA,1)*d;
        delta_m{2} = ones(nuB,1)*d;
        delta_m{3} = ones(nuC,1)*d;
        delta_m{4} = ones(nuE,1)*d;
        delta_m{5} = ones(nuG,1)*d;
        delta_m{6} = ones(nuP,1)*d;
    delta_P = [1e-6, 1e-5];

    u_max  = [21600; 378];
    u_min  = [10800; 323];

    inv_A_us = diag(u_max-u_min);
    A_us = inv(diag(u_max-u_min));
    b_u  = u_min;
    
    
    
iter = 0;
h = waitbar(0,'Please wait...');
for i=1:length(F_B)
    for j=1:length(T_R)
        u = [F_B(i); T_R(j)];
        [y, phi, g] = SimPlant(u, y0_p, Modifiers, Theta_M, fsolve_options);
        
        SAVE_u1(i,j)    = u(1);
        SAVE_u2(i,j)    = u(2);
        SAVE_phi_p(i,j) = phi;
        SAVE_g_p(i,j,:) = g;
        
        SAVE_u1_test(i,j)    = u(1);
        SAVE_u2_test(i,j)    = u(2);
        SAVE_phi_p_test(i,j) = phi;
        SAVE_g_p_test(i,j,:) = g;
        
        iter = iter + 1;
        waitbar(iter/NB_iter)
    end
end
close(h) 

%% 
figure 
hold on
contourf(T_R, F_B./1000,SAVE_g_p,[-1000 1 0]);
    T = [255, 150, 150        %// red
         255, 150, 150        %// red
         255, 255, 255        %// green
         255, 255, 255]./255; %// green  
    x = [10000
         0.01
         0
         -1000];
    map = interp1(x/255,T,linspace(0,1,255));
    colormap(map);
    [CC,hh] = contour(T_R, F_B./1000, -SAVE_phi_p/1e5,[6:0.1:7],'k','LineWidth',1);
    [CC,hh] = contour(T_R, F_B./1000, -SAVE_phi_p/1e5,'k','LineWidth',1);
    clabel(CC,hh,'LabelSpacing',300); 
    % plot(u_opt(2), u_opt(1)/1000,'ob', 'MarkerEdgeColor','k',...
    %                 'MarkerFaceColor',[0, 0.6, 0],...
    %                 'MarkerSize',8);           
    % plot(370, 3020/1000, 'ob', 'MarkerEdgeColor','k',...
    %                 'MarkerFaceColor','k',...
    %                 'MarkerSize',8);            
    hXLabel = xlabel('$T_R$ [K]');
    hYLabel = ylabel('$F_B$ [t/h]');    
set(gca,'FontSize', 11,'FontName','Helvetica');
set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
set(gcf, 'PaperUnits', 'centimeters');
x_width=14 ;y_width=8;   
set(gcf, 'PaperPosition', [0 0 x_width y_width]);
print('-painters','-depsc','Map_TR_FA_model')

 

%% 
for k = 1:5
    Modifiers = struct();
    Modifiers = Results.Modifiers{Method}{k};
    
    NB_iter = length(F_B)*length(T_R);
    iter = 0;
    h = waitbar(0,'Please wait...');
    for i=1:length(F_B)
        for j=1:length(T_R)
            u = [F_B(i); T_R(j)];
            
            y = fsolve(@(y_temp) System2(0, y_temp, u, Theta_M, Modifiers), y0_p, fsolve_options);
            [~, y, g, phi] = System2(0, y, u, Theta_M, Modifiers);

            SAVE_u1(i,j)  = u(1);
            SAVE_u2(i,j)  = u(2);
            SAVE_phi(i,j) = phi;
            SAVE_g(i,j) = g;
            

            iter = iter + 1;
            waitbar(iter/NB_iter)
        end
    end
    close(h) 
    


    uk{k} = [Results.uk1{Method}(k); Results.uk2{Method}(k)];
    uk_s{k}  = A_us *(uk{k}-b_u);
        Modifiers.type = 'none';
    Plant_derivatives = derivatives_P(uk_s{k}, uk{k}, delta_P,          Theta_P,  A_us, b_u, y0_p, Modifiers, fsolve_options);
    Model_derivatives = derivatives_M(uk_s{k}, uk{k}, delta_M, delta_m, Theta_M,  A_us, b_u, y0_p, Modifiers, fsolve_options, Plant_derivatives.uuk);
    
    epsilon_phi_k = Plant_derivatives.phik     - Model_derivatives.phik;
    lambda_phi_k  = Plant_derivatives.dphik_du - Model_derivatives.dphik_du;
            
   for i=1:length(F_B)
        for j=1:length(T_R)

            SAVE_phi_p_AffCor(i,j) = SAVE_phi_p_test(i,j) + epsilon_phi_k + lambda_phi_k'*([SAVE_u1(i,j); SAVE_u2(i,j)] - uk{k}) ;
            
            iter = iter + 1;
            waitbar(iter/NB_iter)
        end
   end
    
   
    %%
    figure 
    hold on
    contourf(T_R, F_B./1000,SAVE_g,[-1000 1 0]);
        T = [255, 150, 150        %// red
             255, 150, 150        %// red
             255, 255, 255        %// green
             255, 255, 255]./255; %// green  
        x = [10000
             0.01
             0
             -1000];
        map = interp1(x/255,T,linspace(0,1,255));
        colormap(map);
%         [CC,hh] = contour(T_R, F_B./1e3, -SAVE_phi/1e5,[-20:2:20],'k','LineWidth',1);
%         [CC,hh] = contour(T_R, F_B./1e3, -(SAVE_phi)/1e5,'r','LineWidth',1);
%         [CC,hh] = contour(T_R, F_B./1e3, -(SAVE_phi-SAVE_phi_p_AffCor)/1e5,'k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1e3, -(SAVE_phi_p_AffCor)/1e5,'k','LineWidth',1);
        
        
        clabel(CC,hh,'LabelSpacing',300); 
         plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
         plot(Results.uk2{Method}(k+1), Results.uk1{Method}(k+1)./1e3,'og','MarkerEdgeColor','g','MarkerFaceColor','g','MarkerSize',8);
         
        hXLabel = xlabel('$T_R$ [K]');
        hYLabel = ylabel('$F_B$ [t/h]');    
    set(gca,'FontSize', 11,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
    set(gcf, 'PaperUnits', 'centimeters');
    x_width=14 ;y_width=8;   
    set(gcf, 'PaperPosition', [0 0 x_width y_width]);
    print('-painters','-depsc',['Map_TR_FA_k_',num2str(k)])
    
end    







%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')