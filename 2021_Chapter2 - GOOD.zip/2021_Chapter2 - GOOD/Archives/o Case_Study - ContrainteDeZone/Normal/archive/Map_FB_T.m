clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

%% 

Method = 5;

addpath('Plant')
addpath('Functions')

load('test.mat')
B = Results.B;
% B  = [6666.66; 8333.33; 11111.11; 0; 0];
% B  = [0; 0; 0; 8077.6; 12438.5]


Bp = [0; 0; 0; 0; 0];
    Theta_P = Parameters('Plant', Bp);   % 'Plant' or 'Mismatch'
    Theta_M = Parameters('Mismatch', B);    % 'Plant' or 'Mismatch'
    
PBstruct = ProblemStructure();        % options for solver

fsolve_options    = PBstruct.fsolve_options;

N = 10;
%% normal
% F_B = 10800:(21600-10800)/(N-1):21600;
% T_R = 323:(378-323)/(N-1):378;
% % T_R = 323:(360-323)/(N-1):360;
%% contrain zoom
F_B = 17000:(21600-17000)/(N-1):21600;
T_R = 350:(360-355)/(N-1):365;
%% libre zoom
% F_B = 16800:(21600-16800)/(N-1):21600;
% T_R = 360:(370-360)/(N-1):370;




y0_p = [0.122; 0.383-0.1970; 0.0; 0.085; 0.039; 0.121; 0.383; 0.025; 0.039] ; 

Modifiers = struct();
    Modifiers.type = 'none';

NB_iter = length(F_B)*length(T_R);
iter = 0;
h = waitbar(0,'Please wait...');
for i=1:length(F_B)
    for j=1:length(T_R)
        u = [F_B(i); T_R(j)];
        [y, phi, g] = SimModel_ppmm(u, y0_p, Modifiers, Theta_P, fsolve_options);
        
        SAVE_u1(i,j)    = u(1);
        SAVE_u2(i,j)    = u(2);
        SAVE_phi_p(i,j) = phi;
        SAVE_g_p(i,j,:) = g;
        
        iter = iter + 1;
        waitbar(iter/NB_iter)
    end
end
[px,py] = gradient(SAVE_phi_p);
close(h) 

%% 
figure 
hold on
contourf(T_R, F_B./1000,SAVE_g_p,[-1000 1 0]);
    T = [255, 150, 150        %// red
         255, 150, 150        %// red
         255, 255, 255        %// green
         255, 255, 255]./255; %// green  
    x = [10000
         0.01
         0
         -1000];
    map = interp1(x/255,T,linspace(0,1,255));
    colormap(map);
%     [CC,hh] = contour(T_R, F_B./1000, -SAVE_phi_p/1e5,[6:0.1:7],'k','LineWidth',1);
    [CC,hh] = contour(T_R, F_B./1000, -SAVE_phi_p/1e5,'k','LineWidth',1);
%     quiver(T_R,F_B./1000,px,py)
    clabel(CC,hh,'LabelSpacing',300); 
    % plot(u_opt(2), u_opt(1)/1000,'ob', 'MarkerEdgeColor','k',...
    %                 'MarkerFaceColor',[0, 0.6, 0],...
    %                 'MarkerSize',8);           
    % plot(370, 3020/1000, 'ob', 'MarkerEdgeColor','k',...
    %                 'MarkerFaceColor','k',...
    %                 'MarkerSize',8);            
    hXLabel = xlabel('$T_R$ [K]');
    hYLabel = ylabel('$F_B$ [t/h]');    
set(gca,'FontSize', 11,'FontName','Helvetica');
set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
set(gcf, 'PaperUnits', 'centimeters');
x_width=14 ;y_width=8;   
set(gcf, 'PaperPosition', [0 0 x_width y_width]);
print('-painters','-depsc','Map_TR_FA_plant')

%%

iter = 0;
h = waitbar(0,'Please wait...');
for i=1:length(F_B)
    for j=1:length(T_R)
        u = [F_B(i); T_R(j)];
        [y, phi, g] = SimModel_spmm(u, y0_p, Modifiers, Theta_M, fsolve_options);
        
        SAVE_u1(i,j)  = u(1);
        SAVE_u2(i,j)  = u(2);
        SAVE_phi_m(i,j) = phi;
        SAVE_g_m(i,j,:) = g;
        
        SAVE_u1_test(i,j)  = u(1);
        SAVE_u2_test(i,j)  = u(2);
        SAVE_phi_test(i,j) = phi;
        SAVE_g_test(i,j,:) = g;
        
        iter = iter + 1;
        waitbar(iter/NB_iter)
    end
end
close(h) 

%% 
figure 
hold on
contourf(T_R, F_B./1000,SAVE_g_m,[-1000 1 0]);
    T = [255, 150, 150        %// red
         255, 150, 150        %// red
         255, 255, 255        %// green
         255, 255, 255]./255; %// green  
    x = [10000
         0.01
         0
         -1000];
    map = interp1(x/255,T,linspace(0,1,255));
    colormap(map);
    [CC,hh] = contour(T_R, F_B./1000, -SAVE_phi_m/1e5,[6:0.1:7],'k','LineWidth',1);
    [CC,hh] = contour(T_R, F_B./1000, -SAVE_phi_m/1e5,'k','LineWidth',1);
    clabel(CC,hh,'LabelSpacing',300); 
    % plot(u_opt(2), u_opt(1)/1000,'ob', 'MarkerEdgeColor','k',...
    %                 'MarkerFaceColor',[0, 0.6, 0],...
    %                 'MarkerSize',8);           
    % plot(370, 3020/1000, 'ob', 'MarkerEdgeColor','k',...
    %                 'MarkerFaceColor','k',...
    %                 'MarkerSize',8);            
    hXLabel = xlabel('$T_R$ [K]');
    hYLabel = ylabel('$F_B$ [t/h]');    
set(gca,'FontSize', 11,'FontName','Helvetica');
set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
set(gcf, 'PaperUnits', 'centimeters');
x_width=14 ;y_width=8;   
set(gcf, 'PaperPosition', [0 0 x_width y_width]);
print('-painters','-depsc','Map_TR_FA_model')

%% 
figure 
hold on
contourf(T_R, F_B./1000,SAVE_g_m,[-1000 1 0]);
    T = [255, 150, 150        %// red
         255, 150, 150        %// red
         255, 255, 255        %// green
         255, 255, 255]./255; %// green  
    x = [10000
         0.01
         0
         -1000];
    map = interp1(x/255,T,linspace(0,1,255));
    colormap(map);
%     [CC,hh] = contour(T_R, F_B./1000, -(SAVE_phi_p-SAVE_phi)/1e5,[6:0.1:7],'k','LineWidth',1);
    [CC,hh] = contour(T_R, F_B./1000, -(SAVE_phi_p-SAVE_phi_m)/1e5,'k','LineWidth',1);
    clabel(CC,hh,'LabelSpacing',300); 
    % plot(u_opt(2), u_opt(1)/1000,'ob', 'MarkerEdgeColor','k',...
    %                 'MarkerFaceColor',[0, 0.6, 0],...
    %                 'MarkerSize',8);           
    % plot(370, 3020/1000, 'ob', 'MarkerEdgeColor','k',...
    %                 'MarkerFaceColor','k',...
    %                 'MarkerSize',8);            
    hXLabel = xlabel('$T_R$ [K]');
    hYLabel = ylabel('$F_B$ [t/h]');    
set(gca,'FontSize', 11,'FontName','Helvetica');
set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
set(gcf, 'PaperUnits', 'centimeters');
x_width=14 ;y_width=8;   
set(gcf, 'PaperPosition', [0 0 x_width y_width]);
print('-painters','-depsc','Map_TR_FA_pm_misatch')


%%
% figure(10) 
% 
% surf(T_R, F_B./1000, -(SAVE_phi_p-SAVE_phi)/1e5) 
% hold on
% %
 

%% 
for k = 1:7
    Modifiers = struct();
    Modifiers = Results.Modifiers{Method}{k};
    
    NB_iter = length(F_B)*length(T_R);
    iter = 0;
    h = waitbar(0,'Please wait...');
    for i=1:length(F_B)
        for j=1:length(T_R)
            u = [F_B(i); T_R(j)];
            
%             y_temp2 = fsolve(@(y_temp) System2_ppmm(0, y_temp, u, Theta_M, Modifiers), y0_p, fsolve_options);
%             [~, y, g, phi] = System2_ppmm(0, y_temp2, u, Theta_M, Modifiers);
            [y, phi, g] = SimModel_spmm(u, y0_p, Modifiers, Theta_M, fsolve_options);
        
            SAVE_u1(i,j)  = u(1);
            SAVE_u2(i,j)  = u(2);
            SAVE_phi(i,j) = phi;
            SAVE_g(i,j) = g;

            iter = iter + 1;
            waitbar(iter/NB_iter)
        end
    end
    close(h) 
    
    %%
    figure 
    hold on
    contourf(T_R, F_B./1000,SAVE_g,[-1000 1 0]);
        T = [255, 150, 150        %// red
             255, 150, 150        %// red
             255, 255, 255        %// green
             255, 255, 255]./255; %// green  
        x = [10000
             0.01
             0
             -1000];
        map = interp1(x/255,T,linspace(0,1,255));
        colormap(map);
%         [CC,hh] = contour(T_R, F_B./1e3, -SAVE_phi/1e5,[-20:2:20],'k','LineWidth',1);
%         [CC,hh] = contour(T_R, F_B./1e3, -(SAVE_phi-SAVE_phi_p_test)/1e5,[6:0.1:7],'k','LineWidth',1);
%         [CC,hh] = contour(T_R, F_B./1e3, -(SAVE_phi-SAVE_phi_p_test)/1e5,'k','LineWidth',1);
%         [CC,hh] = contour(T_R, F_B./1e3, -(SAVE_phi)/1e5,[0:1:50],'k','LineWidth',1);

%         [CC,hh] = contour(T_R, F_B./1e3, -(SAVE_phi)/1e5,[6:0.05:8],'k','LineWidth',1);
%         [CC,hh] = contour(T_R, F_B./1e3, -(SAVE_phi_p)/1e5,[6.7:0.01:8],'--k','LineWidth',1);
%         clabel(CC,hh,'LabelSpacing',300);
%         [CC,hh] = contour(T_R, F_B./1e3, -(SAVE_phi_test)/1e5,[6:0.2:7],':k','LineWidth',1);
        
        [CC,hh] = contour(T_R, F_B./1e3, -(SAVE_phi)/1e5,'k','LineWidth',1);
        [CC,hh] = contour(T_R, F_B./1e3, -(SAVE_phi_p)/1e5,'--k','LineWidth',1);
        clabel(CC,hh,'LabelSpacing',300);
        [CC,hh] = contour(T_R, F_B./1e3, -(SAVE_phi_test)/1e5,[6:0.2:7],':k','LineWidth',1);
        
% %         clabel(CC,hh,'LabelSpacing',300); 
         plot(Results.uk2{Method}(k), Results.uk1{Method}(k)./1e3,'ok','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',8);
         plot(Results.uk2{Method}(k+1), Results.uk1{Method}(k+1)./1e3,'og','MarkerEdgeColor','g','MarkerFaceColor','g','MarkerSize',8);
         
        hXLabel = xlabel('$T_R$ [K]');
        hYLabel = ylabel('$F_B$ [t/h]');    
    set(gca,'FontSize', 11,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 13 ,'Interpreter','LaTex');
    set(gcf, 'PaperUnits', 'centimeters');
    x_width=14 ;y_width=8;   
    set(gcf, 'PaperPosition', [0 0 x_width y_width]);
    print('-painters','-depsc',['Map_TR_FA_k_',num2str(k)])
    
%     figure(10)
%     surf(T_R, F_B./1000, -(SAVE_phi_p-SAVE_phi)/1e5)
%     
end    







%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')