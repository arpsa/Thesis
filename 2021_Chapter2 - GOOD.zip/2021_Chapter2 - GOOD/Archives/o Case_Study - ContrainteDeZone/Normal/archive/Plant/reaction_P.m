function dx_P = reaction_P(t, x_P, u_P, Parameters)

% x_P = P_R;
% u_P = [F_B; T_R; A_R; B_R; C_R];

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Parameters
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

W = 2105; %Vr*rho_R;   % [kg]

A2 = Parameters.A2; % [1/h]
B2 = Parameters.B2; % [�K]
A3 = Parameters.A3; % [1/h]
B3 = Parameters.B3; % [�K]
A4 = Parameters.A4; % [1/h]
B4 = Parameters.B4; % [�K]
A5 = Parameters.A5; % [1/h]
B5 = Parameters.B5; % [�K]

MA = 100;
MB = 100;
MC = 200;
MP = 100;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  2.- Nomenclature
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

F_A = u_P(1);
F_B = u_P(2);
T_R = u_P(3);
F   = F_A+F_B;
X_P = 0;

A_R = u_P(4);
B_R = u_P(5);
C_R = u_P(6);
P_R = x_P;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  3.- Model
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k2 = A2*exp(-B2/T_R);
k3 = A3*exp(-B3/T_R);
k4 = A4*exp(-B4/T_R);
k5 = A5*exp(-B5/T_R);
%
% A +  B -> C      (1)
% C +  B -> P + E  (2)
% P +  C -> G      (3)
% A + 2B -> P + E  (4)
% A +  B + P -> G  (5)
%  
r2 = k2*B_R*C_R;
r3 = k3*C_R*P_R;
r4 = k4*A_R*B_R^2;
r5 = k5*A_R*B_R*P_R;

dx_P = F*X_P/W - F*P_R/W + MP/MB*r2 - MP/MC*r3  + MP/MA*r4   - MP/MA*r5;

end