function dx_R = WOreactorDyn(t, x, u, Parameters)


% u = [F_A; T_R];
%
% x = [A_R; B_R; C_R; E_R; G_R; P_R]
%
% y = [X_A; X_E; X_G; X_P]

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Parameters
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reactor design 
% Vr    = 2.1088;               % [m3]    Reactor volume
% rho_R = 800.923168698;     % [kg/m^3] Density of the reactant mixture
% %
W = 2105; %Vr*rho_R;   % [kg]
%
A1 = Parameters.A1; % [1/h]
B1 = Parameters.B1; % [�K]
A2 = Parameters.A2; % [1/h]
B2 = Parameters.B2; % [�K]
A3 = Parameters.A3; % [1/h]
B3 = Parameters.B3; % [�K]
A4 = Parameters.A4; % [1/h]
B4 = Parameters.B4; % [�K]
A5 = Parameters.A5; % [1/h]
B5 = Parameters.B5; % [�K]

MA = 100;
MB = 100;
MC = 200;
ME = 200;
MG = 300;
MP = 100;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  2.- Nomenclature
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

F_A = u(1);
F_B = Parameters.FB;
T_R = u(2);

F   = F_A+F_B;
X_A = F_A/F;
X_B = F_B/F;
X_C = 0;
X_E = 0;
X_G = 0;
X_P = 0;

A_R = x(1);
B_R = x(2);
C_R = x(3);
E_R = x(4);
G_R = x(5);
P_R = x(6);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  3.- Model
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k1 = A1*exp(-B1/T_R);
k2 = A2*exp(-B2/T_R);
k3 = A3*exp(-B3/T_R);
k4 = A4*exp(-B4/T_R);
k5 = A5*exp(-B5/T_R);
%
% A +  B -> C      (1)
% C +  B -> P + E  (2)
% P +  C -> G      (3)
% A + 2B -> P + E  (4)
% A +  B + P -> G  (5)
%  
r1 = k1*A_R*B_R;
r2 = k2*B_R*C_R;
r3 = k3*C_R*P_R;
r4 = k4*A_R*B_R^2;
r5 = k5*A_R*B_R*P_R;
%
dx_R = zeros(7,1);
dx_R(1) = F*X_A/W - F*A_R/W - r1                              - r4         - r5;
dx_R(2) = F*X_B/W - F*B_R/W - MB/MA*r1 - r2                   - 2*MB/MA*r4 - MB/MA*r5;
dx_R(3) = F*X_C/W - F*C_R/W + MC/MA*r1 - MC/MB*r2 - r3;
dx_R(5) = F*X_E/W - F*E_R/W + ME/MP*r2                        + ME/MA*r4;
dx_R(6) = F*X_G/W - F*G_R/W                       + MG/MC*r3               + MG/MA*r5;
dx_R(7) = F*X_P/W - F*P_R/W            + MP/MB*r2 - MP/MC*r3  + MP/MA*r4   - MP/MA*r5;



