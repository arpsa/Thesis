function [dy, y_simple, g, phi, uu, yy] = System2_spmm(t, y, u, Parameters, Modifiers)

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   I.- Sub-systems
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Notations
F_A = u(1); F_B = u(2); T_R = u(3);

A_R = y(1); B_R  = y(2); E_R  = y(3); G_R  = y(4);  P_R  = y(5);
yyA = y(6); yyB = y(7); yyP = y(8);

%% Dynamic of A
u_A  = [F_A; F_B; T_R; yyB; yyP];
y_A  = A_R;
dy_A = reaction_A_spmm(t, y_A, u_A, Parameters);
if strcmp(Modifiers.type,'iMAy1')
    epsilon_iMAy1_yA = Modifiers.epsilon_iMAy1_yA;
    lambda_iMAy1_yA  = Modifiers.lambda_iMAy1_yA;
    uk               = Modifiers.uk;
    y_A = y_A + (epsilon_iMAy1_yA + lambda_iMAy1_yA*(u-uk));
elseif strcmp(Modifiers.type,'iMAy2')
    epsilon_iMAy2_yA = Modifiers.epsilon_iMAy2_yA;
    lambda_iMAy2_yA  = Modifiers.lambda_iMAy2_yA;
    uAk              = Modifiers.uAk;
    y_A = y_A + epsilon_iMAy2_yA + lambda_iMAy2_yA*(u_A-uAk);
end


%% Dynamic of B
u_B  = [F_A; F_B; T_R; yyA; yyP];
y_B  = B_R;
dy_B = reaction_B_spmm(t, y_B, u_B, Parameters);
if strcmp(Modifiers.type,'iMAy1')
    epsilon_iMAy1_yB = Modifiers.epsilon_iMAy1_yB;
    lambda_iMAy1_yB  = Modifiers.lambda_iMAy1_yB;
    uk               = Modifiers.uk;
    y_B = y_B + (epsilon_iMAy1_yB + lambda_iMAy1_yB*(u-uk));
elseif strcmp(Modifiers.type,'iMAy2')
    epsilon_iMAy2_yB = Modifiers.epsilon_iMAy2_yB;
    lambda_iMAy2_yB  = Modifiers.lambda_iMAy2_yB;
    uBk              = Modifiers.uBk;
    y_B = y_B + epsilon_iMAy2_yB + lambda_iMAy2_yB*(u_B-uBk);
end 


%% Dynamic of C
u_C  = [];
y_C  = 0;
dy_C = 0;


%% Dynamic of G
u_G  = [F_A; F_B; T_R; yyA; yyB; yyP];
y_G  = G_R;
dy_G = reaction_G_spmm(t, y_G, u_G, Parameters);
if strcmp(Modifiers.type,'iMAy1')
    epsilon_iMAy1_yG = Modifiers.epsilon_iMAy1_yG;
    lambda_iMAy1_yG  = Modifiers.lambda_iMAy1_yG;
    uk               = Modifiers.uk;
    y_G = y_G + (epsilon_iMAy1_yG + lambda_iMAy1_yG*(u-uk));
elseif strcmp(Modifiers.type,'iMAy2')
    epsilon_iMAy2_yG = Modifiers.epsilon_iMAy2_yG;
    lambda_iMAy2_yG  = Modifiers.lambda_iMAy2_yG;
    uGk              = Modifiers.uGk;
    y_G = y_G + epsilon_iMAy2_yG + lambda_iMAy2_yG*(u_G-uGk);
end


%% Dynamic of P
u_P  = [F_A; F_B; T_R; yyA; yyB];
y_P  = P_R;
dy_P = reaction_P_spmm(t, y_P, u_P, Parameters);
if strcmp(Modifiers.type,'iMAy1')
    epsilon_iMAy1_yP = Modifiers.epsilon_iMAy1_yP;
    lambda_iMAy1_yP  = Modifiers.lambda_iMAy1_yP;
    uk               = Modifiers.uk;
    y_P = y_P + (epsilon_iMAy1_yP + lambda_iMAy1_yP*(u-uk));
elseif strcmp(Modifiers.type,'iMAy2')
    epsilon_iMAy2_yP = Modifiers.epsilon_iMAy2_yP;
    lambda_iMAy2_yP  = Modifiers.lambda_iMAy2_yP;
    uPk              = Modifiers.uPk;
    y_P = y_P + epsilon_iMAy2_yP + lambda_iMAy2_yP*(u_P-uPk);
end


%% Dynamic of E
u_E  = [F_A; F_B; T_R; yyA; yyB]; 
y_E  = E_R;
dy_E = reaction_E_spmm(t, y_E, u_E, Parameters);
if strcmp(Modifiers.type,'iMAy1')
    epsilon_iMAy1_yE = Modifiers.epsilon_iMAy1_yE;
    lambda_iMAy1_yE  = Modifiers.lambda_iMAy1_yE;
    uk               = Modifiers.uk;
    y_E = y_E + (epsilon_iMAy1_yE + lambda_iMAy1_yE*(u-uk));
elseif strcmp(Modifiers.type,'iMAy2')
    epsilon_iMAy2_yE = Modifiers.epsilon_iMAy2_yE;
    lambda_iMAy2_yE  = Modifiers.lambda_iMAy2_yE;
    uEk              = Modifiers.uEk;
    y_E = y_E + epsilon_iMAy2_yE + lambda_iMAy2_yE*(u_E-uEk);
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   II.- System
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% dy  = [dy_A; dy_B; dy_E; dy_G; dy_P;
%        y_A-yy_A; y_B-yy_B; y_P-yy_P];
dy  = [dy_A; dy_B; dy_E; dy_G; dy_P; yyA-y_A; yyB-y_B; yyP-y_P];
y_simple = [y_A; y_B; y_C; y_E; y_G; y_P];

[phi, g] = uy2phig(u, y_simple,Parameters);

if strcmp(Modifiers.type,'MA')
    phi = phi + Modifiers.epsilon_phi_k + Modifiers.lambda_phi_k'*(u-Modifiers.uk);
    g   = g   + Modifiers.epsilon_g_k   + Modifiers.lambda_g_k  *(u-Modifiers.uk);
elseif strcmp(Modifiers.type,'MAy')
    y_simple = y_simple + Modifiers.epsilon_y_k + Modifiers.lambda_y_k*(u-Modifiers.uk);
    [phi, g] = uy2phig(u, y_simple,Parameters);
end  
   
uu{1} = u_A; uu{2} = u_B; uu{3} = u_C; uu{4} = u_E; uu{5} = u_G;  uu{6} = u_P; 
yy{1} = y_A; yy{2} = y_B; yy{3} = y_C; yy{4} = y_E; yy{5} = y_G;  yy{6} = y_P; 







end