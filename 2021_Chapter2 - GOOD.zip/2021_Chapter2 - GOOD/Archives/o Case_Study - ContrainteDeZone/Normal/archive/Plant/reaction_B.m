function dx_B = reaction_B(t, x_B, u_B, Parameters)
% x_B = B_R;
% u_B = [F_B; T_R; A_R; C_R; P_R];

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Parameters
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

W = 2105; %Vr*rho_R;   % [kg]

A1 = Parameters.A1; % [1/h]
B1 = Parameters.B1; % [�K]
A2 = Parameters.A2; % [1/h]
B2 = Parameters.B2; % [�K]
A4 = Parameters.A4; % [1/h]
B4 = Parameters.B4; % [�K]
A5 = Parameters.A5; % [1/h]
B5 = Parameters.B5; % [�K]

MA = 100;
MB = 100;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  2.- Nomenclature
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

F_A = u_B(1);
F_B = u_B(2);
T_R = u_B(3);

F   = F_A+F_B;
X_B = F_B/F;

A_R = u_B(4);
B_R = x_B;
C_R = u_B(5);
P_R = u_B(6);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  3.- Model
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k1 = A1*exp(-B1/T_R);
k2 = A2*exp(-B2/T_R);
k4 = A4*exp(-B4/T_R);
k5 = A5*exp(-B5/T_R);
%
% A +  B -> C      (1)
% C +  B -> P + E  (2)
% P +  C -> G      (3)
% A + 2B -> P + E  (4)
% A +  B + P -> G  (5)
%  
r1 = k1*A_R*B_R;
r2 = k2*B_R*C_R;
r4 = k4*A_R*B_R^2;
r5 = k5*A_R*B_R*P_R;

dx_B = F*X_B/W - F*x_B/W - MB/MA*r1 - r2 - 2*MB/MA*r4 - MB/MA*r5;

end