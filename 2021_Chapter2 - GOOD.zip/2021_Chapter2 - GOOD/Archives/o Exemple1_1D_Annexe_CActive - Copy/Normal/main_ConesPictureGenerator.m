clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic
%% Code architecture initialization & Output files 
addpath('Functions')

Results_file_name = 'Results_Main';

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  0.- Initialization of the algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 0.2.- Simulations parameters
PBstruct = ProblemStructure();        % options for solver | nb iterations
    fmincon_options = PBstruct.fmincon_options;
    fsolve_options  = PBstruct.fsolve_options;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Save Results
Results  = struct();
struct_Y = struct();

a = 1;
b = 3; 
%%
% for i = 1:length(uu)
%     for j = 1:length(aa)]
        ups = 0;
        %% A ups 
        [phi_k, Dphi_k, DDphi_k,DDDphi_k,g,Dg,DDg]    = model(ups,a, b);
        [phi_pk, Dphi_pk, DDphi_pk,DDDphi_pk,gp,Dgp,DDgp] = plant(ups);
        lambda_phi  = Dphi_pk - Dphi_k;
        lambda_g    = Dgp - Dg;
        epsilon_g   = gp - g;
        %% Apres ups 
        delta = 1e-5;
        [phi_k, Dphi_k, DDphi_k,DDDphi_k,g,Dg,DDg]    = model(ups+delta,a, b);
        [phi_pk, Dphi_pk, DDphi_pk,DDDphi_pk,gp,Dgp,DDgp] = plant(ups+delta);
        lambda_phi_p1  = Dphi_pk - Dphi_k;
        lambda_g_p1    = Dgp - Dg;
        epsilon_g_p1   = gp - g;
        %% Avant ups 
        [phi_k, Dphi_k, DDphi_k,DDDphi_k,g,Dg,DDg]    = model(ups-delta,a, b);
        [phi_pk, Dphi_pk, DDphi_pk,DDDphi_pk,gp,Dgp,DDgp] = plant(ups-delta);
        lambda_phi_m1  = Dphi_pk - Dphi_k;
        lambda_g_m1    = Dgp - Dg;
        epsilon_g_m1   = gp - g;
        %% 3.- Compute next point
        uk = 0;
        [uopt    , ~,~,LMultipliers]    = RunOptimization(uk, uk, lambda_phi,lambda_g,epsilon_g   ,a, b, fmincon_options);
        LambdaUpp     = LMultipliers.ineqnonlin;
        [uopt_p1 , ~,~,LMultipliers_p1] = RunOptimization(uk, uk+delta, lambda_phi_p1,lambda_g_p1,epsilon_g_p1,a, b, fmincon_options);
        LambdaUpp_p1  = LMultipliers_p1.ineqnonlin;
        [uopt_m1 , ~,~,LMultipliers_m1] = RunOptimization(uk, uk-delta, lambda_phi_m1,lambda_g_m1,epsilon_g_m1,a, b, fmincon_options);
        LambdaUpp_m1  = LMultipliers_m1.ineqnonlin;

        NablaS_p1 = (LambdaUpp_p1 - LambdaUpp)/abs(delta) * delta/norm(delta);
        NablaS_m1 = (LambdaUpp_m1 - LambdaUpp)/abs(delta) * -delta/norm(delta);

        disp(['Nabla^S +1: ',num2str( NablaS_p1*Dgp )])
        disp(['Nabla^S -1: ',num2str( NablaS_m1*Dgp )])
        disp(['Estimation: ',num2str( DDphi_k-DDphi_pk  + LambdaUpp*(DDg-DDgp) )])
        disp(['lambda: ',num2str( LambdaUpp )])
       
        
%         plot([0 0.2 1 2 3 4], [0 1.36 10 28 54 88])
        
%         + LambdaUpp*((DDphi_k-DDphi_pk)/2)*((DDphi_k-DDphi_pk)/24)
        
        
%         LambdaLow   = LMultipliers.lower;
%         LambdaUpp  = LMultipliers.upper;
%         DDphi_pkk  = DDphi_pk;
%         DDphi_kk  = DDphi_k;
%         Dphi_pkk     = Dphi_pk;
%         phi_pkk    = phi_pk;
%     end
% end
% %%
% figure
%     hold on
% %     plot(uu,uopt(:,1),'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
%     plot(uu,uopt,'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% %     plot(uu(398:602),uopt(398:602,1),'k', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% %     plot(uu(602:end),uopt(602:end,1),'k', 'Color','b', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
%     plot(uu,uu, 'k:')  
%     ylim([0 6])
%         xlim([-5 5])
%         hXLabel = xlabel('$v$');
%         hYLabel = ylabel('$sol(v)$');
%         set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%         set(gca,'FontSize',10);
%         set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%         set(gca,'Layer','Top');
%         set(gcf, 'PaperUnits', 'centimeters');
%         x_width=4.45; y_width=4.45;  
%         set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%         print('-painters','-dpdf','CActive_SolU')
% 
%     
% %% Zoom
% figure
%     hold on
% %     plot(uu,LambdaLow(:,1),'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% %         ylim([0 6])
%     plot(uu,LambdaLow,'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% %     plot(uu(398:602),LambdaLow(398:602,1),'k', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% %     plot(uu(602:end),LambdaLow(602:end,1),'k', 'Color','b', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
%         ylim([-1 15])
%         xlim([-5 5])
%         hXLabel = xlabel('$v$');
%         hYLabel = ylabel('$\lambda^*_{(1)}(v)$');
%         set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%         set(gca,'FontSize',10);
%         set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%         set(gca,'Layer','Top');
%         set(gcf, 'PaperUnits', 'centimeters');
%         x_width=4.45; y_width=4.45;  
%         set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%         print('-painters','-dpdf','CActive_LambdaLow')
% %% Zoom
% figure
%     hold on
% %     plot(uu,LambdaLow(:,1),'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% %         ylim([0 6])
%     plot(uu(1:end-1),(LambdaUpp(2:end,1)-LambdaLow(1:end-1,1))./(uu(2:end)-uu(1:end-1)),'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% %     plot(uu(1:end-1),(LambdaLow(2:end,1)-LambdaLow(1:end-1,1))./(uu(2:end)-uu(1:end-1)),'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% %     plot(uu(398:602),LambdaLow(398:602,1),'k', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% %     plot(uu(602:end),LambdaLow(602:end,1),'k', 'Color','b', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% %         ylim([-1 15])
%         xlim([-5 5])
%         hXLabel = xlabel('$v$');
%         hYLabel = ylabel('$d\lambda^*_{(1)}(v)$');
%         set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%         set(gca,'FontSize',10);
%         set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%         set(gca,'Layer','Top');
%         set(gcf, 'PaperUnits', 'centimeters');
%         x_width=4.45; y_width=4.45;  
%         set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%         print('-painters','-dpdf','CActive_DLambdaLow')
% 
% %% Zoom
% figure
%     hold on
%     plot(uu,LambdaUpp,'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
%         ylim([-3 45])        
%         xlim([-5 5])
%         hXLabel = xlabel('$v$');
%         hYLabel = ylabel('$\lambda^*_{(2)}(v)$');
%         set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%         set(gca,'FontSize',10);
%         set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%         set(gca,'Layer','Top');
%         set(gcf, 'PaperUnits', 'centimeters');
%         x_width=4.45; y_width=4.45;  
%         set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%         print('-painters','-dpdf','CActive_LambdaUpp')
% %% Zoom
% figure
%     hold on
%     plot(uu,Dphi_pkk,'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
%         ylim([-3 45])        
%         xlim([-5 5])
%         hXLabel = xlabel('$v$');
%         hYLabel = ylabel('$\nabla_u \phi$');
%         set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%         set(gca,'FontSize',10);
%         set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%         set(gca,'Layer','Top');
%         set(gcf, 'PaperUnits', 'centimeters');
%         x_width=4.45; y_width=4.45;  
%         set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%         print('-painters','-dpdf','CActive_DPhi')
% %% Zoom
% figure
%     hold on
%     plot(uu,DDphi_pkk,'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
%         ylim([-3 45])        
%         xlim([-5 5])
%         hXLabel = xlabel('$v$');
%         hYLabel = ylabel('$\nabla_u \phi$');
%         set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%         set(gca,'FontSize',10);
%         set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%         set(gca,'Layer','Top');
%         set(gcf, 'PaperUnits', 'centimeters');
%         x_width=4.45; y_width=4.45;  
%         set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%         print('-painters','-dpdf','CActive_DDPhi')
% %% Zoom
% figure
% hold on
%     plot(uu, -Dphi_pkk - LambdaUpp*1,'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')

%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')