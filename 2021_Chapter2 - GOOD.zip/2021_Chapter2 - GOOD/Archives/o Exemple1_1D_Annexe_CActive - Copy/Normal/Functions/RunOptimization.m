function [u, eflag, outpt, LMultipliers] = RunOptimization(u0, uk, lambda_phi,lambda_g,epsilon_g,a,B, opts)

Last_u   = [];
Last_f   = [];
Last_c   = []; % Attention c is not the input of the plant but the NL constraint !!
Last_ceq = [];

%%%%%%%%%%%%%%%  

lb = [];
ub =  [];

Aeq = [];  
beq = [];

A = [];
b = [];

%%%%%%%%%%%%%%%  
% [x,fval,exitflag,output,lambda,grad,hessian]

[u, ~ ,eflag, outpt, LMultipliers] = fmincon(@(u)objfun(u, uk,lambda_phi,lambda_g,epsilon_g,a,B),...
                                u0, A, b, Aeq, beq, lb, ub, ...
                                @(u)constr(u,uk, lambda_phi,lambda_g,epsilon_g,a,B),opts);

    function y = objfun(u, uk,lambda_phi,lambda_g,epsilon_g,a,B)
        if ~isequal(u,Last_u) % Check if computation is necessary
            [phi, ~, ~,~,g] = model(u,a,B);
            Last_u   = u;
            Last_f   = phi + lambda_phi*(u-uk);
            Last_c   = g +epsilon_g + lambda_g*(u-uk);
            Last_ceq = [];
        end
        y = Last_f;
    end

    function [c,ceq] = constr(u, uk,lambda_phi,lambda_g,epsilon_g,a,B)
        if ~isequal(u,Last_u) % Check if computation is necessary
            [phi, ~, ~,~,g] = model(u,a,B);
            Last_u   = u;
            Last_f   = phi + lambda_phi*(u-uk);
            Last_c   = g +epsilon_g + lambda_g*(u-uk);
            Last_ceq = [];
        end
        c   = Last_c;
        ceq = Last_ceq;
    end

end