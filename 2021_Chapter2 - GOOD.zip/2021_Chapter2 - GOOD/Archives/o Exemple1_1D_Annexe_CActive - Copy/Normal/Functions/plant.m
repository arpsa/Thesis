function [phi_p, Dphi_p,DDphi_p,DDDphi_p, gp,Dgp,DDgp] = plant(u)
test3 = 0;
test4 = 0;

    phi_p    =  (u-1)^2 + test3* (u-1)^4      + test4* (u-1)^5 ;%
    Dphi_p   =  (u-1)*2 + test3* 4* (u-1)^3   + test4* 5*(u-1)^4 ;%
    DDphi_p  =  2       + test3* 4*3* (u-1)^2 + test4* 5*4*(u-1)^3;%
    DDDphi_p =  0       + test3* 4*3*2*(u-1)  + test4* 5*4*3*(u-1)^2;%;%


test0 = 6;
test1 = 2;   
test2 = 0;
    gp   = -1000 + test0*u + test1* u^2 + test2* u^3;
    Dgp  = test0*1 + test1* u*2  + test2* 3*u^2;
    DDgp =           test1*2 +  test2* 3*2*u;
    
end