function [phi, Dphi, DDphi,DDDphi,g,Dg,DDg] = model(u,a,b)

test3 = 0.00;

    phi    = a*(u+1) + b*(u+1)^2 +(u+1)^4      *test3;%
    Dphi   = a + 2*b*(u+1)       +4*(u+1)^3    *test3;%
    DDphi  = 2*b                 +4*3*(u+1)^2  *test3;%
    DDDphi = 0                   +4*3*2*(u+1)  *test3;%
    

test = 2;
    g   = u + test* u^2;
    Dg  = 1 + test* 2*u;
    DDg =     test* 2;
    
%     g   = 1 + u + u^3;
%     Dg  = a + 2*b*u;
%     Dg = 2*b;
end