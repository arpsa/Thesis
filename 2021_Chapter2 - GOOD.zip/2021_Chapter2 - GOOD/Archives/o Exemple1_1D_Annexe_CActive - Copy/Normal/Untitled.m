clc

v = [-1;-1;-5];
I = [1 0 0;
     0 1 0;
     0 0 0];
II = [-3 1 0;
      1 -10 4;
      0 4 -2];
  
v'*(II*I*v)
  
%  [A, B] =  eig(II);
%   
%   A*B*A' - II;
%   
%   I - A*B*A'
%   
%   A*(I-B)*A'
  
%   
%   D = [-10   0   0 ;
%        0   -10   0 ;
%        0     0   -1];
%    
%   V = [1/sqrt(2)  1/sqrt(2) 0;
%        1/sqrt(2) -1/sqrt(2) 0;
%        0          0         1];
% II = V*D*V';
  
% v'*I*II*v
 
% AA = [0 0 0;
%       0 0 0;
%       7 8 9];
% 
%   
%  I*A*inv(A) 
%   
% v'*A*I*inv(A)*v/norm(v)^2
% v'*A*I*inv(A)*v/norm(v)^2
% 
% A*I*inv(A)
% A*inv(A)
% disp(['A*I = '])
% AI = A*I
% IA = (I*A)'
% disp(['v''*B*I*I*A*v = ',   num2str(v'*B*I*I*A*v) ])
% disp(['v''*B*I*I*A*v = ',   num2str((v'*B*I)*(I*A*v)) ])

% 
% disp(['v''*B*I*A*v = ',   num2str(v'*B*I*A*v) ])
% disp(['v''*B*I*I*A*v = ',   num2str(v'*B*I*I*A*v) ])
% disp(['v''*B*I*I*A*v = ',   num2str((v'*B*I)*(I*A*v)) ])


