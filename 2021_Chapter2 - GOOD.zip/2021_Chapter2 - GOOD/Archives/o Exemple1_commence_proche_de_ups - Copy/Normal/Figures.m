clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic
%%
MA_Kok   = 2; Managament_off = 1; 
MA_Kopt  = 3; Managament_on  = 2; 
MA_Koptp = 4;

load('Results_DataGenerator1')

% u_Kok_on   = Results.U_SAVE{MA_Kok,  Managament_on};
% K_Kok_on   = Results.K_SAVE{MA_Kok,  Managament_on};
% Kopt_Kok_on = Results.Kopt_SAVE{MA_Kok,  Managament_on};
% 
% u_Kopt_on  = Results.U_SAVE{MA_Kopt, Managament_on};
% K_Kopt_on  = Results.K_SAVE{MA_Kopt, Managament_on};
% 
% u_Koptp_on  = Results.U_SAVE{MA_Koptp, Managament_on};
% K_Koptp_on  = Results.K_SAVE{MA_Koptp, Managament_on};
% 
% NBiter     = Results.U_SAVE{MA_Kopt, Managament_off};
% %%
% load('Results_DataGenerator2')
% u_K1  = Results.U_SAVE{1};
% u_K15 = Results.U_SAVE{2};
% u_K2  = Results.U_SAVE{3};
% u_K25 = Results.U_SAVE{4};
% u_K3  = Results.U_SAVE{5};
% u_K35 = Results.U_SAVE{6};
% u_K4  = Results.U_SAVE{7};
% u_K45 = Results.U_SAVE{8};
% u_K5  = Results.U_SAVE{9};
% NBiter2 = Results.NBiter{1};
% 
% lim2 = 20; % for method 2
% lim1 = 50; % for method 1
% lim0 = 20; % for method 

%% ***** Figures *****

figure
hold on
lim2 = 20; 
for i = 1:101
    plot(0:lim2-1, Results.U_SAVE{MA_Kok,  Managament_on,i}(1:lim2),  'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
end
for i = 1:101
    plot(0:lim2-1, Results.U_SAVE{MA_Kopt,  Managament_on,i}(1:lim2),  'Color','m', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
end
for i = 1:101
    plot(0:lim2-1, Results.U_SAVE{MA_Koptp,  Managament_on,i}(1:lim2),  'Color','b', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
end
    
%%
figure
hold on
lim2 = 50; 
% for i = 1:101
%     plot(0:lim2-1, log(abs(Results.U_SAVE{MA_Kok,  Managament_on,i}(1:lim2) -1))/log(10),  'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
% end
for i = 68
    plot(0:lim2-1, log(abs(Results.U_SAVE{MA_Kopt,  Managament_on,i}(1:lim2)-1))/log(10),  'Color','m', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
end
% for i = 1:101
%     plot(0:lim2-1, log(abs(Results.U_SAVE{MA_Koptp,  Managament_on,i}(1:lim2)-1))/log(10),  'Color','b', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7]);
% end


% 
% 
% lim2 = 100;
% figure
% hold on
% 
% plot(0:lim2-1,u_Kok_off(1:lim2), 'b', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
% plot(0:lim2-1,u_Kopt_off(1:lim2), 'b', 'Color',[1 0.8 1], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
% plot(0:lim2-1,u_Kok_on(1:lim2) , 'b', 'Color','k', 'LineStyle','-', 'LineWidth', 0.5,'MarkerSize',5, 'MarkerFaceColor','k')
% plot(0:lim2-1,u_Kopt_on(1:lim2) , 'b', 'Color','m', 'LineStyle','-', 'LineWidth', 0.5,'MarkerSize',5, 'MarkerFaceColor','k')
% 
%  hXLabel = xlabel('Iterations');
%     hYLabel = ylabel('$u_k$');
%     set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%     set(gca,'FontSize',10);
%     set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%     set(gca,'Layer','Top');
%     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=4.45; y_width=4;  
%     set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%     print('-painters','-dpdf','ConvManagement_U')
% 
%   
% lim2 = 100;  
% %% Methode 2 - |U-Up|
% figure
% hold on
% plot(0:lim2-1,log(abs(u_Kopt_off(1:lim2)-1))/log(10), 'b', 'Color',[1 0.8 1], 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
% plot(0:lim2-1,log(abs(u_Kopt_on(1:lim2)-1))/log(10) , 'b', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% 
% plot(0:lim2-1,log(abs(u_Kok_off(1:lim2)-1))/log(10), 'b', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
% plot(0:lim2-1,log(abs(u_Kok_on(1:lim2)-1))/log(10) , 'b', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% 
%  hXLabel = xlabel('Iterations');
%     hYLabel = ylabel('$\log_{10}(|u_k-u_p^{\star}|)$');
%     set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%     set(gca,'FontSize',10);
%     set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%     set(gca,'Layer','Top');
%     set(gcf, 'PaperUnits', 'centimeters');
%     set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%     print('-painters','-dpdf','ConvManagement_UUp')
% 
% 
% %% Methode 2 - Kk
% figure
% hold on
% plot(0:lim2-1,K_Kopt_off(1:lim2),'b', 'Color',[1 0.8 1]    , 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
% plot(0:lim2-1,K_Kok_off(1:lim2), 'b', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
% 
% plot(0:lim2-1,K_Kopt_on(1:lim2), 'b', 'Color',      'm'    , 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% plot(0:lim2-1,K_Kok_on(1:lim2),  'b', 'Color',          'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% 
%     hXLabel = xlabel('Iterations');
%     hYLabel = ylabel('$K_k$');
%     set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%     set(gca,'FontSize',10);
%     set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%     set(gca,'Layer','Top');
%     set(gcf, 'PaperUnits', 'centimeters'); 
%     set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%     print('-painters','-dpdf','ConvManagement_K')
% 
%    
% %% Mehtod 1 - U
% figure
% hold on
% plot(0:lim0-1,u_Kopt_on(1:lim0), 'b', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','m')
% plot(0:lim0-1,u_Kok_on(1:lim0), 'b', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% 
%    hXLabel = xlabel('Iterations');
%     hYLabel = ylabel('$u_k$');
%     set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%     set(gca,'FontSize',10);
%     set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%     set(gca,'Layer','Top');
%     set(gcf, 'PaperUnits', 'centimeters');
%     set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%     print('-painters','-dpdf','Method1vs2_U')
% 
% 
% %% Methode 1 vs Mehtode 2- |U-Up|
% lim2 = 100;
% figure
% plot(0:lim2-1,log(abs(u_Kopt_on(1:lim2)-1))/log(10), 'm', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','m')
% hold on
% plot(0:lim2-1,log(abs(u_Kok_on(1:lim2)-1))/log(10), 'b', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% plot([1 1]*20,[-15 0.6], 'Color','k', 'LineStyle',':', 'LineWidth', 0.5)
% 
% txt = '$k=5$';
% text(2,-14,txt,'FontSize',9,'Color','m','Interpreter','LaTex')
% txt = '$k=50$';
% text(50,-10,txt,'FontSize',9,'Color','k','Interpreter','LaTex')
% 
% ylim([-15 0.6])
% xticks([0 20 50 100])
% 
%     hXLabel = xlabel('Iterations');
%     hYLabel = ylabel('$\log_{10}(|u_k-u_p^{\star}|)$');
%     set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%     set(gca,'FontSize',10);
%     set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%     set(gca,'Layer','Top');
%     set(gcf, 'PaperUnits', 'centimeters');
%     set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%     print('-painters','-dpdf','Method1vs2_UmUp')
% 
%     
% %% Methode 1 - Kk
% lim1 = 21;
% figure
% hold on
% plot(0:lim1-1,K_Kok_on(1:lim1)    , 'k', 'Color',          'k', 'LineStyle','-', 'LineWidth' , 2,'MarkerSize',5, 'MarkerFaceColor','k')
% plot(0:lim1-1,Kopt_Kok_on(1:lim1),  'g', 'Color',[0.5 0.5 0.8]*0.9, 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% plot(0:lim1-1,K_Kopt_on(1:lim1)    , 'k', 'Color',          'm', 'LineStyle','-', 'LineWidth' , 2,'MarkerSize',5, 'MarkerFaceColor','m')
% plot([0 lim1-1],[1 1]*0.5 , 'k', 'Color', 'k', 'LineStyle',':', 'LineWidth' , 0.5)
% plot([0 lim1-1],[1 1]*0.25 , 'k', 'Color', 'k', 'LineStyle',':', 'LineWidth' , 0.5)
% 
% txt = '$K^{\prime}_k$';
% text(10,0.6,txt,'FontSize',10,'Color',[0.5 0.5 0.8]*0.9,'Interpreter','LaTex')
% 
% 
% ylim([0 1])
% 
% yticks([0 0.25 0.5 1])
%     hXLabel = xlabel('Iterations');
%     hYLabel = ylabel('$K_k$');
%     set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%     set(gca,'FontSize',10);
%     set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%     set(gca,'Layer','Top');
%     set(gcf, 'PaperUnits', 'centimeters');
%     set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%     print('-painters','-dpdf','Method1vs2_Kk')
%     
% %% No methode
%  figure
%     hold on 
%     plot(0:30, u_K5(1:31) ,  'b', 'Color',[0.8 0.8 0.8], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
%     plot(0:30, u_K4(1:31) ,  'b', 'Color','r', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
%     plot(0:30, u_K3(1:31) ,  'b', 'Color',[0.3 0.8 0.3], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
%     plot(0:30, u_K25(1:31) , 'b', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
%     
%     xlim([0,15])
%     hXLabel = xlabel('Iterations');
%     hYLabel = ylabel('$u_k$');
%     set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%     set(gca,'FontSize',10);
%     set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%     set(gca,'Layer','Top');
%     set(gcf, 'PaperUnits', 'centimeters');
%     set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%     print('-painters','-dpdf','NoMethod_U')
% 
% %% 2 - |U-Up|    [1 0.8 1]
%  figure
%     hold on 
%     plot(0:30,log(max(abs(u_K5(1:31)-1),1e-13))/log(10), 'b', 'Color',[0.9 0.9 0.9], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.9 0.9 0.9])
%      plot(0:30,log(max(abs(u_K25(1:31)-1),1e-13))/log(10), 'b', 'Color',[0.8 0.8 0.8], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
%     plot(0:30,log(max(abs(u_K3(1:31)-1),1e-13))/log(10),  'b', 'Color',[0.9 1 0.9] , 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
%     plot(0:30,log(max(abs(u_K4(1:31)-1),1e-13))/log(10),  'b', 'Color',[1 0.8 0.8], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
% 
%     plot(0:10,log(max(abs(u_K25(1:11)-1),1e-13))/log(10), 'b', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
%         txt = ' $K=0.25$';
%         text(11,log(abs(u_K25(11)-1))/log(10),txt,'FontSize',10,'Interpreter','LaTex')
%     plot(0:10,log(max(abs(u_K3(1:11)-1),1e-13))/log(10), 'b', 'Color',[0.3 0.8 0.3], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
%         txt = ' $K=\{0.2,0.3\}$';
%         text(11,log(abs(u_K3(11)-1))/log(10),txt,'FontSize',10,'Interpreter','LaTex')
%     plot(0:10,log(max(abs(u_K4(1:11)-1),1e-13))/log(10), 'b', 'Color','r', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
%         txt = ' $K=\{0.1,0.4\}$';
%         text(11,log(abs(u_K4(11)-1))/log(10),txt,'FontSize',10,'Interpreter','LaTex')
%     plot(0:10,log(max(abs(u_K5(1:11)-1),1e-13))/log(10), 'b', 'Color',[0.8 0.8 0.8], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
%         txt = ' $K\geq0.5$';
%         text(11,log(abs(u_K5(11)-1))/log(10),txt,'FontSize',10,'Interpreter','LaTex')
%         
%     xlim([0,30])
%     hXLabel = xlabel('Iterations');
%     hYLabel = ylabel('$\log_{10}(|u_k-u_p^{\star}|)$');
%     set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
%     set(gca,'FontSize',10);
%     set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%     set(gca,'Layer','Top');
%     set(gcf, 'PaperUnits', 'centimeters');
%     set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%     print('-painters','-dpdf','NoMethod_AllK')
%     
% % close all