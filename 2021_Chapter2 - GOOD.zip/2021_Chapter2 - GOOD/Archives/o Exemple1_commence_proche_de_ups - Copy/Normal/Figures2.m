clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

%%  Figure neutre
figure
% x = x';
% plot(uu,uopt(:,1))
% plot(uu,uopt(:,2))   
% plot(x,x,'k--')
% plot(x,-x,'k--')


x = -1:0.1:1;
FK_0_9 = (1-2/0.9)*x;
FK_0_8 = (1-2/0.8)*x;
FK_0_7 = (1-2/0.7)*x;
FK_0_6 = (1-2/0.6)*x;
FK_0_5 = (1-2/0.5)*x;
FK_0_4 = (1-2/0.4)*x;
FK_0_3 = (1-2/0.3)*x;
FK_0_2 = (1-2/0.2)*x;
FK_0_1 = (1-2/0.1)*x;
FK_0_0 = (1-2/0.00001)*x;

% x2 = [x, fliplr(x)];
% inBetween = [x, fliplr(-x)];
% fill(x2, inBetween, 'g'); 180


hold on
patch([x fliplr(x)], [ones(size(x)) fliplr(-ones(size(x)))], [255 181  181]/255,'LineStyle','none')
patch([x fliplr(x)], [x fliplr(-x)],          [197     224      180]/255,'LineStyle','none')
patch([x fliplr(x)], [-x fliplr(FK_0_9)],     [220+  5 224+  3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_9 fliplr(FK_0_8)], [220+2*5 230+2*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_8 fliplr(FK_0_7)], [220+3*5 230+3*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_7 fliplr(FK_0_6)], [220+4*5 230+4*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_6 fliplr(FK_0_5)], [220+5*5 230+5*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_5 fliplr(FK_0_4)], [220+6*5 230+6*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_4 fliplr(FK_0_3)], [220+7*5 230+7*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_3 fliplr(FK_0_2)], [220+7*5 230+7*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_2 fliplr(FK_0_1)], [220+7*5 230+7*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_1 fliplr(FK_0_0)], [220+7*5 230+7*3  180]/255,'LineStyle','none')


% patch([x fliplr(x)], [-x fliplr(FK_0_9)],     [180-  5 200-  3  180]/255,'LineStyle','none')
% patch([x fliplr(x)], [FK_0_9 fliplr(FK_0_8)], [180-2*5 200-2*3  180+1*3]/255,'LineStyle','none')
% patch([x fliplr(x)], [FK_0_8 fliplr(FK_0_7)], [180-3*5 200-3*3  180+2*3]/255,'LineStyle','none')
% patch([x fliplr(x)], [FK_0_7 fliplr(FK_0_6)], [180-4*5 200-4*3  180+3*3]/255,'LineStyle','none')
% patch([x fliplr(x)], [FK_0_6 fliplr(FK_0_5)], [180-5*5 200-5*3  180+4*3]/255,'LineStyle','none')
% patch([x fliplr(x)], [FK_0_5 fliplr(FK_0_4)], [180-6*5 200-6*3  180+5*3]/255,'LineStyle','none')
% patch([x fliplr(x)], [FK_0_4 fliplr(FK_0_3)], [180-7*5 200-7*3  180+6*3]/255,'LineStyle','none')
% patch([x fliplr(x)], [FK_0_3 fliplr(FK_0_2)], [180-8*5 200-7*3  180+7*3]/255,'LineStyle','none')
% patch([x fliplr(x)], [FK_0_2 fliplr(FK_0_1)], [180-9*5 200-7*3  180+8*3]/255,'LineStyle','none')
% patch([x fliplr(x)], [FK_0_1 fliplr(FK_0_0)], [180-10*5 200-7*3 180+9*3]/255,'LineStyle','none')



% plot(x,x, 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
% 
% plot(x,-x, 'Color','k', 'LineStyle','--', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
% plot(x,FK_0_8, 'Color','k', 'LineStyle',':', 'LineWidth', 0.5,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
% plot(x,FK_0_6, 'Color','k', 'LineStyle',':', 'LineWidth', 0.5,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
% plot(x,FK_0_3, 'Color','k', 'LineStyle',':', 'LineWidth', 0.5,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
% plot(x,FK_0_0, 'Color','k', 'LineStyle',':', 'LineWidth', 0.5,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])

ylim([-1 1])
xlim([-1 1])
%     hXLabel = xlabel('$u_k$');
%     hYLabel = ylabel('$sol(u_k)$');
%     set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
    set(gca,'FontSize',10);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    
% set(gcf,'CurrentAxes',h)
% drawArrow = @(x,y,varargin) quiver( x(1),y(1),x(2)-x(1),y(2)-y(1),0, varargin{:} )       
% drawArrow([-1 0],[1 1],'linewidth',1,'color','k')   
% ylim([-1 1])
% xlim([-1 1])   
%     
    set(gcf, 'PaperUnits', 'centimeters');
    x_width=4.75; y_width=4.45;  
    set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
    print('-painters','-dpdf','ConeGeneral')

    
    
%% ***** Figures *****

stop


%% Methode 2 - U
%% Methode 2 - |U
lim2 = 100;
figure
hold on

plot(0:lim2-1,u_Kok_off(1:lim2), 'b', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
plot(0:lim2-1,u_Kopt_off(1:lim2), 'b', 'Color',[1 0.8 1], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
plot(0:lim2-1,u_Kok_on(1:lim2) , 'b', 'Color','k', 'LineStyle','-', 'LineWidth', 0.5,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:lim2-1,u_Kopt_on(1:lim2) , 'b', 'Color','m', 'LineStyle','-', 'LineWidth', 0.5,'MarkerSize',5, 'MarkerFaceColor','k')

 hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u_k$');
    set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
    set(gca,'FontSize',10);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gcf, 'PaperUnits', 'centimeters');
    x_width=4.45; y_width=4;  
    set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
    print('-painters','-dpdf','ConvManagement_U')

  
lim2 = 100;  
%% Methode 2 - |U-Up|
figure
hold on
plot(0:lim2-1,log(abs(u_Kopt_off(1:lim2)-1))/log(10), 'b', 'Color',[1 0.8 1], 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
plot(0:lim2-1,log(abs(u_Kopt_on(1:lim2)-1))/log(10) , 'b', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')

plot(0:lim2-1,log(abs(u_Kok_off(1:lim2)-1))/log(10), 'b', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
plot(0:lim2-1,log(abs(u_Kok_on(1:lim2)-1))/log(10) , 'b', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')

 hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$\log_{10}(|u_k-u_p^{\star}|)$');
    set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
    set(gca,'FontSize',10);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
    print('-painters','-dpdf','ConvManagement_UUp')


%% Methode 2 - Kk
figure
hold on
plot(0:lim2-1,K_Kopt_off(1:lim2),'b', 'Color',[1 0.8 1]    , 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])
plot(0:lim2-1,K_Kok_off(1:lim2), 'b', 'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor',[0.7 0.7 0.7])

plot(0:lim2-1,K_Kopt_on(1:lim2), 'b', 'Color',      'm'    , 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:lim2-1,K_Kok_on(1:lim2),  'b', 'Color',          'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')

    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$K_k$');
    set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
    set(gca,'FontSize',10);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gcf, 'PaperUnits', 'centimeters'); 
    set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
    print('-painters','-dpdf','ConvManagement_K')

   
%% Mehtod 1 - U
figure
hold on
plot(0:lim0-1,u_Kopt_on(1:lim0), 'b', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','m')
plot(0:lim0-1,u_Kok_on(1:lim0), 'b', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')

   hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u_k$');
    set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
    set(gca,'FontSize',10);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
    print('-painters','-dpdf','Method1vs2_U')


%% Methode 1 vs Mehtode 2- |U-Up|
lim2 = 100;
figure
plot(0:lim2-1,log(abs(u_Kopt_on(1:lim2)-1))/log(10), 'm', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','m')
hold on
plot(0:lim2-1,log(abs(u_Kok_on(1:lim2)-1))/log(10), 'b', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot([1 1]*20,[-15 0.6], 'Color','k', 'LineStyle',':', 'LineWidth', 0.5)

txt = '$k=4$';
text(2,-14,txt,'FontSize',9,'Color','m','Interpreter','LaTex')
txt = '$k=60$';
text(60,-10,txt,'FontSize',9,'Color','k','Interpreter','LaTex')

ylim([-15 0.6])
xticks([0 20 50 100])

    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$\log_{10}(|u_k-u_p^{\star}|)$');
    set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
    set(gca,'FontSize',10);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
    print('-painters','-dpdf','Method1vs2_UmUp')

    
%% Methode 1 - Kk
lim1 = 21;
figure
hold on
plot(0:lim1-1,K_Kok_on(1:lim1)    , 'k', 'Color',          'k', 'LineStyle','-', 'LineWidth' , 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:lim1-1,Kopt_Kok_on(1:lim1),  'g', 'Color',[0.5 0.5 0.8]*0.9, 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:lim1-1,K_Kopt_on(1:lim1)    , 'k', 'Color',          'm', 'LineStyle','-', 'LineWidth' , 2,'MarkerSize',5, 'MarkerFaceColor','m')
plot([0 lim1-1],[1 1]*0.5 , 'k', 'Color', 'k', 'LineStyle',':', 'LineWidth' , 0.5)
plot([0 lim1-1],[1 1]*0.25 , 'k', 'Color', 'k', 'LineStyle',':', 'LineWidth' , 0.5)

txt = '$K^{\prime}_k$';
text(10,0.6,txt,'FontSize',10,'Color',[0.5 0.5 0.8]*0.9,'Interpreter','LaTex')


ylim([0 1])

yticks([0 0.25 0.5 1])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$K_k$');
    set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
    set(gca,'FontSize',10);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
    print('-painters','-dpdf','Method1vs2_Kk')
    
%% No methode
 figure
    hold on 
    plot(0:30, u_K5(1:31) ,  'b', 'Color',[0.8 0.8 0.8], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
    plot(0:30, u_K4(1:31) ,  'b', 'Color','r', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
    plot(0:30, u_K3(1:31) ,  'b', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
    plot(0:30, u_K25(1:31) , 'b', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
    
    xlim([0,15])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u_k$');
    set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
    set(gca,'FontSize',10);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
    print('-painters','-dpdf','NoMethod_U')

%% 2 - |U-Up|
 figure
    hold on 
    plot(0:30,log(max(abs(u_K5(1:31)-1),1e-13))/log(10), 'b', 'Color',[0.9 0.9 0.9], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.9 0.9 0.9])
     plot(0:30,log(max(abs(u_K25(1:31)-1),1e-13))/log(10), 'b', 'Color',[0.8 0.8 0.8], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
    plot(0:30,log(max(abs(u_K3(1:31)-1),1e-13))/log(10),  'b', 'Color',[1 0.8 1], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
    plot(0:30,log(max(abs(u_K4(1:31)-1),1e-13))/log(10),  'b', 'Color',[1 0.8 0.8], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])

    plot(0:10,log(max(abs(u_K25(1:11)-1),1e-13))/log(10), 'b', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
        txt = ' $K=0.25$';
        text(11,log(abs(u_K25(11)-1))/log(10),txt,'FontSize',10,'Interpreter','LaTex')
    plot(0:10,log(max(abs(u_K3(1:11)-1),1e-13))/log(10), 'b', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
        txt = ' $K=\{0.2,0.3\}$';
        text(11,log(abs(u_K3(11)-1))/log(10),txt,'FontSize',10,'Interpreter','LaTex')
    plot(0:10,log(max(abs(u_K4(1:11)-1),1e-13))/log(10), 'b', 'Color','r', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
        txt = ' $K=\{0.1,0.4\}$';
        text(11,log(abs(u_K4(11)-1))/log(10),txt,'FontSize',10,'Interpreter','LaTex')
    plot(0:10,log(max(abs(u_K5(1:11)-1),1e-13))/log(10), 'b', 'Color',[0.8 0.8 0.8], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor',[0.8 0.8 0.8])
        txt = ' $K\geq0.5$';
        text(11,log(abs(u_K5(11)-1))/log(10),txt,'FontSize',10,'Interpreter','LaTex')
        
    xlim([0,30])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$\log_{10}(|u_k-u_p^{\star}|)$');
    set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
    set(gca,'FontSize',10);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
    print('-painters','-dpdf','NoMethod_AllK')
    
% close all