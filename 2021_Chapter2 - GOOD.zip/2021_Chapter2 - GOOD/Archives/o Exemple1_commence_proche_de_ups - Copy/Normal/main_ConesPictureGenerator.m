clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

% format shortEng

%% Code architecture initialization & Output files 
addpath('Functions')

Results_file_name = 'Results_Main';

%% Tuning paramters


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  0.- Initialization of the algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 0.1.- Parameter defined by the user
u_max  =  5;
u_min  = -5;
NB= 100;
uu = u_min:(u_max-u_min)/(NB-1):u_max;


% 0.2.- Simulations parameters
PBstruct = ProblemStructure();        % options for solver | nb iterations
    fmincon_options = PBstruct.fmincon_options;
    fsolve_options  = PBstruct.fsolve_options;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Save Results
Results  = struct();
struct_Y = struct();

% KKopt(1) = k;

Modifiers = struct();
delta = 0;
        EstimateDDp_MAX = 0;
aa = [1/4, 2];
for i = 1:length(uu)
    for j = 1:length(aa)
        a(j) = aa(j);
        uk = uu(i);
        disp(num2str(uk))
        %% 1.- Do experiment
        [phi_k, Dphi_k]   = model(uk,a(j));
        [phi_pk, Dphi_pk] = plant(uk);
        %% 2.- Compute modifiers
        lambda = Dphi_pk - Dphi_k;
        %% 3.- Compute next point
        uopt(i,j) = RunOptimization(uk, uk, lambda,delta,a(j), fmincon_options);
    end
end
%%
figure

x = -6:0.1:6;
FK_0_9 = (1-2/0.9)*(x-1)+1;
FK_0_8 = (1-2/0.8)*(x-1)+1;
FK_0_7 = (1-2/0.7)*(x-1)+1;
FK_0_6 = (1-2/0.6)*(x-1)+1;
FK_0_5 = (1-2/0.5)*(x-1)+1;
FK_0_4 = (1-2/0.4)*(x-1)+1;
FK_0_3 = (1-2/0.3)*(x-1)+1;
FK_0_2 = (1-2/0.2)*(x-1)+1;
FK_0_1 = (1-2/0.1)*(x-1)+1;
FK_0_0 = (1-2/0.00001)*(x-1)+1;

hold on
ups = 1;
patch([x fliplr(x)], [6*ones(size(x)) fliplr(-6*ones(size(x)))], [255 181  181]/255,'LineStyle','none')
patch([x fliplr(x)], [x fliplr(-x+2*ups)],          [197     224      180]/255,'LineStyle','none')
patch([x fliplr(x)], [-(x-ups)+ups fliplr(FK_0_9)],     [220+  5 224+  3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_9 fliplr(FK_0_8)], [220+2*5 230+2*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_8 fliplr(FK_0_7)], [220+3*5 230+3*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_7 fliplr(FK_0_6)], [220+4*5 230+4*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_6 fliplr(FK_0_5)], [220+5*5 230+5*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_5 fliplr(FK_0_4)], [220+6*5 230+6*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_4 fliplr(FK_0_3)], [220+7*5 230+7*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_3 fliplr(FK_0_2)], [220+7*5 230+7*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_2 fliplr(FK_0_1)], [220+7*5 230+7*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_1 fliplr(FK_0_0)], [220+7*5 230+7*3  180]/255,'LineStyle','none')

plot(uu,uopt(:,1),'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% plot(x,x,'k--')
KKK = 0.5;
% plot(uu+1,(1-2/KKK)*uu + 1,'b', 'Color',[0.5 0.5 0.5], 'LineStyle','--', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')

ylim([-6 6])
xlim([-5 5])

hXLabel = xlabel('$u_k$');
hYLabel = ylabel('$sol(u_k)$');
    set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
    
    set(gca,'FontSize',10);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gcf, 'PaperUnits', 'centimeters');
    x_width=4.45; y_width=4.45;  
    set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
    print('-painters','-dpdf','LocalCone')

%% Zoom
figure
    
hold on
   patch([x fliplr(x)], [6*ones(size(x)) fliplr(-6*ones(size(x)))], [255 181  181]/255,'LineStyle','none')
patch([x fliplr(x)], [x fliplr(-x+2*ups)],          [197     224      180]/255,'LineStyle','none')
patch([x fliplr(x)], [-(x-ups)+ups fliplr(FK_0_9)],     [220+  5 224+  3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_9 fliplr(FK_0_8)], [220+2*5 230+2*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_8 fliplr(FK_0_7)], [220+3*5 230+3*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_7 fliplr(FK_0_6)], [220+4*5 230+4*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_6 fliplr(FK_0_5)], [220+5*5 230+5*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_5 fliplr(FK_0_4)], [220+6*5 230+6*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_4 fliplr(FK_0_3)], [220+7*5 230+7*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_3 fliplr(FK_0_2)], [220+7*5 230+7*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_2 fliplr(FK_0_1)], [220+7*5 230+7*3  180]/255,'LineStyle','none')
patch([x fliplr(x)], [FK_0_1 fliplr(FK_0_0)], [220+7*5 230+7*3  180]/255,'LineStyle','none')

plot(uu,uopt(:,1),'k', 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% plot(x,x,'k--')
KKK = 0.5;
% plot(uu+1,(1-2/KKK)*uu + 1,'b', 'Color',[0.5 0.5 0.5], 'LineStyle','--', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')

ylim([0 2])
xlim([0 2])

hXLabel = xlabel('$u_k$');
hYLabel = ylabel('$sol(u_k)$');
    set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
    
    set(gca,'FontSize',10);
    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    set(gca,'Layer','Top');
    set(gcf, 'PaperUnits', 'centimeters');
    x_width=4.45; y_width=4.45;  
    set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
    print('-painters','-dpdf','LocalCone_Zoom') 
    
    
    %     set(gcf, 'PaperUnits', 'centimeters');
%     x_width=4.75; y_width=4.45;  
%     set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%     print('-painters','-dpdf','ConeGeneral')
    
% 
%     %% 1.- Do experiment
%     [phi_k, Dphi_k]   = model(uk);
%     [phi_pk, Dphi_pk] = plant(uk);
%     %% 2.- Compute modifiers
%     lambda = Dphi_pk - Dphi_k;
%     %% 3.- Compute next point
%     delta(k) = 0;
%     ukp1_opt(k+1) = RunOptimization(uk, uk, lambda, delta(k), fmincon_options);
%     %% Post processing
%     if k > 1 && usedelta == 1
%         [~,~,c] = model(u(k));
%         if (u(k)-u(k-1)) < 0.001
%             Delta(k) = Delta(k-1); %% eciter les valeurs naze
%         else
%             Delta(k) = (ukp1_opt(k+1)-ukp1_opt(k))/(u(k)-u(k-1));    % 
%         end
%         EstimateDDp(k) = -(Delta(k)-1)*(c+delta(k));
%         if EstimateDDp(k) > EstimateDDp_MAX
%             EstimateDDp_MAX = EstimateDDp(k);
%         else
%             EstimateDDp(k) = EstimateDDp_MAX;
%         end
%         
%         
%         delta_temp = EstimateDDp(k) -(c+delta(k)); % variable temporaire
%         if delta_temp > 0
%             delta(k) = delta_temp+delta(k);
%             delta(k+1) = delta(k);
%             ukp1_opt(k+1) = RunOptimization(uk, uk, lambda, delta(k), fmincon_options);
%         else 
%             delta(k+1) = delta(k);
%         end
%     end
%     %% 4.- Apply filter
%     if use_methode == 0 || k == 1
%     %%%%%%% ******** Methode 0 ******** %%%%%%%
%         u(k+1) = uk + K*(ukp1_opt(k+1) - uk);
%         KKopt(k) = K;
%     elseif use_methode == 1
%     %%%%%%% ******** Methode 1.2 ******** %%%%%%%
%         flag = 0;
%         KK(k) = 1;
%         if (abs(u(k)-u(k-1)) < 0.0001) && (abs(ukp1_opt(k+1)-ukp1_opt(k)) < 0.0001) && (manageconvergence == 1)
%             KK(k)    = KK(k-1);
%             KKopt(k) = KKopt(k-1);
%         else
%             while flag == 0 
%                 test = abs(1 - KK(k)*(1-  (ukp1_opt(k+1)-ukp1_opt(k))/(u(k)-u(k-1)) ));
%                 if test <1 
%                     flag = 1;
%                     KKopt(k) = KK(k);
%                     KK(k)    = KK(k)-0.1;
%                 else
%                     KK(k) = KK(k)-0.0001;
%                 end
%             end
%         end
%         u(k+1) = uk + KK(k)*(ukp1_opt(k+1) - uk);
%     else
%     %%%%%%% ******** Methode 2.2 ******** %%%%%%%
%         test = 100000000;
%         if (abs(u(k)-u(k-1)) < 0.001) && (abs(ukp1_opt(k+1)-ukp1_opt(k)) < 0.001) && (manageconvergence == 1)
%             disp('Filter has converged')
%             KK(k)    = KK(k-1);
%             KKopt(k) = KK(k);
%         else
%             KK(k)= RunOptimizationK( ukp1_opt(k+1), ...
%                               ukp1_opt(k),   ...
%                               u(k),u(k-1), fmincon_options);
%             KKopt(k) = KK(k);
%         end
%         u(k+1) = uk + KK(k)*(ukp1_opt(k+1) - uk);
%     end
%     
%     k
% end
% 
% %% Plot results
% figure
% plot([0:NBiter],u)
% title('U')
% %%
% figure
% semilogy([0:NBiter],abs(u-1))
% %%
% figure
% plot([0:NBiter-1],KK)
% title('K')
% % figure
% % plot([0:NBiter-1],KKopt)
% %%
% figure
% plot(delta)
% title('delta')
% % hold all
% % plot(newtest)
% 
% %%
% figure
% plot(EstimateDDp)
% title('2nd derive estimee')
% % hold all
% % plot(newtest)
% 
% 
% 
% % 
% %%
% Results.u      = u;
% Results.KK     = KK;
% Results.KKopt  = KKopt;
% Results.NBiter = NBiter;
% 
% % save(Results_file_name, 'Results')
% 
%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')