function [u, eflag, outpt] = RunOptimization(u0, uk,  ukm1,uopt_k, k, lambda, opts)

Last_u   = [];
Last_f   = [];
Last_c   = []; % Attention c is not the input of the plant but the NL constraint !!
Last_ceq = [];

%%%%%%%%%%%%%%%  

lb = [-5, 0];
ub = [5,  1];

Aeq = [];  
beq = [];

A = [];
b = [];

delta0 = 0.5;
x0 = [u0, delta0];

%%%%%%%%%%%%%%%  

[u, eflag, outpt] = fmincon(@(x)objfun(x, uk, ukm1,uopt_k, k, lambda),...
                                x0, A, b, Aeq, beq, lb, ub, ...
                                @(x)constr(x,uk, ukm1,uopt_k, k,  lambda),opts);

    function y = objfun(x, uk, ukm1,uopt_k, k, lambda)
        if ~isequal(x,Last_u) % Check if computation is necessary
            if  k == 1 ||  (abs(uk-ukm1) < 0.0001) 
                phi_m = model(x(1)) + lambda*(x(1)-uk);
                Last_u   = x;
                Last_f   = phi_m;
                Last_c   = x(2);
                Last_ceq = [];
            else
                phi_m = model(x(1)) + lambda*(x(1)-uk) + x(2)*1000*(x(1)-uopt_k)^2;
                Last_u   = x;
                Last_f   = phi_m;
                Last_c   = (x(1)-uopt_k)/abs(uk-ukm1)-1;
%                 abs(uk-ukm1)
%                 1- (x(1)-uopt_k)/abs(uk-ukm1)-0.5
                Last_ceq = [];
            end
        end
        y = Last_f;
    end

    function [c,ceq] = constr(x, uk, ukm1,uopt_k, k, lambda)
        if ~isequal(x,Last_u) % Check if computation is necessary
            if  k == 1 ||  (abs(uk-ukm1) < 0.0001) 
                phi_m = model(x(1)) + lambda*(x(1)-uk);
                Last_u   = x;
                Last_f   = phi_m;
                Last_c   = x(2);
                Last_ceq = [];
            else
                phi_m = model(x(1)) + lambda*(x(1)-uk) + x(2)*1000*(x(1)-uopt_k)^2;
                Last_u   = x;
                Last_f   = phi_m;
                Last_c   = (x(1)-uopt_k)/abs(uk-ukm1)-1;
%                 1- (x(1)-uopt_k)/abs(uk-ukm1)-0.5
                Last_ceq = [];
            end
        end
        c   = Last_c;
        ceq = Last_ceq;
    end

end