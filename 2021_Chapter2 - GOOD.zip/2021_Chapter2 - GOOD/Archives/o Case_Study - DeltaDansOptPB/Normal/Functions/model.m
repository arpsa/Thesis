function [phi, Dphi] = model(u)
    phi  = 1/100*u^2;
    Dphi = 2/100*u;
end