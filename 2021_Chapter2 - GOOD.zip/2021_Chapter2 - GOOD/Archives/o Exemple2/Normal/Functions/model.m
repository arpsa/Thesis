function [phi, Dphi] = model(u,theta)
    phi  = theta* u.^2;
    Dphi = theta* u.*2;
end