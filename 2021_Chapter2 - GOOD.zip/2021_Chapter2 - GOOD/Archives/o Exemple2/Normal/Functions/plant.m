function [phi_p, Dphi_p] = plant(u)
%     a = 1;
%     b = 0;
%     c = 0;
%     phi_p  = c*(u-1)^2 +  b*(u-1)^3   +  a*(u-1)^4;
%     Dphi_p = c*2*(u-1) +  b*3*(u-1)^2 +  a*4*(u-1)^3;
    a = 1;
    phi_p  = (1 - u.^2 + u.^3 + 1/4*u.^4 - 3/5*u.^5 + 1/6*u.^6)/4;
    Dphi_p = ((u+1).*u.*(u-1).^2.*(u-2))/4;
    
%     a = 0.1;
%     phi_p  = (u-1)^2 + a*(u-1)^3;
%     Dphi_p = 2*(u-1) + a*3*(u-1)^2;
    
%     phi_p  = (u-1)^2;
%     Dphi_p = 2*(u-1);
end