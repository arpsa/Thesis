clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

% format shortEng

%% Code architecture initialization & Output files 
addpath('Functions')

Noise = 0 ;  % 0:No, 1:Yes
Results_file_name = 'Results_Main';

%% Tuning paramters


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  0.- Initialization of the algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 0.1.- Parameter defined by the user
u_max  =  5;
u_min  = -5;
NBiter = 50;
K = 1;
use_methode = 2; % [0]: fixer K, 
                 % [1]: Choix de K pour garantir Niveau 2, 
                 % [2]: Choix optimal de K.                

manageconvergence = 1; % [0]: Yes, [1]: No

% 0.2.- Simulations parameters
PBstruct = ProblemStructure();        % options for solver | nb iterations
    fmincon_options = PBstruct.fmincon_options;
    fsolve_options  = PBstruct.fsolve_options;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Save Results
Results  = struct();
struct_Y = struct();

u(1) = 0; % opt
u0   = 0;
ukp1_opt(1) = 0;
KK(1) = K;
% KKopt(1) = k;

Modifiers = struct();

for k = 1:NBiter
    %% 1.- Do experiment
    uk = u(k); 
    [phi_k, Dphi_k] = model(uk);
    [phi_pk, Dphi_pk] = plant(uk);
    %% 2.- Compute modifiers
    lambda = Dphi_pk - Dphi_k;
    %% 3.- Compute next point
    disp('opt nrmale')
    delta(k) = 0;
    ukp1_opt(k+1) = RunOptimization(u(k), uk, lambda,delta(k),0, fmincon_options);
    
    if k > 1
        iter = 0;
        delta(k) = 0;
        flag = 0;
        while flag == 0
            if abs(u(k)-u(k-1)) < 0.001 %% Gestion des petits pas 
                flag = 1;
                delta(k) = delta(k-1);
            else
%                 testt(k) = (ukp1_opt(k+1) - ukp1_opt(k))-  0.9*abs(u(k)-u(k-1)); % <0
                testt(k) = abs(ukp1_opt(k+1) - ukp1_opt(k))- 0.98* abs(u(k)-u(k-1)); % <0
%                 testt(k) = (ukp1_opt(k+1) - ukp1_opt(k))/(u(k)-u(k-1)); % <0
%                 testt(k)
                if testt(k) >= 0 %% No convergence
                    if delta(k) == 0
                       delta(k) = 0.1;
                    else
                        delta(k) = delta(k) + 0.1;
                    end
%                     delta(k)
%     disp('opt nrmale')
%                     delta(k) = 0.5;
                    ukp1_opt(k+1) = RunOptimization(ukp1_opt(k), uk, lambda,delta(k), ukp1_opt(k),  fmincon_options);
                    
                else
                    flag = 1;
                end
            end
        end
        Deltatrefle(k) = (ukp1_opt(k+1) - ukp1_opt(k))/(u(k)-u(k-1));
%         Delta(k) = testt;
    end
    %% 4.- Apply filter
    if use_methode == 0 || k == 1
    %%%%%%% ******** Methode 0 ******** %%%%%%%
        u(k+1) = uk + K*(ukp1_opt(k+1) - uk);
        KKopt(k) = K;
    elseif use_methode == 1
    %%%%%%% ******** Methode 1.2 ******** %%%%%%%
        flag = 0;
        KK(k) = 1;
        if (abs(u(k)-u(k-1)) < 0.001) && (abs(ukp1_opt(k+1)-ukp1_opt(k)) < 0.001) && (manageconvergence == 1)
            KK(k)    = KK(k-1);
            KKopt(k) = KKopt(k-1);
        else
            while flag == 0 
                test = abs(1 - KK(k)*(1-  (ukp1_opt(k+1)-ukp1_opt(k))/(u(k)-u(k-1)) ));
                if test <1 
                    flag = 1;
                    KKopt(k) = KK(k);
                    KK(k)    = KK(k)-0.1;
                else
                    KK(k) = KK(k)-0.0001;
                end
            end
        end
        u(k+1) = uk + KK(k)*(ukp1_opt(k+1) - uk);
    else
    %%%%%%% ******** Methode 2.2 ******** %%%%%%%
        if (abs(u(k)-u(k-1)) < 0.001)  && (manageconvergence == 1) && (abs(ukp1_opt(k+1)-ukp1_opt(k)) < 0.001)
            KK(k)    = KK(k-1);
            KKopt(k) = KK(k);
        else
            
            disp('opt K')
            KK(k)= RunOptimizationK( ukp1_opt(k+1), ...
                              ukp1_opt(k),   ...
                              u(k),u(k-1), fmincon_options);
            KKopt(k) = KK(k);
        end
        u(k+1) = uk + KK(k)*(ukp1_opt(k+1) - uk);
    end
    
    disp('hhhh')
%     pause(3)
end

%% Plot results
figure
plot([0:NBiter],u)
%%
figure
semilogy([0:NBiter],abs(u-1))
%%
figure
plot([0:NBiter-1],KK)

%%
figure
plot([0:NBiter-1],KKopt)

%%
figure
plot(testt)
%%
figure
plot(delta)
title('delta')

%%
figure
plot(Deltatrefle)
title('Deltatrefle')


% 
%%
Results.u      = u;
Results.KK     = KK;
Results.KKopt  = KKopt;
Results.NBiter = NBiter;

% save(Results_file_name, 'Results')

%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')