function [K, eflag, outpt] = RunOptimizationK(uopt_kp1,uopt_k, uk, ukm1,opts)

Last_K   = [];
Last_f   = [];
Last_c   = []; % Attention c is not the input of the plant but the NL constraint !!
Last_ceq = [];

%%%%%%%%%%%%%%%  

lb = 0.1;
ub = 1;

Aeq = [];  
beq = [];

A = [];
b = [];

%%%%%%%%%%%%%%%  
K0 = 0.7;

[K, eflag, outpt] = fmincon(@(K)objfun(K, uopt_kp1, uopt_k, uk, ukm1),...
                                K0, A, b, Aeq, beq, lb, ub, ...
                                @(K)constr(K, uopt_kp1, uopt_k, uk, ukm1),opts);

    function y = objfun(K, uopt_kp1, uopt_k, uk, ukm1)
        if ~isequal(K,Last_K) % Check if computation is necessary
            phi      = abs(1 - K*(1-  (uopt_kp1-uopt_k)/(uk-ukm1) ));
            Last_K   = K;
            Last_f   = phi;
            Last_c   = [];
            Last_ceq = [];
        end
        y = Last_f;
    end

    function [c,ceq] = constr(K, uopt_kp1, uopt_k, uk, ukm1)
        if ~isequal(K,Last_K) % Check if computation is necessary
            phi      = abs(1 - K*(1-  (uopt_kp1 - uopt_k)/(uk-ukm1) ));
            Last_K   = K;
            Last_f   = phi;
            Last_c   = [];
            Last_ceq = [];
        end
        c   = Last_c;
        ceq = Last_ceq;
    end

end