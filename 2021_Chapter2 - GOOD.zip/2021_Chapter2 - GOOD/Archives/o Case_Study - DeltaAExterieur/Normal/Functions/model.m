function [phi, Dphi] = model(u)
%     phi  = 1/40*u^2;
%     Dphi = 2/40*u;
    phi  = 1/3*u^2;
    Dphi = 1/3*2*u;
end