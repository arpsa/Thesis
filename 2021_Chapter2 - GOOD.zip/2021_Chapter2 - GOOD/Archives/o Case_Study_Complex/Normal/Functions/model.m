function [phi, Dphi, DDphi] = model(u,a)

% a = 1/4;  % Normal case study
% a = 1/20; % Case not so stable
% a = -1/4;  % Case unstable

%     phi   = u^2/4;
%     Dphi  = u/2  ;
%     DDphi = 1/2;
%     
    
%     phi   = 1/30*u^2;
%     Dphi  = 1/30*2*u  ;
%     DDphi = 1/30*2;
%     
    
    phi   = a*u^2;
    Dphi  = a*2*u;
    DDphi = a*2;
end