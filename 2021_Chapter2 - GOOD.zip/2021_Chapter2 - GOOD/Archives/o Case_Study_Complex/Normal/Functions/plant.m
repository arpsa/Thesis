function [phi_p, Dphi_p] = plant(u)
a = 0.05;
    phi_p  = (u-1)^2; %+ a*(u-1)^4;
    Dphi_p = 2*(u-1); %  + a*4*(u-1)^3;
end