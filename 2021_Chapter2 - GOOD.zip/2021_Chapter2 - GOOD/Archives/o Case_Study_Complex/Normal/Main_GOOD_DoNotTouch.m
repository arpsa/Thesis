clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

% format shortEng

%% Code architecture initialization & Output files 
addpath('Functions')

Noise = 0 ;  % 0:No, 1:Yes
Results_file_name = 'Results_Main';

%% Tuning paramters


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  0.- Initialization of the algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 0.1.- Parameter defined by the user
u_max  =  5;
u_min  = -5;
NBiter = 50;
K = 1;
use_methode = 2; % [0]: fixer K, 
                 % [1]: Choix de K pour garantir Niveau 2, 
                 % [2]: Choix optimal de K.                

manageconvergence = 1; % [0]: No, [1]: Yes
usedelta = 0;          % [0]: No, [1]: Yes

% 0.2.- Simulations parameters
PBstruct = ProblemStructure();        % options for solver | nb iterations
    fmincon_options = PBstruct.fmincon_options;
    fsolve_options  = PBstruct.fsolve_options;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Save Results
Results  = struct();
struct_Y = struct();

u(1) = 0; % opt
u0   = u(1);
ukp1_opt(1) = 0;
KK(1) = K;
% KKopt(1) = k;

Modifiers = struct();
delta = [0, 0];
        EstimateDDp_MAX = 0;
a = 1/4;

for k = 1:NBiter
    %% 1.- Do experiment
    uk = u(k); 
    [phi_k, Dphi_k] = model(uk,a);
    [phi_pk, Dphi_pk] = plant(uk);
    %% 2.- Compute modifiers
    lambda = Dphi_pk - Dphi_k;
    %% 3.- Compute next point
    delta(k) = 0;
    ukp1_opt(k+1) = RunOptimization(uk, uk, lambda, delta(k),a, fmincon_options);
    %% Post processing
    if k > 1 && usedelta == 1
        [~,~,c] = model(u(k));
        if (u(k)-u(k-1)) < 0.001
            Delta(k) = Delta(k-1); %% eciter les valeurs naze
        else
            Delta(k) = (ukp1_opt(k+1)-ukp1_opt(k))/(u(k)-u(k-1));    % 
        end
        EstimateDDp(k) = -(Delta(k)-1)*(c+delta(k));
        if EstimateDDp(k) > EstimateDDp_MAX
            EstimateDDp_MAX = EstimateDDp(k);
        else
            EstimateDDp(k) = EstimateDDp_MAX;
        end
        
        
        delta_temp = EstimateDDp(k) -(c+delta(k)); % variable temporaire
        if delta_temp > 0
            delta(k) = delta_temp+delta(k);
            delta(k+1) = delta(k);
            ukp1_opt(k+1) = RunOptimization(uk, uk, lambda, delta(k), fmincon_options);
        else 
            delta(k+1) = delta(k);
        end
    end
    %% 4.- Apply filter
    if use_methode == 0 || k == 1
    %%%%%%% ******** Methode 0 ******** %%%%%%%
        u(k+1) = uk + K*(ukp1_opt(k+1) - uk);
        KKopt(k) = K;
    elseif use_methode == 1
    %%%%%%% ******** Methode 1.2 ******** %%%%%%%
        flag = 0;
        KK(k) = 1;
        if (abs(u(k)-u(k-1)) < 0.0001) && (abs(ukp1_opt(k+1)-ukp1_opt(k)) < 0.0001) && (manageconvergence == 1)
            KK(k)    = KK(k-1);
            KKopt(k) = KKopt(k-1);
        else
            while flag == 0 
                test = abs(1 - KK(k)*(1-  (ukp1_opt(k+1)-ukp1_opt(k))/(u(k)-u(k-1)) ));
                if test <1 
                    flag = 1;
                    KKopt(k) = KK(k);
                    KK(k)    = KK(k)-0.1;
                else
                    KK(k) = KK(k)-0.0001;
                end
            end
        end
        u(k+1) = uk + KK(k)*(ukp1_opt(k+1) - uk);
    else
    %%%%%%% ******** Methode 2.2 ******** %%%%%%%
        test = 100000000;
        if (abs(u(k)-u(k-1)) < 0.001) && (abs(ukp1_opt(k+1)-ukp1_opt(k)) < 0.001) && (manageconvergence == 1)
            disp('Filter has converged')
            KK(k)    = KK(k-1);
            KKopt(k) = KK(k);
        else
            KK(k)= RunOptimizationK( ukp1_opt(k+1), ...
                              ukp1_opt(k),   ...
                              u(k),u(k-1), fmincon_options);
            KKopt(k) = KK(k);
        end
        u(k+1) = uk + KK(k)*(ukp1_opt(k+1) - uk);
    end
    
    k
end

%% Plot results
figure
plot([0:NBiter],u)
title('U')
%%
figure
semilogy([0:NBiter],abs(u-1))
%%
figure
plot([0:NBiter-1],KK)
title('K')
% figure
% plot([0:NBiter-1],KKopt)
%%
figure
plot(delta)
title('delta')
% hold all
% plot(newtest)

%%
figure
plot(EstimateDDp)
title('2nd derive estimee')
% hold all
% plot(newtest)



% 
%%
Results.u      = u;
Results.KK     = KK;
Results.KKopt  = KKopt;
Results.NBiter = NBiter;

% save(Results_file_name, 'Results')

%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')