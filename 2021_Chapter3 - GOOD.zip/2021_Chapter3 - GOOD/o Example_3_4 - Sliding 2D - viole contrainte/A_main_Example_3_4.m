clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

%%
Results_file_name = 'Example_3_4';
global Last_u Last_f Last_c Last_ceq Modifiers

%% Grid for the plot
U1 = 0 : 0.01 : 1;
U2 = 0 : 0.01 : 1;

%% Evaluate the model and plant et several locations for the plot
for j = 1:length(U1)
    for i = 1:length(U2)
        u1(i,j) = U1(i);
        u2(i,j) = U2(j);
        U = [u1(i,j); u2(i,j)];
        PHI_p(i,j) = u2phip(U);  PHI(i,j) = u2phi(U);
        G_p(i,j)   = u2gp(U);    G(i,j)   = u2g(U);
    end
end

%% Solver's parameters
fmincon_options = optimoptions(@fmincon,'Algorithm','sqp' , ...'interior-point'   'sqp' 'active-set'
                                        'MaxIter',1000,... 
                                        'Display', 'off', ...''final',...  off   iter
                                        'MaxFunEvals',1000,...
                                        'TolFun',1e-8,...
                                        'TolCon',1e-8,...
                                        'TolX',1e-8,...
                                        'FinDiffType','central' ,... % ,...%'forward' (default), or 'central' 
                                        'ScaleProblem','obj-and-constr');     
                                    
%% Compute the plant optimum
Last_u = [];  Last_c   = [];
Last_f = [];  Last_ceq = [];
ub = [1, 1];  Aeq = [];  A = [];
lb = [0, 0];  beq = [];  b = [];
u0 = [0.5; 0.5];
ups = fmincon(@(u)objfunp(u),u0, A, b, ...
           Aeq, beq, lb, ub, @(u)constrp(u),fmincon_options);
 
%% Compute model optimum
Last_u = [];  Last_c   = [];
Last_f = [];  Last_ceq = [];
us = fmincon(@(u)objfun(u),u0, A, b, ...
           Aeq, beq, lb, ub, @(u)constr(u),fmincon_options);

%%
figure
    contourf(u1', u2',G_p',[-1000  0], 'Linestyle', 'none');
    T = [255, 150, 150        %// red
         255, 150, 150        %// red
         255, 255, 255        %// white
         255, 255, 255]./255; %// white  
    x = [10000
         0.01
         0
         -1000];
    map = interp1(x/255,T,linspace(0,1,255));
    colormap(map);
    hold on
    [Cphi, hphi] = contour(u1',u2',PHI_p','k');
%     [Cphi, hphi] = contour(u1',u2',PHI_p',[0.137 0.137] ,'k:');
%     clabel(Cphi,hphi,'LabelSpacing',300); 
    plot(ups(1), ups(2),'ko','MarkerEdgeColor',[0, 0.6, 0],'MarkerFaceColor',[0, 0.6, 0],'MarkerSize',6);
    text(ups(1), ups(2),'\boldmath$u^{\star}_p$', 'VerticalAlignment','bottom','Color',[0, 0.6, 0], 'Interpreter','latex','FontSize',13)
    hXLabel = xlabel('$u_{(1)}$');
    hYLabel = ylabel('$u_{(2)}$'); 
    xticks([0 0.5 1])
    yticks([0 0.5 1])
    set(gca,'FontSize', 10,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 11 ,'Interpreter','LaTex');
    set(gca,'TickLength', [.02 .02],'LineWidth', 1);
    set(gca,'Layer','Top');
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=5; y_width=5;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_4_map_plant')
        
 %%   
figure 
% subplot(1,2,2)
    contourf(u1', u2',G',[-1000  0], 'Linestyle', 'none');
    T = [255, 150, 150        %// red
         255, 150, 150        %// red
         255, 255, 255        %// white
         255, 255, 255]./255; %// white  
    x = [10000
         0.01
         0
         -1000];
    map = interp1(x/255,T,linspace(0,1,255));
    colormap(map);
    hold on
    [Cphi, hphi] = contour(u1',u2',PHI','k');  % [-10:0.5:5],
%     clabel(Cphi,hphi,'LabelSpacing',300); 
    
    plot(us(1), us(2),'ko','MarkerEdgeColor',[0, 0.6, 0],'MarkerFaceColor',[0, 0.6, 0],'MarkerSize',6);
    text(us(1)+0.04, us(2),'\boldmath$u^{\star}$', 'VerticalAlignment','bottom','Color',[0, 0.6, 0], 'Interpreter','latex','FontSize',13)

    hXLabel = xlabel('$u_{(1)}$');
    hYLabel = ylabel('$u_{(2)}$'); 
    xticks([0 0.5 1])
    yticks([0 0.5 1])   
    set(gca,'FontSize', 10,'FontName','Helvetica');
    set([hXLabel, hYLabel],'FontSize', 11,'Interpreter','LaTex');
    set(gca,'TickLength', [.02 .02],'LineWidth', 1);
    set(gca,'Layer','Top');
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=5; y_width=5;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_4_map_model')

%% ***********************************************************************
% II.- Let's apply MFCA, KMFCA, and KMA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Modifiers = struct();
Results   = struct();
MFCA=1;  KMFCA=2; KMFCpA=3;  adKMA_0=4; adKMA_025=5;  
adKMA_05=6;     adKMA_075=7; adKMA_1=8; adKMA_125=9; adKMA=10; 
adKMA_FORCE=11; NBiter=31;  ConvTest = 1e-10;
u{1} = us;
% adKMA_0 adKMA_025 adKMA_05 adKMA_075 adKMA_1 adKMA_125 
for Methode = [MFCA KMFCA KMFCpA]
    Last_u = -1;
    if     Methode == KMFCpA
        disp('KMFCpA');
    elseif Methode == KMFCA
        disp('KMFCA');
    elseif Methode == MFCA 
        disp('MFCA');
    elseif Methode == adKMA_0   || Methode == adKMA_025 || Methode == adKMA_05  || ...
           Methode == adKMA_075 || Methode == adKMA_1  || Methode == adKMA_125  || ...
           Methode == adKMA
        disp('adKMA');
    end   
    MinDeltaS(1) = 1e8;
    for k = 1:NBiter
        % 1) Compute the model's and plant's values end derivatives at uk.
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        for hide_get_data = 1     
            [phi(k),  dphi{k} ]    = u2phi(u{k});
            [phip(k), dphip{k}]    = u2phip(u{k});
            [g(k),dg{k},ddg{k}]    = u2g(u{k});
            [gp(k),dgp{k},ddgp{k}] = u2gp(u{k});

            Modifiers.epsilon_g   = gp(k)    - g(k);
            Modifiers.lambda__g   = dgp{k}   - dg{k};
            Modifiers.lambda__phi = dphip{k} - dphi{k};
            Modifiers.gp          = gp(k);
            Modifiers.dgp         = dgp{k};
            Modifiers.uk          = u{k};
            if min(eig(ddg{k})) < 0 
                Modifiers.UseAfAprox  = 1;
            else
                Modifiers.UseAfAprox  = 0;
            end
        end
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % 2) Select next iteration 
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        if Methode == MFCA
            for Hide_MFCA = 1     
                Last_u = [];  Last_c   = [];
                Last_f = [];  Last_ceq = [];
                ub = [1, 1];  Aeq = [];  A = [];
                lb = [0, 0];  beq = [];  b = [];
                uopt{k+1} = fmincon(@(u)objfun_MFCA(u),u{k}, A, b, ...
                         Aeq, beq, lb, ub, @(u)constr_MFCA(u),fmincon_options);
                % 3) Apply filter
                if k == 1
                    K(k) = 0.1;
                else
                    if max(abs(u{k}-u{k-1})) > ConvTest
                        NablaS = (u{k}-u{k-1})'*(uopt{k+1}-uopt{k})/(norm(u{k}-u{k-1})^2);
                        if NablaS < 1
                            K(k) = 1/(1-NablaS);
                        else
                            K(k) = 1;
                        end
                    else
                        K(k) = K(k-1);
                    end
                end
                u{k+1} = u{k} + K(k)*(uopt{k+1}-u{k});
                disp(['u(',num2str(k),') = [',num2str(u{k}(1)),', ',num2str(u{k}(2))]);
            end
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        elseif Methode == KMFCA || Methode == KMFCpA
            for Hide_KMFCA = 1    
                Modifiers.k = k;
                if Methode == KMFCA 
                    Modifiers.Active = 1; % Feature introduced for KMFCpA .. here we leave it at 1 so that it does not affect KMFCA
                    Active(k) = 1;
                else
                    if k == 1
                        Modifiers.Active = 0;
                        Active(k) = 0;
                    end
                end
                
                if k > 1
                    Modifiers.ukm1  = u{k-1};
                    Modifiers.uoptk = uopt{k};
                    Modifiers.K_km1 = K(k-1);
                end
                Last_u = [];  Last_c   = [];
                Last_f = [];  Last_ceq = [];
                ub = [1, 1];  Aeq = [];  A = [];
                lb = [0, 0];  beq = [];  b = [];
                uini = [0.5; 0.5];
                [uopt{k+1},~,~,~,lambda]  = fmincon(@(u)objfun_KMFCA(u),u{k}, A, b, ...
                        Aeq, beq, lb, ub, @(u)constr_KMFCA(u),fmincon_options);
  
                if k == 1
                    K(k) = 0.1;
                else
                    if max(abs(u{k}-u{k-1})) > ConvTest
                        NablaS = (u{k}-u{k-1})'*(uopt{k+1}-uopt{k})/(norm(u{k}-u{k-1})^2);
                        if NablaS < 1
                            K(k) = max(0.1, 1/(1-NablaS));
                        else
                            K(k) = 1;
                        end
                    else
                        K(k) = K(k-1);
                    end
                end
                u{k+1} = u{k} + K(k)*(uopt{k+1}-u{k});
                disp(['u(',num2str(k),') = [',num2str(u{k}(1)),', ',num2str(u{k}(2)),']']);

                if Methode == KMFCpA  
                    gtest1 = u2g(uopt{k+1}) + Modifiers.epsilon_g +  Modifiers.lambda__g' * (uopt{k+1} - Modifiers.uk);
                    gtest2 = u2g(u{k+1})    + Modifiers.epsilon_g +  Modifiers.lambda__g' * (u{k+1}    - Modifiers.uk);
                    % Contournement contraintes "inutiles" lambda.ineqnonlin(1) >0 || lambda.ineqnonlin(2) >0 ||
                    if gtest1 > -1e-4  || gtest2 > -1e-4 
                        Modifiers.Active = 1;
                        Active(k) = 1;
                        % Recompute next point
                        [uopt{k+1},~,~,~,lambda]  = fmincon(@(u)objfun_KMFCA(u),u{k}, A, b, ...
                                        Aeq, beq, lb, ub, @(u)constr_KMFCA(u),fmincon_options);
                        if k == 1
                            K(k) = 0.1;
                        else
                            if max(abs(u{k}-u{k-1})) > ConvTest
                                NablaS = (u{k}-u{k-1})'*(uopt{k+1}-uopt{k})/(norm(u{k}-u{k-1})^2);
                                if NablaS < 1
                                    K(k) = max(0.1, 1/(1-NablaS));
                                else
                                    K(k) = 1;
                                end
                            else
                                K(k) = K(k-1);
                            end
                        end
                        u{k+1} = u{k} + K(k)*(uopt{k+1}-u{k});
                        disp(['u(',num2str(k),') = [',num2str(u{k}(1)),', ',num2str(u{k}(2)),']']);
                    else
                        Modifiers.Active = 0;
                        Active(k) = 0;
                        
                    end
                end

            end
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        elseif Methode == adKMA_0 || Methode == adKMA_025   || Methode == adKMA_05 || ...
               Methode == adKMA_075 || Methode == adKMA_1  || Methode ==  adKMA_125 
            for Hide_adKMA = 1    
                Ktest = 0.1:0.05:2;
                Results.Ktest{Methode,k} = Ktest;
                MinDist=1e10;  flag=0;  NablaS=0; K(k)=0.1;
                utest = u{k};
                for i = 1:length(Ktest)
                    uinit = utest;
                    Modifiers.K = Ktest(i);
                    Last_u = [];  Last_c   = [];
                    Last_f = [];  Last_ceq = [];
                    ub = [1; 1];  Aeq = [];  A = [];
                    lb = [0; 0];  beq = [];  b = [];
                    [utest,~,exflag] = fmincon(@(u)objfun_adKMA(u),uinit, A, b, ...
                        Aeq, beq, lb, ub, @(u)constr_adKMA(u),fmincon_options);
                    Results.utest{Methode,k}{i} = utest;
                    if k > 1 
                        if max(abs(u{k}-u{k-1})) > 1e-3
                            NablaS = (u{k}-u{k-1})'*(utest-uopt{k})/(norm(u{k}-u{k-1})^2);
                            if NablaS < 1
                                Kmax = 1/(1-NablaS);
                            else
                                Kmax = 1;
                            end
                        else
                            Kmax = K(k-1);
                        end
                    else
                        Kmax = 0.1;
                    end
                    % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
                    if  Methode == adKMA_0
                        b=0;
                    elseif  Methode == adKMA_025
                        b=0.25;
                    elseif  Methode == adKMA_05
                        b=0.5;
                    elseif  Methode == adKMA_075
                        b=0.75;
                    elseif  Methode == adKMA_1
                        b=1;
                    elseif  Methode == adKMA_125
                        b=1.25;
                    end 
                    % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    
                    if Ktest(i) <= Kmax && NablaS < 1
                        flag = 1;
                        if round((1+b-2*Ktest(i)+Ktest(i)^2)*norm(utest-u{k}),6) <= MinDist
                            MinDist = round((1+b-2*Ktest(i)+Ktest(i)^2)*norm(utest-u{k}),6);
%                         if round(1*norm(utest-u{k}),6) <= MinDist
                            MinDist = round(1*norm(utest-u{k}),6);
                            K2       = Ktest(i);
                            uopt2    = utest;
                        end
                    elseif Ktest(i) == 1 
                        K1       = Ktest(i);
                        uopt1    = utest;
                    end
                    Results.dist{Methode,k}(i)   = (1+b-2*Ktest(i)+Ktest(i)^2)*norm(utest-u{k});
                    Results.NablaS{Methode,k}(i) = NablaS;
                    Results.Kmax{Methode,k}(i)   = Kmax;
                end
                if flag == 1
                    K(k)    = K2; 
                    uopt{k+1} = uopt2;
                else
                    K(k)    = K1; 
                    uopt{k+1} = uopt1;
                end
                u{k+1} = u{k} + K(k) * (uopt{k+1} - u{k}); 
                disp(['u(',num2str(k),') = [',num2str(u{k}(1)),', ',num2str(u{k}(2)),']']);
            end
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        elseif Methode == adKMA
            for Hide_adKMA = 1    
                %                ~~~~~~~~~~~~~~~~~~~~~~~~~
                Last_u = [];  Last_c   = [];
                Last_f = [];  Last_ceq = [];
                ub = [1; 1];  Aeq = [];  A = [];
                lb = [0; 0];  beq = [];  b = [];
                flag = 0; K(k) = 0; uinit = u{k};
                %                ~~~~~~~~~~~~~~~~~~~~~~~~~
                if k == 1
                    K(k) = 0.1; 
                    Modifiers.K = K(k);
                    uopt{k+1} = fmincon(@(u)objfun_adKMA(u),uinit, A, b, ...
                        Aeq, beq, lb, ub, @(u)constr_adKMA(u),fmincon_options);
                    flag = 1;
                else
                    if max(abs(u{k}-u{k-1})) > 1e-7
                        StopForLoop = 0;
                        for Ktest = 0.1:0.05:2
                            if StopForLoop == 0
                                Modifiers.K = Ktest;
                                utest = fmincon(@(u)objfun_adKMA(u),uinit, A, b, ...
                                        Aeq, beq, lb, ub, @(u)constr_adKMA(u),fmincon_options);
                                NablaS = (u{k}-u{k-1})'*(utest-uopt{k})/(norm(u{k}-u{k-1})^2);
                                if NablaS < 1 
                                    if Ktest < 1/(1-NablaS)
                                        K(k)      = Ktest; 
                                        uopt{k+1} = utest;
                                        flag      = 1;
                                    else
                                        StopForLoop = 1;
                                    end
                                else
                                    StopForLoop = 1;
                                end
                                    
                            end
                        end
                    else
                        K(k) = K(k-1); 
                        Modifiers.K = K(k);
                        uopt{k+1} = fmincon(@(u)objfun_adKMA(u),uinit, A, b, ...
                            Aeq, beq, lb, ub, @(u)constr_adKMA(u),fmincon_options);
                    end
                end
                if flag == 0 
                    K(k) = 1; 
                    Modifiers.K = K(k);
                    uopt{k+1} = fmincon(@(u)objfun_adKMA(u),uinit, A, b, ...
                        Aeq, beq, lb, ub, @(u)constr_adKMA(u),fmincon_options);
                    
                end
                
                u{k+1} = u{k} + K(k) * (uopt{k+1} - u{k}); 
                disp(['u(',num2str(k),') = [',num2str(u{k}(1)),', ',num2str(u{k}(2)),']']);
            end
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        elseif Methode == adKMA_FORCE
            for Hide_adKMA_FORCE = 1    
                %                ~~~~~~~~~~~~~~~~~~~~~~~~~
                Last_u = [];  Last_c   = [];
                Last_f = [];  Last_ceq = [];
                ub = [1, 1];  Aeq = [];  A = [];
                lb = [0, 0];  beq = [];  b = [];
                flag = 0; K(k) = 0; uinit =  [0 ;1];%u{k};
                Dist = 1e10;
                %                ~~~~~~~~~~~~~~~~~~~~~~~~~
                if k == 1
                    K(k) = 0.1; 
                    Modifiers.K = K(k);
                    uopt{k+1} = fmincon(@(u)objfun_adKMA(u),uinit, A, b, ...
                        Aeq, beq, lb, ub, @(u)constr_adKMA(u),fmincon_options);
                    flag = 1;
                else
                    if max(abs(u{k}-u{k-1})) > 1e-9
                        flag = 0;
                        for Ktest = 0.1:0.025:2
                            Modifiers.K = Ktest;
                            [utest,~,eflag] = fmincon(@(u)objfun_adKMA(u),uinit, A, b, ...
                                    Aeq, beq, lb, ub, @(u)constr_adKMA(u),fmincon_options);
                            NablaS = (u{k}-u{k-1})'*(utest-uopt{k})/(norm(u{k}-u{k-1})^2);
                            if NablaS < 1 && eflag >= 0
                                Dist_temp = abs(1-Ktest*(1-NablaS));  % floor(abs(1-Ktest*(1-NablaS))*1e5)/1e5;
                                if Dist_temp < Dist && Ktest < 1/(1-NablaS)%  Dist_temp <1
                                    Dist = Dist_temp;
                                    K(k) = Ktest;
                                    uopt{k+1} = utest;
                                    flag = 1;
                                end
                            end
                        end
                        if flag == 0
                             K(k) = 1;
                             Modifiers.K = Ktest;
                             uopt{k+1}  = fmincon(@(u)objfun_adKMA(u),uinit, A, b, ...
                                    Aeq, beq, lb, ub, @(u)constr_adKMA(u),fmincon_options);
                        end
                    else
                        K(k) = K(k-1); 
                        Modifiers.K = K(k);
                        uopt{k+1} = fmincon(@(u)objfun_adKMA(u),uinit, A, b, ...
                            Aeq, beq, lb, ub, @(u)constr_adKMA(u),fmincon_options);
                    end
                end
                     
                u{k+1} = u{k} + K(k) * (uopt{k+1} - u{k}); 
                disp(['u(',num2str(k),') = [',num2str(u{k}(1)),', ',num2str(u{k}(2)),']']);
                disp(['Kk = ',num2str(K(k))])
            end
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        end
    end
    % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    for Hide_Save_Data = 1        
        for i = 1:NBiter
            Results.u1{Methode}(i)    = u{i}(1);
            Results.u2{Methode}(i)    = u{i}(2);
            Results.phipk{Methode}(i) = phip(i);
            Results.gpk{Methode}(i)   = gp(i);
            Results.Kk{Methode}(i)    = K(i);
            Results.dgpk{Methode}{i}  = dgp{i};
            Results.u{Methode}{i}     = u{i};
            if Methode == KMFCpA
                Results.Active{Methode}{i} = Active(i);
            end
        end
    end
    % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
end

Results.ups = ups;
Results.phips = u2phip(ups);
Results.gps   = u2gp(ups);

save(Results_file_name, 'Results')
%%
figure
y1 = [1 1]; y2 = [1.5 1.5];
x = [0 NBiter-1]; 
fill( [x fliplr(x)],  [y1 fliplr(y2)], [1 0.8 0.8],'EdgeColor','none');
hold on
plot(0:NBiter-1, Results.u1{MFCA},'Color',[0.5 0.5 0.5], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, Results.u1{KMFCA},'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, Results.u1{KMFCpA},'m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot([0 NBiter-1], ups(1)*[1 1],'g', 'LineStyle','--', 'LineWidth', 1.5,'MarkerSize',5, 'Color',[0.3 0.8 0.3])  
    ylim([0 1.5])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u_{(1)}$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_4_u1k')
%%
figure
y1 = [1 1]; y2 = [2 2];
x = [0 NBiter-1]; 
fill( [x fliplr(x)],  [y1 fliplr(y2)], [1 0.8 0.8],'EdgeColor','none');
hold on
plot(0:NBiter-1, Results.u2{MFCA} ,'Color',[0.5 0.5 0.5], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, Results.u2{KMFCA},   'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, Results.u2{KMFCpA},  'm', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot([0 NBiter-1], ups(2)*[1 1]   ,   'g', 'LineStyle','--', 'LineWidth', 1.5,'MarkerSize',5, 'Color',[0.3 0.8 0.3])  
    ylim([0.5 2])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u_{(2)}$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_4_u2k')
%%
figure
y1 = [0 0]; y2 = [0.1 0.1];
x = [0 NBiter-1]; 
fill( [x fliplr(x)],  [y1 fliplr(y2)], [1 0.8 0.8],'EdgeColor','none');
hold on
plot(0:NBiter-1, Results.gpk{MFCA}  ,'Color',[0.5 0.5 0.5], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, Results.gpk{KMFCA} ,'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, Results.gpk{KMFCpA},'m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot([0 NBiter-1], Results.gps*[1 1],'g', 'LineStyle','--', 'LineWidth', 1.5,'MarkerSize',5, 'Color',[0.3 0.8 0.3])  
    ylim([-0.3 0.1])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$g_p(${\boldmath$u$}${}_k)$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_4_gk')
%%
figure
hold on
plot(0:NBiter-1, Results.phipk{MFCA} ,'Color',[0.5 0.5 0.5], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, Results.phipk{KMFCA},'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, Results.phipk{KMFCpA},'m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot([0 NBiter-1], Results.phips*[1 1]   ,'g', 'LineStyle','--', 'LineWidth', 2,'MarkerSize',5, 'Color',[0.3 0.8 0.3])  
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$\phi_p(${\boldmath$u$}${}_k)$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_4_phik')



%% adKMA_FORCE
figure 
hold on
plot(0:NBiter-1, Results.Kk{MFCA} ,'Color',[0.5 0.5 0.5], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, Results.Kk{KMFCA},'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, Results.Kk{KMFCpA},'m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$K_k$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_4_Kk')
%%
figure
hold on
plot(0:NBiter-1, log(abs(Results.u1{MFCA}  - ups(1))+1e-16)/log(10),'Color',[0.5 0.5 0.5]', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, log(abs(Results.u2{MFCA}  - ups(2))+1e-16)/log(10),'Color',[0.5 0.5 0.5], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% plot(0:NBiter-1, log(abs(Results.u1{adKMA_05}    - ups(1))+1e-16)/log(10),[0.749, 0.5647, 0], 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','b')
% plot(0:NBiter-1, log(abs(Results.u2{adKMA_05}    - ups(2))+1e-16)/log(10),[0.749, 0.5647, 0], 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','b')
% plot(0:NBiter-1, log(abs(Results.u1{adKMA}    - ups(1))+1e-16)/log(10),'Color','b', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','b')
% plot(0:NBiter-1, log(abs(Results.u2{adKMA}    - ups(2))+1e-16)/log(10),'Color','b', 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','b')
% plot(0:NBiter-1, log(abs(Results.u1{adKMA_FORCE}    - ups(1))+1e-16)/log(10),'Color',[0.749, 0.5647, 0], 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','b')
% plot(0:NBiter-1, log(abs(Results.u2{adKMA_FORCE}    - ups(2))+1e-16)/log(10),'Color',[0.749, 0.5647, 0], 'LineStyle','-', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','b')
% plot(0:NBiter-1, log(abs(Results.u1{adKMA_0}    - ups(1))+1e-16)/log(10),'Color',[0.749, 0.5647, 0], 'LineStyle',':', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','b')
% plot(0:NBiter-1, log(abs(Results.u2{adKMA_0}    - ups(2))+1e-16)/log(10),'Color',[0.749, 0.5647, 0], 'LineStyle',':', 'LineWidth', 3,'MarkerSize',5, 'MarkerFaceColor','b')

plot(0:NBiter-1, log(abs(Results.u1{KMFCA}    - ups(1))+1e-16)/log(10),'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, log(abs(Results.u2{KMFCA}    - ups(2))+1e-16)/log(10),'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, log(abs(Results.u1{KMFCpA}   - ups(1)+1e-16))/log(10),'m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(0:NBiter-1, log(abs(Results.u2{KMFCpA}   - ups(2)+1e-16))/log(10),'m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
% adKMA_FORCE

    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$log_{10}(|u_{(i)}-u_{p(i)}^{\star}|)$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_4_loguk')
%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')
   
    
%% Plant & model functions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
function [phip, dphip] = u2phip(u)
    A    = [2 1; 1 2];
    center = [1;0.3];
    phip  = (u-center)'*A*(u-center)/2;
    dphip =  A*(u-center);
end
function [phi, dphi]   = u2phi(u) 
    A    = [2 -1.1; -1.1 1.9];
    center = [0.5;0.6];
    phi  = (u-center)'*A*(u-center)/2;
    dphi =  A*(u-center);
end
function [gp,dgp,ddgp] = u2gp(u)  
    A    = -[1 0; 0 1];
    center = [1;0];
    gp  = 0.3 + (u-center)'*A*(u-center)/2;
    dgp =  A*(u-center);
    ddgp =  A;
end
function [g,dg,ddg]    = u2g(u)  
%     A    = -[1 0.3; 0.3 1]*1.7;
    A    = -[1.7 0.5; 0.5 1.7];
    center = [1.2;0.1];
    g  = 0.75 + (u-center)'*A*(u-center)/2;
    dg =  A*(u-center);
    ddg=  A;
end

%% Nominal Opt Plant ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfunp(u)
    global Last_f
    ToDop(u)
    y = Last_f;
end
function [c,ceq] = constrp(u)
    global  Last_c Last_ceq 
    ToDop(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDop(u)  
    global Last_u Last_c Last_f Last_ceq 
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        phip = u2phip(u);
        gp   = u2gp(u);
        Last_u   = u;
        Last_f   = phip;
        Last_c   = gp;
        Last_ceq = [];
    end
end

%% Nominal Opt Model ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun(u)
    global Last_f
    ToDo(u)
    y = Last_f;
end
function [c,ceq] = constr(u)
    global  Last_c Last_ceq 
    ToDo(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo(u)  
    global Last_u Last_c Last_f Last_ceq
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        phi = u2phi(u);
        g   = u2g(u);
        Last_u   = u;
        Last_f   = phi;
        Last_c   = g;
        Last_ceq = [];
    end
end

%% MFCA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_MFCA(u)
    global Last_f
    ToDo_MFCA(u)
    y = Last_f;
end
function [c,ceq] = constr_MFCA(u)
    global  Last_c Last_ceq 
    ToDo_MFCA(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_MFCA(u)  
    global Last_u Last_c Last_f Last_ceq Modifiers
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        phi = u2phi(u);
        g   = u2g(u);
        % Apply an afine correction          
        phi = phi + Modifiers.lambda__phi' * (u - Modifiers.uk);
        if Modifiers.UseAfAprox == 1
            g = Modifiers.gp  + Modifiers.dgp' *(u-Modifiers.uk);
        else
            g  = g   + Modifiers.epsilon_g   + Modifiers.lambda__g' * (u - Modifiers.uk);
        end
        Last_u   = u;
        Last_f   = phi;
        Last_c   = g;
        Last_ceq = [];
    end
end

%% KMFCA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_KMFCA(u)
    global Last_f
    ToDo_KMFCA(u)
    y = Last_f;
end
function [c,ceq] = constr_KMFCA(u)
    global  Last_c Last_ceq 
    ToDo_KMFCA(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_KMFCA(u)  
    global Last_u Last_c Last_f Last_ceq Modifiers
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        phi = u2phi(u);
        g   = u2g(u);
        % Compute  filter
        k = Modifiers.k;
        if k == 1
            K = 0.1;
        else
            uk    = Modifiers.uk;
            ukm1  = Modifiers.ukm1;
            uoptk = Modifiers.uoptk;
            K_km1 = Modifiers.K_km1;
            if abs(uk-ukm1) > 1e-8
                NablaS = (uk-ukm1)'*(u-uoptk)/(norm(uk-ukm1)^2);
                if NablaS < 1
                    K = max(0.1, 1/(1-NablaS));
                else
                    K = 1;
                end
            else
                K = K_km1;
            end
        end
        u2 = Modifiers.uk + K*(u-Modifiers.uk);
        g2  = u2g(u2);
        % Apply an afine correction          
        phi = phi + Modifiers.lambda__phi' * (u - Modifiers.uk);
        g2  = g2   + Modifiers.epsilon_g   + Modifiers.lambda__g' * (u2 - Modifiers.uk);
        if Modifiers.UseAfAprox == 1 && Modifiers.Active == 1
            g = Modifiers.gp  + Modifiers.dgp' *(u-Modifiers.uk);
        else
            g  = g   + Modifiers.epsilon_g   + Modifiers.lambda__g' * (u - Modifiers.uk);
        end
        Last_u   = u;
        Last_f   = phi;
        Last_c   = [g;g2;u2-1;-u2;K-4];
        Last_ceq = [];
    end
end

%% adKMA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_adKMA(u)
    global Last_f
    ToDo_adKMA(u)
    y = Last_f;
end
function [c,ceq] = constr_adKMA(u)
    global  Last_c Last_ceq 
    ToDo_adKMA(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_adKMA(u)  
    global Last_u Last_c Last_f Last_ceq Modifiers
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u_kp1^s and u_kp1
        phi = u2phi(u);
        g   = u2g(u);
        K   = Modifiers.K;
        u2  = Modifiers.uk + K*(u-Modifiers.uk);
        g2  = u2g(u2);
        % Apply an afine correction          
        phi = phi                       + Modifiers.lambda__phi'*(u - Modifiers.uk);
        g   = g   + Modifiers.epsilon_g + Modifiers.lambda__g'  *(u - Modifiers.uk);
        g2  = g2  + Modifiers.epsilon_g + Modifiers.lambda__g'  *(u2 - Modifiers.uk);
        % Return cost and constraints
        Last_u   = u;
        Last_f   = phi;
        Last_c   = [g;g2;u2-1;-u2];
        Last_ceq = [];
    end
end