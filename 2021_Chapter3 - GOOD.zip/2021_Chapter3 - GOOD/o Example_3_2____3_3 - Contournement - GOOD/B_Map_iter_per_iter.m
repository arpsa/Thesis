clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

%%
load('Example_3_2.mat')

%% Grid for the plot
U1 = 0 : 0.01 : 1;
U2 = 0 : 0.01 : 1;
MFCA=1;  KMFCA=2;  adKMA=3; KMFCpA=4;
%% Evaluate the model and plant et several locations for the plot

for Methode =  [KMFCA] % adKMA MFCA KMFCA 
    uk = Results.u{Methode};
    Kk = Results.Kk{Methode};
    
    if     Methode == adKMA
        kset = 1:5;
    elseif Methode == MFCA
        kset = 1:25;
    elseif Methode == KMFCA
        kset = 1:10;
    elseif Methode == KMFCpA
        kset = 1:10;
    end
    for k = kset
        [phipk dphipk] = u2phip(uk{k});
        [gpk   dgpk]   = u2gp(uk{k}); 
        [phik dphik]   = u2phi(uk{k});
        [gk   dgk]     = u2g(uk{k}); 
        for j = 1:length(U1)
            for i = 1:length(U2)
                u1(i,j) = U1(i);
                u2(i,j) = U2(j);
                U   = [u1(i,j); u2(i,j)];
                PHI = u2phi(U);  
                G   = u2g(U);
                PHIk(i,j)  = PHI + phipk - phik + (dphipk-dphik)'*(U - uk{k});
                Gklin(i,j) = gpk + dgpk'*(U - uk{k});
                Gk(i,j)    = G + (gpk-gk) + (dgpk-dgk)'*(U - uk{k});
            end
        end
        
        uotpk{k+1} = (uk{k+1}-uk{k})/Kk(k) + uk{k};

        if Methode == MFCA || Methode == KMFCA || (Methode == KMFCpA &&  Results.Active{KMFCpA}{k} == 1)
        figure 
        hold on
        if Methode == MFCA
            T = [ 255,150,150    %// overlap  228,175,175 
              255,150,150        %// overlap
              255,150,150        %// gray
              255,150,150        %// gray
              255,150,150           %// white
              255,150,150]./255;   %// white again 
            x = [299; 200; 199; 100; 99; 0];
        else
            T = [ 182, 137, 182    %// overlap  228,175,175 
              182, 137, 182        %// overlap
              255, 255, 255        %// gray
              255, 255, 255        %// gray
              255,150,150           %// white
              255,150,150]./255;   %// white again 
            x = [299; 200; 199; 100; 99; 0];
        end
        map = interp1(x/255,T,linspace(0,1,255));
        colormap(map);
        contourf(u1, u2,Gklin,[0 99],'edgecolor','none');
        contourf(u1, u2, Gk+100,[100 199],'edgecolor','none')
        contourf(u1, u2, min(Gklin,Gk)+200 , [200 1000],'edgecolor','none');
    
        [Cphi, hphi] = contour(u1',u2',PHIk','k');  % [-10:0.5:5],
        
        plot([uk{k}(1) uk{k+1}(1)], [uk{k}(2) uk{k+1}(2)],'Color',[0.5 0.5 0.5]);
        plot([uk{k}(1) uotpk{k+1}(1)], [uk{k}(2) uotpk{k+1}(2)],':','Color',[0.5 0.5 0.5]);
        plot(uk{k}(1), uk{k}(2),'ko','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',3);
        plot(uk{k+1}(1), uk{k+1}(2),'Marker','o','MarkerEdgeColor',[0.5 0.5 0.5],'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',3);
        plot(uotpk{k+1}(1), uotpk{k+1}(2),'Marker','p','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',3);

        xl = xlim;
        yl = ylim;
        lenthx = xl(2)-xl(1);
        lenthy = yl(2)-yl(1);
        minx = xl(1);
        miny = yl(1);
        fill([0 1  1 0], [0 0 1 1],'k','facealpha', 0,'edgecolor','r','LineWidth', 2)
        fill((minx+0.50*lenthx)+[0 0.50*lenthx  0.50*lenthx 0], miny+[0 0 0.15*lenthy 0.15*lenthy],'k','facealpha', 0.8,'edgecolor','none') 
        text((minx+0.55*lenthx)  , -0.02*lenthy , ['\boldmath$k$=\boldmath$',num2str(k-1),'$'], 'VerticalAlignment','bottom','Color','w', 'Interpreter','latex','FontSize',10)
        
        
        plot([uk{k}(1) uk{k+1}(1)], [uk{k}(2) uk{k+1}(2)],'Color',[0.5 0.5 0.5]);
        plot([uk{k}(1) uotpk{k+1}(1)], [uk{k}(2) uotpk{k+1}(2)],':','Color',[0.5 0.5 0.5]);
        plot(uk{k}(1), uk{k}(2),'ko','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',3);
        plot(uk{k+1}(1), uk{k+1}(2),'Marker','o','MarkerEdgeColor',[0.5 0.5 0.5],'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',3);
        plot(uotpk{k+1}(1), uotpk{k+1}(2),'Marker','p','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',3);

%         text((minx+0.55*lenthx)  , -0.02*lenthy , ['\boldmath$k$=\boldmath$',num2str(k-1),'$'], 'VerticalAlignment','bottom','Color','w', 'Interpreter','latex','FontSize',10)
        
        set(gca,'FontSize', 9,'FontName','Helvetica');
        set(gca,'Color', 'w');
        set(gca,'Layer','Bottom');
        set(gca,'xticklabel',[],'yticklabel',[])
        %% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        elseif (Methode == adKMA) || (Methode == KMFCpA &&  Results.Active{KMFCpA}{k} == 0)
            figure 
            hold on
            T = [ 182, 137, 182    %// overlap  228,175,175 
              182, 137, 182        %// overlap
              182, 137, 182        %// gray
              182, 137, 182        %// gray
              255,150,150          %// white
              255,150,150]./255;   %// white again 
            x = [299; 200; 199; 100; 99; 0];
            map = interp1(x/255,T,linspace(0,1,255));
            colormap(map);
%             contourf(u1, u2,Gklin,[0 99],'edgecolor','none');
        contourf(u1, u2, Gk+100,[100 199],'edgecolor','none')
%             contourf(u1, u2, min(Gklin,Gk)+200 , [200 1000],'edgecolor','none');

            [Cphi, hphi] = contour(u1',u2',PHIk','k');  % [-10:0.5:5],

            plot([uk{k}(1) uk{k+1}(1)], [uk{k}(2) uk{k+1}(2)],'Color',[0.5 0.5 0.5]);
            plot([uk{k}(1) uotpk{k+1}(1)], [uk{k}(2) uotpk{k+1}(2)],':','Color',[0.5 0.5 0.5]);
            plot(uk{k}(1), uk{k}(2),'ko','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',3);
            plot(uk{k+1}(1), uk{k+1}(2),'Marker','o','MarkerEdgeColor',[0.5 0.5 0.5],'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',3);
            plot(uotpk{k+1}(1), uotpk{k+1}(2),'Marker','p','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',3);

            xl = xlim;
            yl = ylim;
            lenthx = xl(2)-xl(1);
            lenthy = yl(2)-yl(1);
            minx = xl(1);
            miny = yl(1);
            fill([0 1  1 0], [0 0 1 1],'k','facealpha', 0,'edgecolor','r','LineWidth', 2)
            fill((minx+0.50*lenthx)+[0 0.50*lenthx  0.50*lenthx 0], miny+[0 0 0.15*lenthy 0.15*lenthy],'k','facealpha', 0.8,'edgecolor','none') 
            text((minx+0.55*lenthx)  , -0.02*lenthy , ['\boldmath$k$=\boldmath$',num2str(k-1),'$'], 'VerticalAlignment','bottom','Color','w', 'Interpreter','latex','FontSize',10)


            plot([uk{k}(1) uk{k+1}(1)], [uk{k}(2) uk{k+1}(2)],'Color',[0.5 0.5 0.5]);
            plot([uk{k}(1) uotpk{k+1}(1)], [uk{k}(2) uotpk{k+1}(2)],':','Color',[0.5 0.5 0.5]);
            plot(uk{k}(1), uk{k}(2),'ko','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',3);
            plot(uk{k+1}(1), uk{k+1}(2),'Marker','o','MarkerEdgeColor',[0.5 0.5 0.5],'MarkerFaceColor',[0.5 0.5 0.5],'MarkerSize',3);
            plot(uotpk{k+1}(1), uotpk{k+1}(2),'Marker','p','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',3);

%             text((minx+0.55*lenthx)  , -0.02*lenthy , ['\boldmath$k$=\boldmath$',num2str(k-1),'$'], 'VerticalAlignment','bottom','Color','w', 'Interpreter','latex','FontSize',10)

            set(gca,'FontSize', 9,'FontName','Helvetica');
            set(gca,'Color', 'w');
            set(gca,'Layer','Bottom');
            set(gca,'xticklabel',[],'yticklabel',[])
                        
        end
        
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=3; y_width=3;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        if Methode == KMFCpA
            print('-painters','-dpdf',['Mehtod_',num2str(Methode),'_Exemple_3_3_map_updated_model_k_',num2str(k-1)])
        else
            print('-painters','-dpdf',['Mehtod_',num2str(Methode),'_Exemple_3_2_map_updated_model_k_',num2str(k-1)])
        end
    end
    close all
end
%%

disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')



%% Plant & model functions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
function [phip, dphip] = u2phip(u)
    a = 3/2; b = -[4; 2];  C = [8 0 ; 0 4];
    phip  = a + b'*u + u'*C*u/2;
    dphip =     b   + C*u;
end
function [phi, dphi]   = u2phi(u) 
    a = 0;  b =-[0.1; 0.1];  C = [2 0 ; 0 2];
    phi  = a + b'*u + u'*C*u/2;
    dphi =     b   + C*u;
end
function [gp,dgp,ddgp] = u2gp(u)  
    a=-2;  b= [6; 10];  C=-[20 0; 0 36];
    gp    = a + b'*u + u'*C*u/2;
    dgp   =     b   +    C*u;
    ddgp  =              C;
end
function [g,dg,ddg]    = u2g(u)   
    a=-2;  b= [6; 10];  C=-[20 0; 0 36];
    g    = a + b'*u + u'*C*u/2;
    dg   =     b   +    C*u;
    ddg  =              C;
end

%% Nominal Opt Plant ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfunp(u)
    global Last_f
    ToDop(u)
    y = Last_f;
end
function [c,ceq] = constrp(u)
    global  Last_c Last_ceq 
    ToDop(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDop(u)  
    global Last_u Last_c Last_f Last_ceq 
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        phip = u2phip(u);
        gp   = u2gp(u);
        Last_u   = u;
        Last_f   = phip;
        Last_c   = gp;
        Last_ceq = [];
    end
end

%% Nominal Opt Model ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun(u)
    global Last_f
    ToDo(u)
    y = Last_f;
end
function [c,ceq] = constr(u)
    global  Last_c Last_ceq 
    ToDo(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo(u)  
    global Last_u Last_c Last_f Last_ceq
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        phi = u2phi(u);
        g   = u2g(u);
        Last_u   = u;
        Last_f   = phi;
        Last_c   = g;
        Last_ceq = [];
    end
end

%% MFCA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_MFCA(u)
    global Last_f
    ToDo_MFCA(u)
    y = Last_f;
end
function [c,ceq] = constr_MFCA(u)
    global  Last_c Last_ceq 
    ToDo_MFCA(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_MFCA(u)  
    global Last_u Last_c Last_f Last_ceq Modifiers
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        phi = u2phi(u);
        g   = u2g(u);
        % Apply an afine correction          
        phi = phi + Modifiers.lambda__phi' * (u - Modifiers.uk);
        if Modifiers.UseAfAprox == 1
            g = Modifiers.gp  + Modifiers.dgp' *(u-Modifiers.uk);
        else
            g  = g   + Modifiers.epsilon_g   + Modifiers.lambda__g' * (u - Modifiers.uk);
        end
        Last_u   = u;
        Last_f   = phi;
        Last_c   = g;
        Last_ceq = [];
    end
end

%% KMFCA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_KMFCA(u)
    global Last_f
    ToDo_KMFCA(u)
    y = Last_f;
end
function [c,ceq] = constr_KMFCA(u)
    global  Last_c Last_ceq 
    ToDo_KMFCA(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_KMFCA(u)  
    global Last_u Last_c Last_f Last_ceq Modifiers
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        phi = u2phi(u);
        g   = u2g(u);
        % Compute  filter
        k = Modifiers.k;
        if k == 1
            K = 0.1;
        else
            uk    = Modifiers.uk;
            ukm1  = Modifiers.ukm1;
            uoptk = Modifiers.uoptk;
            K_km1 = Modifiers.K_km1;
            if abs(uk-ukm1) > 1e-8
                NablaS = (uk-ukm1)'*(u-uoptk)/(norm(uk-ukm1)^2);
                if NablaS < 1
                    K = 1/(1-NablaS);
                else
                    K = 1;
                end
            else
                K = K_km1;
            end
        end
        u2 = Modifiers.uk + K*(u-Modifiers.uk);
        g2  = u2g(u2);
        g2  = g2   + Modifiers.epsilon_g   + Modifiers.lambda__g' * (u2 - Modifiers.uk);
        % Apply an afine correction          
        phi = phi + Modifiers.lambda__phi' * (u - Modifiers.uk);
        if Modifiers.UseAfAprox == 1
            g = Modifiers.gp  + Modifiers.dgp' *(u-Modifiers.uk);
        else
            g  = g   + Modifiers.epsilon_g   + Modifiers.lambda__g' * (u - Modifiers.uk);
        end
        Last_u   = u;
        Last_f   = phi;
        Last_c   = [g;g2;u2-1;-u2];
        Last_ceq = [];
    end
end

%% adKMA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_adKMA(u)
    global Last_f
    ToDo_adKMA(u)
    y = Last_f;
end
function [c,ceq] = constr_adKMA(u)
    global  Last_c Last_ceq 
    ToDo_adKMA(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_adKMA(u)  
    global Last_u Last_c Last_f Last_ceq Modifiers
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u_kp1^s and u_kp1
        phi = u2phi(u);
        g   = u2g(u);
        K   = Modifiers.K;
        u2  = Modifiers.uk + K*(u-Modifiers.uk);
        g2  = u2g(u2);
        % Apply an afine correction          
        phi = phi                       + Modifiers.lambda__phi'*(u - Modifiers.uk);
        g   = g   + Modifiers.epsilon_g + Modifiers.lambda__g'  *(u - Modifiers.uk);
        g2  = g2  + Modifiers.epsilon_g + Modifiers.lambda__g'  *(u2 - Modifiers.uk);
        % Return cost and constraints
        Last_u   = u;
        Last_f   = phi;
        Last_c   = [g;g2;u2-1;-u2];
        Last_ceq = [];
    end
end
   