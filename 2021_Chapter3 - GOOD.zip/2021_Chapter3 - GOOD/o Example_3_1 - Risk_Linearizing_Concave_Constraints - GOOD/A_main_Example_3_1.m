
clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

%% 
Results_file_name = 'Example_3_1';
global Last_u Last_c Last_f Last_ceq Modifiers

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% I.- Plot the model and plant's cost and constraint functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PHI  = [];
G    = [];
DG   = [];
DDG  = [];
PHIp = [];
Gp   = [];
DGp  = [];
DDGp = [];
X    = [];
for x = 0:0.01:1
    phi           = u2phi(x) ;
    [g,dg,ddg]    = u2g(x)   ;
    phip          = u2phip(x);
    [gp,dgp,ddgp] = u2gp(x)  ;
    PHI  = [PHI ; phi ];
    G    = [G   ; g   ];
    DG   = [DG  ; dg  ];
    DDG  = [DDG ; ddg ];
    PHIp = [PHIp; phip];
    Gp   = [Gp  ; gp  ];
    DGp  = [DGp ; dgp ];
    DDGp = [DDGp; ddgp];
    X    = [X   ; x   ];
end
%%
figure
hold on
plot(X,PHI , 'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(X,G   , 'r', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','r')
plot(X,PHIp, 'k:', 'LineStyle',':', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
plot(X,Gp  , 'r:', 'LineStyle',':', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','r')
% ylim([-10 10])
ylim([-2 5])

txt = '$\phi(u)$';
text(0.89,1.8,txt,'FontSize',9,'Color','k','Interpreter','LaTex')
txt = '$\phi_p(u)$';
text(0.88,0,txt,'FontSize',9,'Color','k','Interpreter','LaTex')
txt = '$g(u)$';
text(0.69,3.5,txt,'FontSize',9,'Color','r','Interpreter','LaTex')
txt = '$g_p(u)$';
text(0.89,3.5,txt,'FontSize',9,'Color','r','Interpreter','LaTex')

    hXLabel = xlabel('$u$');
    hYLabel = ylabel('$\phi(u)$ or $g(u)$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=8; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_1_Fonctions')
        
%% ***********************************************************************
% II.- Let's apply MFCA, KMFCA, and KMA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 1.- Initialisation (first point is the model's optimum)
NBiter = 25;
%% 2.- Algorithms
fmincon_options = optimoptions(@fmincon,'Algorithm','sqp' , ...
                                'MaxIter',100000,... 
                                'Display', 'off', ...'
                                'MaxFunEvals',100000,...
                                'TolFun',1e-9,...
                                'TolCon',1e-9,...
                                'TolX',1e-9,...
                                'FinDiffType','central' ,... 
                                'ScaleProblem','obj-and-constr');
Modifiers = struct();
Results   = struct();

Last_u = [];  Last_c   = [];
Last_f = [];  Last_ceq = [];
ub = 1;  Aeq = [];  A = [];
lb = 0;  beq = [];  b = [];

u(1) = fmincon(@(u)objfun(u),0.5, A, b, ...
         Aeq, beq, lb, ub, @(u)constr(u),fmincon_options);

u(1)                      
MFCA = 1; KMFCA = 2; adKMA = 3;
for Methode = [MFCA KMFCA adKMA] % MFCA - KMFCA - adKMA
    Last_u = -1;
    for k = 1:NBiter
        % 1) Compute the model's and plant's values end derivatives at uk. 
        [phi(k),  dphi(k) ]    = u2phi(u(k));
        [phip(k), dphip(k)]    = u2phip(u(k));
        [g(k),dg(k),ddg(k)]    = u2g(u(k));
        [gp(k),dgp(k),ddgp(k)] = u2gp(u(k));
        
        Modifiers.epsilon_g   = gp(k)    - g(k);
        Modifiers.lambda__g   = dgp(k)   - dg(k);
        Modifiers.lambda__phi = dphip(k) - dphi(k);
        Modifiers.gp          = gp(k);
        Modifiers.dgp         = dgp(k);
        Modifiers.uk          = u(k);
        if ddg(k) < 0 
            Modifiers.UseAfAprox  = 1;
        else
            Modifiers.UseAfAprox  = 0;
        end
        
        % 2) Select next iteration 
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        if Methode == MFCA
            for Hide_MFCA = 1 
                Last_u = [];  Last_c   = [];
                Last_f = [];  Last_ceq = [];
                ub = 1;  Aeq = [];  A = [];
                lb = 0;  beq = [];  b = [];
                uopt(k+1) = fmincon(@(u)objfun_MFCA(u),u(k), A, b, ...
                         Aeq, beq, lb, ub, @(u)constr_MFCA(u),fmincon_options);
                % 3) Apply filter
                if k == 1
                    K(k) = 0.1;
                else
                    if abs(u(k)-u(k-1)) > 1e-12
                        NablaS = (u(k)-u(k-1))'*(uopt(k+1)-uopt(k))/(norm(u(k)-u(k-1))^2);
                        if NablaS < 1
                            K(k) = 1/(1-NablaS);
                        else
                            K(k) = 1;
                        end
                    else
                        K(k) = K(k-1);
                    end
                end
                u(k+1) = u(k) + K(k)*(uopt(k+1)-u(k));
                disp(['u(',num2str(k),') = ',num2str(u(k))]);
            end
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        elseif Methode == KMFCA
            for Hide_KMFCA = 1
                Modifiers.k = k;
                if k > 1
                    Modifiers.ukm1  = u(k-1);
                    Modifiers.uoptk = uopt(k);
                    Modifiers.K_km1 = K(k-1);
                end
                Last_u = [];  Last_c   = [];
                Last_f = [];  Last_ceq = [];
                ub = 1;  Aeq = [];  A = [];
                lb = 0;  beq = [];  b = [];
                uopt(k+1) = fmincon(@(u)objfun_KMFCA(u),u(k), A, b, ...
                        Aeq, beq, lb, ub, @(u)constr_KMFCA(u),fmincon_options);
                if k == 1
                    K(k) = 0.1;
                else
                    if abs(u(k)-u(k-1)) > 1e-12
                        NablaS = (u(k)-u(k-1))'*(uopt(k+1)-uopt(k))/(norm(u(k)-u(k-1))^2);
                        if NablaS < 1
                            K(k) = 1/(1-NablaS);
                        else
                            K(k) = 1;
                        end
                    else
                        K(k) = K(k-1);
                    end
                end
                u(k+1) = u(k) + K(k)*(uopt(k+1)-u(k));
                disp(['u(',num2str(k),') = ',num2str(u(k))]);
            end
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        elseif Methode == adKMA
            for Hide_adKMA = 1
                Ktest = 0.1:0.1:2;
                MinDist=1e10;  flag=0;  NablaS=0; K(k)=0.1;
                for i = 1:length(Ktest)
                    Modifiers.K = Ktest(i);
                    Last_u = [];  Last_c   = [];
                    Last_f = [];  Last_ceq = [];
                    ub = 1;  Aeq = [];  A = [];
                    lb = 0;  beq = [];  b = [];
                    utest = fmincon(@(u)objfun_adKMA(u),u(k), A, b, ...
                        Aeq, beq, lb, ub, @(u)constr_adKMA(u),fmincon_options);
                    if k > 1 
                        if abs(u(k)-u(k-1)) > 1e-12
                            NablaS = (u(k)-u(k-1))'*(utest-uopt(k))/(norm(u(k)-u(k-1))^2);
                            if NablaS < 1
                                Kmax = 1/(1-NablaS);
                            else
                                Kmax = 1;
                            end
                        else
                            Kmax = K(k-1);
                        end
                    else
                        Kmax = 0.1;
                    end
                    if Ktest(i) <= Kmax && NablaS < 1
                        flag = 1;
                        if (1.15-2*Ktest(i)+Ktest(i)^2)*norm(utest-u(k)) <= MinDist 
                            MinDist = (1.15-2*Ktest(i)+Ktest(i)^2)*norm(utest-u(k)); 
                            K2       = Ktest(i);
                            uopt2    = utest;
                        end
                    else
                        K1       = Ktest(i);
                        uopt1    = utest;
                    end
                end
                if flag == 1
                    K(k)    = K2; 
                    uopt(k) = uopt2;
                else
                    K(k)    = K1; 
                    uopt(k) = uopt1;
                end
                u(k+1) = u(k) + K(k) * (uopt(k) - u(k));
            end
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        end
    end
    
    % Save Data
    Results.u{Methode}             = u;
    Results.gp{Methode}            = gp;
    Results.phip{Methode}          = phip;
    Results.K{Methode}             = K;
    Results.Modifiers_gp{Methode}  = gp;
    Results.Modifiers_dgp{Methode} = dgp;
    Results.Modifiers_uk{Methode}  = u;
    
    u = u(1);
    
end

ups = fmincon(@(u)objfunp(u),u(1), A, b, ...
           Aeq, beq, lb, ub, @(u)constrp(u),fmincon_options);
Results.phiopt =  u2phip(ups);
Results.gopt   =  u2gp(ups);
Results.ups    = ups; 

save(Results_file_name, 'Results')

%%
klim =16;
%%
figure
plot(0:klim-1, Results.u{MFCA}(1:klim),'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
hold on
plot(0:klim-1, Results.u{KMFCA}(1:klim),'k', 'LineStyle','-', 'LineWidth',3,'MarkerSize',5, 'MarkerFaceColor','k') 
% plot(0:klim-1, Results.u{adKMA}(1:klim),'b', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')   
plot([0 klim-1], Results.ups*[1 1],'g', 'LineStyle','--', 'LineWidth', 1,'MarkerSize',5, 'Color',[0.3 0.8 0.3])    
    ylim([0.2 1])
    yticks(0.2:0.2:1)
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$u$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_1_uk')
             
%%
figure

    y1 = [0 0]; y2 = [100 100];
    x = [0 klim-1]; 
    fill( [x fliplr(x)],  [y1 fliplr(y2)], [1 0.8 0.8],'EdgeColor','none');
    hold on
    plot(0:klim-1, Results.gp{MFCA}(1:klim),'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
    plot(0:klim-1, Results.gp{KMFCA}(1:klim),'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','m')
%     plot(0:klim-1, Results.gp{adKMA}(1:klim),'b', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','b')
    plot([0 klim-1], Results.gopt*[1 1],'g', 'LineStyle','--', 'LineWidth', 1,'MarkerSize',5, 'Color',[0.3 0.8 0.3]) 
    ylim([-2 8])
    % ylim([-7 74])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$g_p(u_k)$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
%         
%     ax=axes;
%     set(ax,'units','normalized','position',[0.7,0.3,0.15,0.3])
%     box(ax,'on')
%     fill( [x fliplr(x)],  [y1 fliplr(y2)], [1 0.7 0.7],'EdgeColor','none')
%     hold on
%     plot(0:klim-1, Results.gp{MFCA}(1:klim),'k-o','Color',[0.7 0.7 0.7],'LineWidth',1,'MarkerSize',1.5, 'MarkerFaceColor','k','MarkerEdgeColor','k','parent',ax)
%     plot(0:klim-1, Results.gp{KMFCA}(1:klim),'k','LineWidth',1,'parent',ax)
% %     plot(0:klim-1, Results.gp{adKMA}(1:klim),'b','LineWidth',1,'parent',ax)
%     plot([0 klim-1], Results.gopt*[1 1],'g--','Color',[0.3 0.8 0.3],'LineWidth',1,'parent',ax)
%     set(ax,'xlim',[0,10],'ylim',[-7,78]);
%         xticks([])
%         yticks([0 17 74])
%         set(gca,'FontSize',9);
%         set(gca,'FontName','Helvetica','TickLength',[.03 .03],'LineWidth',0.5);
        
        set(gca,'Layer','Top');
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_1_g_uk')

        %%
figure
plot(0:klim-1, Results.phip{MFCA}(1:klim),'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
hold on
plot(0:klim-1, Results.phip{KMFCA}(1:klim),'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','m')
% plot(0:klim-1, Results.phip{adKMA}(1:klim),'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','b')     
plot([0 klim-1], Results.phiopt*[1 1],'g', 'LineStyle','--', 'LineWidth', 1,'MarkerSize',5, 'Color',[0.3 0.8 0.3])     
    ylim([-1.5 3])
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$\phi_p(u_k)$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_1_phi_uk')
%%
figure
plot(0:klim-1, Results.K{MFCA}(1:klim),'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
hold on
plot(0:klim-1, Results.K{KMFCA}(1:klim),'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','m')
% plot(0:klim-1, Results.K{adKMA}(1:klim),'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','b')   
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$K_k$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_1_Kk')

%%
figure
plot(0:klim-1, log(abs(Results.u{MFCA}(1:klim)  - ups + 1e-15))/log(10),'Color',[0.7 0.7 0.7], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
hold on
plot(0:klim-1, log(abs(Results.u{KMFCA}(1:klim) - ups + 1e-15))/log(10),'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','m') 
% plot(0:klim-1, log(abs(Results.u{adKMA}(1:klim) - ups + 1e-15))/log(10),'b', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','b') 
    hXLabel = xlabel('Iterations');
    hYLabel = ylabel('$log_{10}(|u_k-u_p^{\star}|)$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gca, 'Position', [0.3, 0.3, 0.65, 0.65])
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.45; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple_3_1_log_uk')


%%

disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')



%% Plant & model functions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function [phip, dphip] = u2phip(u)
    a = 5; b = -14; c = 8;
    phip  = a + b*u + c*u^2;
    dphip =     b   + c*u*2;
end
function [phi, dphi]   = u2phi(u) 
    o = 0.2; 
    a = o^2*5; b = -2*o*5; c = 5;
    phi   = a + b*u + c*u^2;
    dphi  =     b   + c*u*2;
end
function [g,dg,ddg]    = u2g(u)   
%     a= -9;  b = 78.5; c = -320.83; d = 358.33;
    a= -1;  b = 9; c = -35; d = 40;
    g    = a-1 + b*u +   c*u^2 +     d*u^3;
    dg   =     b   + c*2*u   +   d*3*u^2;
    ddg  =           c*2     + d*3*2*u  ;
end
function [gp,dgp,ddgp] = u2gp(u)  
%     ap = -8; bp = 56.587; cp = -234.77; dp = 259.2;
    ap = -1; bp = 7; cp = -29; dp = 32;
    gp    = ap-1 + bp*u +   cp*u^2 +     dp*u^3;
    dgp   =      bp   + cp*2*u   +   dp*3*u^2;
    ddgp  =             cp*2     + dp*3*2*u  ;
end

%% MFCA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_MFCA(u)
    global Last_f
    ToDo_MFCA(u)
    y = Last_f;
end
function [c,ceq] = constr_MFCA(u)
    global  Last_c Last_ceq 
    ToDo_MFCA(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_MFCA(u)  
    global Last_u Last_c Last_f Last_ceq Modifiers
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        phi = u2phi(u);
        g   = u2g(u);
        % Apply an afine correction          
        phi = phi + Modifiers.lambda__phi' * (u - Modifiers.uk);
        if Modifiers.UseAfAprox == 1
            g = Modifiers.gp  + Modifiers.dgp *(u-Modifiers.uk);
        else
            g  = g   + Modifiers.epsilon_g   + Modifiers.lambda__g' * (u - Modifiers.uk);
        end
        Last_u   = u;
        Last_f   = phi;
        Last_c   = g;
        Last_ceq = [];
    end
end

%% KMFCA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_KMFCA(u)
    global Last_f
    ToDo_KMFCA(u)
    y = Last_f;
end
function [c,ceq] = constr_KMFCA(u)
    global  Last_c Last_ceq 
    ToDo_KMFCA(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_KMFCA(u)  
    global Last_u Last_c Last_f Last_ceq Modifiers
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        phi = u2phi(u);
        g   = u2g(u);
        % Compute  filter
        k = Modifiers.k;
        if k == 1
            K = 0.1;
        else
            uk    = Modifiers.uk;
            ukm1  = Modifiers.ukm1;
            uoptk = Modifiers.uoptk;
            K_km1 = Modifiers.K_km1;
            if abs(uk-ukm1) > 1e-8
                NablaS = (uk-ukm1)'*(u-uoptk)/(norm(uk-ukm1)^2);
                if NablaS < 1
                    K = 1/(1-NablaS);
                else
                    K = 1;
                end
            else
                K = K_km1;
            end
        end
        u2 = Modifiers.uk + K*(u-Modifiers.uk);
        g2  = u2g(u2);
        g2  = g2   + Modifiers.epsilon_g   + Modifiers.lambda__g' * (u2 - Modifiers.uk);
        % Apply an afine correction          
        phi = phi + Modifiers.lambda__phi' * (u - Modifiers.uk);
        if Modifiers.UseAfAprox == 1
            g = Modifiers.gp  + Modifiers.dgp *(u-Modifiers.uk);
        else
            g  = g   + Modifiers.epsilon_g   + Modifiers.lambda__g' * (u - Modifiers.uk);
        end
        Last_u   = u;
        Last_f   = phi;
        Last_c   = [g;g2;u2-1;-u2];
        Last_ceq = [];
    end
end

%% adKMA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun_adKMA(u)
    global Last_f
    ToDo_adKMA(u)
    y = Last_f;
end
function [c,ceq] = constr_adKMA(u)
    global  Last_c Last_ceq 
    ToDo_adKMA(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo_adKMA(u)  
    global Last_u Last_c Last_f Last_ceq Modifiers
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u_kp1^s and u_kp1
        phi = u2phi(u);
        g   = u2g(u);
        K   = Modifiers.K;
        u2  = Modifiers.uk + K*(u-Modifiers.uk);
        g2  = u2g(u2);
        % Apply an afine correction          
        phi = phi                       + Modifiers.lambda__phi'*(u - Modifiers.uk);
        g   = g   + Modifiers.epsilon_g + Modifiers.lambda__g'  *(u - Modifiers.uk);
        g2  = g2  + Modifiers.epsilon_g + Modifiers.lambda__g'  *(u2 - Modifiers.uk);
        % Return cost and constraints
        Last_u   = u;
        Last_f   = phi;
        Last_c   = [g;g2;u2-1;-u2];
        Last_ceq = [];
    end
end

%% Plant opt PB ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfunp(u)
    global Last_f
    ToDop(u)
    y = Last_f;
end
function [c,ceq] = constrp(u)
    global  Last_c Last_ceq 
    ToDop(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDop(u)  
    global Last_u Last_c Last_f Last_ceq 
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        phip = u2phip(u);
        gp   = u2gp(u);
        Last_u   = u;
        Last_f   = phip;
        Last_c   = gp;
        Last_ceq = [];
    end
end

%% Plant opt model  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function y       = objfun(u)
    global Last_f
    ToDo(u)
    y = Last_f;
end
function [c,ceq] = constr(u)
    global  Last_c Last_ceq 
    ToDo(u)
    c   = Last_c;
    ceq = Last_ceq;
end
function []      = ToDo(u)  
    global Last_u Last_c Last_f Last_ceq 
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        phip = u2phi(u);
        gp   = u2g(u);
        Last_u   = u;
        Last_f   = phip;
        Last_c   = gp;
        Last_ceq = [];
    end
end
