function out = draw_arrow(startpoint,endpoint)
    x1 = endpoint;
    x4 = [endpoint(1)-0.1*sign(endpoint(1)-startpoint(1)) endpoint(2)];
    x2 = [endpoint(1)-0.1*sign(endpoint(1)-startpoint(1)) endpoint(2)+0.8];
    x3 = [endpoint(1)-0.1*sign(endpoint(1)-startpoint(1)) endpoint(2)-0.8];
    hold on;
    fill([x1(1) x2(1) x3(1)],[x1(2) x2(2) x3(2)],[0.5 0.5 0.5],'EdgeColor','none');     % this fills the arrowhead (black)
    plot([startpoint(1) x4(1)],[startpoint(2) x4(2)],'linewidth',3,'color',[0.5 0.5 0.5]);
end
   
   
   
   
   
   
   
   