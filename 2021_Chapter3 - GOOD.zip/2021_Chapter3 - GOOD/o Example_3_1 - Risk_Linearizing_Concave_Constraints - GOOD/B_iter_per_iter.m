
clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic
%% 
load('Example_3_1.mat')
%%
MFCA = 1; KMFCA = 2; adKMA = 3;
for Methode = [MFCA KMFCA]% adKMA
    %% Which iterations should be ploted
    
    if     Methode == MFCA
        Kset = 1:7;
    elseif Methode ==  KMFCA
        Kset = 1:5;
    elseif Methode ==  adKMA
        Kset = 1:5;
    end
    
    for k = Kset
        
        %% Generate data 
        
        PHI  = [];
        Glin = [];
        G    = [];
        PHIp = [];
        Gp   = [];
        X    = [];
        uk   = Results.u{Methode}(k);
        ukp1 = Results.u{Methode}(k+1);
        Kk   = Results.K{Methode}(k);
        [phipk, dphipk] = u2phip(uk);
        [gpk,dgpk]      = u2gp(uk)  ;
        [phik, dphik]   = u2phi(uk);
        [gk,dgk,ddgk]        = u2g(uk)  ;
        
        for x = 0:0.01:1
            phi  = u2phi(x);
            g    = u2g(x)  ;
            phip = u2phip(x);
            gp   = u2gp(x);  
            
            phi_modif   = phi + (phipk-phik) + (dphipk-dphik)*(x-uk);
            g_modif_lin = gpk + dgpk*(x-uk); % Linearize constraint if locally concave
            g_modif     = g   +(gpk-gk) + (dgpk-dgk)*(x-uk);
            
            PHI  = [PHI ; phi_modif ];
            G    = [G   ; g_modif   ];
            Glin = [Glin; g_modif_lin   ];
            PHIp = [PHIp; phip ];
            Gp   = [Gp  ; gp   ];
            X    = [X   ; x   ];
        end
        
        %% Plot data 
        figure
        hold on
        
        % Vertical lines and arrow
        plot(  uk*[1 1], [-10 10], 'Color',[0.5 0.5 0.5], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','r')
        plot(ukp1*[1 1], [-10 10], 'Color',[0.5 0.5 0.5], 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','r')
        plot( (uk+(ukp1-uk)/Kk)*[1 1], [-10 10], 'g', 'LineStyle','--', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','r')
        draw_arrow([uk +3],[ukp1 +3])
        
        % Curves
        plot(X,PHI , 'k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
        if (Methode == MFCA && ddgk<=0) 
            plot(X,Glin, 'r', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','r')
            plot(X,G   , 'r', 'Color',[255 181 181]/255,'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','r')
        elseif (Methode == KMFCA && ddgk<=0)
             plot(X,Glin, 'r', 'Color','m', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','r')
            plot(X,G   , 'r', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','r')
        else
            plot(X,G   , 'r', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','r')
        end
        % Optional:
        % plot(X,PHIp , 'k', 'LineStyle',':', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
        % plot(X,Gp   , 'r', 'LineStyle',':', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','r')
        
        % Top right black box with k = ..
        ylim([-2.5 5])
        xlim([0 1])
        xl = xlim;
        yl = ylim;
        lenthx = xl(2)-xl(1);
        lenthy = yl(2)-yl(1);
        minx   = xl(1);
        miny   = yl(1);
        fill((minx+0.50*lenthx)+[0 0.50*lenthx  0.50*lenthx 0], miny+[0.85*lenthy 0.85*lenthy lenthy lenthy],'k','facealpha', 0.8,'edgecolor','none') 
        text((minx+0.55*lenthx)  , miny+0.83*lenthy , ['\boldmath$k$=\boldmath$',num2str(k-1),'$'], 'VerticalAlignment','bottom','Color','w', 'Interpreter','latex','FontSize',10)
        
        % Figure options
        hXLabel = xlabel('$u$');
        hYLabel = ylabel('$\phi_k(u)$ or $g_k(u)$');
            set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
            set(gca,'FontSize',10);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-dpdf',['Methode_',num2str(Methode),'_Exemple_3_1_Fonctions_Model_k_',num2str(k)])
    end
end

%% Close all at the end (comment to keep everything on display)
close all
%%

disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')



%% Plant & model functions ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function [phip, dphip] = u2phip(u)
    a = 5; b = -14; c = 8;
    phip  = a + b*u + c*u^2;
    dphip =     b   + c*u*2;
end
function [phi, dphi]   = u2phi(u) 
    o = 0.2; 
    a = o^2*5; b = -2*o*5; c = 5;
    phi   = a + b*u + c*u^2;
    dphi  =     b   + c*u*2;
end
function [g,dg,ddg]    = u2g(u)   
%     a= -9;  b = 78.5; c = -320.83; d = 358.33;
    a= -1;  b = 9; c = -35; d = 40;
    g    = a-1 + b*u +   c*u^2 +     d*u^3;
    dg   =     b   + c*2*u   +   d*3*u^2;
    ddg  =           c*2     + d*3*2*u  ;
end
function [gp,dgp,ddgp] = u2gp(u)  
%     ap = -8; bp = 56.587; cp = -234.77; dp = 259.2;
    ap = -1; bp = 7; cp = -29; dp = 32;
    gp    = ap-1 + bp*u +   cp*u^2 +     dp*u^3;
    dgp   =      bp   + cp*2*u   +   dp*3*u^2;
    ddgp  =             cp*2     + dp*3*2*u  ;
end
