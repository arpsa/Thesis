function [y_test,sy_test] = LinReg_predictions(DIII,id_cluster,x_test)
    %% Hyperparameters 
    L  = DIII.L;      %[ell1 0; 0 ell2];
    sf = DIII.sigmaf;
    
    %% Define some notations
    point = 0; derivative = 1;
    
    x            = DIII.Cluster{id_cluster}.x;
    y            = DIII.Cluster{id_cluster}.y;
    y_sigma      = DIII.Cluster{id_cluster}.y_sigma;
    dy_dv        = DIII.Cluster{id_cluster}.dy_dv;
    sigma_dy_dv  = DIII.Cluster{id_cluster}.sigma_dy_dv;
    v            = DIII.Cluster{id_cluster}.v;
    nx           = DIII.nx;
        
    %% Get the number of data in the  database
    if isempty(dy_dv) == 1
        if DIII.new == 1
            NB_Data_old = 0;
        else
            NB_Data_old = 1;
        end
    else
        NB_Data_old = 1+length(dy_dv);
    end
    NB_Data_new = 0; % no new data this time
    NB_Data = NB_Data_old + NB_Data_new;

        
    %% Structurat the data
    for i = 1:NB_Data_old
        if i == 1
            Data{i,1} = point; 
            Data{i,2} = x; 
            Data{i,3} = y_sigma; 
            Data{i,4} = y; 
        else
            Data{i,1} = derivative; 
            Data{i,2} = x; 
            Data{i,3} = sigma_dy_dv(i-1);
            Data{i,4} = dy_dv(i-1); 
            Data{i,5} = v(i-1,:); 
        end
    end
    
    %% kernel functions
    k_ff_ii = @(x1,x2,sigmay)        sf^2*exp(-1/2*(x1-x2)'*L*(x1-x2)) + sigmay^2; 
    k_DD_ii = @(x1,x2,v1,v2,sigmay)  v2*( L*(eye(nx)-(x1-x2)*(x1-x2)'*L)* k_ff_ii(x1,x2,sigmay) )*v1';  % < a checker !
    k_ff    = @(x1,x2)               sf^2*exp(-1/2*(x1-x2)'*L*(x1-x2));
    k_Df    = @(x1,x2,v)             v*( -L*(x1-x2)* k_ff(x1,x2) );
    k_fD    = @(x1,x2,v)             v*(  L*(x1-x2)* k_ff(x1,x2) );
    k_DD    = @(x1,x2,v1,v2)         v2*( L*(eye(nx)-(x1-x2)*(x1-x2)'*L)* k_ff(x1,x2) )*v1';  % < a checker !

%     k_ff_ii = @(x1,x2,sigmay)       (x1-x)*(x2-x)'  + sf^2*exp(-1/2*(x1-x2)'*L*(x1-x2)) + sigmay^2; 
%     k_DD_ii = @(x1,x2,v1,v2,sigmay) v1*v2'          + v2*( L*(eye(nx)-(x1-x2)*(x1-x2)'*L)* k_ff_ii(x1,x2,sigmay) )*v1';  % < a checker !
%     k_ff    = @(x1,x2)              (x1-x)*(x2-x)' + sf^2*exp(-1/2*(x1-x2)'*L*(x1-x2));
%     k_Df    = @(x1,x2,v)            v*(x2-x)'       + v*( -L*(x1-x2)* k_ff(x1,x2) );
%     k_fD    = @(x1,x2,v)            v*(x1-x)'       + v*(  L*(x1-x2)* k_ff(x1,x2) );
%     k_DD    = @(x1,x2,v1,v2)        v1*v2'          + v2*( L*(eye(nx)-(x1-x2)*(x1-x2)'*L)* k_ff(x1,x2) )*v1';  % < a checker !
    
    
    
    %% Build design vector & kernel matrix:
    NB_Data
    for i = 1:NB_Data
        % design vector:
        Y_dY(i,1) = Data{i,4};
        % kernel matrix
        for j = i:NB_Data
            if i == j
                if  Data{i,1} == point &&  Data{j,1} == point 
                    C(i,j) = k_ff_ii(Data{i,2}, Data{j,2},                       Data{i,3});
                    
                elseif Data{i,1} == point &&  Data{i,1} == derivative 
                    disp('Impossible -- A point can''t be a value and a derivative')
                    C(i,j) = k_fD_ii(Data{i,2}, Data{j,2},                       Data{i,3});
                    
                elseif Data{i,1} == derivative &&  Data{i,1} == point
                    disp('Impossible -- A point can''t be a value and a derivative')
                    C(i,j) = k_Df_ii(Data{i,2}, Data{j,2},                       Data{i,3});
                    
                elseif Data{i,1} == derivative &&  Data{i,1} == derivative
                    C(i,j) = k_DD_ii(Data{i,2}, Data{j,2}, Data{i,5}, Data{j,5}, Data{i,3});
                end
            else
                if  Data{i,1} == point &&  Data{j,1} == point 
                    C(i,j) = k_ff(Data{i,2},Data{j,2});
                    
                elseif Data{i,1} == point &&  Data{j,1} == derivative 
                    C(i,j) = k_fD(Data{i,2},Data{j,2},Data{j,5});
                    
                elseif Data{i,1} == derivative &&  Data{j,1} == point 
                    C(i,j) = k_Df(Data{i,2},Data{j,2},Data{i,5});
                    
                elseif Data{i,1} == derivative &&  Data{j,1} == derivative
                    C(i,j) = k_DD(Data{i,2},Data{j,2},Data{i,5},Data{j,5});
                end
            end
            C(j,i) = C(i,j);
        end
    end
    C_m1 = inv(C);
    
    
    %% Predict value at x_test
    % Build C*
    c_ss  = k_ff(x_test,x_test);
%     for i = 1:nx 
%         va         = [zeros(1,i-1), 1, zeros(1,nx-i)];
%         k_fD(x_test,x_test,va)
%         bc_ss(i,1) = k_fD(x_test,x_test,va);
%         for j = 1:nx
%             vb         = [zeros(1,j-1), 1, zeros(1,nx-j)];
%             bC_ss(i,j) = k_DD(x_test,x_test,va,vb);
%         end
%     end 
%     C_ss = [c_ss , bc_ss';
%             bc_ss, bC_ss];
        
    for i = 1:NB_Data
        for j = 1:1
            
            if       j == 1    &&   Data{i,1} == point
                C_s(i,j) =   k_ff(x_test,Data{i,2});
                
            elseif   j == 1    &&   Data{i,1} == derivative 
                C_s(i,j) =   k_fD(x_test,Data{i,2},Data{i,5});
            end
        end       
    end
    
    
    y_test  = C_s'*C_m1*Y_dY; 
    sy_test = sqrt(c_ss - C_s'*C_m1*C_s);
    
        
    
    
    
end