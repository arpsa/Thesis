clear all
close all
clc
disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
disp(' ')
%% 

% addpath('F') 

    %% Hyperparameters 
DIII.L      = 1/(12^2);      % 1D
DIII.sigmaf = 100;

DIII.Cluster{1}.x           = [];
DIII.Cluster{1}.y           = [];
DIII.Cluster{1}.y_sigma     = [];
DIII.Cluster{1}.dy_dv       = [];
DIII.Cluster{1}.sigma_dy_dv = [];
DIII.Cluster{1}.v           = [];
DIII.Cluster{1}.nbpts       = 0;
DIII.nx                     = 1;
        
Xstack = [];
Ystack = [];
for k = 1:10
    % Get a new point
    x = normrnd(0,1/2);
    y = f_x(x) + normrnd(0,0.1);
    Xstack = [Xstack;x];
    Ystack = [Ystack;y];
    
    % Insert in DIII
    DIII.Cluster{1}.X       = x;
    DIII.Cluster{1}.Y       = y ;
    DIII.Cluster{1}.Y_sigma = 0.1;
    % Regression
    if k == 1
        DIII.new = 1;
    else
        DIII.new = 0;
    end
    [DIII_new] = LinReg(DIII,1);
        DIII     = DIII_new;
        DIII.new = 0;
    
    DIII.Cluster{1}.nbpts = DIII.Cluster{1}.nbpts+1;  % <<<<< not used
        
        % Prediction:
        u_test = -1:0.1:1;
        for i = 1:length(u_test)
            [Ey(i),sy] = LinReg_predictions(DIII,1,u_test(i));
            ub(i)      =  2*sy;
            lb(i)      = -2*sy;
            y_real(i)  = f_x(u_test(i));
        end
        
    %% plot figure
        figure
        hold on 
        plot(u_test,Ey,'k--')
        plot(u_test,Ey+ub,'k:')
        plot(u_test,Ey+lb,'k:')
        plot(u_test,y_real,'b-')
        xlim([-1 1])
        ylim([-1.5 1.5])
        for ii = 1:k
           plot(Xstack(ii,1), Ystack(ii,1),'bo')
        end
        title(['At k = ',num2str(k)])
    
%     SAVE_sigma_dy_dv(k) = DIII.Cluster{1}.sigma_dy_dv;
    SAVE_y_sigma(k) = DIII.Cluster{1}.y_sigma;
end
%%
figure
plot(SAVE_y_sigma)
ylabel('sigma_y^2')
xlabel('nb pts')


function y = f_x(x)
    y = x-1;
end