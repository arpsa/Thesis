function DIII_new = LinReg(DIII,id_cluster)
    %% Hyperparameters 
    L  = DIII.L;      %[ell1 0; 0 ell2];
    sf = DIII.sigmaf;
    
    %% Name the new data
    X       = DIII.Cluster{id_cluster}.X;
    Y       = DIII.Cluster{id_cluster}.Y;
    Y_sigma = DIII.Cluster{id_cluster}.Y_sigma;
    %% Define some notations
    point = 0; derivative = 1;
    
%     if DIII.new == 0
        x            = DIII.Cluster{id_cluster}.x;
        y            = DIII.Cluster{id_cluster}.y;
        y_sigma      = DIII.Cluster{id_cluster}.y_sigma;
        dy_dv        = DIII.Cluster{id_cluster}.dy_dv;
        sigma_dy_dv  = DIII.Cluster{id_cluster}.sigma_dy_dv;
        v            = DIII.Cluster{id_cluster}.v;
        nx           = DIII.nx;
        
        
        %% Calcule du barycentre sur x: 
        if DIII.new == 1
            x_mean = X;
        else
            nbpts = DIII.Cluster{1}.nbpts;
%             y_sigma = y_sigma/nbpts;
            x_mean = (X*Y_sigma + x*nbpts*y_sigma)/(Y_sigma+nbpts*y_sigma);
        end
        
        %% Get the number of data in the "old" database
        if isempty(dy_dv) == 1
            if DIII.new == 1
                NB_Data_old = 0;
            else
                NB_Data_old = 1;
            end
        else
            NB_Data_old = 1+length(dy_dv);
        end
        NB_Data_new = 1;
        NB_Data = NB_Data_old + NB_Data_new;
    
        
        %% Structurat the data
        for i = 1:NB_Data_old
            if i == 1
                Data{i,1} = point; 
                Data{i,2} = x; 
                Data{i,3} = y_sigma; 
                Data{i,4} = y; 
            else
                Data{i,1} = derivative; 
                Data{i,2} = x; 
                Data{i,3} = sigma_dy_dv(i-1);
                Data{i,4} = dy_dv(i-1); 
                Data{i,5} = v(i-1,:); 
            end
        end
        
        %% Add the new point to this structure
        if NB_Data_old == 0
            i = 1;
        else
            i = i+1;
        end
        Data{i,1} = point; 
        Data{i,2} = X; 
        Data{i,3} = Y_sigma;
        Data{i,4} = Y;
        
    %% kernel functions
    k_ff_ii = @(x1,x2,sigmay)         sf^2*exp(-1/2*(x1-x2)'*L*(x1-x2)) + sigmay^2; 
    k_DD_ii = @(x1,x2,v1,v2,sigmay)   v2*( L*(eye(nx)-(x1-x2)*(x1-x2)'*L)* k_ff_ii(x1,x2,sigmay) )*v1';  % < a checker !
    k_ff    = @(x1,x2)                sf^2*exp(-1/2*(x1-x2)'*L*(x1-x2));
    k_Df    = @(x1,x2,v)              v*( -L*(x1-x2)* k_ff(x1,x2) );
    k_fD    = @(x1,x2,v)              v*(  L*(x1-x2)* k_ff(x1,x2) );
    k_DD    = @(x1,x2,v1,v2)          v2*( L*(eye(nx)-(x1-x2)*(x1-x2)'*L)* k_ff(x1,x2) )*v1';  % < a checker !
    
%     k_ff_ii = @(x1,x2,sigmay)       (x1-x_mean)*(x2-x_mean)' + sf^2*exp(-1/2*(x1-x2)'*L*(x1-x2)) + sigmay^2; 
%     k_DD_ii = @(x1,x2,v1,v2,sigmay) v1*v2'                   + v2*( L*(eye(nx)-(x1-x2)*(x1-x2)'*L)* k_ff_ii(x1,x2,sigmay) )*v1';  % < a checker !
%     k_ff    = @(x1,x2)              (x1-x_mean)*(x2-x_mean)' + sf^2*exp(-1/2*(x1-x2)'*L*(x1-x2));
%     k_Df    = @(x1,x2,v)            v*(x2-x_mean)'           + v*( -L*(x1-x2)* k_ff(x1,x2) );
%     k_fD    = @(x1,x2,v)            v*(x1-x_mean)'           + v*(  L*(x1-x2)* k_ff(x1,x2) );
%     k_DD    = @(x1,x2,v1,v2)        v1*v2'                   + v2*( L*(eye(nx)-(x1-x2)*(x1-x2)'*L)* k_ff(x1,x2) )*v1';  % < a checker !
    
    
    %% Build design vector & kernel matrix:
    for i = 1:NB_Data
        % design vector:
        Y_dY(i,1) = Data{i,4};
        % kernel matrix
        for j = i:NB_Data
            if i == j
                if  Data{i,1} == point &&  Data{j,1} == point 
                    C(i,j) = k_ff_ii(Data{i,2}, Data{j,2},                       Data{i,3});
                    
                elseif Data{i,1} == point &&  Data{i,1} == derivative 
                    disp('Impossible -- A point can''t be a value and a derivative')
                    C(i,j) = k_fD_ii(Data{i,2}, Data{j,2},                       Data{i,3});
                    
                elseif Data{i,1} == derivative &&  Data{i,1} == point
                    disp('Impossible -- A point can''t be a value and a derivative')
                    C(i,j) = k_Df_ii(Data{i,2}, Data{j,2},                       Data{i,3});
                    
                elseif Data{i,1} == derivative &&  Data{i,1} == derivative
                    C(i,j) = k_DD_ii(Data{i,2}, Data{j,2}, Data{i,5}, Data{j,5}, Data{i,3});
                end
            else
                if  Data{i,1} == point &&  Data{j,1} == point 
                    C(i,j) = k_ff(Data{i,2},Data{j,2});
                    
                elseif Data{i,1} == point &&  Data{j,1} == derivative 
                    C(i,j) = k_fD(Data{i,2},Data{j,2},Data{j,5});
                    
                elseif Data{i,1} == derivative &&  Data{j,1} == point 
                    C(i,j) = k_Df(Data{i,2},Data{j,2},Data{i,5});
                    
                elseif Data{i,1} == derivative &&  Data{j,1} == derivative
                    C(i,j) = k_DD(Data{i,2},Data{j,2},Data{i,5},Data{j,5});
                end
            end
            C(j,i) = C(i,j);
        end
    end
    C_m1 = inv(C);
    
    
    %% Predict value and gradient at x_mean
    % Build C*
    c_ss  = k_ff(x_mean,x_mean);
    for i = 1:nx 
        va         = [zeros(1,i-1), 1, zeros(1,nx-i)];
        k_fD(x_mean,x_mean,va)
        bc_ss(i,1) = k_fD(x_mean,x_mean,va);
        for j = 1:nx
            vb         = [zeros(1,j-1), 1, zeros(1,nx-j)];
            bC_ss(i,j) = k_DD(x_mean,x_mean,va,vb);
        end
    end 
    C_ss = [c_ss , bc_ss';
            bc_ss, bC_ss];
        
    for i = 1:NB_Data
        for j = 1:(nx+1)
            
            if       j == 1    &&   Data{i,1} == point
                C_s(i,j) =   k_ff(x_mean,Data{i,2});
                
            elseif   j == 1    &&   Data{i,1} == derivative 
                C_s(i,j) =   k_fD(x_mean,Data{i,2},Data{i,5});
                
            elseif   j >  1    &&   Data{i,1} == point
                v = [zeros(1,j-1-1), 1, zeros(1,nx-j+1)];
                C_s(i,j) =   k_Df(x_mean,Data{i,2},v);
                
            elseif   j >  1    &&   Data{i,1} == derivative
                v = [zeros(1,j-1-1), 1, zeros(1,nx-j+1)];
                C_s(i,j) =   k_DD(x_mean,Data{i,2},v,Data{i,5});
            end
        end       
    end
    
    
    Eresult = C_s'*C_m1*Y_dY; 
    Vresult = C_ss - C_s'*C_m1*C_s;
    DIII_new = DIII;
        DIII_new.Cluster{id_cluster}.x       = x_mean;
        DIII_new.Cluster{id_cluster}.y       = Eresult(1);
        DIII_new.Cluster{id_cluster}.y_sigma = sqrt(Vresult(1,1));
        
    %% Get the directions of interet:
    % Let's define some usefull objects ... 
    dy_dx = Eresult(2:end);
    SIGMA = Vresult(2:end,2:end);
    
    gamma = 1;
    
    [V,D] = eig(sf^2*L - gamma*SIGMA); % D: Diagonal matrix with eigenvalues
                                       % V: Column vector with eigenvalues
    % Extract directions of interest
    v_save = [];    dy_dv_save = [];  sigma_dy_dv_save = [];
    for i = 1:nx
        if D(i,i) >= 0
            v_interest       = V(:,i);
            dy_dv_save       = [dy_dv_save; v_interest'*dy_dx];
            sigma_dy_dv_save = [sigma_dy_dv_save; sqrt(v_interest'*SIGMA*v_interest)];
            v_save           = [v_save; v_interest'];
        end 
    end
    
    % Save new data
    
    DIII_new.Cluster{id_cluster}.dy_dv       = dy_dv_save;
    DIII_new.Cluster{id_cluster}.sigma_dy_dv = sigma_dy_dv_save;
    DIII_new.Cluster{id_cluster}.v           = v_save;
    

%     else % if DIII_new ==1 
%         
%     %% The point is the new database ... 
%     
%     DIII_new = DIII;
%         DIII_new.Cluster{id_cluster}.x           = X;
%         DIII_new.Cluster{id_cluster}.y           = Y;
%         DIII_new.Cluster{id_cluster}.y_sigma     = Y_sigma;
%         DIII_new.Cluster{id_cluster}.dy_dv       = [];
%         DIII_new.Cluster{id_cluster}.sigma_dy_dv = [];
%         DIII_new.Cluster{id_cluster}.v           = [];
%         
%     end
    
    
    
end