function [u, eflag, outpt] = RunOptimization(u0, uk, lambda,LAMBDA,delta,theta, opts)

Last_u   = [];
Last_f   = [];
Last_c   = []; % Attention c is not the input of the plant but the NL constraint !!
Last_ceq = [];

%%%%%%%%%%%%%%%  

lb = -1.5;
% lb = -0.5;
ub = 2.5;

Aeq = [];  
beq = [];

A = [];
b = [];

%%%%%%%%%%%%%%%  

[u, eflag, outpt] = fmincon(@(u)objfun(u, uk,lambda,LAMBDA,delta,theta),...
                                u0, A, b, Aeq, beq, lb, ub, ...
                                @(u)constr(u,uk, lambda,LAMBDA,delta,theta),opts);

    function y = objfun(u, uk,lambda,LAMBDA, delta,theta)
        if ~isequal(u,Last_u) % Check if computation is necessary
            phi_m = model(u,theta) + lambda*(u-uk) + (LAMBDA+ delta)*(u-uk)^2;
            Last_u   = u;
            Last_f   = phi_m;
            Last_c   = [];
            Last_ceq = [];
        end
        y = Last_f;
    end

    function [c,ceq] = constr(u, uk,lambda,LAMBDA,delta,theta)
        if ~isequal(u,Last_u) % Check if computation is necessary
            phi_m = model(u,theta) + lambda*(u-uk)+ (LAMBDA+ delta)*(u-uk)^2;
            Last_u   = u;
            Last_f   = phi_m;
            Last_c   = [];
            Last_ceq = [];
        end
        c   = Last_c;
        ceq = Last_ceq;
    end

end