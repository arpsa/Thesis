function [phi, Dphi, DDphi] = model(u,theta)
    phi   = theta* u.^2;
    Dphi  = theta* u.*2;
    DDphi = theta    *2;
end