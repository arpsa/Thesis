clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic

% format shortEng

%% Code architecture initialization & Output files 
addpath('Functions')

Results_file_name = 'Results_Main';

%% Tuning paramters


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  0.- Initialization of the algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 0.1.- Parameter defined by the user
u_max  =  2.5;
u_min  = -1.5;
NB= 100;
uu = u_min:0.01:u_max;


% 0.2.- Simulations parameters
PBstruct = ProblemStructure();        % options for solver | nb iterations
    fmincon_options = PBstruct.fmincon_options;
    fsolve_options  = PBstruct.fsolve_options;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  1.- Algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Save Results
Results  = struct();
struct_Y = struct();

% KKopt(1) = k;

Modifiers = struct();
delta = 0;
        EstimateDDp_MAX = 0;
        
        theta = 1/4;
for k = 1:length(uu)
    uk = uu(k);
    disp(num2str(uk))
    %% 1.- Do experiment
    [phi_k,  Dphi_k,  DDphi_k(k) ] = model(uk,theta);
    [phi_pk, Dphi_pk, DDphi_pk(k)] = plant(uk);
    %% 2.- Compute modifiers
    lambda = Dphi_pk - Dphi_k;
    %% 3.- Estimer manellement Hessien
    h = 0.5;
    sigma = 0.02;
    DDphi_pk_est(k) = ( plant(uk + h)+(rand*sigma-sigma/2)  - ...
                        2*(plant(uk)+ (rand*sigma-sigma/2)) + ...
                        plant(uk - h)+(rand*sigma-sigma/2)) / h^2;
    LAMBDA = DDphi_pk(k) - DDphi_k(k) ;
    uopt(k)  = RunOptimization(uk-5, uk, lambda,LAMBDA, delta,theta, fmincon_options);
    uopt2(k)  = RunOptimization(uk+5, uk, lambda,LAMBDA, delta,theta, fmincon_options);
    
    LAMBDAest = DDphi_pk_est(k) - DDphi_k(k) ;
    uoptest(k) = RunOptimization(uk-5, uk, lambda,LAMBDAest, delta,theta, fmincon_options);
    uoptest2(k) = RunOptimization(uk+5, uk, lambda,LAMBDAest, delta,theta, fmincon_options);
    %% 3.- Compute next point
%     uopt(k)  = RunOptimization(uk+0.0001, uk, lambda,LAMBDA, delta,theta, fmincon_options);
end
%%





%% COURBE GLOBALE
figure
%     ups = 1;
%     x = 0.5:0.01:1.5;
%     FK_1   = max(x(1),min(  (1-2/1)  *(x-ups)+ups  ,x(end)));
%     FK_0_9 = max(x(1),min(  (1-2/0.9)*(x-ups)+ups  ,x(end)));
%     FK_0_8 = max(x(1),min(  (1-2/0.8)*(x-ups)+ups  ,x(end)));
%     FK_0_7 = max(x(1),min(  (1-2/0.7)*(x-ups)+ups  ,x(end)));
%     FK_0_6 = max(x(1),min(  (1-2/0.6)*(x-ups)+ups  ,x(end)));
%     FK_0_5 = max(x(1),min(  (1-2/0.5)*(x-ups)+ups  ,x(end)));
%     FK_0_4 = max(x(1),min(  (1-2/0.4)*(x-ups)+ups  ,x(end)));
%     FK_0_3 = max(x(1),min(  (1-2/0.3)*(x-ups)+ups  ,x(end)));
%     FK_0_2 = max(x(1),min(  (1-2/0.2)*(x-ups)+ups  ,x(end)));
%     FK_0_1 = max(x(1),min(  (1-2/0.1)*(x-ups)+ups  ,x(end)));
%     FK_0_0 = max(x(1),min(  (1-2/0.00001)*(x-ups)+ups  ,x(end)));
%     hold on
%     patch([x fliplr(x)], [x(end)*ones(size(x)) fliplr(x(1)*ones(size(x)))], [255 181  181]/255,'LineStyle','none')
%     patch([x fliplr(x)], [x      fliplr(FK_1)  ],       [197     224      180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_1   fliplr(FK_0_9)],       [220+  5 224+  3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_9 fliplr(FK_0_8)],       [220+2*5 230+2*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_8 fliplr(FK_0_7)],       [220+3*5 230+3*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_7 fliplr(FK_0_6)],       [220+4*5 230+4*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_6 fliplr(FK_0_5)],       [220+5*5 230+5*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_5 fliplr(FK_0_4)],       [220+6*5 230+6*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_4 fliplr(FK_0_3)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_3 fliplr(FK_0_2)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_2 fliplr(FK_0_1)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_1 fliplr(FK_0_0)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    % ********************
    ups = 2;
    x = 1.5:0.01:2.5;
    FK_1   = max(x(1),min(  (1-2/1)  *(x-ups)+ups  ,x(end)));
    FK_0_9 = max(x(1),min(  (1-2/0.9)*(x-ups)+ups  ,x(end)));
    FK_0_8 = max(x(1),min(  (1-2/0.8)*(x-ups)+ups  ,x(end)));
    FK_0_7 = max(x(1),min(  (1-2/0.7)*(x-ups)+ups  ,x(end)));
    FK_0_6 = max(x(1),min(  (1-2/0.6)*(x-ups)+ups  ,x(end)));
    FK_0_5 = max(x(1),min(  (1-2/0.5)*(x-ups)+ups  ,x(end)));
    FK_0_4 = max(x(1),min(  (1-2/0.4)*(x-ups)+ups  ,x(end)));
    FK_0_3 = max(x(1),min(  (1-2/0.3)*(x-ups)+ups  ,x(end)));
    FK_0_2 = max(x(1),min(  (1-2/0.2)*(x-ups)+ups  ,x(end)));
    FK_0_1 = max(x(1),min(  (1-2/0.1)*(x-ups)+ups  ,x(end)));
    FK_0_0 = max(x(1),min(  (1-2/0.00001)*(x-ups)+ups  ,x(end)));
    hold on
    patch([x fliplr(x)], [x(end)*ones(size(x)) fliplr(x(1)*ones(size(x)))], [255 181  181]/255,'LineStyle','none')
    patch([x fliplr(x)], [x      fliplr(FK_1)  ],       [197     224      180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_1   fliplr(FK_0_9)],       [220+  5 224+  3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_9 fliplr(FK_0_8)],       [220+2*5 230+2*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_8 fliplr(FK_0_7)],       [220+3*5 230+3*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_7 fliplr(FK_0_6)],       [220+4*5 230+4*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_6 fliplr(FK_0_5)],       [220+5*5 230+5*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_5 fliplr(FK_0_4)],       [220+6*5 230+6*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_4 fliplr(FK_0_3)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_3 fliplr(FK_0_2)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_2 fliplr(FK_0_1)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_1 fliplr(FK_0_0)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    % ********************
%     ups = 0;
%     x = [-0.5:0.01:0.5]+ups;
%     FK_1   = max(x(1),min(  (1-2/1)  *(x-ups)+ups  ,x(end)));
%     FK_0_9 = max(x(1),min(  (1-2/0.9)*(x-ups)+ups  ,x(end)));
%     FK_0_8 = max(x(1),min(  (1-2/0.8)*(x-ups)+ups  ,x(end)));
%     FK_0_7 = max(x(1),min(  (1-2/0.7)*(x-ups)+ups  ,x(end)));
%     FK_0_6 = max(x(1),min(  (1-2/0.6)*(x-ups)+ups  ,x(end)));
%     FK_0_5 = max(x(1),min(  (1-2/0.5)*(x-ups)+ups  ,x(end)));
%     FK_0_4 = max(x(1),min(  (1-2/0.4)*(x-ups)+ups  ,x(end)));
%     FK_0_3 = max(x(1),min(  (1-2/0.3)*(x-ups)+ups  ,x(end)));
%     FK_0_2 = max(x(1),min(  (1-2/0.2)*(x-ups)+ups  ,x(end)));
%     FK_0_1 = max(x(1),min(  (1-2/0.1)*(x-ups)+ups  ,x(end)));
%     FK_0_0 = max(x(1),min(  (1-2/0.00001)*(x-ups)+ups  ,x(end)));
%     hold on
%     patch([x fliplr(x)], [x(end)*ones(size(x)) fliplr(x(1)*ones(size(x)))], [255 181  181]/255,'LineStyle','none')
%     patch([x fliplr(x)], [x      fliplr(FK_1)  ],       [197     224      180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_1   fliplr(FK_0_9)],       [220+  5 224+  3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_9 fliplr(FK_0_8)],       [220+2*5 230+2*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_8 fliplr(FK_0_7)],       [220+3*5 230+3*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_7 fliplr(FK_0_6)],       [220+4*5 230+4*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_6 fliplr(FK_0_5)],       [220+5*5 230+5*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_5 fliplr(FK_0_4)],       [220+6*5 230+6*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_4 fliplr(FK_0_3)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_3 fliplr(FK_0_2)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_2 fliplr(FK_0_1)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_1 fliplr(FK_0_0)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    % ********************
    ups = -1;
    x = [-0.5:0.01:0.5]+ups;
    FK_1   = max(x(1),min(  (1-2/1)  *(x-ups)+ups  ,x(end)));
    FK_0_9 = max(x(1),min(  (1-2/0.9)*(x-ups)+ups  ,x(end)));
    FK_0_8 = max(x(1),min(  (1-2/0.8)*(x-ups)+ups  ,x(end)));
    FK_0_7 = max(x(1),min(  (1-2/0.7)*(x-ups)+ups  ,x(end)));
    FK_0_6 = max(x(1),min(  (1-2/0.6)*(x-ups)+ups  ,x(end)));
    FK_0_5 = max(x(1),min(  (1-2/0.5)*(x-ups)+ups  ,x(end)));
    FK_0_4 = max(x(1),min(  (1-2/0.4)*(x-ups)+ups  ,x(end)));
    FK_0_3 = max(x(1),min(  (1-2/0.3)*(x-ups)+ups  ,x(end)));
    FK_0_2 = max(x(1),min(  (1-2/0.2)*(x-ups)+ups  ,x(end)));
    FK_0_1 = max(x(1),min(  (1-2/0.1)*(x-ups)+ups  ,x(end)));
    FK_0_0 = max(x(1),min(  (1-2/0.00001)*(x-ups)+ups  ,x(end)));
    hold on
    patch([x fliplr(x)], [x(end)*ones(size(x)) fliplr(x(1)*ones(size(x)))], [255 181  181]/255,'LineStyle','none')
    patch([x fliplr(x)], [x      fliplr(FK_1)  ],       [197     224      180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_1   fliplr(FK_0_9)],       [220+  5 224+  3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_9 fliplr(FK_0_8)],       [220+2*5 230+2*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_8 fliplr(FK_0_7)],       [220+3*5 230+3*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_7 fliplr(FK_0_6)],       [220+4*5 230+4*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_6 fliplr(FK_0_5)],       [220+5*5 230+5*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_5 fliplr(FK_0_4)],       [220+6*5 230+6*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_4 fliplr(FK_0_3)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_3 fliplr(FK_0_2)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_2 fliplr(FK_0_1)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_1 fliplr(FK_0_0)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    
    
    
    
    plot(uu(1:330),uopt(1:330) ,'k-'    , 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
    plot(uu(331:end),uopt(331:end) ,'k-'    , 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
    
    plot(uu(1:80),uopt2(1:80) ,'k-'   , 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
    plot(uu(81:end),uopt2(81:end) ,'k-'   , 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
    
    plot(uu(1:321),uoptest(1:321),'b-'  , 'Color','b', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor','k')
    plot(uu(322:end),uoptest(322:end),'b-'  , 'Color','b', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor','k')
    plot(uu(1:88),uoptest2(1:88),'b-' , 'Color','b', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor','k')
    plot(uu(89:end),uoptest2(89:end),'b-' , 'Color','b', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor','k')
    
    
    plot(-1, -1 ,'ko-'   , 'Color','k', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',4, 'MarkerFaceColor','k')
    plot(2, 2 ,'ko-'   , 'Color','k', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',4, 'MarkerFaceColor','k')
    plot(uu,uu ,'k-'   , 'Color','k', 'LineStyle',':', 'LineWidth', 0.5,'MarkerSize',5, 'MarkerFaceColor','k')
    ylim([-1.6 2.6])
    xlim([-1.6 2.6])
    hXLabel = xlabel('$u_k$');
    hYLabel = ylabel('$sol(u_k)$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=9; y_width=4.5;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple2_LocalCone_perfectHessian')

        
        
%%      
figure
%     ups = 1;
%     x = 0.5:0.01:1.5;
%     FK_1   = max(x(1),min(  (1-2/1)  *(x-ups)+ups  ,x(end)));
%     FK_0_9 = max(x(1),min(  (1-2/0.9)*(x-ups)+ups  ,x(end)));
%     FK_0_8 = max(x(1),min(  (1-2/0.8)*(x-ups)+ups  ,x(end)));
%     FK_0_7 = max(x(1),min(  (1-2/0.7)*(x-ups)+ups  ,x(end)));
%     FK_0_6 = max(x(1),min(  (1-2/0.6)*(x-ups)+ups  ,x(end)));
%     FK_0_5 = max(x(1),min(  (1-2/0.5)*(x-ups)+ups  ,x(end)));
%     FK_0_4 = max(x(1),min(  (1-2/0.4)*(x-ups)+ups  ,x(end)));
%     FK_0_3 = max(x(1),min(  (1-2/0.3)*(x-ups)+ups  ,x(end)));
%     FK_0_2 = max(x(1),min(  (1-2/0.2)*(x-ups)+ups  ,x(end)));
%     FK_0_1 = max(x(1),min(  (1-2/0.1)*(x-ups)+ups  ,x(end)));
%     FK_0_0 = max(x(1),min(  (1-2/0.00001)*(x-ups)+ups  ,x(end)));
%     hold on
%     patch([x fliplr(x)], [x(end)*ones(size(x)) fliplr(x(1)*ones(size(x)))], [255 181  181]/255,'LineStyle','none')
%     patch([x fliplr(x)], [x      fliplr(FK_1)  ],       [197     224      180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_1   fliplr(FK_0_9)],       [220+  5 224+  3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_9 fliplr(FK_0_8)],       [220+2*5 230+2*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_8 fliplr(FK_0_7)],       [220+3*5 230+3*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_7 fliplr(FK_0_6)],       [220+4*5 230+4*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_6 fliplr(FK_0_5)],       [220+5*5 230+5*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_5 fliplr(FK_0_4)],       [220+6*5 230+6*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_4 fliplr(FK_0_3)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_3 fliplr(FK_0_2)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_2 fliplr(FK_0_1)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_1 fliplr(FK_0_0)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    % ********************
    ups = 2;
    x = 1.5:0.01:2.5;
    FK_1   = max(x(1),min(  (1-2/1)  *(x-ups)+ups  ,x(end)));
    FK_0_9 = max(x(1),min(  (1-2/0.9)*(x-ups)+ups  ,x(end)));
    FK_0_8 = max(x(1),min(  (1-2/0.8)*(x-ups)+ups  ,x(end)));
    FK_0_7 = max(x(1),min(  (1-2/0.7)*(x-ups)+ups  ,x(end)));
    FK_0_6 = max(x(1),min(  (1-2/0.6)*(x-ups)+ups  ,x(end)));
    FK_0_5 = max(x(1),min(  (1-2/0.5)*(x-ups)+ups  ,x(end)));
    FK_0_4 = max(x(1),min(  (1-2/0.4)*(x-ups)+ups  ,x(end)));
    FK_0_3 = max(x(1),min(  (1-2/0.3)*(x-ups)+ups  ,x(end)));
    FK_0_2 = max(x(1),min(  (1-2/0.2)*(x-ups)+ups  ,x(end)));
    FK_0_1 = max(x(1),min(  (1-2/0.1)*(x-ups)+ups  ,x(end)));
    FK_0_0 = max(x(1),min(  (1-2/0.00001)*(x-ups)+ups  ,x(end)));
    hold on
    patch([x fliplr(x)], [x(end)*ones(size(x)) fliplr(x(1)*ones(size(x)))], [255 181  181]/255,'LineStyle','none')
    patch([x fliplr(x)], [x      fliplr(FK_1)  ],       [197     224      180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_1   fliplr(FK_0_9)],       [220+  5 224+  3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_9 fliplr(FK_0_8)],       [220+2*5 230+2*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_8 fliplr(FK_0_7)],       [220+3*5 230+3*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_7 fliplr(FK_0_6)],       [220+4*5 230+4*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_6 fliplr(FK_0_5)],       [220+5*5 230+5*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_5 fliplr(FK_0_4)],       [220+6*5 230+6*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_4 fliplr(FK_0_3)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_3 fliplr(FK_0_2)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_2 fliplr(FK_0_1)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_1 fliplr(FK_0_0)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    % ********************
%     ups = 0;
%     x = [-0.5:0.01:0.5]+ups;
%     FK_1   = max(x(1),min(  (1-2/1)  *(x-ups)+ups  ,x(end)));
%     FK_0_9 = max(x(1),min(  (1-2/0.9)*(x-ups)+ups  ,x(end)));
%     FK_0_8 = max(x(1),min(  (1-2/0.8)*(x-ups)+ups  ,x(end)));
%     FK_0_7 = max(x(1),min(  (1-2/0.7)*(x-ups)+ups  ,x(end)));
%     FK_0_6 = max(x(1),min(  (1-2/0.6)*(x-ups)+ups  ,x(end)));
%     FK_0_5 = max(x(1),min(  (1-2/0.5)*(x-ups)+ups  ,x(end)));
%     FK_0_4 = max(x(1),min(  (1-2/0.4)*(x-ups)+ups  ,x(end)));
%     FK_0_3 = max(x(1),min(  (1-2/0.3)*(x-ups)+ups  ,x(end)));
%     FK_0_2 = max(x(1),min(  (1-2/0.2)*(x-ups)+ups  ,x(end)));
%     FK_0_1 = max(x(1),min(  (1-2/0.1)*(x-ups)+ups  ,x(end)));
%     FK_0_0 = max(x(1),min(  (1-2/0.00001)*(x-ups)+ups  ,x(end)));
%     hold on
%     patch([x fliplr(x)], [x(end)*ones(size(x)) fliplr(x(1)*ones(size(x)))], [255 181  181]/255,'LineStyle','none')
%     patch([x fliplr(x)], [x      fliplr(FK_1)  ],       [197     224      180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_1   fliplr(FK_0_9)],       [220+  5 224+  3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_9 fliplr(FK_0_8)],       [220+2*5 230+2*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_8 fliplr(FK_0_7)],       [220+3*5 230+3*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_7 fliplr(FK_0_6)],       [220+4*5 230+4*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_6 fliplr(FK_0_5)],       [220+5*5 230+5*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_5 fliplr(FK_0_4)],       [220+6*5 230+6*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_4 fliplr(FK_0_3)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_3 fliplr(FK_0_2)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_2 fliplr(FK_0_1)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
%     patch([x fliplr(x)], [FK_0_1 fliplr(FK_0_0)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    % ********************
    ups = -1;
    x = [-0.5:0.01:0.5]+ups;
    FK_1   = max(x(1),min(  (1-2/1)  *(x-ups)+ups  ,x(end)));
    FK_0_9 = max(x(1),min(  (1-2/0.9)*(x-ups)+ups  ,x(end)));
    FK_0_8 = max(x(1),min(  (1-2/0.8)*(x-ups)+ups  ,x(end)));
    FK_0_7 = max(x(1),min(  (1-2/0.7)*(x-ups)+ups  ,x(end)));
    FK_0_6 = max(x(1),min(  (1-2/0.6)*(x-ups)+ups  ,x(end)));
    FK_0_5 = max(x(1),min(  (1-2/0.5)*(x-ups)+ups  ,x(end)));
    FK_0_4 = max(x(1),min(  (1-2/0.4)*(x-ups)+ups  ,x(end)));
    FK_0_3 = max(x(1),min(  (1-2/0.3)*(x-ups)+ups  ,x(end)));
    FK_0_2 = max(x(1),min(  (1-2/0.2)*(x-ups)+ups  ,x(end)));
    FK_0_1 = max(x(1),min(  (1-2/0.1)*(x-ups)+ups  ,x(end)));
    FK_0_0 = max(x(1),min(  (1-2/0.00001)*(x-ups)+ups  ,x(end)));
    hold on
    patch([x fliplr(x)], [x(end)*ones(size(x)) fliplr(x(1)*ones(size(x)))], [255 181  181]/255,'LineStyle','none')
    patch([x fliplr(x)], [x      fliplr(FK_1)  ],       [197     224      180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_1   fliplr(FK_0_9)],       [220+  5 224+  3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_9 fliplr(FK_0_8)],       [220+2*5 230+2*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_8 fliplr(FK_0_7)],       [220+3*5 230+3*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_7 fliplr(FK_0_6)],       [220+4*5 230+4*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_6 fliplr(FK_0_5)],       [220+5*5 230+5*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_5 fliplr(FK_0_4)],       [220+6*5 230+6*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_4 fliplr(FK_0_3)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_3 fliplr(FK_0_2)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_2 fliplr(FK_0_1)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    patch([x fliplr(x)], [FK_0_1 fliplr(FK_0_0)],       [220+7*5 230+7*3  180]/255,'LineStyle','none')
    
    
    
    
    plot(uu(1:330),uopt(1:330) ,'k-'    , 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
    plot(uu(331:end),uopt(331:end) ,'k-'    , 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
    
    plot(uu(1:80),uopt2(1:80) ,'k-'   , 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
    plot(uu(81:end),uopt2(81:end) ,'k-'   , 'Color','k', 'LineStyle','-', 'LineWidth', 2,'MarkerSize',5, 'MarkerFaceColor','k')
    
    plot(uu(1:321),uoptest(1:321),'b-'  , 'Color','b', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor','k')
    plot(uu(322:end),uoptest(322:end),'b-'  , 'Color','b', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor','k')
    plot(uu(1:88),uoptest2(1:88),'b-' , 'Color','b', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor','k')
    plot(uu(89:end),uoptest2(89:end),'b-' , 'Color','b', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',5, 'MarkerFaceColor','k')
    
    
    plot(-1, -1 ,'ko-'   , 'Color','k', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',4, 'MarkerFaceColor','k')
    plot(2, 2 ,'ko-'   , 'Color','k', 'LineStyle','-', 'LineWidth', 1,'MarkerSize',4, 'MarkerFaceColor','k')
    plot(uu,uu ,'k-'   , 'Color','k', 'LineStyle',':', 'LineWidth', 0.5,'MarkerSize',5, 'MarkerFaceColor','k')
    ylim([-1.5 -0.5])
    xlim([-1.5 -0.5])
    hXLabel = xlabel('$u_k$');
    hYLabel = ylabel('$sol(u_k)$');
        set([hXLabel, hYLabel],'FontSize', 10 ,'Interpreter','LaTex');
        set(gca,'FontSize',10);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
        set(gcf, 'PaperUnits', 'centimeters');
        x_width=4.35; y_width=4.5;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf','Exemple2_LocalCone_perfectHessian_2')
        
        %%
 figure
 plot(uu, (DDphi_pk - DDphi_pk_est)   )
%  DDphi_pk(k)] = plant(uk);
%     %% 2.- Compute modifiers
%     lambda = Dphi_pk - Dphi_k;
%     %% 3.- Estimer manellement Hessien
%     h = 0.5;
%     sigma = 0.02;
    
%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')