clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
disp(' ')

global Last_u Last_c Last_f Last_ceq ... Global variables of the optimiser
       Theta Theta_P ... Parameters of the model and plant
       DIII
addpath('Functions') 
addpath('Model') 

SimName = 'Opt1_Sc2';

Enabled  = 1;  Disabled  = []; Necessary  = 1; Yes = 1; No = 0;
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% I.- Initialisation 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for Hide_Initialisation = Necessary %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
    for Simulation_Parameters = Necessary  
    % 0.1.- Solver's parameters 
    fsolve_options = ...
        optimset( 'Algorithm','trust-region-reflective',...levenberg-marquardt     trust-region-reflective
                  'LargeScale','on',...
                  'Diagnostics','off',...
                  'Display','off' ,...  final
                  'FunValCheck','on',...
                  'MaxFunEvals',100000,...
                  'MaxIter',100000,...
                  'TolFun',1e-9, ...
                  'TolX',1e-9, ...
                  'TolCon',1e-9);
    % 0.2.- Starting point: The plant starts at the optimum of the model
    x0 = [0.0954210512900398,0.495389198230272,0.0202316625316664,0.292316782869007,0.0221713337472192,0.0744699713317962,0.0975846325572503,0.506621728875040,0.0206905240004531,0.298944662726475,0.0761584518407816,0.102318284476230,0.531197018221757,0.0216941751485505,0.313445929230421,0.0313445929230421,0.102318284468528,0.531197018272062,0.0216941753629298,0.313445928996801,0.0313445928996801];
    x0 = x0';
    % 0.3.- Optimizer's parameters   
    fmincon_options = ...
    optimoptions(@fmincon,'Algorithm','sqp' , ... interior-point sqp active-set  !!! Don't use sqp: it could try inputs out of the boundaries => make the model crash
                          'MaxIter',1000000,... 
                          'Display', 'off', ...   final off iter
                          'MaxFunEvals',100000,...
                          'TolFun',1e-10,... 
                          'TolCon',1e-10,...
                          'TolX',1e-10,...
                          'FinDiffType','central'); % ,... % ,...%'forward' (default), or 'central' 
%                           'ScaleProblem','obj-and-constr');
    end   %%%%%%%%%%%%%%%%%%%%%%%%
    for Generate_Model_plant  = Necessary  
        Theta_P = init_SetParameters('Plant');
        Theta   = init_SetParameters('Model');
        nu = 1; % 1 manipulated variable
        nx = 2; % 1 manipulated variable + 1 perturbation
        nf = 3; % 3 functions to correct
    end   %%%%%%%%%%%%%%%%%%%%%%%%
    for Model_Hyperparameters = Necessary  
        ell1{1} = 4;    ell1{2} = 4;    ell1{3} = 4;
        ell2{1} = 0.5;    ell2{2} = 0.5;    ell2{3} = 0.5;
    end   %%%%%%%%%%%%%%%%%%%%%%%%
    for Assumption_Plant      = Necessary  
        sigmaf{1} =  1/2;  sigmaf{2} =  1/2;  sigmaf{3} =  2/2; 
        % Part 2 of max gradient:
        f_b2{1} = 3*sigmaf{1}/(sqrt(2))*[ell1{1}^(-1); ell2{1}^(-1)];
        f_b2{2} = 3*sigmaf{2}/(sqrt(2))*[ell1{2}^(-1); ell2{2}^(-1)];
        f_b2{3} = 3*sigmaf{3}/(sqrt(2))*[ell1{3}^(-1); ell2{3}^(-1)];
    end   %%%%%%%%%%%%%%%%%%%%%%%%
    for Initial_perturbation  = Necessary  
        d0 = 0;    dk{1} = d0; 
    end   %%%%%%%%%%%%%%%%%%%%%%%%
    for Nominal_Optimisation  = Necessary  
        for Initialise_the_solver = 1       
            u0  = 15;
            ubs = 20;  A   = []; b   = [];
            lbs = 10;  Aeq = []; beq = [];  
            Last_u = []; Last_c = []; Last_f = []; Last_ceq = [];
        end
        for Solve_the_model       = 1       
            % Set the pertubation to its initial value          
            disturbance_nom.tspand = [0,1];     
            disturbance_nom.dspan  = d0*[1,1];
            % Initial estimate of the error function
            Ee0 = [0;0;0]; Ve0 = [sigmaf{1}^2;sigmaf{2}^2;sigmaf{3}^2];
            Ve0 = [0;0;0]; % <-- For this problem there is no "danger" in 
                           % violating the constraints (for a limited time)
            % Optimal operating condition:
            [us,~,exitflag,~,lambda] = ...
                fmincon(@(u)opt_objfunp(u,disturbance_nom,Ee0,Ve0,Theta),u0,A,b,Aeq,beq,lbs,ubs,@(u)opt_constrp(u,disturbance_nom,Ee0,Ve0,Theta),fmincon_options);
            if    exitflag == 0
                disp('Nominal Model optimization: The solver stopped before converging')
            elseif exitflag < 0
                disp('Nominal Model optimization: The solver failed to find a solution')
            end
            % Initial operating condition
            uk{1} = us(1);
        end
        for Plot_initial_view     = Enabled 
            figure(7)
            for Evaluate_model_plant_correction_functions = Enabled 
                disturbance_now.tspand = [0,1];
                disturbance_now.dspan  = dk{1}*[1 1];
                disturbance_now.tspand_alpha  = [0,1];
                disturbance_now.dspan_alpha   = 0.5499*[1 1];
                umin = 10; umax = 20; nb_test = 50;
                u_test = umin:(umax-umin)/(nb_test-1):umax;
                for i = 1:length(u_test)
                    % evaluate model
                    x_sol = fsolve(@(x) Sim_WOprocess(0, x, u_test(i) ,disturbance_now, Theta), x0, fsolve_options);
                    [~,y]          = Sim_WOprocess(0, x_sol, u_test(i) ,disturbance_now, Theta);
                    [g(i), phi(i)] = opt_uy2gphi(u_test(i),y,[0;0;0],[0;0;0]);
                    y1(i)          = y(1);   y2(i) = y(2);   y3(i) = y(3); 
                    % with the uncertainty
                    Ee = [0;0;0]; Ve = [sigmaf{1}^2;sigmaf{2}^2;sigmaf{3}^2];
                    [h_0(i),varphi_0(i),var_varphi_0(i), var_h_0(i)] = opt_uy2gphi(u_test(i),y,Ee,Ve);
                    y1_corr(i)   = Ee(1)              ;   y2_corr(i)   = Ee(2)              ;   y3_corr(i)   = Ee(3);
                    y1_corr_p(i) = Ee(1)+2*Ve(1)^(1/2);   y2_corr_p(i) = Ee(2)+2*Ve(2)^(1/2);   y3_corr_p(i) = Ee(3)+2*Ve(3)^(1/2); 
                    y1_corr_m(i) = Ee(1)-2*Ve(1)^(1/2);   y2_corr_m(i) = Ee(2)-2*Ve(2)^(1/2);   y3_corr_m(i) = Ee(3)-2*Ve(3)^(1/2);
                    % evaluate plant
                    x_sol             = fsolve(@(x) Sim_WOprocess(0, x, u_test(i) ,disturbance_now, Theta_P), x0, fsolve_options);
                    [~,yp]            = Sim_WOprocess(0, x_sol, u_test(i) ,disturbance_now, Theta_P);
                    [g_p(i),phi_p(i)] = opt_uy2gphi(u_test(i),yp,[0;0;0],[0;0;0]);
                    y1p(i)            = yp(1);   y2p(i) = yp(2);   y3p(i) = yp(3); 

                end
            end  
            for plot_Y1  = Enabled  
                subplot(2,5,1)
                hold off
                    % function
                    X=[u_test,fliplr(u_test)];                
                    Y=[y1_corr_p+y1,fliplr(y1_corr_m+y1)] ;             
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
                    hold on 
                    plot(u_test,y1,'k--')
                    plot(u_test,(y1_corr+y1),'k-')
                    plot(u_test,y1p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$u [t/h]$');
                    hYLabel = ylabel('$y_{(1)}$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
            end  
            for plot_Y2  = Enabled  
                subplot(2,5,2)
                hold off
                    % functions
                    X=[u_test,fliplr(u_test)];                
                    Y=[y2_corr_p+y2,fliplr(y2_corr_m+y2)];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
                    hold on 
                    plot(u_test,y2,'k--')
                    plot(u_test,(y2_corr+y2),'k-')
                    plot(u_test,y2p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$u [t/h]$');
                    hYLabel = ylabel('$y_{(2)}$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
            end  
            for plot_Y3  = Enabled  
                subplot(2,5,3)
                hold off
                    % functions
                    X=[u_test,fliplr(u_test)];                
                    Y=[y3_corr_p+y3,fliplr(y3_corr_m+y3)];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none'); 
                    hold on 
                    plot(u_test,y3,'k--')
                    plot(u_test,(y3_corr+y3),'k-')
                    plot(u_test,y3p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$u [t/h]$');
                    hYLabel = ylabel('$y_{(3)}$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
            end
            for plot_phi = Enabled  
                subplot(2,5,4)
                    hold off
                    % functions
                    X=[u_test,fliplr(u_test)];                
                    Y=[varphi_0+2*var_varphi_0.^(1/2),fliplr(varphi_0-2*var_varphi_0.^(1/2))];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none'); 
                    hold on 
                    plot(u_test,phi,'k--')
                    plot(u_test,varphi_0,'k-')
                    plot(u_test,phi_p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$u [t/h]$');
                    hYLabel = ylabel('$\phi$ [\$/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
            end
            for plot_g   = Enabled  
                subplot(2,5,5)
                hold off
                    % functions
                    X=[u_test,fliplr(u_test)];                
                    Y=[h_0,fliplr(h_0-4*var_h_0.^(1/2))];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none'); 
                    hold on 
                    plot(u_test,g,'k--')
                    plot(u_test,(h_0-2*var_h_0.^(1/2)),'k-')
                    plot(u_test,g_p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$u [t/h]$');
                    hYLabel = ylabel('$g$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');

            end
        % Plot xxx w.r.t. d
            for Evaluate_model_plant_correction_functions = Enabled 
                u_test = uk{1};
                dmin = -1; dmax = 1; nb_test = 50;
                d_test = dmin:(dmax-dmin)/(nb_test-1):dmax;
                for i = 1:length(d_test)
                    disturbance_now.tspand = [0,1];
                    disturbance_now.dspan  = d_test(i)*[1 1];
                    % evaluate model
                    x_sol          = fsolve(@(x) Sim_WOprocess(0, x, u_test ,disturbance_now, Theta), x0, fsolve_options);
                    [~,y]          = Sim_WOprocess(0, x_sol, u_test ,disturbance_now, Theta);
                    [g(i), phi(i)] = opt_uy2gphi(u_test,y,[0;0;0],[0;0;0]);
                    y1(i)          = y(1);   y2(i) = y(2);   y3(i) = y(3); 
                    % evaluate correction function
                    Ee = [0;0;0]; Ve = [sigmaf{1}^2;sigmaf{2}^2;sigmaf{3}^2];
                    [h_0(i),varphi_0(i),var_varphi_0(i), var_h_0(i)] = opt_uy2gphi(u_test,y,Ee,Ve);
                    y1_corr(i)   = Ee(1)              ;   y2_corr(i)   = Ee(2)              ;   y3_corr(i)   = Ee(3);
                    y1_corr_p(i) = Ee(1)+2*Ve(1)^(1/2);   y2_corr_p(i) = Ee(2)+2*Ve(2)^(1/2);   y3_corr_p(i) = Ee(3)+2*Ve(3)^(1/2); 
                    y1_corr_m(i) = Ee(1)-2*Ve(1)^(1/2);   y2_corr_m(i) = Ee(2)-2*Ve(2)^(1/2);   y3_corr_m(i) = Ee(3)-2*Ve(3)^(1/2);
                    % evaluate plant
                    x_sol = fsolve(@(x) Sim_WOprocess(0, x, u_test ,disturbance_now, Theta_P), x0, fsolve_options);
                    [~,yp] = Sim_WOprocess(0, x_sol, u_test ,disturbance_now, Theta_P);
                    [g_p(i), phi_p(i) ] = opt_uy2gphi(u_test,yp,[0;0;0],[0;0;0]); 
                    y1p(i) = yp(1);   y2p(i) = yp(2);   y3p(i) = yp(3); 
                end
            end  
            for plot_Y1  = Enabled  
                subplot(2,5,6)
                hold off
                    % function
                    X=[d_test,fliplr(d_test)];                
                    Y=[y1_corr_p+y1,fliplr(y1_corr_m+y1)];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
                    hold on 
                    plot(d_test,y1,'k--')
                    plot(d_test,(y1_corr+y1),'k-')
                    plot(d_test,y1p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$d [t/h]$');
                    hYLabel = ylabel('$y_{(1)}$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');

            end  
            for plot_Y2  = Enabled  
                subplot(2,5,7)
                hold off
                    % functions
                    X=[d_test,fliplr(d_test)];                
                    Y=[y2_corr_p+y2,fliplr(y2_corr_m+y2)];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
                    hold on 
                    plot(d_test,y2,'k--')
                    plot(d_test,(y2_corr+y2),'k-')
                    plot(d_test,y2p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$d [t/h]$');
                    hYLabel = ylabel('$y_{(2)}$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
            end  
            for plot_Y3  = Enabled  
                subplot(2,5,8)
                hold off
                    % functions
                    X=[d_test,fliplr(d_test)];                
                    Y=[y3_corr_p+y3,fliplr(y3_corr_m+y3)];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none'); 
                    hold on 
                    plot(d_test,y3,'k--')
                    plot(d_test,(y3_corr+y3),'k-')
                    plot(d_test,y3p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$d [th]$');
                    hYLabel = ylabel('$y_{(3)}$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
            end
            for plot_phi = Enabled  
                subplot(2,5,9)
                    hold off
                    % functions
                    X=[d_test,fliplr(d_test)];                
                    Y=[varphi_0+2*var_varphi_0.^(1/2),fliplr(varphi_0-2*var_varphi_0.^(1/2))];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none'); 
                    hold on 
                    plot(d_test,phi,'k--')
                    plot(d_test,varphi_0,'k-')
                    plot(d_test,phi_p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$d [t/h]$');
                    hYLabel = ylabel('$\phi$ [\$/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');

            end
            for plot_g   = Enabled  
                subplot(2,5,10)
                hold off
                    % functions
                    X=[d_test,fliplr(d_test)];                
                    Y=[h_0,fliplr(h_0-4*var_h_0.^(1/2))];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none'); 
                    hold on 
                    plot(d_test,g,'k--')
                    plot(d_test,(h_0-2*var_h_0.^(1/2)),'k-')
                    plot(d_test,g_p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$d [t/h]$');
                    hYLabel = ylabel('$g$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');

            end
            
            
            for Save_Figure_7 = 1  
                figure(7)
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=23; y_width=9;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_GP_view_k_0'])
            end
        end  
        for Solve_the_plant       = 1  
                   
            disturbance_nom.tspand_alpha = [0,1];     
            disturbance_nom.dspan_alpha  = 0.5499*[1,1];
            
            % No error
            Ee0p = [0;0;0]; Ve0p = [0;0;0];
            [us_best,~,exitflag,~,lambda_best] = ...
                fmincon(@(u)opt_objfunp(u,disturbance_nom,Ee0p,Ve0p,Theta_P),u0,A,b,Aeq,beq,lbs,ubs,@(u)opt_constrp(u,disturbance_nom,Ee0p,Ve0p,Theta_P),fmincon_options);
            if    exitflag == 0
                disp('Nominal Plant optimization: The solver stopped before converging')
            elseif exitflag < 0
                disp('Nominal Plant optimization: The solver failed to find a solution')
            end
            % Best initial operating condition:
            uk_best{1} =us_best(1);
        end            
    end   %%%%%%%%%%%%%%%%%%%%%%%% 
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% II.- ASP 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for Create_DIII                 = Necessary  
    % Initialise statistical database:
    DII = struct();
    DIII = ResetDIII(ell1,ell2,sigmaf,nx,nu,nf);
%     % Initialisation of Compressed Database:
%     DIII{1} = struct();
%         % Plant hyperparameters 
%         DIII{1}.ell1 = ell1{1};   DIII{1}.ell2 = ell2{1}; 
%         DIII{2}.ell1 = ell1{2};   DIII{2}.ell2 = ell2{2}; 
%         DIII{3}.ell1 = ell1{3};   DIII{3}.ell2 = ell2{3};    
%         DIII{1}.L = diag([ell1{1}^(-2); ell2{1}^(-2)]);  
%         DIII{2}.L = diag([ell1{2}^(-2); ell2{2}^(-2)]);  
%         DIII{3}.L = diag([ell1{3}^(-2); ell2{3}^(-2)]);
%         DIII{1}.sf = sigmaf{1};  DIII{2}.sf = sigmaf{2};  DIII{3}.sf = sigmaf{3}; 
%         % A priori affine domain dimentions
%         DIII{1}.a1 = ell1{1}/6*1/2;  DIII{1}.a2 = ell2{1}/6*1/2;    
%         DIII{2}.a1 = ell1{2}/6*1/2;  DIII{2}.a2 = ell2{2}/6*1/2;    
%         DIII{3}.a1 = ell1{3}/6*1/2;  DIII{3}.a2 = ell2{3}/6*1/2;
%         DIII{1}.A = [DIII{1}.a1,DIII{1}.a2];
%         DIII{2}.A = [DIII{2}.a1,DIII{2}.a2];
%         DIII{3}.A = [DIII{3}.a1,DIII{3}.a2];
%         % Initialise the clusters
%         DIII{1}.nbCluster = 0;     
%         DIII{1}.Cluster{1}.X_centerS     = [];
%         DIII{1}.Cluster{1}.Y_centerS     = [];
%         DIII{1}.Cluster{1}.Y_var_centerS = []; 
%         DIII{1}.Cluster{1}.X_point       = [];
%         DIII{1}.Cluster{1}.Y_point       = [];
%         DIII{1}.Cluster{1}.Y_var_point   = []; 
%         DIII{1}.Cluster{1}.X_both        = [];
%         DIII{1}.Cluster{1}.Y_both        = [];
%         DIII{1}.Cluster{1}.Y_var_both    = [];
%         % Just to know:
%         DIII{1}.Cluster{1}.nbpts           = 0;
%         % For regression
%         DIII{1}.inv_C   = [];
%         DIII{1}.yp_m_y  = []; % <<<<<<<<<<
%         DIII{1}.Data    = [];   
%         % PB informations
%         for i = 1:nf
%             DIII{i}.nbCluster = 0;  
%             DIII{i}.nx  = nx;
%             DIII{i}.nu  = nu;
%             DIII{i}.ny  = nf;
%             if i > 1
%                 DIII{i}.Cluster{1} = DIII{1}.Cluster{1};
%             end
%         end           
end %%%%%%%%%%%%%%%%%%%%%%%%% 
for Initialise_figure_Real_time = Necessary  
    % Real Time variables
    RT_t    = []; RT_t_best    = [];     
    RT_FB   = []; RT_FB_best   = [];  
    RT_FG   = []; RT_FG_best   = [];  
    RT_FP   = []; RT_FP_best   = []; 
    RT_FD   = []; RT_FD_best   = [];   
    RT_cost = []; RT_cost_best = []; 
    RT_FA   = []; RT_valve = [];
    RT_losses = [];
    RT_FAn = [];  
    RT_FBn = [];   
    RT_FGn = [];
    RT_FPn = [];
    RT_FDn = [];
    %
    f1 = figure(1); f2 = figure(2); f3 = figure(3); f4 = figure(4); f5 = figure(5); f6 = figure(6);
    f1.Position(1) = 450*0; f1.Position(2) = 100+340; f1.Position(3) = 450; f1.Position(4) = 300;
    f2.Position(1) = 450*1; f2.Position(2) = 100+340; f2.Position(3) = 450; f2.Position(4) = 300;
    f3.Position(1) = 450*2; f3.Position(2) = 100+340; f3.Position(3) = 450; f3.Position(4) = 300;
    f4.Position(1) = 450*0; f4.Position(2) = 100;     f4.Position(3) = 450; f4.Position(4) = 300;
    f5.Position(1) = 450*1; f5.Position(2) = 100;     f5.Position(3) = 450; f5.Position(4) = 300;
    f6.Position(1) = 450*2; f6.Position(2) = 100;     f6.Position(3) = 450; f6.Position(4) = 300;
    
    % Number of points to plot on figure 7
    nb_observation = 0;
    SAVE_uk = [];  SAVE_y1k = [];  SAVE_y3k = [];  SAVE_phik = [];
    SAVE_dk = [];  SAVE_y2k = [];  SAVE_gk  = [];
    SAVE_tk = [];  SAVE_modek = [];
end %%%%%%%%%%%%%%%%%%%%%%%%%
for Set_simulation_parameters   = Necessary  
    for Set_Initial_inputs                = 1  
        dk{1}          = d0;           % initial temperature
        uk{1}          = us(1);       % initial operating condition
        uk_best{1}     = us_best(1);  % initial best operating condition
    end
    for Set_Decision_Trigger_parameters   = 1  
        waiting_time_at_SS = 0.5; % 30 min  
    end
    for Set_measured_disturbance_Signal   = 1  
        disturbance.tspand   = 0:10000:10000;   % F_A changes every 100h 
        disturbance.dspan    = d0*[1 1]; % the initial perturbation is d0 
    end
    for Set_UNmeasured_disturbance_Signal = 1  
        t_alpha1 = 70; % must be > 0.1
        t_alpha2 = 72; % must be > 0.1
        % Scenario 1 
%         disturbance.tspand_alpha = [0       t_alpha1   1e9];   
%         disturbance.dspan_alpha  = [0.5499  0.8        0.8];
        % Scenario 2
        disturbance.tspand_alpha = [0       t_alpha1 t_alpha2     1e9];   
        disturbance.dspan_alpha  = [0.5499  0.8      0.5499    0.5499];
    end
    for Set_indicators                    = 1  
        validation_mode = 0; 
        stand_by_mode   = 0;
        nb_decisions    = 0;
    end
    x_last      = x0;
    x_last_best = x0;
end %%%%%%%%%%%%%%%%%%%%%%%%%
for validation_step             = Necessary  
    a_max = max([DIII{1}.a1,DIII{2}.a1,DIII{3}.a1]);
    step_size_min_grad = a_max;
    step_size_max_grad = a_max*2;
    deltamax_u1   = 0.01;  % t/h  -- a considered "small" variation of the plant's input
    do_the_validation = Enabled; % Enabled or Disabled
    if isempty(do_the_validation) ~= 1
        deltamin_cost = 0.11; % no noise on inputs
%         deltamin_cost = 0.4; % with noise on inputs
    else
        deltamin_cost = 1e9;
    end
    Delta_u = diag(deltamax_u1);
    Delta_phi_Delta_u_accepted = deltamin_cost/deltamax_u1;
end %%%%%%%%%%%%%%%%%%%%%%%%%
for coherency_check_param       = Necessary  
    y_kp1_min(1) = -Inf;   y_kp1_min(2) = -Inf;   y_kp1_min(3) = -Inf;
    y_kp1_max(1) =  Inf;   y_kp1_max(2) =  Inf;   y_kp1_max(3) =  Inf;
    
    y_kp1_min_copy(1) = -Inf;   y_kp1_min_copy(2) = -Inf;   y_kp1_min_copy(3) = -Inf;
    y_kp1_max_copy(1) =  Inf;   y_kp1_max_copy(2) =  Inf;   y_kp1_max_copy(3) =  Inf;
    
    Option_Coherency_controler = 1; % When surprising observations are made: 
                                    % 1: React immediatly with nominal
                                    %    optimisation
                                    % 2: Wait for SS and then empty
                                    %    database and so on 
   Last_k_uncoherent = 0;
end %%%%%%%%%%%%%%%%%%%%%%%%%

sigmaFA = (10/2)/1000; sigmaFB = (10/2)/1000; sigmaFG = (10/2)/1000;  sigmaFP = (10/2)/1000;  sigmaFD = (10/2)/1000;
t_end = 400;           
%%
NB_iter = 100;

for k = 1:NB_iter %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    skip_all = 0;
    % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % ******                   Simulation part                   ******* %
    % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%     for Iter_display_and_breaker     = Enabled   
        disp(['iter k = ',num2str(k)])
        if k ~= 1 && RT_t(end)>=t_end
            disp('break')
            break
        end
%     end
    %%%%%%%%%%%%%%%%%%%
    for Apply_inputs_TRANSIENT       = Enabled   
        for sim_normal_decision  = 1 
            for Get_value_of_perturbation = 1
                if isempty(RT_t) == 0
                    tspan =  RT_t(end):0.1:(200+RT_t(end));
                    d_current = interp1(disturbance.tspand,disturbance.dspan,t(end),'previous');
                else
                    tspan = 0:0.1:200;
                    d_current = interp1(disturbance.tspand,disturbance.dspan,0,'previous');
                end
            end
            for Set_decision_trigger      = 1
                options = odeset('RelTol',1e-12,'Stats','off','Events',@(t,T)trig_DecisionTrigger(t,T,uk{k},disturbance,Theta_P,tspan,d_current,stand_by_mode,y_kp1_min_copy,y_kp1_max_copy,Option_Coherency_controler));
            end
            for Simulate_decision_results = 1
                [t,x,te,xe,ie] = ode45(@(t,x) Sim_WOprocess(t,x,uk{k},disturbance,Theta_P), tspan, x_last,options);
                x_last = x(end,:); % Initialisation of the next simulation
            end
        end
        for sim_ideal_decision   = 1 
            for Get_simulation_duration = 1        
                if isempty(RT_t_best) == 0
                    tspan_best =  [RT_t_best(end):0.01:t(end)];
                else
                    tspan_best = [0:0.01:t(end)];
                end
            end
            for Simulate_best_decision_results = 1 
                options2 = odeset('RelTol',1e-8,'Stats','off');
                [t_best,x_best] = ode45(@(t,x) Sim_WOprocess(t,x,uk_best{k},disturbance,Theta_P), tspan_best, x_last_best,options2);
                x_last_best = x_best(end,:); % Initialisation of the next simulation
            end
        end
    end   %%%%%%%%%%%%%%%%%%%
    for Plot_RealTime_data_TRANSIENT = Enabled   
        for create_time_series = 1  
            DI_FA   = [];   
            DI_t    = [];  DI_t_best  = [];   
            DI_FB   = [];  DI_FB_best = [];  
            DI_FG   = [];  DI_FG_best = [];   
            DI_FP   = [];  DI_FP_best = [];    
            DI_FD   = [];  DI_FD_best = [];   
            DI_cost = [];  DI_cost_best = [];  
            DI_valve = [];
            for i = 1:length(t)            
                % Applied
                [dx, y, u_applied] = Sim_WOprocess(t(i),x(i,:),uk{k},disturbance,Theta_P);
                [~,phi] = opt_uy2gphi(u_applied,y,[0;0;0],[0;0;0]);
                % Construct the series of data
                DI_t(i)    = t(i);  DI_FB(i)   = u_applied; 
                DI_FG(i)   = y(1);  DI_FP(i)   = y(2); 
                DI_FD(i)   = y(3);  DI_FA(i) = y(4);
                DI_cost(i) = phi;
                DI_valve(i) = interp1(disturbance.tspand_alpha,disturbance.dspan_alpha,t(i),'previous');
            end   
            DI_FAn = DI_FA+ normrnd(0,sigmaFA,size(DI_FA));
            DI_FBn = DI_FB+ normrnd(0,sigmaFB,size(DI_FB)); 
            DI_FGn = DI_FG+ normrnd(0,sigmaFG,size(DI_FG)); 
            DI_FPn = DI_FP+ normrnd(0,sigmaFP,size(DI_FP));  
            DI_FDn = DI_FD+ normrnd(0,sigmaFD,size(DI_FD));
            for i = 1:length(t_best)       
                % Best possible
                [dx, y, u_applied] = Sim_WOprocess(t_best(i),x_best(i,:),uk_best{k},disturbance,Theta_P);
                [~,phi] = opt_uy2gphi(u_applied,y,[0;0;0],[0;0;0]);
                % Construct the series of data
                DI_t_best(i)  = t_best(i);  DI_FB_best(i)   = u_applied; 
                DI_FG_best(i) = y(1);       DI_FP_best(i)   = y(2);       
                DI_FD_best(i) = y(3);       DI_cost_best(i) = phi;
            end  
            DI_costbest_addapted = interp1(DI_t_best,DI_cost_best,DI_t);
            DI_losses = abs(DI_costbest_addapted-DI_cost);
            % Prepare data for Real-time plots
            if k == 1
                RT_t      = t';
                RT_t_best = t_best';
            else
                RT_t      = [RT_t, t'];
                RT_t_best = [RT_t_best, t_best'];
            end
            RT_FA = [RT_FA, DI_FA];   RT_FAn = [RT_FAn, DI_FAn];
            RT_FB = [RT_FB, DI_FB];   RT_FBn = [RT_FBn, DI_FBn];   RT_FB_best = [RT_FB_best , DI_FB_best ];
            RT_FG = [RT_FG, DI_FG];   RT_FGn = [RT_FGn, DI_FGn];   RT_FG_best = [RT_FG_best , DI_FG_best ];
            RT_FP = [RT_FP, DI_FP];   RT_FPn = [RT_FPn, DI_FPn];   RT_FP_best = [RT_FP_best , DI_FP_best ];
            RT_FD = [RT_FD, DI_FD];   RT_FDn = [RT_FDn, DI_FDn];   RT_FD_best = [RT_FD_best , DI_FD_best ];
            RT_cost      = [RT_cost,DI_cost]; RT_losses = [RT_losses,DI_losses];  
            RT_cost_best = [RT_cost_best,DI_cost_best]; 
            RT_valve = [RT_valve, DI_valve];
        end
        for Hide_plot_data     = 1  
            figure(1)
                hold on
                ylim([-430 -330])
                plot(RT_t_best,RT_cost_best,'m')
                plot(RT_t     ,RT_cost,'k')   
                ylabel('phi')              
            figure(2)   
                hold on
                ylim([5.5 7.8])
                plot(RT_t     ,RT_FAn,'k')
                ylabel('F_A')      
            figure(3)   
                hold on
                ylim([14 18])
                plot(RT_t_best,RT_FB_best,'m')
                plot(RT_t     ,RT_FBn,'k')
                ylabel('F_B')  
            figure(4)   
                hold on
                ylim([1.2 2])
                plot(RT_t_best,RT_FG_best,'m')
                plot(RT_t     ,RT_FGn,'k')
                ylabel('F_G')
            figure(5)   
                hold off
                X=[[0 10000],fliplr([0 10000])];  
                Y=[2.370*[1,1],fliplr(2.7*[1,1])];       
                fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
                hold on
                ylim([1.9 2.5])
                plot(RT_t_best,RT_FP_best,'m')
                plot(RT_t     ,RT_FPn,'k')
                ylabel('F_P')
                xlim([0,RT_t(end)])
            figure(6)   
                hold on
                ylim([17 21])
                plot(RT_t_best,RT_FD_best,'m')
                plot(RT_t     ,RT_FDn,'k')
                ylabel('F_D')
            figure(13)
                hold off
                X=[[0 10000],fliplr([0 10000])];  
                Y=[[-3 -3],fliplr(log(deltamin_cost)/log(10)*[1,1])];               
                fill(X,Y,'y','EdgeColor','none');
                hold on 
                plot(RT_t,log(RT_losses+1e-2)./log(10),'k')  
                xlim([0,RT_t(end)])
            figure(14) 
                hold off
                plot(RT_t,RT_valve,'k')  
                ylabel('alpha')  
                xlim([0,RT_t(end)])
                ylim([0.5 1])
        end
    end   %%%%%%%%%%%%%%%%%%%
    for If_SS_reached                = Enabled   
        if isempty(ie) == 1
            ie = 10; % a valeu that is not {1,2,3} 
        end
        if  ie == 2 % Don't get SS data, go directly to the update of the decision
            ie_ss = 1;
            disp(['t = ',num2str(t(end)),', Event detected -- variation of d'])
        elseif ie == 3 && Option_Coherency_controler == 1
            disp(['t = ',num2str(t(end)),', Event detected -- Uncoherent observation: Reset Database'])
            disp('Do: Nominal model optimisation')
            DIII = ResetDIII(ell1,ell2,sigmaf,nx,nu,nf);
            skip_all = 1;
        else
            for Apply_inputs_SS                = 1   
                for sim_normal_decision   = 1 
                    for Creat_time_series             = 1  
                        tspan      =  t(end):0.01:t(end)+waiting_time_at_SS;
                        tspan_best =  t(end):0.01:t(end)+waiting_time_at_SS;
                    end
                    for Get_current_disturbance_value = 1  
                        d_current = interp1(disturbance.tspand,disturbance.dspan,t(end),'previous');
                    end
                    for Set_Decision_trigger          = 1  
                        options = odeset('RelTol',1e-8,'Stats','off','Events',...                             
                        @(t,T)trig_DecisionTrigger_Waitingtime(t,T,uk{k},disturbance,Theta_P,tspan,d_current, y_kp1_min,y_kp1_max,Option_Coherency_controler));
                    end
                    for Simulate_plant                = 1  
                        [t,x,te_ss,xe_ss,ie_ss] = ode45(@(t,x) Sim_WOprocess(t,x,uk{k},disturbance,Theta_P), tspan, x_last,options);
                        x_last = x(end,:); % Initialisation of the next simulation
                    end
                end
                for sim_ideal_decision    = 1 
                    [t_best,x_best] = ode45(@(t,x) Sim_WOprocess(t,x,uk_best{k},disturbance,Theta_P), tspan_best, x_last_best,options);
                    x_last_best = x_best(end,:); % Initialisation of the next simulation
                end
            end   %%%%%%%%%%%%%%%%
            for Plot_RealTime_data_SS          = 1   
                for create_time_series = 1    
                    DI_FA = [];   DI_valve     = [];
                    DI_t  = [];   DI_t_best    = [];    
                    DI_FB = [];   DI_FB_best   = [];  
                    DI_FG = [];   DI_FG_best   = [];  
                    DI_FP = [];   DI_FP_best   = [];  
                    DI_FD = [];   DI_FD_best   = [];
                    DI_cost = []; DI_cost_best = []; 
                    for i = 1:length(t)     
                        % Applied
                        [dx, y, u_applied] = Sim_WOprocess(t(i),x(i,:),uk{k},disturbance,Theta_P);
                        [~,phi] = opt_uy2gphi(u_applied,y,[0;0;0],[0;0;0]);
                        % Construct the series of data
                        DI_t(i)= t(i);     DI_FB(i) = u_applied; 
                        DI_FG(i)  = y(1);  DI_FP(i) = y(2); DI_FD(i) = y(3); DI_FA(i) = y(4);
                        DI_cost(i) = phi;
                        DI_valve(i) = interp1(disturbance.tspand_alpha,disturbance.dspan_alpha,t(i),'previous');
                    end  
                    DI_FAn = DI_FA+ normrnd(0,sigmaFA,size(DI_FA)); 
                    DI_FBn = DI_FB+ normrnd(0,sigmaFB,size(DI_FB)); 
                    DI_FGn = DI_FG+ normrnd(0,sigmaFG,size(DI_FG)); 
                    DI_FPn = DI_FP+ normrnd(0,sigmaFP,size(DI_FP));  
                    DI_FDn = DI_FD+ normrnd(0,sigmaFD,size(DI_FD));
                    for i = 1:length(t_best)
                        % Best possible
                        [dx, y, u_applied] = Sim_WOprocess(t_best(i),x_best(i,:),uk_best{k},disturbance,Theta_P);
                        [~,phi] = opt_uy2gphi(u_applied,y,[0;0;0],[0;0;0]);
                        % Construct the series of data
                        DI_t_best(i)= t_best(i);  DI_FB_best(i) = u_applied; 
                        DI_FG_best(i)  = y(1);  DI_FP_best(i) = y(2); DI_FD_best(i) = y(3); 
                        DI_cost_best(i) = phi;
                    end  
                    DI_costbest_addapted = interp1(DI_t_best,DI_cost_best,DI_t);
                    DI_losses = abs(DI_costbest_addapted-DI_cost);
                    % Prepare data for Real-time plots
                    RT_t      = [RT_t, t'];
                    RT_t_best = [RT_t_best, t_best'];
                    RT_FA = [RT_FA, DI_FA];   RT_FAn = [RT_FAn, DI_FAn];
                    RT_FB = [RT_FB, DI_FB];   RT_FBn = [RT_FBn, DI_FBn];   RT_FB_best = [RT_FB_best , DI_FB_best ];
                    RT_FG = [RT_FG, DI_FG];   RT_FGn = [RT_FGn, DI_FGn];   RT_FG_best = [RT_FG_best , DI_FG_best ];
                    RT_FP = [RT_FP, DI_FP];   RT_FPn = [RT_FPn, DI_FPn];   RT_FP_best = [RT_FP_best , DI_FP_best ];
                    RT_FD = [RT_FD, DI_FD];   RT_FDn = [RT_FDn, DI_FDn];   RT_FD_best = [RT_FD_best , DI_FD_best ];
                    RT_cost      = [RT_cost,DI_cost];  RT_losses = [RT_losses,DI_losses];  
                    RT_cost_best = [RT_cost_best,DI_cost_best]; 
                    RT_valve = [RT_valve, DI_valve];
                end
                for Hide_plot_data     = 1    
                    figure(1)
                        hold off
                        ylim([-430 -330])
                        plot(RT_t_best,RT_cost_best,'m')
                        hold on
                        plot(RT_t     ,RT_cost,'k') 
                        ylabel('phi')              
                    figure(2)  
                        hold off 
                        ylim([5.5 7.8])
                        plot(RT_t     ,RT_FAn,'k')
                        hold on
                        ylabel('F_A')      
                    figure(3)   
                        hold off
                        ylim([14 18])
                        plot(RT_t_best,RT_FB_best,'m')
                        hold on
                        plot(RT_t     ,RT_FBn,'k')
                        ylabel('F_B')  
                    figure(4)   
                        hold off
                        ylim([1.2 2])
                        plot(RT_t_best,RT_FG_best,'m')
                        hold on
                        plot(RT_t     ,RT_FGn,'k')
                        ylabel('F_G')
                    figure(5)   
                        hold off
                        X=[[0 10000],fliplr([0 10000])];  
                        Y=[2.370*[1,1],fliplr(2.7*[1,1])];       
                        fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
                        hold on
                        ylim([1.9 2.5])
                        plot(RT_t_best,RT_FP_best,'m')
                        plot(RT_t     ,RT_FPn,'k')
                        ylabel('F_P')
                        xlim([0,RT_t(end)])
                    figure(6)   
                        hold off
                        ylim([17 21])
                        plot(RT_t_best,RT_FD_best,'m')
                        hold on
                        plot(RT_t     ,RT_FDn,'k')
                        ylabel('F_D')
                    figure(13)
                        hold off
                        X=[[0 10000],fliplr([0 10000])];  
                        Y=[[-3 -3],fliplr(log(deltamin_cost)/log(10)*[1,1])];       
                        fill(X,Y,'y','EdgeColor','none');
                        hold on 
                        plot(RT_t,log(RT_losses+1e-2)./log(10),'k')  
                        xlim([0,RT_t(end)])
                    figure(14) 
                        hold off
                        plot(RT_t,RT_valve,'k')  
                        ylabel('alpha')
                        xlim([0,RT_t(end)])
                        ylim([0.5 1])
                end
            end   %%%%%%%%%%%%%%%%
            if isempty(ie_ss) == 1
                ie_ss = 10;
            end
            if     ie_ss == 1
                disp(['t = ', num2str(te_ss),', Event detected -- variation of d']);
            elseif ie_ss == 2 && Option_Coherency_controler == 1
                % display action
                disp(['t = ',num2str(t(end)),', Event detected -- Uncoherent observation: Reset Database'])
                DIII = ResetDIII(ell1,ell2,sigmaf,nx,nu,nf);
                skip_all = 1;
            elseif ie_ss == 2 && Option_Coherency_controler == 2
                % display action
                disp(['t = ',num2str(t(end)),', Event detected -- Uncoherent observation: Option 2 - wait'])
                skip_all = 1;
            end
        end
    end   %%%%%%%%%%%%%%%%%%%
    
    % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % ******      Data processing & Decision making part         ******* %
    % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % **** If a new data is collected, then add it to the database   *** %
    tic  % start timer %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if ie_ss == 10 &&  skip_all == 0 % then we have a new point to add to the database. 
    % Otherwise: one just make a decision based on the previous data
        for Statistical_analysis      = Enabled   
            % inputs
            DII.X_mean = mean([DI_FBn(1:end-1)',(DI_FAn(1:end-1)-6.577089366)']);
            dk{k} = DII.X_mean(2);
            DII.X_var  = cov([DI_FBn(1:end-1)',(DI_FAn(1:end-1)-6.577089366)'])/10; 
            [nabla_x_y1, nabla_x_y2, nabla_x_y3] = model_GetDerivatives(DII.X_mean,Theta);
            
            DII.Y1_mean  = mean(DI_FGn);
            DII.Y1_var   = (var(DI_FGn) + (abs(nabla_x_y1)+f_b2{1})' *DII.X_var* (abs(nabla_x_y1)+f_b2{1}) );
                
            DII.Y2_mean  = mean(DI_FPn);
            DII.Y2_var   = (var(DI_FPn) + (abs(nabla_x_y2)+f_b2{2})' *DII.X_var* (abs(nabla_x_y2)+f_b2{2}) );
                    
            DII.Y3_mean  = mean(DI_FDn);
            DII.Y3_var   = (var(DI_FDn) + (abs(nabla_x_y3)+f_b2{3})' *DII.X_var* (abs(nabla_x_y3)+f_b2{3}) );
            
            DII.phi_mean  = mean(DI_cost);
            
            % Evaluate model at DII.X_mean
            disturbance_now.tspand = [0,1];      
            disturbance_now.dspan  = DII.X_mean(2)*[1,1]; 
                xx_sol = fsolve(@(xx) Sim_WOprocess(0, xx, DII.X_mean(1),disturbance_now, Theta), x0, fsolve_options);
                [~,Ymodel] = Sim_WOprocess(0, xx_sol, DII.X_mean(1),disturbance_now, Theta);
             
            DII.Y1_error_mean  = DII.Y1_mean - Ymodel(1);
            DII.Y2_error_mean  = DII.Y2_mean - Ymodel(2);
            DII.Y3_error_mean  = DII.Y3_mean - Ymodel(3);
            
        end   %%%%%%%%%%%%%%%%%%
        for Save_plant_data_4_figures = Enabled   
            nb_observation = nb_observation +1;
            SAVE_uk    = [SAVE_uk;   DII.X_mean(1)]; 
            SAVE_dk    = [SAVE_dk;   DII.X_mean(2)];
            SAVE_y1k   = [SAVE_y1k;  DII.Y1_mean]; 
            SAVE_y2k   = [SAVE_y2k;  DII.Y2_mean]; 
            SAVE_y3k   = [SAVE_y3k;  DII.Y3_mean];
                [SAVE_gk_temp,SAVE_phik_temp] = opt_uy2gphi(SAVE_uk(end),[SAVE_y1k(end);SAVE_y2k(end);SAVE_y3k(end);SAVE_dk(end)+6.577089366],[0;0;0],[0;0;0]);
            SAVE_gk    = [SAVE_gk;   SAVE_gk_temp];
            SAVE_phik  = [SAVE_phik; SAVE_phik_temp];
        end   %%%%%%%%%%%%%%%%%%
        for Coherency_controller      = Enabled   
            if  y_kp1_min(1) > DII.Y1_mean || DII.Y1_mean > y_kp1_max(1) || ... % test y1
                y_kp1_min(2) > DII.Y2_mean || DII.Y2_mean > y_kp1_max(2) || ... % test y2
                y_kp1_min(3) > DII.Y3_mean || DII.Y3_mean > y_kp1_max(3)        % test y3
                % display action
                disp(['t = ',num2str(t(end)),' -- Coherency_controller: Reset Database'])
                % Reset database
                DIII = ResetDIII(ell1,ell2,sigmaf,nx,nu,nf);
                % Save when the reset occured for the figures (to plot in red the rejected points)
                Last_k_uncoherent = k-1;
            end
        end   % not implemented for this case study
        for Compressor                = Enabled   
            DIII = comp_updateDIII(DIII,DII);
        end   %%%%%%%%%%%%%%%%%%
        for Model_data_fusion         = Enabled   
            % 5.1.- Build design vector & kernel matrix (you don't want to
            % recompute them at each iteration of the solver -- so compute them
            % only once and before launching the solver ;) ....)
            GP_PrecomputeMu();
        end   %%%%%%%%%%%%%%%%%%
    else
        % Make a decision w.r.t. the last observed value of the disturbance
        dk{k} = DI_FAn(end)-6.577089366;
    end
    % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    if skip_all == 0%
        % **** Make a decision based on the model & the data collected  **** %
        for Updated_Model_based_optimisation = Enabled  
            % 5.2.- Model based optimisation
            % 5.2.1.- Set the UNmanipulable inputs:
            disturbance_now.tspand = [0 1];
            d_now = interp1(disturbance.tspand,disturbance.dspan,t(end)+0.1,'previous'); 
            disturbance_now.dspan  = d_now*[1 1];

            disturbance_now.tspand_alpha = [0,1];     
            disturbance_now.dspan_alpha  = [1,1]*interp1(disturbance.tspand_alpha,disturbance.dspan_alpha,t(end),'previous');

            % 5.2.2.- Identify the optimal manipulable inputs
            for Optimisation_IdealMOdel   = 1 
                Last_u = []; Last_c = []; Last_f = []; Last_ceq = [];
                [us_best,~,exitflag,~,lambda_best] = ...
                    fmincon(@(u)opt_objfunp(u,disturbance_now,Ee0p,Ve0p,Theta_P),u0,A,b,Aeq,beq,lbs,ubs,@(u)opt_constrp(u,disturbance_now,Ee0p,Ve0p,Theta_P),fmincon_options);
                if    exitflag == 0
                    disp('Nominal Plant optimization: The solver stopped before converging')
                elseif exitflag < 0
                    disp('Nominal Plant optimization: The solver failed to find a solution')
                end
            end
            for Optimisation_UpdatedModel = 1 
                Last_u = []; Last_c = []; Last_f = []; Last_ceq = [];
                [us,~,exitflag,~,lambda] = ...
                    fmincon(@(u)opt_updated_objfun(u,disturbance_now,Theta),us_best,A,b,Aeq,beq,lbs,ubs,@(u)opt_updated_constr(u,disturbance_now,Theta),fmincon_options);
                if    exitflag == 0
                    disp(['Updated Model optimization: The solver stopped before converging | k = ',num2str(k)])
                elseif exitflag < 0
                    disp(['Updated Model optimization: The solver failed to find a solution | k = ',num2str(k)])
                end
            end
            uk{k+1}      = us;
            uk_best{k+1} = us_best;
    %         dk{k+1}      = interp1(disturbance.tspand,disturbance.dspan,t(end)+0.1,'previous');
        end  %%%%%%%%%%%%%%%%%
        for Validation_step                  = Enabled  
            stand_by_mode = 0; 
            if k ~= 1 % we need a previous step
                for convergence_detector = 1
    %                 if abs([uk{k+1};dk{k+1}] - [uk{k};dk{k}]) < min([DIII{1}.A;DIII{2}.A;DIII{3}.A])'
                    if abs([uk{k+1};dk{k}] - [uk{k};dk{k-1}]) < [0.6667;0.0167] % min([DIII{1}.A;DIII{2}.A;DIII{3}.A])'
                        % 5.3.1.- Then we should check whether we have a good knowledge
                        % of the gradient (w.r.t. u) of plant at [uk{k+1};dk{k+1}].
                        [M, TEST,IEMIE,M2]  = val_compute_SIGMA_DL_du(DIII, [uk{k+1};dk{k}]' ,lambda,Theta,Delta_phi_Delta_u_accepted);
                        test = 2*sqrt(max(eig(Delta_u*M*Delta_u)));
                        disp(['Possible improvement = ',num2str(test),' $/h'])
                        if test <= abs(deltamin_cost) && TEST > 0
                             disp(['t = ',num2str(t(end)),' -- Optimum identified -- standby mode activated'])
                             stand_by_mode = 1;
                             validation_mode = 0; 
                        else
                             disp(['t = ',num2str(t(end)),' -- Near optimality possible -- Validation protocle activated'])
                             validation_mode = 1; 
                             flag = 0;
                             var_temp = 0;

                            disturbance_now.tspand = [0,1];
                            disturbance_now.dspan  = dk{k}*[1 1];
                            uk_copy = uk{k+1};
                             for iii = 1 :1000
                                 if flag == 0     
                                    % add a random perturbation
                                    if IEMIE == 0  && TEST > 0 % If one needs to improove local estimate of the VALUE of a constraint: Make very a SMALL step
    %                                     disp('Petite perturbation')
                                        perturbation     = min([1,max([-1, normrnd(0,step_size_max_grad)])]);
                                        min_perturbation = step_size_min_grad*2;
                                    else % if M2 == 0  % If one needs to improove local estimate of the Gradient of the cost: Make a MEDIUM step
    %                                     disp('Grande perturbation')
                                        perturbation     = min([1,max([-1, normrnd(0,step_size_max_grad)])]);
                                        min_perturbation = step_size_min_grad*2;
                                    end
                                    if abs(perturbation) > min_perturbation  % we don't want too small perturbations
                                        utest(1) = uk_copy + perturbation;
                                        utest(2) = uk_copy - perturbation;
                                        for ii = 1:2
                                            x_sol = fsolve(@(x) Sim_WOprocess(0, x, utest(ii) ,disturbance_now, Theta), x0, fsolve_options);
                                            [~,y] = Sim_WOprocess(0, x_sol, utest(ii) ,disturbance_now, Theta);
                                            [Ee,Ve] = GP_mu([utest(ii),dk{k}]);
                                            [g_corr, varphi, var_varphi, var_h] = opt_uy2gphi(utest(ii),y,Ee,Ve);
                                            if g_corr-2*sqrt(var_h)     < 0.1 && ...
                                               utest(ii)   <= ubs && ...
                                               utest(ii)   >= lbs && ...
                                               var_varphi > var_temp % we accept temporary violations => Helps to get the gradient of the cost functions (boost decision making -- do it is possible)
                                                flag     = 1;
                                                var_temp = var_varphi;
                                                uk{k+1}  = utest(ii); 
                                            end
                                        end
                                    end
                                 end

                             end
                        end
                    else
                        validation_mode = 0; 
                    end
                end
            end
        end  %%%%%%%%%%%%%%%%%
        for Coherency_controller_Update      = Enabled  
            disturbance_next.tspand = [0 1];
            disturbance_next.dspan  = dk{k}*[1 1];
            [x_sol] = fsolve(@(x) Sim_WOprocess(0, x, uk{k+1},disturbance_next,Theta), x0, fsolve_options);
            [~,y] = Sim_WOprocess(0,x_sol,uk{k+1},disturbance_next,Theta);
            [Ee,Ve] = GP_mu([uk{k+1},dk{k} ]); % Ee: Expectancy of the error 
                                                 % Ve: Variance of the error
            y_kp1_min(1) =  y(1) + Ee(1) - 2*sqrt(Ve(1))  - 2*sqrt(sigmaFG);
            y_kp1_max(1) =  y(1) + Ee(1) + 2*sqrt(Ve(1))  + 2*sqrt(sigmaFG);
            y_kp1_min(2) =  y(2) + Ee(2) - 2*sqrt(Ve(2))  - 2*sqrt(sigmaFP);
            y_kp1_max(2) =  y(2) + Ee(2) + 2*sqrt(Ve(2))  + 2*sqrt(sigmaFP);
            y_kp1_min(3) =  y(3) + Ee(3) - 2*sqrt(Ve(3))  - 2*sqrt(sigmaFD);
            y_kp1_max(4) =  y(3) + Ee(3) + 2*sqrt(Ve(3))  + 2*sqrt(sigmaFD);   
            
            y_kp1_min_copy = y_kp1_min;
            y_kp1_max_copy = y_kp1_max;
        end  %%%%%%%%%%%%%%%%%
        for Register_decision                = Enabled  
            nb_decisions = nb_decisions + 1;
            SAVE_tk    = [SAVE_tk;   t(end)];
            SAVE_validation_mode(k) = validation_mode; 
            SAVE_modek = [SAVE_modek; stand_by_mode];
        end  %%%%%%%%%%%%%%%%%
        for Update_VLC                       = Disabled 
            for update__VCL     = 1   
                [nabla_u_phi, nabla_ud_phi, nabla_uu_phi, ha, nabla_u_ha, nabla_d_ha,d_mesh,us_mesh] = QP_approx_updated([uk{k+1},dk{k}],lambda,Theta,u0,A,b,Aeq,beq,lbs,ubs,fmincon_options,VLC);
                if VLC.Option == 2
                    VLC.d_mesh  = d_mesh;
                    VLC.us_mesh = us_mesh;
                else
                    Q   = nabla_uu_phi;   H = nabla_u_ha;
                    if isempty(ha) == 1
                        QH  = Q;
                        invQH = pinv(QH);    
                        psi11 = invQH(1:nu,1:nu); 
                        psi12 = invQH(1:nu,nu+1:end);
                        Gks   = -psi11*nabla_ud_phi;
                        VLC.Gks     = Gks;
                        VLC.mean_d  = dk{k}; 
                    else
                        QH  = [Q,H';H,zeros(size(H,1),size(H,1))];
                        invQH = pinv(QH);   
                        psi11 = invQH(1:nu,1:nu); 
                        psi12 = invQH(1:nu,nu+1:end);
                        Gks   = -psi11*nabla_ud_phi - psi12*nabla_d_ha;
                        VLC.Gks     = Gks;
                        VLC.mean_d  = dk{k}; % values of d at which the model were solved
                    end
                end
            end
            for update_best_VCL = 1   
                [nabla_u_phi_best, nabla_ud_phi_best, nabla_uu_phi_best, ha_best, nabla_u_ha_best, nabla_d_ha_best, d_mesh_best, us_mesh_best] = QP_approx([uk_best{k+1},dk{k}],lambda_best,Theta_P,u0,A,b,Aeq,beq,lbs,ubs,fmincon_options,VLC_best);
                if VLC_best.Option == 2
                    VLC_best.d_mesh  = d_mesh_best;
                    VLC_best.us_mesh = us_mesh_best;
                else
                    Q_best   = nabla_uu_phi_best;   H_best = nabla_u_ha_best; 
                    if isempty(ha_best) == 1
                        QH_best  = Q_best;
                        invQH_best = pinv(QH_best);  
                        psi11_best = invQH_best(1:nu,1:nu); 
                        psi12_best = invQH_best(1:nu,nu+1:end);
                        Gks_best   = -psi11_best*nabla_ud_phi_best;
                            VLC_best.Gks     = Gks_best;
                            VLC_best.mean_d  = dk{k}; 
                    else
                        QH_best  = [Q_best,H_best';H_best,zeros(size(H_best,1),size(H_best,1))];
                        invQH_best = pinv(QH_best);   
                        psi11_best = invQH_best(1:nu,1:nu); 
                        psi12_best = invQH_best(1:nu,nu+1:end);
                        Gks_best   = -psi11_best*nabla_ud_phi_best - psi12_best*nabla_d_ha_best;
                            VLC_best.Gks     = Gks_best;
                            VLC_best.mean_d  = dk{k}; 
                    end
                end
            end

        end  % VCL not implented
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        timerVal(k) = toc;  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for plot_what_ASP_sees      = Enabled 
            % Plot xxx w.r.t. u
            %%
            figure(8)
            for Evaluate_model_plant_correction_functions = 1 
                disturbance_now.tspand = [0,1];
                disturbance_now.dspan  = dk{k}*[1 1];
                umin = 10; umax = 20; nb_test = 50;
                u_test = umin:(umax-umin)/(nb_test-1):umax;
                for i = 1:length(u_test)
                    % evaluate model
                    x_sol          = fsolve(@(x) Sim_WOprocess(0, x, u_test(i) ,disturbance_now, Theta), x0, fsolve_options);
                    [~,y]          = Sim_WOprocess(0, x_sol, u_test(i) ,disturbance_now, Theta);
                    [g(i), phi(i)] = opt_uy2gphi(u_test(i),y,[0;0;0],[0;0;0]);
                    y1(i)          = y(1);   y2(i) = y(2);   y3(i) = y(3); 
                    % evaluate correction function
                    [Ee,Ve] = GP_mu([u_test(i),dk{k}]);
                    [g_corr(i),phi_corr(i),var_phi_corr(i), var_g_corr(i)] = opt_uy2gphi(u_test(i),y,Ee,Ve);
                    y1_corr(i)   = Ee(1)              ;   y2_corr(i)   = Ee(2)              ;   y3_corr(i)   = Ee(3);
                    y1_corr_p(i) = Ee(1)+2*Ve(1)^(1/2);   y2_corr_p(i) = Ee(2)+2*Ve(2)^(1/2);   y3_corr_p(i) = Ee(3)+2*Ve(3)^(1/2); 
                    y1_corr_m(i) = Ee(1)-2*Ve(1)^(1/2);   y2_corr_m(i) = Ee(2)-2*Ve(2)^(1/2);   y3_corr_m(i) = Ee(3)-2*Ve(3)^(1/2);
                    % evaluate plant
                    x_sol            = fsolve(@(x) Sim_WOprocess(0, x, u_test(i) ,disturbance_now, Theta_P), x0, fsolve_options);
                    [~,y]            = Sim_WOprocess(0, x_sol, u_test(i) ,disturbance_now, Theta_P);
                    [gp(i), phip(i)] = opt_uy2gphi(u_test(i),y,[0;0;0],[0;0;0]);
                    y1p(i) = y(1);   y2p(i) = y(2);   y3p(i) = y(3); 

                end
            end  
            for plot_Y1       = 1  
                subplot(2,5,1)
                hold off
                    % function
                    X=[u_test,fliplr(u_test)];                
                    Y=[y1_corr_p+y1,fliplr(y1_corr_m+y1)] ;             
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
                    hold on 
                    % Data
                    for ii = 1:nb_observation
                        if ii <= Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_y1k(ii),15,'bo','MarkerFaceColor',[1 0.6 0.6],'MarkerEdgeColor','none')
                        else
                            dist = max([1 - abs(dk{k} - SAVE_dk(ii))/0.3, 0.4]);
                            scatter(SAVE_uk(ii),SAVE_y1k(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    for ii = 1:nb_observation
                        dist = max([1 - abs(dk{k} - SAVE_dk(ii))/0.3, 0.2]);
                        if dist < 0.01 && ii > Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_y1k(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    plot(u_test,y1,'k--')
                    plot(u_test,(y1_corr+y1),'k-')
                    plot(u_test,y1p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$u [t/h]$');
                    hYLabel = ylabel('$y_{(1)}$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
                    ylim([0 4])
            end  
            for plot_Y2       = 1  
                subplot(2,5,2)
                hold off
                    % functions
                    X=[u_test,fliplr(u_test)];                
                    Y=[y2_corr_p+y2,fliplr(y2_corr_m+y2)];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
                    hold on 
                    % Data
                    for ii = 1:nb_observation
                        if ii <= Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_y2k(ii),15,'bo','MarkerFaceColor',[1 0.6 0.6],'MarkerEdgeColor','none')
                        else
                            dist = max([1 - abs(dk{k} - SAVE_dk(ii))/0.3, 0.4]);
                            scatter(SAVE_uk(ii),SAVE_y2k(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    for ii = 1:nb_observation
                        dist = max([1 - abs(dk{k} - SAVE_dk(ii))/0.3, 0.2]);
                        if dist < 0.01 && ii > Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_y2k(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    plot(u_test,y2,'k--')
                    plot(u_test,(y2_corr+y2),'k-')
                    plot(u_test,y2p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$u [t/h]$');
                    hYLabel = ylabel('$y_{(2)}$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
                    ylim([0 3])
            end  
            for plot_Y3       = 1  
                subplot(2,5,3)
                hold off
                    % functions
                    X=[u_test,fliplr(u_test)];                
                    Y=[y3_corr_p+y3,fliplr(y3_corr_m+y3)];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none'); 
                    hold on 
                    % Data
                    for ii = 1:nb_observation
                        if ii <= Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_y3k(ii),15,'bo','MarkerFaceColor',[1 0.6 0.6],'MarkerEdgeColor','none')
                        else
                            dist = max([1 - abs(dk{k} - SAVE_dk(ii))/0.3, 0.4]);
                            scatter(SAVE_uk(ii),SAVE_y3k(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    for ii = 1:nb_observation
                        dist = max([1 - abs(dk{k} - SAVE_dk(ii))/0.3, 0.2]);
                        if dist < 0.01 && ii > Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_y3k(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    plot(u_test,y3,'k--')
                    plot(u_test,(y3_corr+y3),'k-')
                    plot(u_test,y3p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$u [t/h]$');
                    hYLabel = ylabel('$y_{(3)}$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
                    ylim([10 25])
            end
            for plot_phi      = 1  
                subplot(2,5,4)
                    hold off
                    % functions
                    X=[u_test,fliplr(u_test)];                
                    Y=[phi_corr+2*var_phi_corr.^(1/2),fliplr(phi_corr-2*var_phi_corr.^(1/2))];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none'); 
                    hold on 
                    % Data
                    for ii = 1:nb_observation
                        if ii <= Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_phik(ii),15,'bo','MarkerFaceColor',[1 0.6 0.6],'MarkerEdgeColor','none')
                        else
                            dist = max([1 - abs(dk{k} - SAVE_dk(ii))/0.3, 0.4]);
                            scatter(SAVE_uk(ii),SAVE_phik(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    for ii = 1:nb_observation
                        dist = max([1 - abs(dk{k} - SAVE_dk(ii))/0.3, 0.2]);
                        if dist < 0.01 && ii > Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_phik(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    plot(u_test,phi,'k--')
                    plot(u_test,phi_corr,'k-')
                    plot(u_test,phip,'r--')
                    % Plot gca
    %                 ylim([-400, -300])
                    hXLabel = xlabel('$u [t/h]$');
                    hYLabel = ylabel('$\phi$ [\$/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
                    ylim([-1000 500])

            end
            for plot_g        = 1  
                subplot(2,5,5)
                hold off
                    % functions
                    X=[u_test,fliplr(u_test)];                
                    Y=[g_corr,fliplr(g_corr-4*var_g_corr.^(1/2))];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none'); 
                    hold on 
                    % Data
                    for ii = 1:nb_observation
                        if ii <= Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_gk(ii),15,'bo','MarkerFaceColor',[1 0.6 0.6],'MarkerEdgeColor','none')
                        else
                            dist = max([1 - abs(dk{k} - SAVE_dk(ii))/0.3, 0.4]);
                            scatter(SAVE_uk(ii),SAVE_gk(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    for ii = 1:nb_observation
                        dist = max([1 - abs(dk{k} - SAVE_dk(ii))/0.3, 0.2]);
                        if dist < 0.01 && ii > Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_gk(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    plot(u_test,g,'k--')
                    plot(u_test,(g_corr-2*var_g_corr.^(1/2)),'k-')
                    plot(u_test,gp,'r--')
                    % Plot gca
                    hXLabel = xlabel('$u [t/h]$');
                    hYLabel = ylabel('$g$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
                    ylim([-1.5 1])

            end
            figure(9)
            for plot_phi_3D   = 1  
    %             figure
                    % functions
                    hold off
                    X=[u_test,fliplr(u_test)];                
                    Y=[phi_corr+2*var_phi_corr.^(1/2),fliplr(phi_corr-2*var_phi_corr.^(1/2))];              
                    fill3(dk{k}*ones(size(Y)),X,Y,[0.8 0.8 0.8],'EdgeColor','none','facealpha',.5); 
                    hold on 
                    plot3(dk{k}*ones(size(u_test)),u_test,phi,'k--')
                    plot3(dk{k}*ones(size(u_test)),u_test,phi_corr,'k-')
                    plot3(dk{k}*ones(size(u_test)),u_test,phip,'r--')
                    grid on
                    % Data
                    for ii = 1:nb_observation
                        if ii <= Last_k_uncoherent
                            scatter3(SAVE_dk(ii),SAVE_uk(ii),SAVE_phik(ii),15,'bo','MarkerFaceColor',[1 0.6 0.6],'MarkerEdgeColor','none')
                        else
                            dist = max([1 - abs(dk{k} - SAVE_dk(ii))/0.3, 0.2]);
                            scatter3(SAVE_dk(ii),SAVE_uk(ii),SAVE_phik(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    xlim([-1 1])
                    ylim([10 20])
            end
            % Plot xxx w.r.t. d
            figure(8)
            for Evaluate_model_plant_correction_functions =1  
                u_test = uk{k};
                dmin = -1; dmax = 1; nb_test = 50;
                d_test = dmin:(dmax-dmin)/(nb_test-1):dmax;
                for i = 1:length(d_test)
                    disturbance_now.tspand = [0,1];
                    disturbance_now.dspan  = d_test(i)*[1 1];
                    % evaluate model
                    x_sol          = fsolve(@(x) Sim_WOprocess(0, x, u_test ,disturbance_now, Theta), x0, fsolve_options);
                    [~,y]          = Sim_WOprocess(0, x_sol, u_test ,disturbance_now, Theta);
                    [g(i), phi(i)] = opt_uy2gphi(u_test,y,[0;0;0],[0;0;0]);
                    y1(i) = y(1);   y2(i) = y(2);   y3(i) = y(3); 
                    % evaluate correction function
                    [Ee,Ve] = GP_mu([u_test,d_test(i)]);
                    [g_corr(i),phi_corr(i),var_phi_corr(i), var_g_corr(i)] = opt_uy2gphi(u_test,y,Ee,Ve);
                    y1_corr(i)   = Ee(1)              ;   y2_corr(i)   = Ee(2)              ;   y3_corr(i)   = Ee(3);
                    y1_corr_p(i) = Ee(1)+2*Ve(1)^(1/2);   y2_corr_p(i) = Ee(2)+2*Ve(2)^(1/2);   y3_corr_p(i) = Ee(3)+2*Ve(3)^(1/2); 
                    y1_corr_m(i) = Ee(1)-2*Ve(1)^(1/2);   y2_corr_m(i) = Ee(2)-2*Ve(2)^(1/2);   y3_corr_m(i) = Ee(3)-2*Ve(3)^(1/2);
                    % evaluate plant
                    x_sol            = fsolve(@(x) Sim_WOprocess(0, x, u_test ,disturbance_now, Theta_P), x0, fsolve_options);
                    [~,y]            = Sim_WOprocess(0, x_sol, u_test ,disturbance_now, Theta_P);
                    [gp(i), phip(i)] = opt_uy2gphi(u_test,y,[0;0;0],[0;0;0]);
                    y1p(i) = y(1);   y2p(i) = y(2);   y3p(i) = y(3); 
                end
            end  
            for plot_Y1       = 1  
                subplot(2,5,6)
                hold off
                    % function
                    X=[d_test,fliplr(d_test)];                
                    Y=[y1_corr_p+y1,fliplr(y1_corr_m+y1)];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
                    hold on 
                    % Data
                    for ii = 1:nb_observation
                        if ii <= Last_k_uncoherent
                            scatter(SAVE_dk(ii),SAVE_y1k(ii),15,'bo','MarkerFaceColor',[1 0.6 0.6],'MarkerEdgeColor','none')
                        else
                            dist = max([1 - abs(uk{k} - SAVE_uk(ii))/0.3, 0.4]);
                            scatter(SAVE_dk(ii),SAVE_y1k(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    for ii = 1:nb_observation
                        dist = max([1 - abs(uk{k} - SAVE_uk(ii))/0.3, 0.2]);
                        if dist < 0.01 && ii > Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_y1k(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    plot(d_test,y1,'k--')
                    plot(d_test,(y1_corr+y1),'k-')
                    plot(d_test,y1p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$d [t/h]$');
                    hYLabel = ylabel('$y_{(1)}$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
                    ylim([0 4])

            end  
            for plot_Y2       = 1  
                subplot(2,5,7)
                hold off
                    % functions
                    X=[d_test,fliplr(d_test)];                
                    Y=[y2_corr_p+y2,fliplr(y2_corr_m+y2)];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
                    hold on 
                    % Data
                    for ii = 1:nb_observation
                        if ii <= Last_k_uncoherent
                            scatter(SAVE_dk(ii),SAVE_y2k(ii),15,'bo','MarkerFaceColor',[1 0.6 0.6],'MarkerEdgeColor','none')
                        else
                            dist = max([1 - abs(uk{k} - SAVE_uk(ii))/0.3, 0.4]);
                            scatter(SAVE_dk(ii),SAVE_y2k(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    for ii = 1:nb_observation
                        dist = max([1 - abs(uk{k} - SAVE_uk(ii))/0.3, 0.2]);
                        if dist < 0.01 && ii > Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_y2k(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    plot(d_test,y2,'k--')
                    plot(d_test,(y2_corr+y2),'k-')
                    plot(d_test,y2p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$d [t/h]$');
                    hYLabel = ylabel('$y_{(2)}$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
                    ylim([0 3.5])
            end  
            for plot_Y3       = 1  
                subplot(2,5,8)
                hold off
                    % functions
                    X=[d_test,fliplr(d_test)];                
                    Y=[y3_corr_p+y3,fliplr(y3_corr_m+y3)];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none'); 
                    hold on 
                    % Data
                    for ii = 1:nb_observation
                        if ii <= Last_k_uncoherent
                            scatter(SAVE_dk(ii),SAVE_y3k(ii),15,'bo','MarkerFaceColor',[1 0.6 0.6],'MarkerEdgeColor','none')
                        else
                            dist = max([1 - abs(uk{k} - SAVE_uk(ii))/0.3, 0.4]);
                            scatter(SAVE_dk(ii),SAVE_y3k(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    for ii = 1:nb_observation
                        dist = max([1 - abs(uk{k} - SAVE_uk(ii))/0.3, 0.2]);
                        if dist < 0.01 && ii > Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_y3k(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    plot(d_test,y3,'k--')
                    plot(d_test,(y3_corr+y3),'k-')
                    plot(d_test,y3p,'r--')
                    % Plot gca
                    hXLabel = xlabel('$d [t/h]$');
                    hYLabel = ylabel('$y_{(3)}$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
                    ylim([14 22])
            end
            for plot_phi      = 1  
                subplot(2,5,9)
                    hold off
                    % functions
                    X=[d_test,fliplr(d_test)];                
                    Y=[phi_corr+2*var_phi_corr.^(1/2),fliplr(phi_corr-2*var_phi_corr.^(1/2))];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none'); 
                    hold on 
                    % Data
                    for ii = 1:nb_observation
                        if ii <= Last_k_uncoherent
                            scatter(SAVE_dk(ii),SAVE_phik(ii),15,'bo','MarkerFaceColor',[1 0.6 0.6],'MarkerEdgeColor','none')
                        else
                            dist = max([1 - abs(uk{k} - SAVE_uk(ii))/0.3, 0.4]);
                            scatter(SAVE_dk(ii),SAVE_phik(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    for ii = 1:nb_observation
                        dist = max([1 - abs(uk{k} - SAVE_uk(ii))/0.3, 0.2]);
                        if dist < 0.01 && ii > Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_phik(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    plot(d_test,phi,'k--')
                    plot(d_test,phi_corr,'k-')
                    plot(d_test,phip,'r--')
                    % Plot gca
                    hXLabel = xlabel('$d [t/h]$');
                    hYLabel = ylabel('$\phi$ [\$/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
                    ylim([-1000 500])

            end
            for plot_g        = 1  
                subplot(2,5,10)
                hold off
                    % functions
                    X=[d_test,fliplr(d_test)];                
                    Y=[g_corr,fliplr(g_corr-4*var_g_corr.^(1/2))];              
                    fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none'); 
                    hold on 
                    % Data
                    for ii = 1:nb_observation
                        if ii <= Last_k_uncoherent
                            scatter(SAVE_dk(ii),SAVE_gk(ii),15,'bo','MarkerFaceColor',[1 0.6 0.6],'MarkerEdgeColor','none')
                        else
                            dist = max([1 - abs(uk{k} - SAVE_uk(ii))/0.3, 0.4]);
                            scatter(SAVE_dk(ii),SAVE_gk(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    for ii = 1:nb_observation
                        dist = max([1 - abs(uk{k} - SAVE_uk(ii))/0.3, 0.2]);
                        if dist < 0.01 && ii > Last_k_uncoherent
                            scatter(SAVE_uk(ii),SAVE_gk(ii),15,'bo','MarkerFaceColor',[1-dist 1-dist 1],'MarkerEdgeColor','none')
                        end
                    end
                    plot(d_test,g,'k--')
                    plot(d_test,(g_corr-2*var_g_corr.^(1/2)),'k-')
                    plot(d_test,gp,'r--')
                    % Plot gca
                    hXLabel = xlabel('$d [t/h]$');
                    hYLabel = ylabel('$g$ [t/h]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
                    set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                    set(gca,'Layer','Top');
                    ylim([-1.5 1])

            end
            figure(9)
            for plot_phi_3D   = 1  
    %             figure
                    % functions
                    X=[d_test,fliplr(d_test)];                
                    Y=[phi_corr+2*var_phi_corr.^(1/2),fliplr(phi_corr-2*var_phi_corr.^(1/2))];              
                    fill3(X,uk{k}*ones(size(Y)),Y,[0.8 0.8 0.8],'EdgeColor','none','facealpha',.5); 
                    hold on 
                    plot3(d_test,uk{k}*ones(size(phi)),phi,'k--')
                    plot3(d_test,uk{k}*ones(size(phi)),phi_corr,'k-')
                    plot3(d_test,uk{k}*ones(size(phi)),phip,'r--')
                    grid on
                    % Data
    %                 for ii = 1:nb_observation
    %                     plot3(SAVE_dk(ii),SAVE_uk(ii),SAVE_phik(ii),'bo','MarkerSize',5,'MarkerFaceColor','b','MarkerEdgeColor','b')
    %                 end
                    % Next point
                    plot3(dk{k}*[1 1],uk{k+1}*[1 1],[400 -800],'b')
                    xlim([-1 1])
                    ylim([10 20])
            end

            for Save_Figure_8 = 1  
                figure(8)
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=23; y_width=9;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_GP_view_k_',num2str(k)])
            end
            for Save_Figure_9 = 1  
                figure(9)
                xlim([-1 1])
                ylim([10 20])
                view([130 20]);
                hXLabel = xlabel('$d$ [t/h]');
                hYLabel = ylabel('$u$ [t/h]');
                hZLabel = zlabel('$\phi$ [\$/h]');
                set([hXLabel, hYLabel, hZLabel],'FontSize', 8*2 ,'Interpreter','LaTex');
                set(gca,'FontSize',8*2);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.3, 0.25, 0.55, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.5*2; y_width=4*2;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-r620','-djpeg',['WO_',SimName,'_GP_3D_view_k_',num2str(k)], '-opengl')
            end

            %%
            figure(10)
            for plot_decision_dates   = 1 
                if k == 1
                    hAxes = axes('NextPlot','add','DataAspectRatio',[1 1 1],'YLim',[0 eps],'Color','none');    
                end     
                for ii = 1:nb_decisions
                    if SAVE_modek(ii) == 1 && ii < nb_decisions
                        plot([SAVE_tk(ii) SAVE_tk(ii+1)],[0 0],'b','Linewidth',2);  %# plot decision time
                    end
                    if SAVE_validation_mode(ii) == 0
                        plot(SAVE_tk(ii),0,'.r','MarkerSize',15);  %# plot decision time
                    else
                        plot(SAVE_tk(ii),0,'.g','MarkerSize',15,'Color',[0.1 0.9 0.1]);  %# plot decision time
                    end
                end
                    xlim([0,inf]) % Set the minimum of t at 0h
                    hXLabel = xlabel('$t [t/h]$');
                    set([hXLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
            end
            figure(11)
            for plot_state_database   = 1 
                hold off
                nb_data(k) = 0;
                nb_observationk(k) = nb_observation;
                for ii = 1:DIII{1}.nbCluster
                    nb_data(k) = nb_data(k) + 1;
                end
                plot(1:k,nb_data,'b')
                hold on 
                plot(1:k,nb_observationk,'k')

                    hXLabel = xlabel('Iteration [-]');
                    hYLabel = ylabel('Database size [-]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
            end
            figure(12)
            for plot_computation_time = 1 
                hold off
                plot(1:k,timerVal,'k')
                    hXLabel = xlabel('Iteration [-]');
                    hYLabel = ylabel('Comput. time [s]');
                    set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                    set(gca,'FontSize',8);
            end
        end   %%%%%%%%%%%%%%%%%%%%%%%%%%%
    else
        if Option_Coherency_controler == 1
            for Do_nominal_optimisation         = Enabled   
                % Set the pertubation to its initial value          
                disturbance_nom.tspand = [0,1];     
                disturbance_nom.dspan  = dk{k}*[1,1];
                % Initial estimate of the error function
                Ee0 = [0;0;0]; Ve0 = [0;0;0];
                % Optimal operating condition:
                [us,~,exitflag,~,lambda] = ...
                    fmincon(@(u)opt_objfunp(u,disturbance_nom,Ee0,Ve0,Theta),u0,A,b,Aeq,beq,lbs,ubs,@(u)opt_constrp(u,disturbance_nom,Ee0,Ve0,Theta),fmincon_options);
                if    exitflag == 0
                    disp('Nominal Model optimization: The solver stopped before converging')
                elseif exitflag < 0
                    disp('Nominal Model optimization: The solver failed to find a solution')
                end
                % Initial operating condition
                uk{k+1} = us(1);
            end
            for Do_ideal_nominal_optimisation   = Enabled   
                disturbance_nom.tspand_alpha = [0,1];     
                disturbance_nom.dspan_alpha  = 0.8*[1,1];

                % No error
                Ee0p = [0;0;0]; Ve0p = [0;0;0];
                [us_best,~,exitflag,~,lambda_best] = ...
                    fmincon(@(u)opt_objfunp(u,disturbance_nom,Ee0p,Ve0p,Theta_P),u0,A,b,Aeq,beq,lbs,ubs,@(u)opt_constrp(u,disturbance_nom,Ee0p,Ve0p,Theta_P),fmincon_options);
                if    exitflag == 0
                    disp('Nominal Plant optimization: The solver stopped before converging')
                elseif exitflag < 0
                    disp('Nominal Plant optimization: The solver failed to find a solution')
                end
                % Best initial operating condition:
                uk_best{k+1} =us_best(1);
            end
            for Reset_Coherency_controller_copy = 1         
                % otherwise the next experiement will be imedialty rejected
                y_kp1_min_copy(1) = -Inf;   y_kp1_min_copy(2) = -Inf;   y_kp1_min_copy(3) = -Inf;
                y_kp1_max_copy(1) =  Inf;   y_kp1_max_copy(2) =  Inf;   y_kp1_max_copy(3) =  Inf;
            end
            for Reset_Coherency_controller      = 1         
                % otherwise the next experiement will be imedialty rejected
                y_kp1_min(1) = -Inf;   y_kp1_min(2) = -Inf;   y_kp1_min(3) = -Inf;
                y_kp1_max(1) =  Inf;   y_kp1_max(2) =  Inf;   y_kp1_maxy(3) =  Inf;
            end
            Last_k_uncoherent = k-1;
            stand_by_mode     = 0;
            nb_observationk(k) = nb_observation;
            
            SAVE_tk    = [SAVE_tk;   t(end)];
            validation_mode = 0; 
            SAVE_validation_mode(k) = validation_mode; 
            SAVE_modek = [SAVE_modek; stand_by_mode];
            
        else
            disp(['t = ',num2str(t(end)),' -- Uncoherency observed -- waiting for SS'])
            % reset coherency controller
            for Reset_Coherency_controller_copy    = 1         
                % otherwise the next experiement will be imedialty rejected
                y_kp1_min_copy(1) = -Inf;   y_kp1_min_copy(2) = -Inf;   y_kp1_min_copy(3) = -Inf;
                y_kp1_max_copy(1) =  Inf;   y_kp1_max_copy(2) =  Inf;   y_kp1_max_copy(3) =  Inf;
            end
            % Stop the stand-by mode
            stand_by_mode = 0;
            % Maintain the same operating point
            uk{k+1}      = uk{k}; 
            uk_best{k+1} = uk_best{k}; 
            nb_observationk(k) = nb_observation;
            
            SAVE_tk    = [SAVE_tk;   t(end)];
            validation_mode = 0; 
            SAVE_validation_mode(k) = validation_mode; 
            SAVE_modek = [SAVE_modek; stand_by_mode];
        end
        % ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        timerVal(k) = toc;  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
    
end

%%
for Save_figures = Enabled  
    t(end) = 160;
    for Figure_1 = 1  
        figure(1)
        xlim([0 t(end)])
        ylim([-620 -330])
            hXLabel = xlabel('$t$ [h]');
            hYLabel = ylabel('$\phi$ [\$/h]');
            set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
            set(gca,'FontSize',8);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45*1.5; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-dpdf',['WO_',SimName,'_phi'])
    end
    for Figure_2 = 1  
    figure(2)
    xlim([0 t(end)])
    ylim([5500 7800]/1000)
        hXLabel = xlabel('$t$ [h]');
        hYLabel = ylabel('$\overline{F_A}+d^{\prime(t)}$ [t/h]');
        set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
        set(gca,'FontSize',8);
        set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
        set(gca,'Layer','Top');
            set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45*1.5; y_width=4;  
        set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
        print('-painters','-dpdf',['WO_',SimName,'_d'])
    end
    for Figure_3 = 1  
        figure(3)
        xlim([0 t(end)])
        ylim([13000 19000]/1000)
            hXLabel = xlabel('$t$ [h]');
            hYLabel = ylabel('$u$ [t/h]');
            set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
            set(gca,'FontSize',8);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45*1.5; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-dpdf',['WO_',SimName,'_u'])
    end
    for Figure_4 = 1  
        figure(4)
        xlim([0 t(end)])
        ylim([1000 1800]/1000)
            hXLabel = xlabel('$t$ [h]');
            hYLabel = ylabel('$y_{(1)}$ [t/h]');
            set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
            set(gca,'FontSize',8);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45*1.5; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-dpdf',['WO_',SimName,'_y1'])
    end
    for Figure_5 = 1  
        figure(5)
        xlim([0 t(end)])
        ylim([2000 2700]/1000)
            hXLabel = xlabel('$t$ [h]');
            hYLabel = ylabel('$y_{(2)}$ [t/h]');
            set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
            set(gca,'FontSize',8);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45*1.5; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-dpdf',['WO_',SimName,'_y2'])
    end
    for Figure_6 = 1  
        figure(6)
        xlim([0 t(end)])
        ylim([16000 22000]/1000)
            hXLabel = xlabel('$t$ [h]');
            hYLabel = ylabel('$y_{(3)}$ [t/h]');
            set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
            set(gca,'FontSize',8);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45*1.5; y_width=4;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-dpdf',['WO_',SimName,'_y3'])
    end
    for Figure_10 = 1 
        figure(10)
        xlim([0 t(end)])
            hXLabel = xlabel('$t$ [h]');
            set([hXLabel],'FontSize', 8 ,'Interpreter','LaTex');
            set(gca,'FontSize',8);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
    %         set(gca,'Layer','Top');
    %         set(gca, 'Position', [0.25, 0.25, 0.65, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45*3; y_width=2;  
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-dpdf',['WO_',SimName,'_DecisionDates'])
%         
%             xlim([0 500])
%             hXLabel = xlabel('$t$ [h]');
%             set([hXLabel],'FontSize', 8 ,'Interpreter','LaTex');
%             set(gca,'FontSize',8);
%             set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%     %         set(gca,'Layer','Top');
%     %         set(gca, 'Position', [0.25, 0.25, 0.65, 0.65])
%             set(gcf, 'PaperUnits', 'centimeters');
%             x_width=4.45*3; y_width=2;  
%             set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%             print('-painters','-dpdf',['WO_',SimName,'_DecisionDates_0_500'])
%             
%             xlim([4000 4500])
%             hXLabel = xlabel('$t$ [h]');
%             set([hXLabel],'FontSize', 8 ,'Interpreter','LaTex');
%             set(gca,'FontSize',8);
%             set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%     %         set(gca,'Layer','Top');
%     %         set(gca, 'Position', [0.25, 0.25, 0.65, 0.65])
%             set(gcf, 'PaperUnits', 'centimeters');
%             x_width=4.45*3; y_width=2;  
%             set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%             print('-painters','-dpdf',['WO_',SimName,'_DecisionDates_4000_4500'])
    end
    for Figure_11 = 1 
        figure(11)
            xlim([0 k])
            hXLabel = xlabel('Iteration');
            hYLabel = ylabel('Database size [-]');
            set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
            set(gca,'FontSize',8);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45*1.5; y_width=4;   
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-dpdf',['WO_',SimName,'_database_size'])
    end
    for Figure_12 = 1 
        figure(12)
            xlim([0 k])
            hXLabel = xlabel('Iteration');
            hYLabel = ylabel('Comput. time [s]');
            set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
            set(gca,'FontSize',8);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45*1.5; y_width=4;   
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-dpdf',['WO_',SimName,'_computation time'])
    end
    for Figure_13 = 1 
        figure(13)
        xlim([0 t(end)])
        ylim([-3 2])
            hXLabel = xlabel('$t [h]$');
            hYLabel = ylabel('$log_{10}(|\phi^{\star}(t)-\phi(t)|)$ [\$/h]');
            set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
            set(gca,'FontSize',8);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45*1.5; y_width=4;    
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-dpdf',['WO_',SimName,'_losses'])
    end
    for Figure_14 = 1 
        figure(14)
        xlim([0 t(end)])
        ylim([0.5 0.9])
            hXLabel = xlabel('$t [h]$');
            hYLabel = ylabel('$d^{\prime\prime}(t) = \alpha(t)$ [-]');
            set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
            set(gca,'FontSize',8);
            set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
            set(gca,'Layer','Top');
            set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
            set(gcf, 'PaperUnits', 'centimeters');
            x_width=4.45*1.5; y_width=4;    
            set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
            print('-painters','-dpdf',['WO_',SimName,'_alpha'])
    end
end
%%
disp(' ')
disp('*****************************************************************')
disp(' end                                                             ')
disp('*****************************************************************')
disp(' ')