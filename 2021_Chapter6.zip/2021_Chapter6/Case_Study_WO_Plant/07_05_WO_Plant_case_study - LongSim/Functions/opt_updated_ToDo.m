function [] = opt_updated_ToDo(u,disturbance,Theta) 
    global Last_u Last_c Last_f Last_ceq 
    if ~isequal(u,Last_u) % Check if computation is necessary
        % Evaluate the model at a point u
        if isempty(disturbance) == 1
            d = 0;
        else
            d = disturbance.dspan(1);
        end 
        fsolve_options = ...
            optimset( 'Algorithm','trust-region-reflective',...levenberg-marquardt     trust-region-reflective
                      'LargeScale','on',...
                      'Diagnostics','off',...
                      'Display','off' ,...  final
                      'FunValCheck','on',...
                      'MaxFunEvals',100000,...
                      'MaxIter',100000,...
                      'TolFun',1e-12, ...
                      'TolX',1e-12, ...
                      'TolCon',1e-12);
%       Starting point
        x0 = [ 0.4; 0.4; 0.05; 0.05; 0.05; 0.05; ...
                    0.4; 0.4 ; 0.07; 0.07; 0.06; ...
                    0.4; 0.4; 0.07; 0.07; 0.06;       0.4; 0.4; 0.07; 0.07; 0.06]; 
            
        disturbance.tspand = [0 1];
        disturbance.dspan  = d*[1 1];
        [x_sol] = fsolve(@(x) Sim_WOprocess(0, x, u,disturbance,Theta), x0, fsolve_options);
        [~,y] = Sim_WOprocess(0,x_sol,u,disturbance,Theta);

        [Ee,Ve] = GP_mu([u,d]); % Ee: Expectancy of the error 
                                % Ve: Variance of the error
        [h,varphi, var_varphi, var_h] = opt_uy2gphi(u,y,Ee,Ve);
        Last_u = u; Last_f = varphi; Last_c = h-2*sqrt(var_h); Last_ceq = []; 
    end
end