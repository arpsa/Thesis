function DIII = ResetDIII(ell1,ell2,sigmaf,nx,nu,nf)
    % Initialisation of Compressed Database:
    DIII{1} = struct();
        % Plant hyperparameters 
        DIII{1}.ell1 = ell1{1};   DIII{1}.ell2 = ell2{1}; 
        DIII{2}.ell1 = ell1{2};   DIII{2}.ell2 = ell2{2}; 
        DIII{3}.ell1 = ell1{3};   DIII{3}.ell2 = ell2{3};    
        DIII{1}.L = diag([ell1{1}^(-2); ell2{1}^(-2)]);  
        DIII{2}.L = diag([ell1{2}^(-2); ell2{2}^(-2)]);  
        DIII{3}.L = diag([ell1{3}^(-2); ell2{3}^(-2)]);
        DIII{1}.sf = sigmaf{1};  DIII{2}.sf = sigmaf{2};  DIII{3}.sf = sigmaf{3}; 
        % A priori affine domain dimentions
        DIII{1}.a1 = ell1{1}/6*1/2;  DIII{1}.a2 = ell2{1}/6*1/2;    
        DIII{2}.a1 = ell1{2}/6*1/2;  DIII{2}.a2 = ell2{2}/6*1/2;    
        DIII{3}.a1 = ell1{3}/6*1/2;  DIII{3}.a2 = ell2{3}/6*1/2;
        DIII{1}.A = [DIII{1}.a1,DIII{1}.a2];
        DIII{2}.A = [DIII{2}.a1,DIII{2}.a2];
        DIII{3}.A = [DIII{3}.a1,DIII{3}.a2];
        % Initialise the clusters
        DIII{1}.nbCluster = 0;     
        DIII{1}.Cluster{1}.X_centerS     = [];
        DIII{1}.Cluster{1}.Y_centerS     = [];
        DIII{1}.Cluster{1}.Y_var_centerS = []; 
        DIII{1}.Cluster{1}.X_point       = [];
        DIII{1}.Cluster{1}.Y_point       = [];
        DIII{1}.Cluster{1}.Y_var_point   = []; 
        DIII{1}.Cluster{1}.X_both        = [];
        DIII{1}.Cluster{1}.Y_both        = [];
        DIII{1}.Cluster{1}.Y_var_both    = [];
        % Just to know:
        DIII{1}.Cluster{1}.nbpts           = 0;
        % For regression
        DIII{1}.inv_C   = [];
        DIII{1}.yp_m_y  = []; % <<<<<<<<<<
        DIII{1}.Data    = [];   
        % PB informations
        for i = 1:nf
            DIII{i}.nbCluster = 0;  
            DIII{i}.nx  = nx;
            DIII{i}.nu  = nu;
            DIII{i}.ny  = nf;
            if i > 1
                DIII{i}.Cluster{1} = DIII{1}.Cluster{1};
            end
        end 
end