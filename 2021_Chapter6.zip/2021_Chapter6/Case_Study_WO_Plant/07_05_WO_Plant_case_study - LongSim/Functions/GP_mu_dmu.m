function [Ee,Ve,Ede,Vde,Cede] = GP_mu_dmu(x_test)

    global DIII
    
    
    % Define some notations
    point = 0; derivative = 1;
    
    % Get the number of outputs (the nb of functions to update):
    nb_f = DIII{1}.ny; 
     
    % Correct each functions:
    for yi = 1:nb_f
        %% Get the plant's hyperparameters
        L  = DIII{yi}.L;      
        sf = DIII{yi}.sf;
        nx = DIII{yi}.nx;
        nu = DIII{yi}.nu;
        
        %% Take the data
        NB_Data_Tot = DIII{yi}.NB_Data_Tot; 
        inv_C       = DIII{yi}.inv_C;
        Y1Y2_Yn     = DIII{yi}.Y1Y2_Yn;
        Data        = DIII{yi}.Data;

        %% kernel functions
        k_ff_ii = @(x1,x2,vary)          sf^2*exp(-1/2*(x1-x2)*L*(x1-x2)') + vary ;  
        k_ff    = @(x1,x2)               sf^2*exp(-1/2*(x1-x2)*L*(x1-x2)');
        k_DD_ii = @(x1,x2,v1,v2,vary)    v2*( L*(eye(nx)-(x1-x2)'*(x1-x2)*L)* k_ff(x1,x2) )*v1' + vary; 
        k_Df    = @(x1,x2,v)             v*( -L*(x1-x2)'* k_ff(x1,x2) );
        k_fD    = @(x1,x2,v)             v*(  L*(x1-x2)'* k_ff(x1,x2) );
        k_DD    = @(x1,x2,v1,v2)         v2*( L*(eye(nx)-(x1-x2)'*(x1-x2)*L)* k_ff(x1,x2) )*v1';  


        %% first   c_ss:
        c_ss  = k_ff(x_test,x_test);
        for i = 1:nu 
            va         = [zeros(1,i-1), 1, zeros(1,nx-i)];
            bc_ss(1,i)  = k_fD(x_test,x_test,va);
            for j = 1:nu
                vb         = [zeros(1,j-1), 1, zeros(1,nx-j)];
                bC_ss(i,j) = k_DD(x_test,x_test,vb,va);
            end
        end 
        C_ss = [c_ss , bc_ss;
                -bc_ss' , bC_ss];

        %% second  C_s:
       
        for i = 1:(nu+1)
            for j = 1:NB_Data_Tot
                if       i == 1    &&   Data{j,1} == point
                    C_s(i,j) =   k_ff(x_test,Data{j,2});
                elseif   i == 1    &&   Data{j,1} == derivative
                    C_s(i,j) =   k_fD(x_test,Data{j,2},Data{j,5});
                elseif   i >  1    &&   Data{j,1} == point
                    v = [zeros(1,i-1-1), 1, zeros(1,nx-i+1)];
                    C_s(i,j) =   k_Df(x_test,Data{j,2},v );
                elseif   i >  1    &&   Data{j,1} == derivative
                    v = [zeros(1,i-1-1), 1, zeros(1,nx-i+1)];
                    C_s(i,j) =   k_DD(x_test,Data{j,2},v,Data{j,5});
                end
            end
        end
% 
%         for i = 1:NB_Data_Tot
%             for j = 1:(nu+1)
%                 if       Data{i,1} == point       &&   j == 1 
%                     C_s2(i,j) = k_ff(Data{i,2},x_test);
%                 elseif   Data{i,1} == derivative  &&   j == 1
%                     C_s2(i,j) = k_Df(Data{i,2},x_test,Data{i,5});
%                 elseif   Data{i,1} == point       &&   j >  1
%                     v = [zeros(1,j-1-1), 1, zeros(1,nx-j+1)];
%                     C_s2(i,j) = k_fD(Data{i,2},x_test,v);
%                 elseif   Data{i,1} == derivative  &&   j >  1
%                     v = [zeros(1,j-1-1), 1, zeros(1,nx-j+1)];
%                     C_s2(i,j) = k_DD(Data{i,2},x_test,Data{i,5},v);
%                 end
%             end
%         end
        
        
        %% Finaly the predictions:
        % Compute the a postriori distribution:
        E_all  = C_s*inv_C*Y1Y2_Yn; 
        V_all  = C_ss - C_s*inv_C*C_s';
    
        % Management of the small uncertainties close to the computer's
        % accuaracy at inverting matricies
        if min(eig(V_all)) < 0
            disp('PB -- GP_mu_dmu -- V_all<0 and shoudn''t be')
            a(1) = [1;2]; % manual break :)
        end
    
        % Format the data:
        Ve{yi}   = V_all(1,1);
        Vde{yi}  = V_all(2:end,2:end);
        Cede{yi} = V_all(2:end,1);

        Ee{yi}   = E_all(1);
        Ede{yi}  = E_all(2:end);
        
    end
    
    
end