function [nabla_x_y1, nabla_x_y2, nabla_x_y3, y_00] = model_GetDerivatives(x,Theta)
    fsolve_options = ...
        optimset( 'Algorithm','trust-region-reflective',...levenberg-marquardt     trust-region-reflective
                  'LargeScale','on',...
                  'Diagnostics','off',...
                  'Display','off' ,...  final
                  'FunValCheck','on',...
                  'MaxFunEvals',100000,...
                  'MaxIter',100000,...
                  'TolFun',1e-15, ...
                  'TolX',1e-15, ...
                  'TolCon',1e-15);
    % Starting point
    x0 = [ 0.4; 0.4; 0.05; 0.05; 0.05; 0.05; ...
                0.4; 0.4 ; 0.07; 0.07; 0.06; ...
                0.4; 0.4; 0.07; 0.07; 0.06;       0.4; 0.4; 0.07; 0.07; 0.06];
     
    % Finite difference step sizes:
    du = 0.00001; dd = 0.00001;         
     
    u = x(1);
    disturbance.tspand = [0,1];      
    disturbance.dspan  = x(2)*[1,1]; 
        xx_sol = fsolve(@(xx) Sim_WOprocess(0, xx, u,disturbance, Theta), x0, fsolve_options);
        [~,y_00] = Sim_WOprocess(0, xx_sol, u,disturbance, Theta);
         
        
    u = x(1)+du;
    disturbance.tspand = [0,1];          
    disturbance.dspan  = x(2)*[1,1];  
        xx_sol = fsolve(@(xx) Sim_WOprocess(0, xx, u,disturbance, Theta), x0, fsolve_options);
        [~,y_p0] = Sim_WOprocess(0, xx_sol, u,disturbance, Theta);
    
    u = x(1);
    disturbance.tspand = [0,1];          
    disturbance.dspan  = (x(2)+dd)*[1,1];  
        xx_sol = fsolve(@(xx) Sim_WOprocess(0, xx, u,disturbance, Theta), x0, fsolve_options);
        [~,y_0p] = Sim_WOprocess(0, xx_sol, u,disturbance, Theta);
         
    u = x(1)-du;
    disturbance.tspand = [0,1];          
    disturbance.dspan  = x(2)*[1,1];  
        xx_sol = fsolve(@(xx) Sim_WOprocess(0, xx, u,disturbance, Theta), x0, fsolve_options);
        [~,y_m0] = Sim_WOprocess(0, xx_sol, u,disturbance, Theta);     
    
    u = x(1);
    disturbance.tspand = [0,1];          
    disturbance.dspan  = (x(2)-dd)*[1,1];  
        xx_sol = fsolve(@(xx) Sim_WOprocess(0, xx, u,disturbance, Theta), x0, fsolve_options);
        [~,y_0m] = Sim_WOprocess(0, xx_sol, u,disturbance, Theta);
    
    nabla_x_y1  = [ (y_p0(1) - y_m0(1))/(2*du);
                    (y_0p(1) - y_0m(1))/(2*dd)];
                
    nabla_x_y2  = [ (y_p0(2) - y_m0(2))/(2*du);
                    (y_0p(2) - y_0m(2))/(2*dd)];
                
    nabla_x_y3  = [ (y_p0(3) - y_m0(3))/(2*du);
                    (y_0p(3) - y_0m(3))/(2*dd)];
end