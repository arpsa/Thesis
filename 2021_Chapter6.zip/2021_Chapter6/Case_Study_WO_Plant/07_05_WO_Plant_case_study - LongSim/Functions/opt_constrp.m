function [c,ceq] = opt_constrp(u, d,Ee0,Ve0,Theta)
    global  Last_c Last_ceq 
    opt_ToDop(u, d,Ee0,Ve0,Theta)
    c   = Last_c;
    ceq = Last_ceq;
end