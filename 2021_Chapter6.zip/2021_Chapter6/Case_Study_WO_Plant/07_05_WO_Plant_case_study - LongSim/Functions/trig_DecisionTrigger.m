function [out,isterm,dir] = trig_DecisionTrigger(t,x,u,disturbance,Theta,tspan,d_current,stand_by_mode, y_kp1_min,y_kp1_max,Option_Coherency_controler)
    
    [dx, y] = Sim_WOprocess(t, x, u, disturbance, Theta);
    
    % Trigger a decision making if SS detected
    if tspan(1) + 8 < t && stand_by_mode == 0
        out(1) = max([norm(dx) - 5e-5, tspan(1)+0.15-t]) ;
    else
        out(1) = 1;
    end
    % Trigger a decision making if a significant variation of FA is detected 
    d_realtime = interp1(disturbance.tspand,disturbance.dspan,t,'previous');
    if abs(d_current - d_realtime) > 0.0001
        out(2) = -1;
    else
        out(2) =  1;
    end
    % Trigger a decision making if we are in stand by mode and if the
    % observations do not follow our expectations
    if Option_Coherency_controler == 1 
        % react immediatly
        if stand_by_mode == 1
            if y_kp1_min(1) > y(1) || y(1) > y_kp1_max(1) || ... % test y1
               y_kp1_min(2) > y(2) || y(2) > y_kp1_max(2) || ... % test y2
               y_kp1_min(3) > y(3) || y(3) > y_kp1_max(3)        % test y3
                out(3) = -1; 
            else
                out(3) =  1;
            end
        else
            out(3) = 1;
        end
    else
        % wait fo SS to get some data 
        if norm(dx) - 5e-5 < 0 && stand_by_mode == 1
            if y_kp1_min(1) > y(1) || y(1) > y_kp1_max(1) || ... % test y1
               y_kp1_min(2) > y(2) || y(2) > y_kp1_max(2) || ... % test y2
               y_kp1_min(3) > y(3) || y(3) > y_kp1_max(3)        % test y3
                out(3) = -1; 
            else
                out(3) =  1;
            end
        else
            out(3) = 1;
        end
    end
    
    
    
    
    isterm(1) = 1; % 1: terminate sim when ith event occurs, 0: otherwise
    dir(1)    = 0;    % or -1, doesn't matter
    
    isterm(2) = 1; % 1: terminate sim when ith event occurs, 0: otherwise
    dir(2)    = 0;    % or -1, doesn't matter
    
    isterm(3) = 1; % 1: terminate sim when ith event occurs, 0: otherwise
    dir(3)    = 0;    % or -1, doesn't matter
end