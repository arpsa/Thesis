function DIII_new = comp_updateDIII(DIII,DII)

    ny = DIII{1}.ny;
    nx = DIII{1}.nx;
    
    % Take the new point
    X        = DII.X_mean;
    Y(1)     = DII.Y1_error_mean;
    Y_var(1) = DII.Y1_var;
    Y(2)     = DII.Y2_error_mean;
    Y_var(2) = DII.Y2_var;
    Y(3)     = DII.Y3_error_mean;
    Y_var(3) = DII.Y3_var;
    
       
    DIII_new  = DIII; % Copy the structure
    for yi = 1:ny
        % If it belongs to an existing cluster, then update this cluster:
        NewPointIsInACulster = 0;
        nbCluster = DIII{yi}.nbCluster;
        A = DIII{yi}.A;
        if nbCluster >= 1
            for i = 1:nbCluster
                if all(abs(X - DIII{yi}.Cluster{i}.X_center) <= A) && all(NewPointIsInACulster == 0)
                    % Rise flag
                    NewPointIsInACulster = 1;
                    DIII{yi}.new = 0;
                    %%
                    % They already exists
                    X_center     = DIII{yi}.Cluster{i}.X_center;
                    Y_center     = DIII{yi}.Cluster{i}.Y_center;
                    Y_var_center = DIII{yi}.Cluster{i}.Y_var_center; 
                    % Add the new point
                    DIII{yi}.Cluster{i}.X_point       = X;
                    DIII{yi}.Cluster{i}.Y_point       = Y(yi);
                    DIII{yi}.Cluster{i}.Y_var_point   = Y_var(yi); 
                    % Combine them
                    DIII{yi}.Cluster{i}.X_both        = [X        ; X_center    ];
                    DIII{yi}.Cluster{i}.Y_both        = [Y(yi)    ; Y_center    ];
                    DIII{yi}.Cluster{i}.Y_var_both    = [Y_var(yi); Y_var_center];
                    %% Update Mesh
                    DIII_new{yi} = GP_UpdateCluster(DIII{yi},i);
                end
            end
        end


        % If it does belongs to an existing cluster, then creat a new on:
        if NewPointIsInACulster == 0
            DIII{yi}.nbCluster = DIII{yi}.nbCluster +1;
            % Just an information not really used:
            DIII{yi}.Cluster{DIII{yi}.nbCluster}.nbpts           = 0;
            % Create" the cluster
            DIII{yi}.Cluster{DIII{yi}.nbCluster}.X_center     = X;
            DIII{yi}.Cluster{DIII{yi}.nbCluster}.Y_center     = [];
            DIII{yi}.Cluster{DIII{yi}.nbCluster}.Y_var_center = []; 
                DIII{yi}.Cluster{DIII{yi}.nbCluster}.X_point       = X;
                DIII{yi}.Cluster{DIII{yi}.nbCluster}.Y_point       = Y(yi);
                DIII{yi}.Cluster{DIII{yi}.nbCluster}.Y_var_point   = Y_var(yi); 
                    DIII{yi}.Cluster{DIII{yi}.nbCluster}.X_both        = [X        ;  X];
                    DIII{yi}.Cluster{DIII{yi}.nbCluster}.Y_both        = [Y(yi)    ; []];
                    DIII{yi}.Cluster{DIII{yi}.nbCluster}.Y_var_both    = [Y_var(yi); []];
            % Update cluster (in this case it is rather: "Create" the cluster)
            DIII_new{yi} = GP_UpdateCluster(DIII{yi},DIII{yi}.nbCluster);
        end
    end

end