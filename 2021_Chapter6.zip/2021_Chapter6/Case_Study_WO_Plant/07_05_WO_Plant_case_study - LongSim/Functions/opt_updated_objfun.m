function y = opt_updated_objfun(u,disturbance,Theta)
    global Last_f
    opt_updated_ToDo(u,disturbance,Theta)
    y = Last_f;
end