function [c,ceq] = opt_updated_constr(u,disturbance,Theta)
    global  Last_c Last_ceq 
    opt_updated_ToDo(u,disturbance,Theta)
    c   = Last_c;
    ceq = Last_ceq;
end