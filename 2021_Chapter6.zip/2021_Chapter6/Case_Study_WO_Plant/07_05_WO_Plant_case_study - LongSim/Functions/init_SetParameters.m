function ThetaUncertain = init_SetParameters(test)
% test == 1 => good parameters
%      ~= 1 =>  mismatch

ThetaUncertain = struct();

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% WO reactor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 5 reactions
%
% A +  B -> C      (1)
% C +  B -> P + E  (2)
% P +  C -> G      (3)
% A + 2B -> P + E  (4)
% A +  B + P -> G  (5)
%
if strcmp(test,'Plant') == 1
%     Plant
ThetaUncertain.A1 = 5.9755*1e9;   % [1/h]
ThetaUncertain.B1 = 6666.6666667; % [�K]
ThetaUncertain.A2 = 2.5962*1e12;  % [1/h]
ThetaUncertain.B2 = 8333.3333333; % [�K]
ThetaUncertain.A3 = 9.6283*1e15;  % [1/h]
ThetaUncertain.B3 = 11111.111111; % [�K]

ThetaUncertain.A4 = 0;  % [1/h]
ThetaUncertain.B4 = 1; % [�K]
ThetaUncertain.A5 = 0;  % [1/h]
ThetaUncertain.B5 = 1; % [�K]

else
    
% Model

ThetaUncertain.A1 = 0;   % [1/h]
ThetaUncertain.B1 = 1; % [�K]
ThetaUncertain.A2 = 0;  % [1/h]
ThetaUncertain.B2 = 1; % [�K]
ThetaUncertain.A3 = 0;  % [1/h]
ThetaUncertain.B3 = 1; % [�K]

ThetaUncertain.A4 = 2.189231810604804e+008*3600;  % [1/h] 
ThetaUncertain.B4 = 8077.6; % [�K]
ThetaUncertain.A5 = 4.309773370943014e+013*3600;  % [1/h]
ThetaUncertain.B5 = 12438; % [�K]

end


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Distillation column
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(test,'Plant') == 1
    % Plant
    ThetaUncertain.eff = 0.10;
else
   % Model
    ThetaUncertain.eff = 0.105;
end

if strcmp(test,'Plant') == 1
    ThetaUncertain.IsPlant = 1;
else
    ThetaUncertain.IsPlant = 0;
end


end