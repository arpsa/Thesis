function y = opt_objfunp(u,d,Ee0,Ve0,Theta)
    global Last_f
    opt_ToDop(u,d,Ee0,Ve0,Theta)
    y = Last_f;
end