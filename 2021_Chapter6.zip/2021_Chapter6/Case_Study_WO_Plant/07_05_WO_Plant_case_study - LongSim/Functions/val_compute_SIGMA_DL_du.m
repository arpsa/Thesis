function [M,TEST_signe_phi,I_E__M__I_E,M2] = val_compute_SIGMA_DL_du(DIII,xk,lambda,Theta,Delta_phi_Delta_u_accepted)

    % Step 1: Get the expectancies of the values and gradients of the
    % plant's functions (at the point that is believed to be te plant
    % optimum):
    [Ee,Ve,Ede,Vde,Cede] = GP_mu_dmu(xk);
    
    % Cost function
    partial_y_phi           = [0.01; -0.3; -0.0068]*1000/0.45; 
    partial_u_partial_y_phi = [0   ; 0   ;  0     ]       ;
    partial_y_partial_y_phi = 0;
    lambda0                 = 1; 
    l_01 = 0;  lp_01 = partial_y_phi(1);
    l_02 = 0;  lp_02 = partial_y_phi(2);
    l_03 = 0;  lp_03 = partial_y_phi(3);
    
    % Constrain 
    lambda1               = lambda.ineqnonlin; 
   
     M1 = Vde{1}*(lp_01^2) + Vde{2}*(lp_02^2) + Vde{3}*(lp_03^2); 
     if lambda1 ~= 0
         I_E = 0;
     else 
         I_E = 1;
     end
     I_E__M__I_E = (I_E)*M1*(I_E);
     
     % Variance of the loss due to uncertainty on the constraint
     M2 = lambda1^2*Vde{2} *20; 
     
     M = I_E__M__I_E + M2; 
     
     
    % check direction: 
    % 1.- get updated-model's gradient 
    [nabla_u_phi, var_varphi_00] = model_GetDerivatives_updated(xk,Theta);
    abs_nabla_u_phi_max          = abs(nabla_u_phi) + 2*sqrt(M1); % estimate of the maximal value nabla_u phi can have
    if lambda1 ~= 0   && abs_nabla_u_phi_max > 3*Delta_phi_Delta_u_accepted
        TEST_signe_phi = abs(nabla_u_phi) - 2*sqrt(3.14/2)*sqrt(var_varphi_00); % if < 0 then the cost can change signe 
    else 
        TEST_signe_phi = 1; 
    end
end