function [out,isterm,dir] = trig_DecisionTrigger_Waitingtime(t,x,u,disturbance,Theta,tspan,d_current , y_kp1_min,y_kp1_max, Option_Coherency_controler)


    [dx, y] = Sim_WOprocess(t, x, u, disturbance, Theta);
    
    temp_var = 1;
    % If a disturbance occurs during the waiting time : don't collect data
    % and just make a decision
    d_realtime = interp1(disturbance.tspand,disturbance.dspan,t,'previous');
    if abs(d_current - d_realtime) > 5
        out(1) = -1;
        temp_var = 0;
    else
        out(1) =  1;
    end
    
    % Trigger a decision making if the
    % observations do not follow our expectations
%     if norm(dx) - 5e-5 < 0 
        if y_kp1_min(1) > y(1) || y(1) > y_kp1_max(1) || ... % test y1
           y_kp1_min(2) > y(2) || y(2) > y_kp1_max(2) || ... % test y2
           y_kp1_min(3) > y(3) || y(3) > y_kp1_max(3) || ... % test y3
           temp_var*norm(dx) -  1e-3 > 0
       
%            if Option_Coherency_controler == 1
                out(2) = -1;         % React immediatly 
%            else
%                if t-tspan(1) >= 0.05 % wait to collect some data 
%                    out(2) = -1;
%                else
%                    out(2) = 1;
%                end
%            end
            
        else
            out(2) =  1;
        end
%     else
%         out(2) = 1;
%     end
    
    
    isterm(1) = 1; % 1: terminate sim when ith event occurs, 0: otherwise
    dir(1)    = 0;    % or -1, doesn't matter
    
    isterm(2) = 1; % 1: terminate sim when ith event occurs, 0: otherwise
    dir(2)   = 0;    % or -1, doesn't matter
end