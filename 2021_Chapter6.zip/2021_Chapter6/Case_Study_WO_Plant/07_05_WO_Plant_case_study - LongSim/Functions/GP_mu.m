function [Ee,Ve] = GP_mu(x_test)

    global DIII

    % Define some notations
    point = 0; derivative = 1;
    
    % Get the number of outputs (the nb of functions to update):
    nb_f = DIII{1}.ny; 
    
    Ee = zeros(nb_f,1); 
    Ve = zeros(nb_f,1); 
    % Correct each functions:
    for yi = 1:nb_f
        %% Get the plant's hyperparameters
        L  = DIII{yi}.L;      
        sf = DIII{yi}.sf;
        nx = DIII{yi}.nx;
        
        %% Take the data
        NB_Data_Tot = DIII{yi}.NB_Data_Tot; 
        inv_C       = DIII{yi}.inv_C;
        Y1Y2_Yn     = DIII{yi}.Y1Y2_Yn;
        Data        = DIII{yi}.Data;

        %% kernel functions
        k_ff_ii = @(x1,x2,vary)          sf^2*exp(-1/2*(x1-x2)*L*(x1-x2)') + vary;  
        k_ff    = @(x1,x2)               sf^2*exp(-1/2*(x1-x2)*L*(x1-x2)');
        k_DD_ii = @(x1,x2,v1,v2,vary)    v2*( L*(eye(nx)-(x1-x2)'*(x1-x2)*L)* k_ff(x1,x2) )*v1' + vary; 
        k_Df    = @(x1,x2,v)             v*( -L*(x1-x2)'* k_ff(x1,x2) );
        k_fD    = @(x1,x2,v)             v*(  L*(x1-x2)'* k_ff(x1,x2) );
        k_DD    = @(x1,x2,v1,v2)         v2*( L*(eye(nx)-(x1-x2)'*(x1-x2)*L)* k_ff(x1,x2) )*v1';  


        %% first   c_ss:
        c_ss  = k_ff(x_test,x_test);

        %% second  C_s:
        for i = 1:NB_Data_Tot
            for j = 1:1
                if       j == 1    &&   Data{i,1} == point
                    C_s(i,j) =   k_ff(x_test,Data{i,2});

                elseif   j == 1    &&   Data{i,1} == derivative 
                    C_s(i,j) =   k_fD(x_test,Data{i,2},Data{i,5});
                end
            end       
        end

        %% Finaly the predictions:
        Ee(yi) = C_s'*inv_C*Y1Y2_Yn; 
        Ve(yi) = c_ss - C_s'*inv_C*C_s;
        
        if min(eig(Ve(yi))) < 0
            c_ss
             C_s'*inv_C*C_s
            C_s
            inv_C
            Ve(yi)
            disp('PB -- GP_mu -- Ve(yi)<0 and shoudn''t be')
            Ee(yi)
            a(1) = [1;2] % manual break :)
        end
    end
end