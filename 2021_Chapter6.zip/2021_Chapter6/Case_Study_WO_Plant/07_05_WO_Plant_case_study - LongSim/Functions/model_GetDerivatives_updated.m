function [nabla_u_phi, var_varphi_00] = model_GetDerivatives_updated(x,Theta)
    fsolve_options = ...
        optimset( 'Algorithm','trust-region-reflective',...levenberg-marquardt     trust-region-reflective
                  'LargeScale','on',...
                  'Diagnostics','off',...
                  'Display','off' ,...  final
                  'FunValCheck','on',...
                  'MaxFunEvals',100000,...
                  'MaxIter',100000,...
                  'TolFun',1e-15, ...
                  'TolX',1e-15, ...
                  'TolCon',1e-15);
    % Starting point
    x0 = [ 0.4; 0.4; 0.05; 0.05; 0.05; 0.05; ...
                0.4; 0.4 ; 0.07; 0.07; 0.06; ...
                0.4; 0.4; 0.07; 0.07; 0.06;       0.4; 0.4; 0.07; 0.07; 0.06];
     
    % Finite difference step sizes:
    du = 0.1;        

    u = x(1)+du;
    disturbance.tspand = [0,1];          
    disturbance.dspan  = x(2)*[1,1];  
        xx_sol = fsolve(@(xx) Sim_WOprocess(0, xx, u,disturbance, Theta), x0, fsolve_options);
        [~,y_p0] = Sim_WOprocess(0, xx_sol, u,disturbance, Theta);
        x_test = [x(1)+du;x(2)]';
        [Ee,Ve] = GP_mu(x_test);
        [~, varphi_p0] = opt_uy2gphi(u,y_p0,Ee,Ve);
      
    u = x(1)-du;
    disturbance.tspand = [0,1];          
    disturbance.dspan  = x(2)*[1,1];  
        xx_sol = fsolve(@(xx) Sim_WOprocess(0, xx, u,disturbance, Theta), x0, fsolve_options);
        [~,y_m0] = Sim_WOprocess(0, xx_sol, u,disturbance, Theta); 
        x_test = [x(1)-du;x(2)]';
        [Ee,Ve] = GP_mu(x_test);
        [~, varphi_m0] = opt_uy2gphi(u,y_m0,Ee,Ve);    

    nabla_u_phi  = (varphi_p0 - varphi_m0)/(2*du);
    
    
    u = x(1);
    disturbance.tspand = [0,1];          
    disturbance.dspan  = x(2)*[1,1];  
        xx_sol = fsolve(@(xx) Sim_WOprocess(0, xx, u,disturbance, Theta), x0, fsolve_options);
        [~,y_00] = Sim_WOprocess(0, xx_sol, u,disturbance, Theta); 
        x_test = [x(1);x(2)]';
        [Ee,Ve] = GP_mu(x_test);
        [~, ~, var_varphi_00, ~] = opt_uy2gphi(u,y_00,Ee,Ve);   
        
end