function DIII_new = GP_LinReg(DIII,id_cluster,Theta,yi)

    DIII_new = DIII;
    %% Get the Hyperparameters 
    L  = DIII.L;    
    sf = DIII.sf;
    nx = DIII.nx;
    
    %% Take the centers
    X_centerS     = DIII.Cluster{id_cluster}.X_centerS;
    Y_centerS     = DIII.Cluster{id_cluster}.Y_centerS;
    Y_var_centerS = DIII.Cluster{id_cluster}.Y_var_centerS; 
    
    %% Define some notations
    point = 0; derivative = 1;
    
    %% Put the data in a "coherent structure"
    NBdata = size(Y_centerS,1);
    for i = 1:NBdata
        Data{i,1} = point; 
        Data{i,2} = X_centerS(i,:); 
        Data{i,3} = Y_var_centerS(i); 
        Data{i,4} = Y_centerS(i); 
    end
    
    %% kernel functions
    k_ff_ii = @(x1,x2,vary)           sf^2*exp(-1/2*(x1-x2)*L*(x1-x2)')+ vary;                
    k_ff    = @(x1,x2)                sf^2*exp(-1/2*(x1-x2)*L*(x1-x2)');
    k_DD_ii = @(x1,x2,v1,v2,vary)     v2*( L*(eye(nx)-(x1-x2)'*(x1-x2)*L)* k_ff(x1,x2) )*v1'+ vary; 
    k_Df    = @(x1,x2,v)              v*( -L*(x1-x2)'* k_ff(x1,x2) );
    k_fD    = @(x1,x2,v)              v*( L*(x1-x2)'* k_ff(x1,x2) );
    k_DD    = @(x1,x2,v1,v2)          v2*( L*(eye(nx)-(x1-x2)'*(x1-x2)*L)* k_ff(x1,x2) )*v1'; 
    
    %% Build design vector & kernel matrix:#
    
    C    = zeros(NBdata,NBdata); 
    Y1Y2_Yn = zeros(NBdata,1); 
    
    for i = 1:NBdata
        % design vector:
        Y1Y2_Yn(i,1) = Data{i,4};
        % kernel matrix
        for j = 1:NBdata
            if i == j
                if  Data{i,1} == point &&  Data{j,1} == point 
                    C(i,j) = k_ff_ii(Data{i,2}, Data{j,2},                       Data{i,3});
                elseif Data{i,1} == derivative &&  Data{i,1} == derivative
                    C(i,j) = k_DD_ii(Data{i,2}, Data{j,2}, Data{i,5}, Data{j,5}, Data{i,3});
                end
            else
                if  Data{i,1} == point &&  Data{j,1} == point 
                    C(i,j) = k_ff(Data{i,2},Data{j,2});
                    
                elseif Data{i,1} == point &&  Data{j,1} == derivative 
                    C(i,j) = k_fD(Data{i,2},Data{j,2},Data{j,5});
                    
                elseif Data{i,1} == derivative &&  Data{j,1} == point 
                    C(i,j) = k_Df(Data{i,2},Data{j,2},Data{i,5});
                    
                elseif Data{i,1} == derivative &&  Data{j,1} == derivative
                    C(i,j) = k_DD(Data{i,2},Data{j,2},Data{i,5},Data{j,5});
                end
            end
        end
    end    
    C_m1 = pinv(C);
    
    
    %% Predict value  at x_mean
    x_mean = X_centerS(1,:);
    % Build C*
    c_ss  = k_ff(x_mean,x_mean);

         
    for i = 1:1
        for j = 1:NBdata
            if       i == 1    &&   Data{j,1} == point
                C_s(i,j) =   k_ff(x_mean,Data{j,2});
            elseif   i >  1    &&   Data{j,1} == point
                v = [zeros(1,i-1-1), 1, zeros(1,nx-i+1)];
                C_s(i,j) =   k_Df(x_mean,Data{j,2},v);
            end
        end
    end
         
    %% A posteriri distribution
    Eresult = C_s*C_m1*Y1Y2_Yn; 
    Vresult = c_ss - C_s*C_m1*C_s';
    
    if eig(Vresult)< 0
       disp('PB -- GP_LinReg -- Vresult<0') 
       a(1) = [1;2]; % manual break :)
    end

    DIII_new.Cluster{id_cluster}.x               = x_mean;
    DIII_new.Cluster{id_cluster}.y               = Eresult(1);
    DIII_new.Cluster{id_cluster}.y_var           = Vresult(1,1);

    %% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

end