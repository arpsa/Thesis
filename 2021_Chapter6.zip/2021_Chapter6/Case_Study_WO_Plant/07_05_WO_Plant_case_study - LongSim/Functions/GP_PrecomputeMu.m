function [] = GP_PrecomputeMu()

    global DIII

    %% Define some notations
    point = 0; derivative = 1;
    
    %%     
    for yi = 1:DIII{1}.ny
        %% Hyperparameters 
        L  = DIII{yi}.L;      %[ell1 0; 0 ell2];
        sf = DIII{yi}.sf;
        nx = DIII{yi}.nx;
        
        %% kernel functions
        k_ff_ii = @(x1,x2,vary)          sf^2*exp(-1/2*(x1-x2)*L*(x1-x2)') + vary; 
        k_ff    = @(x1,x2)               sf^2*exp(-1/2*(x1-x2)*L*(x1-x2)');
        k_DD_ii = @(x1,x2,v1,v2,vary)    v2*( L*(eye(nx)-(x1-x2)'*(x1-x2)*L)* k_ff(x1,x2) )*v1'+ vary;
        k_Df    = @(x1,x2,v)             v*( -L*(x1-x2)'* k_ff(x1,x2) );
        k_fD    = @(x1,x2,v)             v*(  L*(x1-x2)'* k_ff(x1,x2) );
        k_DD    = @(x1,x2,v1,v2)         v2*( L*(eye(nx)-(x1-x2)'*(x1-x2)*L)* k_ff(x1,x2) )*v1';



        %% Extract usefull data from the clusters
        for id = 1:DIII{yi}.nbCluster
            % 1.-Take the data we want to use
            X_center     = DIII{yi}.Cluster{id}.X_center;
            Y_center     = DIII{yi}.Cluster{id}.Y_center;
            Y_var_center = DIII{yi}.Cluster{id}.Y_var_center; 
            
            Data{id,1} = point; 
            Data{id,2} = X_center; 
            Data{id,3} = Y_var_center; 
            Data{id,4} = Y_center;
        end
        
        NB_Data_Tot = DIII{yi}.nbCluster; 
        
        for i =1:NB_Data_Tot
            % design vector:
            Y1Y2_Yn(i,1) = Data{i,4};
            % kernel matrix
            for j = i:NB_Data_Tot
                if i == j
                    if  Data{i,1} == point &&  Data{j,1} == point 
                        C(i,j) = k_ff_ii(Data{i,2}, Data{j,2},                       Data{i,3});
                    elseif Data{i,1} == derivative &&  Data{i,1} == derivative
                        C(i,j) = k_DD_ii(Data{i,2}, Data{j,2}, Data{i,5}, Data{j,5}, Data{i,3});
                    end
                else
                    if  Data{i,1} == point &&  Data{j,1} == point 
                        C(i,j) = k_ff(Data{i,2},Data{j,2});

                    elseif Data{i,1} == point &&  Data{j,1} == derivative 
                        C(i,j) = k_fD(Data{i,2},Data{j,2},Data{j,5});

                    elseif Data{i,1} == derivative &&  Data{j,1} == point 
                        C(i,j) = k_Df(Data{i,2},Data{j,2},Data{i,5});

                    elseif Data{i,1} == derivative &&  Data{j,1} == derivative
                        C(i,j) = k_DD(Data{i,2},Data{j,2},Data{i,5},Data{j,5});
                    end
                end
                C(j,i) = C(i,j);
            end
        end
        inv_C = pinv(C);
        
        DIII{yi}.inv_C       = inv_C;
        DIII{yi}.Y1Y2_Yn     = Y1Y2_Yn;
        DIII{yi}.Data        = Data;
        DIII{yi}.NB_Data_Tot = NB_Data_Tot;

    end
end