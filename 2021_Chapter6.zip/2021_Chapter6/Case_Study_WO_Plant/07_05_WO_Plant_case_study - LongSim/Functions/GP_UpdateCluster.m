function DIII_new = GP_UpdateCluster(DIII,id_cluster)
% DIII       -- The database
% id_cluster -- Index of the cluster to update

    %% Get the Hyperparameters 
    L  = DIII.L;    
    sf = DIII.sf;
    nx = DIII.nx;
    
    %% add the info that a new point were used
    DIII.Cluster{id_cluster}.nbpts = DIII.Cluster{id_cluster}.nbpts+1;
    DIII_new = DIII;
    
    %% Take the data
    X_both     = DIII.Cluster{id_cluster}.X_both;
    Y_both     = DIII.Cluster{id_cluster}.Y_both;
    Y_var_both = DIII.Cluster{id_cluster}.Y_var_both; 
    
    X_center = X_both(2,:);
        
    %% Define some notations
    point = 0; derivative = 1;
    
    %% Put the data in a "coherent structure"
    NBdata = size(Y_var_both,1); % merged point + new point  ---- > leads to an updated merged point
    for i = 1:NBdata
        Data{i,1} = point; 
        Data{i,2} = X_both(i,:); 
        Data{i,3} = Y_var_both(i); 
        Data{i,4} = Y_both(i); 
    end
    %% kernel functions
    k_ff_ii = @(x1,x2,vary)           sf^2*exp(-1/2*(x1-x2)*L*(x1-x2)')+ vary;                  
    k_ff    = @(x1,x2)                sf^2*exp(-1/2*(x1-x2)*L*(x1-x2)');
    k_DD_ii = @(x1,x2,v1,v2,vary)     v2*( L*(eye(nx)-(x1-x2)'*(x1-x2)*L)* k_ff(x1,x2) )*v1'+ vary; 
    k_Df    = @(x1,x2,v)              v*( -L*(x1-x2)'* k_ff(x1,x2) );
    k_fD    = @(x1,x2,v)              v*( L*(x1-x2)'* k_ff(x1,x2) );
    k_DD    = @(x1,x2,v1,v2)          v2*( L*(eye(nx)-(x1-x2)'*(x1-x2)*L)* k_ff(x1,x2) )*v1'; 
    
    %% Build design vector & kernel matrix:
    % Initialise them
    C    = zeros(NBdata,NBdata); 
    Y1Y2_Yn = zeros(NBdata,1); 
    % Compute them
    for i = 1:NBdata
        % design vector:
        Y1Y2_Yn(i,1) = Data{i,4};
        % kernel matrix
        for j = 1:NBdata
            if i == j
                if  Data{i,1} == point &&  Data{j,1} == point 
                    C(i,j) = k_ff_ii(Data{i,2}, Data{j,2},                       Data{i,3});
                elseif Data{i,1} == derivative &&  Data{i,1} == derivative
                    C(i,j) = k_DD_ii(Data{i,2}, Data{j,2}, Data{i,5}, Data{j,5}, Data{i,3});
                end
            else
                if  Data{i,1} == point &&  Data{j,1} == point 
                    C(i,j) = k_ff(Data{i,2},Data{j,2});
                    
                elseif Data{i,1} == point &&  Data{j,1} == derivative 
                    C(i,j) = k_fD(Data{i,2},Data{j,2},Data{j,5});
                    
                elseif Data{i,1} == derivative &&  Data{j,1} == point 
                    C(i,j) = k_Df(Data{i,2},Data{j,2},Data{i,5});
                    
                elseif Data{i,1} == derivative &&  Data{j,1} == derivative
                    C(i,j) = k_DD(Data{i,2},Data{j,2},Data{i,5},Data{j,5});
                end
            end
        end
    end    
    C_m1 = pinv(C);
    
    
    %% Predict values at x_mean
    for i = 1:1
        for j = 1:1
            c_ss(i,j)  = k_ff(X_center(i,:),X_center(j,:));
        end
    end
    
    for i = 1:1
        for j = 1:NBdata
            C_s(i,j) =   k_ff(Data{j,2},X_center(i,:));
        end
    end
    
    Eresult = C_s*C_m1*Y1Y2_Yn; 
    Vresult = c_ss - C_s*C_m1*C_s';
    
    %% Return updated grid
    Y_center_updated     = Eresult; 
    Y_var_center_updated = Vresult;
    
    if Vresult<0
       disp('PB -- GP_UpdateMesh -- Vresult<0 and shouldn''t be') 
       a(1) = [1;2]
    end
    
    DIII_new.Cluster{id_cluster}.Y_center     = Y_center_updated;
    DIII_new.Cluster{id_cluster}.Y_var_center = Y_var_center_updated; 
end