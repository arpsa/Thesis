function [h, varphi, var_varphi, var_h] = opt_uy2gphi(u,y,Ee,Ve)
    F_A = y(4);   F_B = u; 
    F_G = y(1)+Ee(1);   F_P = y(2)+Ee(2);   F_D = y(3)+Ee(3);

    h =   F_P - 2.370 + 2*sqrt(Ve(2)); 
    varphi = (F_A*0.02 + F_B*0.03 + F_G*0.01 - F_P*0.3 - 0.0068*F_D)*1000/0.45;

    var_varphi = (0.01^2*Ve(1) + 0.3^2*Ve(2) + 0.0068^2*Ve(3))*(1000/0.45)^2;
    var_h      = Ve(2);
end