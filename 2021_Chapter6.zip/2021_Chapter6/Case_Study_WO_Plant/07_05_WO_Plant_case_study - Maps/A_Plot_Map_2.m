clc
close all    
clear all

disp(' ')
disp('=================================================================')
disp(' Aris PAPASAVVAS                                                 ')
disp('=================================================================')
tic
%%

global Last_u Last_c Last_f Last_ceq 

SimName = 'Map';

addpath('Functions')
addpath('Model')

for Construct_Plant_and_Model  = 1  
    Theta_P = init_SetParameters('Plant');
    Theta   = init_SetParameters('Model');
end
for Set_Solver_Options         = 1  
    % Solver's parameters
    fsolve_options = ...
        optimset( 'Algorithm','trust-region-reflective',...levenberg-marquardt     trust-region-reflective
                  'LargeScale','on',...
                  'Diagnostics','off',...
                  'Display','off' ,...  final
                  'FunValCheck','on',...
                  'MaxFunEvals',100000,...
                  'MaxIter',100000,...
                  'TolFun',1e-9, ...
                  'TolX',1e-9, ...
                  'TolCon',1e-9);
    % Starting point
    x0 = [ 0.4; 0.4; 0.05; 0.05; 0.05; 0.05; ...
                0.4; 0.4 ; 0.07; 0.07; 0.06; ...
                0.4; 0.4; 0.07; 0.07; 0.06;       0.4; 0.4; 0.07; 0.07; 0.06];
            
            fmincon_options = ...
    optimoptions(@fmincon,'Algorithm','sqp' , ... interior-point sqp active-set  !!! Don't use sqp: it could try inputs out of the boundaries => make the model crash
                          'MaxIter',1000000,... 
                          'Display', 'off', ...   final off iter
                          'MaxFunEvals',100000,...
                          'TolFun',1e-10,... 
                          'TolCon',1e-10,...
                          'TolX',1e-10,...
                          'FinDiffType','central'); % ,... % ,...%'forward' (default), or 'central' 
%                           'ScaleProblem','obj-and-constr');
end       


u_min = 13;   u_max = 20;     nb = 50;
u = u_min(1):(u_max(1)-u_min(1))/(nb-1):u_max(1);
 
d_min = -1;   d_max = 1;     nb = 50;
d = d_min(1):(d_max(1)-d_min(1))/(nb-1):d_max(1);

u0  = 15;
ubs = 20;  A   = []; b   = [];
lbs = 10;  Aeq = []; beq = [];  
Last_u = []; Last_c = []; Last_f = []; Last_ceq = [];
            
            
for j = 1:length(d)
    for i = 1:length(u)
        if 1 == 1
            temp_phi =1e8;   temp_phip =1e8;
        end
        U(i,j) = u(i);
        D(i,j) = d(j);
        
        disturbance.tspand = [0,1];          % F_A changes every 20min (0.33h)
        disturbance.dspan  = d(j)*[1,1];  % perturbations on FA: +- 1000kg/h  
        disturbance.tspand_alpha = [0,1];          % F_A changes every 20min (0.33h)
        disturbance.dspan_alpha  = 0.5499*[1,1];  % perturbations on FA: +- 1000kg/h  
         [x_sol,~,exitflag] =  fsolve(@(x) Sim_WOprocess(0, x, u(i),disturbance,Theta_P), x0, fsolve_options);
        if exitflag <= 0
            disp('PB')
        end
        [~,yp] = Sim_WOprocess(0,x_sol,u(i),disturbance,Theta_P);
        [gp, phip] = opt_uy2gphi(u(i),yp,[0,0,0],[0,0,0]);
     
        Y1p(i,j) = yp(1); Gp(i,j)   = gp; 
        Y2p(i,j) = yp(2); PHIp(i,j) = phip; 
        Y3p(i,j) = yp(3);
        
        if i == 1
            Ee0 = [0;0;0]; Ve0 = [0;0;0];
            % Optimal operating condition:
            Last_u = []; Last_c = []; Last_f = []; Last_ceq = [];
            [usp,~,exitflag,~,lambda] = ...
                fmincon(@(u)opt_objfunp(u,disturbance,Ee0,Ve0,Theta_P),u0,A,b,Aeq,beq,lbs,ubs,@(u)opt_constrp(u,disturbance,Ee0,Ve0,Theta_P),fmincon_options);
            if    exitflag == 0
                disp('Nominal Model optimization: The solver stopped before converging')
            elseif exitflag < 0
                disp('Nominal Model optimization: The solver failed to find a solution')
            end
            opt_up(j) = usp;
            
            % Optimal operating condition:
            Last_u = []; Last_c = []; Last_f = []; Last_ceq = [];
            [us,~,exitflag,~,lambda] = ...
                fmincon(@(u)opt_objfunp(u,disturbance,Ee0,Ve0,Theta),u0,A,b,Aeq,beq,lbs,ubs,@(u)opt_constrp(u,disturbance,Ee0,Ve0,Theta),fmincon_options);
            if    exitflag == 0
                disp('Nominal Model optimization: The solver stopped before converging')
            elseif exitflag < 0
                disp('Nominal Model optimization: The solver failed to find a solution')
            end
            opt_u(j) = us;
            
        end
        
         [x_sol,~,exitflag] =  fsolve(@(x) Sim_WOprocess(0, x, u(i),disturbance,Theta), x0, fsolve_options);
        if exitflag <= 0
            disp('PB')
        end
        [~,y] = Sim_WOprocess(0,x_sol,u(i),disturbance,Theta);
        [g, phi] = opt_uy2gphi(u(i),y,[0,0,0],[0,0,0]);
        
        
        Y1(i,j) = y(1); G(i,j) = g; 
        Y2(i,j) = y(2); PHI(i,j) = phi; 
        Y3(i,j) = y(3);
        
    end
end

%%
for Figure_1     = 1  
    figure(1) 
        hold off
        T = [ 255,150,150   %// overlap  228,175,175 
              255,150,150        %// overlap
              255,150,150        %// gray
              255,150,150        %// gray
              255,150,150          %// white
              255,150,150]./255;   %// white again 
            x = [299; 200; 199; 100; 99; 0];
            map = interp1(x/255,T,linspace(0,1,255));
            colormap(map);

        contourf(U, D, G,[0 1],'edgecolor','none')
        hold on
        plot(opt_u,d,'Color',[0.1 0.8 0.1],'LineWidth',2)
        [C,h] = contour(U,D,PHI,'k');
        clabel(C,h)

                hXLabel = xlabel('$u$ [kg/h]');
                hYLabel = ylabel('$d$ [kg/h]');
                set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                set(gca,'FontSize',8);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*1.5; y_width=4;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_phi_wrt_u'])
end
for Figure_2     = 1  
    figure(2) 
        hold off
        T = [ 255,150,150   %// overlap  228,175,175 
              255,150,150        %// overlap
              255,150,150        %// gray
              255,150,150        %// gray
              255,150,150          %// white
              255,150,150]./255;   %// white again 
            x = [299; 200; 199; 100; 99; 0];
            map = interp1(x/255,T,linspace(0,1,255));
            colormap(map);

        contourf(U, D, Gp,[0 1],'edgecolor','none')
        hold on
        plot(opt_up,d,'Color',[0.1 0.8 0.1],'LineWidth',2)
        [C,h] = contour(U,D,PHIp,'k');
        clabel(C,h)

                hXLabel = xlabel('$u$ [kg/h]');
                hYLabel = ylabel('$d$ [kg/h]');
                set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                set(gca,'FontSize',8);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45*1.5; y_width=4;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_phip_wrt_u'])
end
for Figure_345   = 1  
    figure(3) 
        hold off
        [C,h] = contour(U,D,Y1p,'k');
        clabel(C,h)
                hXLabel = xlabel('$u$ [kg/h]');
                hYLabel = ylabel('$d$ [kg/h]');
                set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                set(gca,'FontSize',8);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45; y_width=4;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_y1p_wrt_u'])
    figure(4) 
        hold off
        [C,h] = contour(U,D,Y1,[1:0.2:3],'k');
        clabel(C,h)
                hXLabel = xlabel('$u$ [kg/h]');
                hYLabel = ylabel('$d$ [kg/h]');
                set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                set(gca,'FontSize',8);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45; y_width=4;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_y1_wrt_u'])
    figure(5) 
        hold off
        [C,h] = contour(U,D,Y1p-Y1,'k');
        clabel(C,h)
                hXLabel = xlabel('$u$ [kg/h]');
                hYLabel = ylabel('$d$ [kg/h]');
                set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                set(gca,'FontSize',8);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45; y_width=4;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_y1p_m_y1_wrt_u'])
end
for Figure_678   = 1  
    figure(6) 
        hold off
        [C,h] = contour(U,D,Y2p,'k');
        clabel(C,h)
                hXLabel = xlabel('$u$ [kg/h]');
                hYLabel = ylabel('$d$ [kg/h]');
                set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                set(gca,'FontSize',8);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45; y_width=4;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_y2p_wrt_u'])
    figure(7) 
        hold off
        [C,h] = contour(U,D,Y2,[2:0.2:2.6],'k');
        clabel(C,h)
                hXLabel = xlabel('$u$ [kg/h]');
                hYLabel = ylabel('$d$ [kg/h]');
                set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                set(gca,'FontSize',8);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45; y_width=4;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_y2_wrt_u'])
    figure(8) 
        hold off
        [C,h] = contour(U,D,Y2p-Y2,'k');
        clabel(C,h)
                hXLabel = xlabel('$u$ [kg/h]');
                hYLabel = ylabel('$d$ [kg/h]');
                set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                set(gca,'FontSize',8);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45; y_width=4;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_y2p_m_y2_wrt_u'])
end
for Figure_91011 = 1  
    figure(9) 
        hold off
        [C,h] = contour(U,D,Y3p,'k');
        clabel(C,h)
                hXLabel = xlabel('$u$ [kg/h]');
                hYLabel = ylabel('$d$ [kg/h]');
                set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                set(gca,'FontSize',8);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45; y_width=4;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_y3p_wrt_u'])
    figure(10) 
        hold off
        [C,h] = contour(U,D,Y3,'k');
        clabel(C,h)
                hXLabel = xlabel('$u$ [kg/h]');
                hYLabel = ylabel('$d$ [kg/h]');
                set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                set(gca,'FontSize',8);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45; y_width=4;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_y3_wrt_u'])
    figure(11) 
        hold off
        [C,h] = contour(U,D,Y3p-Y3,'k');
        clabel(C,h)
                hXLabel = xlabel('$u$ [kg/h]');
                hYLabel = ylabel('$d$ [kg/h]');
                set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
                set(gca,'FontSize',8);
                set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
                set(gca,'Layer','Top');
                set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
                set(gcf, 'PaperUnits', 'centimeters');
                x_width=4.45; y_width=4;  
                set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
                print('-painters','-dpdf',['WO_',SimName,'_y3p_m_y3_wrt_u'])
end
%%           
            
            
%%
% 
% phi_min  = 1e9;  phi_min_model  = 1e9;
% phim_min = 1e9;  phim_min_model = 1e9;
% phip_min = 1e9;  phip_min_model = 1e9;
% 
% 
% for i = 1:length(u)
%     for No_dFA    = 1 
%         % Plant
%         [x_sol,~,exitflag] = fsolve(@(x) Sim_WOprocess(0, x, u(i),[],Theta_P), x0, fsolve_options);
%         if exitflag <= 0
%             disp('PB')
%         end
%         [~,y] = Sim_WOprocess(0,x_sol,u(i),[],Theta_P);
%         Y1(i) = y(1);
%         Y2(i) = y(2);
%         Y3(i) = y(3);
%         [g(i), phi(i)] = opt_uy2gphi(u(i),y,[0,0,0],[0,0,0]);
%         if phi_min > phi(i) && g(i) <=0
%             phi_min = phi(i);
%             U_opt = u(i);
%         end
%         if g(i) > 0
%             phi(i) = NaN;
%         end
%             %% Model
%             [x_sol,~,exitflag]   = fsolve(@(x) Sim_WOprocess(0, x, u(i),[],Theta), x0, fsolve_options);
%             if exitflag <= 0
%                 disp('PB')
%             end
%             [~,y] = Sim_WOprocess(0,x_sol,u(i),[],Theta);
% 
%             Y1_model(i) = y(1);
%             Y2_model(i) = y(2);
%             Y3_model(i) = y(3);
% 
%             [g_model(i), phi_model(i)] = opt_uy2gphi(u(i),y,[0,0,0],[0,0,0]);
%             if phi_min_model > phi_model(i) && g_model(i) <=0
%                 phi_min_model = phi_model(i);
%                 U_opt_model = u(i);
%             end
%             if g_model(i) > 0
%                 phi_model(i) = NaN;
%             end
%     end  
%     for plus_dFA  = 1 
%         disturbance.tspand = [0,1];          % F_A changes every 20min (0.33h)
%         disturbance.dspan  = 0.5*[1,1];  % perturbations on FA: +- 1000kg/h  
%         
%         disturbance.tspand_alpha = [0,1];          % F_A changes every 20min (0.33h)
%         disturbance.dspan_alpha  = 0.5499*[1,1];  % perturbations on FA: +- 1000kg/h  
%         
% 
%          [x_sol,~,exitflag] =  fsolve(@(x) Sim_WOprocess(0, x, u(i),disturbance,Theta_P), x0, fsolve_options);
%         if exitflag <= 0
%             disp('PB')
%         end
%         [~,y] = Sim_WOprocess(0,x_sol,u(i),disturbance,Theta_P);
%         Y1p(i) = y(1);
%         Y2p(i) = y(2);
%         Y3p(i) = y(3);
%         [gp(i), phip(i)] = opt_uy2gphi(u(i),y,[0,0,0],[0,0,0]);
%         if phip_min > phip(i) && gp(i) <=0
%             phip_min = phip(i);
%             Up_opt = u(i);
%         end
%         if gp(i) > 0
%             phip(i) = NaN;
%         end
%             %% Model
%              [x_sol,~,exitflag] =  fsolve(@(x) Sim_WOprocess(0, x, u(i),disturbance,Theta), x0, fsolve_options);
%             if exitflag <= 0
%                 disp('PB')
%             end
%             [~,y] = Sim_WOprocess(0,x_sol,u(i),disturbance,Theta);
%             Y1p_model(i) = y(1);
%             Y2p_model(i) = y(2);
%             Y3p_model(i) = y(3);
%             [gp_model(i), phip_model(i)] = opt_uy2gphi(u(i),y,[0,0,0],[0,0,0]);
%             if phip_min_model > phip_model(i) && gp_model(i) <=0
%                 phip_min_model = phip_model(i);
%                 Up_opt_model = u(i);
%             end
%             if gp_model(i) > 0
%                 phip_model(i) = NaN;
%             end
%     end
%     for minus_dFA = 1 
%         
%         disturbance.tspand = [0,1];          % F_A changes every 20min (0.33h)
%         disturbance.dspan  = -0.5*[1,1];  % perturbations on FA: +- 1000kg/h  
%         disturbance.tspand_alpha = [0,1];          % F_A changes every 20min (0.33h)
%         disturbance.dspan_alpha  = 0.5499*[1,1];  % perturbations on FA: +- 1000kg/h  
%         
%         
%         
%          [x_sol,~,exitflag] =  fsolve(@(x) Sim_WOprocess(0, x, u(i),disturbance,Theta_P), x0, fsolve_options);
%         if exitflag <= 0
%             disp('PB')
%         end
%         [dx,y] = Sim_WOprocess(0,x_sol,u(i),disturbance,Theta_P);
%         [gm(i), phim(i)] = opt_uy2gphi(u(i),y,[0,0,0],[0,0,0]);
%         Y1m(i) = y(1);
%         Y2m(i) = y(2);
%         Y3m(i) = y(3);
%         if phim_min > phim(i) && gm(i) <=0
%             phim_min = phim(i);
%             Um_opt = u(i);
%         end
%         if gm(i) > 0
%             phim(i) = NaN;
%         end
%             % Model
%              [x_sol,~,exitflag] =  fsolve(@(x) Sim_WOprocess(0, x, u(i),disturbance,Theta), x0, fsolve_options);
%             if exitflag <= 0
%                 disp('PB')
%             end
%             [dx,y] = Sim_WOprocess(0,x_sol,u(i),disturbance,Theta);
%             [gm_model(i), phim_model(i)] = opt_uy2gphi(u(i),y,[0,0,0],[0,0,0]);
%             Y1m_model(i) = y(1);
%             Y2m_model(i) = y(2);
%             Y3m_model(i) = y(3);
%             if phim_min_model > phim_model(i) && gm_model(i) <=0
%                 phim_min_model = phim_model(i);
%                 Um_opt_model = u(i);
%             end
%             if gm_model(i) > 0
%                 phim_model(i) = NaN;
%             end
%     end
%     U(i) = u(i);
% end
% 
% %%
% figure(1)
%     hold off
%     plot(U,phi,'k')
%     hold on
%     plot(U,phip,'r')
%     plot(U,phim,'b')
%         plot(U,phi_model,'--','Color',[0 0  0], 'LineWidth',1.5)
%         plot(U,phip_model,'--','Color',[1 0 0], 'LineWidth',1.5)
%         plot(U,phim_model,'--','Color',[0 0 1], 'LineWidth',1.5)
%     plot(U_opt,phi_min,'ko:','MarkerSize',2)
%     plot(Up_opt,phip_min,'ro:','MarkerSize',2)
%     plot(Um_opt,phim_min,'bo:','MarkerSize',2)
%         plot(U_opt_model,phi_min_model,'ks','MarkerSize',2)
%         plot(Up_opt_model,phip_min_model,'rs','MarkerSize',2)
%         plot(Um_opt_model,phim_min_model,'bs','MarkerSize',2)
%     
%             hXLabel = xlabel('$u$ [kg/h]');
%             hYLabel = ylabel('$\phi$ [\$/h]');
%             set([hXLabel, hYLabel],'FontSize', 8 ,'Interpreter','LaTex');
%             set(gca,'FontSize',8);
%             set(gca,'FontName','Helvetica','TickLength',[.02 .02],'LineWidth',1);
%             set(gca,'Layer','Top');
%             set(gca, 'Position', [0.17, 0.25, 0.80, 0.65])
%             set(gcf, 'PaperUnits', 'centimeters');
%             x_width=4.45*1.5; y_width=4;  
%             set(gcf, 'PaperPosition', [0 0 x_width y_width],'papersize',[x_width y_width]);
%             print('-painters','-dpdf',['WO_',SimName,'_phi_wrt_u'])
%             
%             
% %%
% figure
% plot(U,g,'k')
% hold on
% plot(U,gp,'r')
% plot(U,gm,'b')
%     plot(U,g_model,'k:')
%     plot(U,gp_model,'r:')
%     plot(U,gm_model,'b:')
% xlabel('FB')
% ylabel('g')
% %%
% figure
% plot(U,Y1,'k')
% hold on
% plot(U,Y1p,'r')
% plot(U,Y1m,'b')
%     plot(U,Y1_model,'k:')
%     plot(U,Y1p_model,'r:')
%     plot(U,Y1m_model,'b:')
% xlabel('FB')
% ylabel('F_G')
% %%
% figure
% plot(U,Y2 ,'k')
% hold on
% plot(U,Y2p,'r')
% plot(U,Y2m,'b')
%     plot(U,Y2_model,'k:')
%     plot(U,Y2p_model,'r:')
%     plot(U,Y2m_model,'b:')
% xlabel('FB')
% ylabel('FP')
% %%
% figure
% plot(U,Y3,'k')
% hold on
% plot(U,Y3p,'r')
% plot(U,Y3m,'b')
%     plot(U,Y3_model,'k:')
%     plot(U,Y3p_model,'r:')
%     plot(U,Y3m_model,'b:')
% xlabel('FB')
% ylabel('F_D')
% 
%     
% %% 
% 
% 
%%
disp(' ')
toc
disp(' ')
disp('=================================================================')
disp('                             End                                 ')
disp('=================================================================')